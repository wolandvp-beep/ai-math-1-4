from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from pathlib import Path

from backend.compat_paths import BACKEND_COMPAT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [Path(__file__).resolve().parent / relative_dir for relative_dir in ('solvers',)] + BACKEND_COMPAT_DIRS)

__all__ = ['BACKEND_COMPAT_DIRS']
