from __future__ import annotations

import ast
import operator as op
import re
from fractions import Fraction
from typing import Optional

from backend.legacy_text_helpers import audit_task_line, finalize_legacy_lines
from backend.quantity_units import (
    _UNIT20260416_CONT_ALIASES,
    _UNIT20260416_CONT_GROUPS,
    _unit20260416_cont_format_compound_from_base,
    _unit20260416_cont_parse_quantity,
    _unit20260416_cont_total_in_unit,
)
from backend.text_utils import normalize_word_problem_text

_SHAPE_FACTS = {
    'треугольник': {'sides': 3, 'angles': 3, 'name': 'треугольник'},
    'квадрат': {'sides': 4, 'angles': 4, 'name': 'квадрат'},
    'прямоугольник': {'sides': 4, 'angles': 4, 'name': 'прямоугольник'},
    'круг': {'sides': 0, 'angles': 0, 'name': 'круг'},
}

_ORDERED_UNITS = {
    'length': ['км', 'м', 'дм', 'см', 'мм'],
    'mass': ['т', 'ц', 'кг', 'г'],
    'time': ['сут', 'ч', 'мин', 'с'],
}

_EXTRA_UNIT_ALIASES = {
    'километр': 'км', 'километра': 'км', 'километров': 'км', 'километры': 'км',
    'метр': 'м', 'метра': 'м', 'метров': 'м', 'метры': 'м',
    'дециметр': 'дм', 'дециметра': 'дм', 'дециметров': 'дм', 'дециметры': 'дм',
    'сантиметр': 'см', 'сантиметра': 'см', 'сантиметров': 'см', 'сантиметры': 'см',
    'миллиметр': 'мм', 'миллиметра': 'мм', 'миллиметров': 'мм', 'миллиметры': 'мм',
    'тонна': 'т', 'тонны': 'т', 'тонн': 'т',
    'центнер': 'ц', 'центнера': 'ц', 'центнеров': 'ц', 'центнеры': 'ц',
    'килограмм': 'кг', 'килограмма': 'кг', 'килограммов': 'кг', 'килограммы': 'кг',
    'грамм': 'г', 'грамма': 'г', 'граммов': 'г', 'граммы': 'г',
    'сутки': 'сут', 'суток': 'сут', 'сутках': 'сут',
    'час': 'ч', 'часа': 'ч', 'часов': 'ч', 'часы': 'ч', 'часах': 'ч',
    'минута': 'мин', 'минуты': 'мин', 'минут': 'мин', 'минутах': 'мин',
    'секунда': 'с', 'секунды': 'с', 'секунд': 'с', 'секундах': 'с',
    'километрах': 'км', 'метрах': 'м', 'дециметрах': 'дм', 'сантиметрах': 'см', 'миллиметрах': 'мм',
    'тоннах': 'т', 'центнерах': 'ц', 'килограммах': 'кг', 'граммах': 'г',
}

_SAFE_OPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.FloorDiv: op.floordiv,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
}


def _normalize(raw_text: str) -> str:
    return normalize_word_problem_text(raw_text)


def _finalize(lines: list[str]) -> str:
    return finalize_legacy_lines(lines)


def _make_payload(raw_text: str, lines: list[str]) -> str:
    return _finalize(['Задача.', audit_task_line(raw_text), *lines])


def _canonical_unit(raw_unit: str) -> Optional[str]:
    raw = str(raw_unit or '').lower().strip(' .,!?:;')
    return _UNIT20260416_CONT_ALIASES.get(raw) or _EXTRA_UNIT_ALIASES.get(raw)


def _unit_factor(unit: str) -> Fraction:
    group = _unit_group(unit)
    mapping = _UNIT20260416_CONT_GROUPS.get(group or '', {})
    value = mapping.get(unit)
    if value is None:
        raise KeyError(unit)
    return Fraction(str(value))


def _unit_group(unit: str) -> Optional[str]:
    for group, mapping in _UNIT20260416_CONT_GROUPS.items():
        if unit in mapping:
            return group
    return None


def _ordered_unit_word(unit: str) -> str:
    if unit == 'см':
        return 'сантиметрах'
    if unit == 'дм':
        return 'дециметрах'
    if unit == 'м':
        return 'метрах'
    if unit == 'мм':
        return 'миллиметрах'
    if unit == 'кг':
        return 'килограммах'
    if unit == 'г':
        return 'граммах'
    if unit == 'т':
        return 'тоннах'
    if unit == 'ц':
        return 'центнерах'
    if unit == 'ч':
        return 'часах'
    if unit == 'мин':
        return 'минутах'
    if unit == 'с':
        return 'секундах'
    if unit == 'сут':
        return 'сутках'
    return unit


def _parse_compound_quantity_text(text: str) -> Optional[dict[str, object]]:
    tokens: list[tuple[int, str]] = []
    group: Optional[str] = None
    for value_text, raw_unit in re.findall(r'(\d+(?:[.,]\d+)?)\s*([а-яёa-z]+)', text.lower()):
        canonical = _canonical_unit(raw_unit)
        if not canonical:
            continue
        current_group = _unit_group(canonical)
        if not current_group:
            continue
        if group is None:
            group = current_group
        elif group != current_group:
            return None
        value = int(float(value_text.replace(',', '.')))
        tokens.append((value, canonical))
    if not tokens or group is None:
        return None
    pretty = ' '.join(f'{value} {unit}' for value, unit in tokens)
    total_in_base = sum(Fraction(value) * _unit_factor(unit) for value, unit in tokens)
    return {
        'group': group,
        'tokens': tokens,
        'pretty': pretty,
        'total_in_base': total_in_base,
    }


def _safe_eval_expr(text: str) -> Optional[float]:
    cleaned = (
        str(text or '')
        .replace('×', '*')
        .replace('·', '*')
        .replace(':', '/')
        .replace('÷', '/')
        .replace(',', '.')
    )
    cleaned = re.sub(r'[^0-9+\-*/(). ]+', '', cleaned)
    cleaned = cleaned.strip()
    if not cleaned:
        return None

    def _eval(node):
        if isinstance(node, ast.Expression):
            return _eval(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _SAFE_OPS:
            left = _eval(node.left)
            right = _eval(node.right)
            if isinstance(node.op, (ast.Div, ast.FloorDiv)) and right == 0:
                raise ZeroDivisionError
            return _SAFE_OPS[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in _SAFE_OPS:
            return _SAFE_OPS[type(node.op)](_eval(node.operand))
        raise ValueError('unsupported expression')

    try:
        tree = ast.parse(cleaned, mode='eval')
        return float(_eval(tree))
    except Exception:
        return None


def _format_number(value: float | int) -> str:
    if abs(value - round(value)) < 1e-9:
        return str(int(round(value)))
    text = f'{value:.10f}'.rstrip('0').rstrip('.')
    return text.replace('.', ',')


def _render_compound_in_target(total_in_target: int, target_unit: str) -> str:
    group = _unit_group(target_unit)
    if not group:
        return f'{total_in_target} {target_unit}'
    return _unit20260416_cont_format_compound_from_base(total_in_target, group, target_unit, [target_unit])


def _build_number_compare(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(r'какой\s+знак\s+поставить\s+между\s+(\d+)\s+и\s+(\d+)', lower)
    if not match:
        match = re.search(r'сравни\s+числа\s+(\d+)\s+и\s+(\d+)', lower)
    if not match:
        match = re.search(r'(?:какое|что)\s+число\s+больше\s*:?\s*(\d+)\s+или\s+(\d+)', lower)
    if not match:
        match = re.search(r'(?:какое|что)\s+число\s+меньше\s*:?\s*(\d+)\s+или\s+(\d+)', lower)
    if not match:
        return None
    first = int(match.group(1))
    second = int(match.group(2))
    sign = '>' if first > second else '<' if first < second else '='
    lines = [
        'Решение.',
        f'Сравниваем числа {first} и {second}.',
        f'1) Между ними нужно поставить знак «{sign}».',
        f'Ответ: {first} {sign} {second}',
        'Совет: при сравнении сначала смотри, у какого числа больше старший разряд, а потом следующий.',
    ]
    if first == second:
        lines[2] = f'1) Эти числа равны, значит ставим знак «{sign}».'
    return _make_payload(raw_text, lines)

def _build_number_relative(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(r'(?:какое|найди)\s+число\s+больше\s+(\d+)\s+на\s+(\d+)', lower)
    if match:
        base = int(match.group(1))
        delta = int(match.group(2))
        answer = base + delta
        return _make_payload(raw_text, [
            'Решение.',
            f'Если число больше {base} на {delta}, то к {base} нужно прибавить {delta}.',
            f'1) {base} + {delta} = {answer}.',
            f'Ответ: {answer}',
            'Совет: слова «на ... больше» подсказывают действие сложения.',
        ])
    match = re.search(r'(?:какое|найди)\s+число\s+меньше\s+(\d+)\s+на\s+(\d+)', lower)
    if not match:
        return None
    base = int(match.group(1))
    delta = int(match.group(2))
    answer = base - delta
    return _make_payload(raw_text, [
        'Решение.',
        f'Если число меньше {base} на {delta}, то от {base} нужно вычесть {delta}.',
        f'1) {base} - {delta} = {answer}.',
        f'Ответ: {answer}',
        'Совет: слова «на ... меньше» подсказывают действие вычитания.',
    ])


def _build_prev_next_number(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(r'(?:какое|назови)\s+число,?\s+(?:которое\s+)?(?:следует\s+за|ид[её]т\s+после)\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        answer = number + 1
        return _make_payload(raw_text, [
            'Решение.',
            f'Следующее число после {number} на 1 больше.',
            f'1) {number} + 1 = {answer}.',
            f'Ответ: {answer}',
            'Совет: следующее число всегда получают прибавлением единицы.',
        ])
    match = re.search(r'(?:какое|назови)\s+число,?\s+(?:которое\s+)?(?:стоит\s+перед|ид[её]т\s+перед)\s+(\d+)', lower)
    if not match:
        return None
    number = int(match.group(1))
    answer = number - 1
    return _make_payload(raw_text, [
        'Решение.',
        f'Число перед {number} на 1 меньше.',
        f'1) {number} - 1 = {answer}.',
        f'Ответ: {answer}',
        'Совет: предыдущее число всегда получают вычитанием единицы.',
    ])

def _build_place_value(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(r'сколько\s+сотен\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        hundreds = number // 100
        return _make_payload(raw_text, [
            'Решение.',
            f'Смотрим, сколько полных сотен содержится в числе {number}.',
            f'1) {number} = {hundreds} сот. и остаток.',
            f'Ответ: {hundreds}',
            'Совет: число сотен находят, если отделяют последние два знака.',
        ])
    match = re.search(r'сколько\s+десятк(?:ов|а)\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        tens = number // 10
        return _make_payload(raw_text, [
            'Решение.',
            f'Смотрим, сколько полных десятков содержится в числе {number}.',
            f'1) {number} = {tens} дес. и остаток.',
            f'Ответ: {tens}',
            'Совет: число десятков находят, если отделяют последнюю цифру.',
        ])
    match = re.search(r'сколько\s+единиц\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        ones = number % 10
        return _make_payload(raw_text, [
            'Решение.',
            f'Единицы — это последняя цифра числа {number}.',
            f'1) Последняя цифра: {ones}.',
            f'Ответ: {ones}',
            'Совет: единицы всегда стоят на последнем месте справа.',
        ])
    match = re.search(r'сколько\s+десятков\s+и\s+единиц\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        tens = number // 10
        ones = number % 10
        return _make_payload(raw_text, [
            'Решение.',
            f'Разбираем число {number} на десятки и единицы.',
            f'1) Десятков: {tens}.',
            f'2) Единиц: {ones}.',
            f'Ответ: {tens} десятков и {ones} единиц',
            'Совет: двузначное число состоит из десятков и единиц.',
        ])
    match = re.search(r'сколько\s+тысяч,?\s+сотен,?\s+десятков\s+и\s+единиц\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        thousands = number // 1000
        hundreds = (number // 100) % 10
        tens = (number // 10) % 10
        ones = number % 10
        return _make_payload(raw_text, [
            'Решение.',
            f'Разбираем число {number} по разрядам.',
            f'1) Тысяч: {thousands}.',
            f'2) Сотен: {hundreds}.',
            f'3) Десятков: {tens}.',
            f'4) Единиц: {ones}.',
            f'Ответ: {thousands} тысяч, {hundreds} сотен, {tens} десятков и {ones} единиц',
            'Совет: в четырёхзначном числе слева стоят тысячи, потом сотни, десятки и единицы.',
        ])
    match = re.search(r'сколько\s+сотен,?\s+десятков\s+и\s+единиц\s+в\s+числе\s+(\d+)', lower)
    if match:
        number = int(match.group(1))
        hundreds = number // 100
        tens = (number // 10) % 10
        ones = number % 10
        return _make_payload(raw_text, [
            'Решение.',
            f'Разбираем число {number} по разрядам.',
            f'1) Сотен: {hundreds}.',
            f'2) Десятков: {tens}.',
            f'3) Единиц: {ones}.',
            f'Ответ: {hundreds} сотен, {tens} десятков и {ones} единиц',
            'Совет: в трёхзначном числе слева стоят сотни, потом десятки, потом единицы.',
        ])
    match = re.search(r'запиши\s+число,?\s+в\s+котором\s+(\d+)\s+тысяч[аи]?\s+(\d+)\s+сотен\s+(\d+)\s+десятк[ао]в?\s+(\d+)\s+единиц', lower)
    if match:
        thousands = int(match.group(1))
        hundreds = int(match.group(2))
        tens = int(match.group(3))
        ones = int(match.group(4))
        number = thousands * 1000 + hundreds * 100 + tens * 10 + ones
        return _make_payload(raw_text, [
            'Решение.',
            f'Собираем число из разрядов: {thousands} тысяч, {hundreds} сотен, {tens} десятков и {ones} единиц.',
            f'1) {thousands} тысяч = {thousands * 1000}.',
            f'2) {hundreds} сотен = {hundreds * 100}.',
            f'3) {tens} десятков = {tens * 10}.',
            f'4) {thousands * 1000} + {hundreds * 100} + {tens * 10} + {ones} = {number}.',
            f'Ответ: {number}',
            'Совет: чтобы составить число по разрядам, складывают тысячи, сотни, десятки и единицы.',
        ])
    match = re.search(r'запиши\s+число,?\s+в\s+котором\s+(\d+)\s+сотен\s+(\d+)\s+десятк[ао]в?\s+(\d+)\s+единиц', lower)
    if match:
        hundreds = int(match.group(1))
        tens = int(match.group(2))
        ones = int(match.group(3))
        number = hundreds * 100 + tens * 10 + ones
        return _make_payload(raw_text, [
            'Решение.',
            f'Собираем число из разрядов: {hundreds} сотен, {tens} десятков и {ones} единиц.',
            f'1) {hundreds} сотен = {hundreds * 100}.',
            f'2) {tens} десятков = {tens * 10}.',
            f'3) {hundreds * 100} + {tens * 10} + {ones} = {number}.',
            f'Ответ: {number}',
            'Совет: чтобы составить число по разрядам, складывают сотни, десятки и единицы.',
        ])
    return None

def _parse_target_unit(text: str) -> Optional[str]:
    words = re.findall(r'[а-яёa-z]+', text.lower())
    for word in words:
        canonical = _canonical_unit(word)
        if canonical:
            return canonical
    return None


def _build_unit_conversion(raw_text: str) -> Optional[str]:
    text = _normalize(raw_text)
    lower = text.lower()

    match = re.search(r'сколько\s+(?:всего\s+)?([а-яёa-z]+)\s+в\s+(.+)', lower)
    if match:
        target_unit = _parse_target_unit(match.group(1))
        quantity_text = match.group(2)
    else:
        match = re.search(r'сколько\s+([а-яёa-z]+)\s+составляют\s+(.+)', lower)
        if match:
            target_unit = _parse_target_unit(match.group(1))
            quantity_text = match.group(2)
        else:
            match = re.search(r'(?:переведи|вырази)\s+(.+?)\s+в\s+([а-яёa-z]+)', lower)
            if not match:
                return None
            quantity_text = match.group(1)
            target_unit = _parse_target_unit(match.group(2))
    if not target_unit:
        return None

    quantity = _parse_compound_quantity_text(quantity_text)
    if not quantity:
        quantity = _unit20260416_cont_parse_quantity(quantity_text)
        if not quantity or _unit_group(target_unit) != quantity.get('group'):
            return None
        answer = _unit20260416_cont_total_in_unit(quantity, target_unit)
        answer_text = _render_compound_in_target(answer, target_unit)
        return _make_payload(raw_text, [
            'Решение.',
            f'Переводим {quantity["pretty"]} в {_ordered_unit_word(target_unit)}.',
            f'1) {quantity["pretty"]} = {answer} {target_unit}.',
            f'Ответ: {answer_text}',
            'Совет: для перевода величины все части нужно выразить в одной и той же единице.',
        ])

    if quantity['group'] != _unit_group(target_unit):
        return None

    total_in_target = quantity['total_in_base'] / _unit_factor(target_unit)
    if isinstance(total_in_target, Fraction) and total_in_target.denominator == 1:
        answer_value: float | int = int(total_in_target)
    else:
        answer_value = float(total_in_target)
    answer_text = (
        _render_compound_in_target(int(answer_value), target_unit)
        if float(answer_value).is_integer()
        else f'{_format_number(answer_value)} {target_unit}'
    )
    return _make_payload(raw_text, [
        'Решение.',
        f'Переводим {quantity["pretty"]} в {_ordered_unit_word(target_unit)}.',
        f'1) {quantity["pretty"]} = {_format_number(answer_value)} {target_unit}.',
        f'Ответ: {answer_text}',
        'Совет: для перевода величины все части нужно выразить в одной и той же единице.',
    ])

def _extract_shape(lower: str) -> Optional[str]:
    for shape in _SHAPE_FACTS:
        if shape in lower:
            return shape
    return None


def _build_geometry_facts(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    shape = _extract_shape(lower)
    if shape and 'сколько углов' in lower:
        count = _SHAPE_FACTS[shape]['angles']
        return _make_payload(raw_text, [
            'Решение.',
            f'У фигуры «{shape}» {count} углов.',
            f'Ответ: {count}',
            'Совет: у многоугольника количество сторон и углов одинаковое.',
        ])
    if shape and 'сколько сторон' in lower:
        count = _SHAPE_FACTS[shape]['sides']
        return _make_payload(raw_text, [
            'Решение.',
            f'У фигуры «{shape}» {count} сторон.',
            f'Ответ: {count}',
            'Совет: у многоугольника количество сторон и углов одинаковое.',
        ])
    if 'как называется фигура' in lower or 'назови фигуру' in lower or 'какая это фигура' in lower:
        if '3 стороны' in lower and '3 угла' in lower:
            answer = 'треугольник'
        elif '4 равные стороны' in lower and ('4 прямых угла' in lower or '4 угла' in lower):
            answer = 'квадрат'
        elif '4 стороны' in lower and '4 угла' in lower and 'равные' not in lower:
            answer = 'прямоугольник'
        elif ('нет углов' in lower or '0 углов' in lower) and ('нет сторон' in lower or '0 сторон' in lower):
            answer = 'круг'
        else:
            return None
        return _make_payload(raw_text, [
            'Решение.',
            f'По описанию это {answer}.',
            f'Ответ: {answer}',
            'Совет: фигуру удобно узнавать по числу сторон, углов и особым признакам.',
        ])
    return None

def _parse_sequence(lower: str) -> list[int]:
    return [int(item) for item in re.findall(r'-?\d+', lower)]


def _next_sequence_values(values: list[int], count: int) -> Optional[list[int]]:
    if len(values) < 3:
        return None
    diffs = [b - a for a, b in zip(values, values[1:])]
    if len(set(diffs)) == 1:
        step = diffs[0]
        last = values[-1]
        result = []
        for _ in range(count):
            last += step
            result.append(last)
        return result
    if all(value != 0 for value in values[:-1]):
        ratios = [Fraction(values[index + 1], values[index]) for index in range(len(values) - 1)]
        if len(set(ratios)) == 1:
            ratio = ratios[0]
            current = Fraction(values[-1], 1)
            result: list[int] = []
            for _ in range(count):
                current *= ratio
                if current.denominator != 1:
                    return None
                result.append(int(current))
            return result
    second = [b - a for a, b in zip(diffs, diffs[1:])]
    if len(second) >= 1 and len(set(second)) == 1:
        diff = diffs[-1]
        delta = second[0]
        last = values[-1]
        result = []
        for _ in range(count):
            diff += delta
            last += diff
            result.append(last)
        return result
    return None


def _build_pattern_task(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower().replace('…', '...')
    if 'ряд' not in lower and 'закономерност' not in lower:
        return None
    values = _parse_sequence(lower)
    if len(values) < 3:
        return None
    need_count = 1 if 'следующее число' in lower else 3
    next_values = _next_sequence_values(values, need_count)
    if not next_values:
        return None
    diffs = [b - a for a, b in zip(values, values[1:])]
    if len(set(diffs)) == 1:
        rule = f'каждый раз прибавляем {diffs[0]}' if diffs[0] >= 0 else f'каждый раз вычитаем {abs(diffs[0])}'
    else:
        if all(value != 0 for value in values[:-1]):
            ratios = [Fraction(values[index + 1], values[index]) for index in range(len(values) - 1)]
            if len(set(ratios)) == 1:
                ratio = ratios[0]
                rule = f'каждое число умножаем на {_format_number(float(ratio)) if ratio.denominator != 1 else ratio.numerator}'
            else:
                second = [b - a for a, b in zip(diffs, diffs[1:])]
                rule = f'разность каждый раз увеличивается на {second[0]}' if len(second) >= 1 and len(set(second)) == 1 else 'числа меняются по правилу'
        else:
            second = [b - a for a, b in zip(diffs, diffs[1:])]
            rule = f'разность каждый раз увеличивается на {second[0]}' if len(second) >= 1 and len(set(second)) == 1 else 'числа меняются по правилу'
    answer_text = ', '.join(str(x) for x in next_values)
    return _make_payload(raw_text, [
        'Решение.',
        f'Смотрим на ряд: {", ".join(str(x) for x in values)}.',
        f'1) Замечаем правило: {rule}.',
        f'2) Продолжаем ряд: {answer_text}.',
        f'Ответ: {answer_text}',
        'Совет: чтобы найти закономерность, сравни соседние числа и смотри, на сколько они меняются.',
    ])


def _build_true_false_task(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(r'(?:верно|правда)\s+ли(?:\s+утверждение)?\s*,?\s*что\s+(.+)', lower)
    if not match:
        return None
    statement = match.group(1).rstrip('?.!')
    if '>' in statement:
        left_text, right_text = statement.split('>', 1)
        left_value = _safe_eval_expr(left_text)
        right_value = _safe_eval_expr(right_text)
        if left_value is None or right_value is None:
            return None
        truth = left_value > right_value
    elif '<' in statement:
        left_text, right_text = statement.split('<', 1)
        left_value = _safe_eval_expr(left_text)
        right_value = _safe_eval_expr(right_text)
        if left_value is None or right_value is None:
            return None
        truth = left_value < right_value
    elif '=' in statement:
        left_text, right_text = statement.split('=', 1)
        left_value = _safe_eval_expr(left_text)
        right_value = _safe_eval_expr(right_text)
        if left_value is None or right_value is None:
            return None
        truth = abs(left_value - right_value) < 1e-9
    else:
        return None
    verdict = 'верно' if truth else 'неверно'
    return _make_payload(raw_text, [
        'Решение.',
        f'Проверяем утверждение: {statement}.',
        f'1) Получаем, что это {verdict}.',
        f'Ответ: {verdict}',
        'Совет: чтобы проверить утверждение, сначала вычисли обе части или сравни числа.',
    ])

def _parse_named_entries(text: str) -> tuple[dict[str, int], list[int]]:
    entries: dict[str, int] = {}
    numbers: list[int] = []
    for name, value in re.findall(r'у\s+([а-яёa-z0-9 -]+?)\s+(\d+)', text, flags=re.IGNORECASE):
        normalized = ' '.join(name.lower().split())
        entries[normalized] = int(value)
        numbers.append(int(value))
    for name, value in re.findall(r'([а-яёa-z0-9 -]+?)\s*[—:-]\s*(\d+)', text, flags=re.IGNORECASE):
        normalized = ' '.join(name.lower().split())
        entries.setdefault(normalized, int(value))
        numbers.append(int(value))
    return entries, numbers


def _normalize_name_key(name: str) -> str:
    return re.sub(r'[^а-яёa-z0-9-]', '', str(name or '').lower())


def _resolve_named_entry(entries: dict[str, int], raw_name: str | None) -> Optional[str]:
    key = _normalize_name_key(raw_name or '')
    if not key:
        return None
    if key in entries:
        return key
    for candidate in entries:
        if len(key) >= 2 and (candidate.startswith(key[:2]) or key.startswith(candidate[:2])):
            return candidate
    for candidate in entries:
        if len(key) >= 1 and candidate[:1] == key[:1]:
            return candidate
    return None


def _build_table_task(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    if 'таблиц' not in lower:
        return None
    entries, numbers = _parse_named_entries(lower)
    if len(numbers) < 2:
        return None
    if 'сколько всего' in lower:
        total = sum(numbers)
        expr = ' + '.join(str(number) for number in numbers)
        return _make_payload(raw_text, [
            'Решение.',
            f'По таблице берём все значения: {expr}.',
            f'1) Складываем: {expr} = {total}.',
            f'Ответ: {total}',
            'Совет: если нужно узнать, сколько всего, складывают все данные из таблицы.',
        ])
    if 'на сколько' in lower and ('больше' in lower or 'меньше' in lower):
        target_match = re.search(r'на\s+сколько\s+у\s+([а-яёa-z-]+)\s+(?:больше|меньше)(?:,?\s*чем\s+у\s+([а-яёa-z-]+))?', lower)
        if target_match and len(entries) >= 2:
            target_key = _resolve_named_entry(entries, target_match.group(1))
            other_key = _resolve_named_entry(entries, target_match.group(2)) if target_match.group(2) else None
            if target_key and other_key and target_key != other_key:
                target_value = entries[target_key]
                other_value = entries[other_key]
            elif target_key:
                other_values = [value for name, value in entries.items() if name != target_key]
                if not other_values:
                    return None
                target_value = entries[target_key]
                other_value = other_values[0]
            else:
                target_value, other_value = numbers[0], numbers[1]
        else:
            target_value, other_value = numbers[0], numbers[1]
        difference = abs(target_value - other_value)
        return _make_payload(raw_text, [
            'Решение.',
            f'Сравниваем два значения: {target_value} и {other_value}.',
            f'1) Находим разность: {max(target_value, other_value)} - {min(target_value, other_value)} = {difference}.',
            f'Ответ: {difference}',
            'Совет: вопрос «на сколько больше или меньше» решают вычитанием.',
        ])
    return None

def _build_generic_reverse_transfer(raw_text: str) -> Optional[str]:
    lower = _normalize(raw_text).lower()
    match = re.search(
        r'у\s+([а-яёa-z-]+)\s+стало\s+(\d+)\s+([а-яёa-z/-]+)\s+после\s+того,\s+как\s+(?:он|она)\s+(?:дал|дала|отдал|отдала)\s+(?:другу|подруге|товарищу)\s+(\d+)\s+([а-яёa-z/-]+)',
        lower,
    )
    if not match:
        return None
    name = match.group(1).capitalize()
    final_total = int(match.group(2))
    item_word = match.group(3)
    given = int(match.group(4))
    initial_total = final_total + given
    return _make_payload(raw_text, [
        'Решение.',
        f'После передачи {given} {item_word} у {name} осталось {final_total} {item_word}.',
        '1) Чтобы узнать, сколько было сначала, к оставшемуся количеству прибавляем отданное.',
        f'2) {final_total} + {given} = {initial_total}.',
        f'Ответ: {initial_total}',
        'Совет: в обратной задаче после передачи возвращаем отданное обратно сложением.',
    ])


def build_primary_textbook_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_number_compare(raw_text)
        or _build_number_relative(raw_text)
        or _build_prev_next_number(raw_text)
        or _build_place_value(raw_text)
        or _build_unit_conversion(raw_text)
        or _build_geometry_facts(raw_text)
        or _build_pattern_task(raw_text)
        or _build_true_false_task(raw_text)
        or _build_table_task(raw_text)
        or _build_generic_reverse_transfer(raw_text)
    )


__all__ = ['build_primary_textbook_explanation']
