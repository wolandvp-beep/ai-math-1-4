from __future__ import annotations

import re
from fractions import Fraction

from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_question_flow_helpers import _question_text
from backend.legacy_school_helpers import _format_number, _to_fraction
from backend.legacy_sequential_action_helpers import _extract_final_change_result_value, _extract_sequential_actions
from backend.text_utils import normalize_word_problem_text


_POSITIVE_VERBS = {'увеличили', 'увеличил', 'увеличила', 'прибавили', 'прибавил', 'прибавила', 'добавили', 'добавил', 'добавила'}
_NEGATIVE_VERBS = {'уменьшили', 'уменьшил', 'уменьшила', 'отняли', 'отнял', 'отняла', 'вычли', 'вычел', 'вычла', 'убавили', 'убавил', 'убавила'}


def _looks_like_reverse_number_change_question(text: str) -> bool:
    lower = normalize_word_problem_text(text).lower().replace('ё', 'е')
    triggers = (
        'какое число было сначала',
        'каким было число сначала',
        'сколько было сначала',
        'найди первоначальное число',
        'найдите первоначальное число',
    )
    return any(trigger in lower for trigger in triggers)


def _extract_number_change_actions(text: str) -> list[dict]:
    lower = normalize_word_problem_text(text).lower().replace('ё', 'е')
    actions: list[dict] = []
    pattern = re.compile(
        r'\b('
        r'увеличили|увеличил|увеличила|'
        r'уменьшили|уменьшил|уменьшила|'
        r'прибавили|прибавил|прибавила|'
        r'добавили|добавил|добавила|'
        r'отняли|отнял|отняла|'
        r'вычли|вычел|вычла|'
        r'убавили|убавил|убавила'
        r')\b[^\d]{0,12}(\d+(?:[.,]\d+)?)'
    )
    for match in pattern.finditer(lower):
        verb = match.group(1)
        value = _to_fraction(match.group(2))
        sign = 1 if verb in _POSITIVE_VERBS else -1
        actions.append({'verb': verb, 'sign': sign, 'value': value})
    return actions


def resolve_reverse_number_change_problem(raw_text: str):
    text = normalize_word_problem_text(raw_text)
    if not _looks_like_reverse_number_change_question(text):
        return None, None

    final_value = _extract_final_change_result_value(text)
    if final_value is None:
        return None, None

    actions = _extract_number_change_actions(text)
    if not actions:
        helper_actions, _ = _extract_sequential_actions(text.lower().replace('ё', 'е'))
        actions = helper_actions
    if not actions:
        return None, None

    current_value = final_value
    reverse_steps: list[tuple[str, Fraction, Fraction, Fraction]] = []
    for action in reversed(actions):
        value = action['value']
        sign = action['sign']
        before_value = current_value - sign * value
        verb = action.get('verb', '')
        reverse_steps.append((verb, value, current_value, before_value))
        current_value = before_value

    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после изменений получилось {_format_number(final_value)}.',
        _ensure_sentence(f'Что нужно найти: {(_question_text(text) or "какое число было сначала").rstrip("?.!").lower()}'),
        '1) Идём от конца к началу и отменяем каждое изменение в обратном порядке.',
    ]
    step_number = 2
    for verb, value, after_value, before_value in reverse_steps:
        normalized_verb = verb.lower().replace('ё', 'е')
        if normalized_verb in _POSITIVE_VERBS:
            action_text = f'Отменяем увеличение на {_format_number(value)}: {_format_number(after_value)} - {_format_number(value)} = {_format_number(before_value)}.'
        elif normalized_verb in _NEGATIVE_VERBS:
            action_text = f'Отменяем уменьшение на {_format_number(value)}: {_format_number(after_value)} + {_format_number(value)} = {_format_number(before_value)}.'
        else:
            delta = before_value - after_value
            if delta >= 0:
                action_text = f'Возвращаем назад изменение: {_format_number(after_value)} + {_format_number(delta)} = {_format_number(before_value)}.'
            else:
                action_text = f'Возвращаем назад изменение: {_format_number(after_value)} - {_format_number(-delta)} = {_format_number(before_value)}.'
        lines.append(f'{step_number}) {action_text}')
        step_number += 1

    lines.extend([
        f'Ответ: {_format_number(current_value)}',
        'Совет: если известно, что получилось после нескольких изменений, нужно идти в обратном порядке и отменять каждое действие.',
    ])
    return _join_lines(lines), 'reverse_number_change'


def build_reverse_number_change_payload(raw_text: str):
    explanation, handler_name = resolve_reverse_number_change_problem(raw_text)
    if not explanation:
        return None
    return {
        'result': explanation,
        'source': f'local-change:{handler_name}',
        'validated': True,
        'normalized_input': normalize_word_problem_text(raw_text),
    }


__all__ = [
    'build_reverse_number_change_payload',
    'resolve_reverse_number_change_problem',
]
