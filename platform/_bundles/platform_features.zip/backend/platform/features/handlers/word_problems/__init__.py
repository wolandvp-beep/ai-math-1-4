from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from backend.compat_paths import FEATURE_HANDLER_PACKAGE_DIRS, LEGACY_INTERNAL_IMPORT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [*FEATURE_HANDLER_PACKAGE_DIRS, *LEGACY_INTERNAL_IMPORT_DIRS])

__all__ = ['FEATURE_HANDLER_PACKAGE_DIRS', 'LEGACY_INTERNAL_IMPORT_DIRS']
