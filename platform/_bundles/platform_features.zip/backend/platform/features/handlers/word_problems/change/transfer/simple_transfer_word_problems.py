from __future__ import annotations

import re
from fractions import Fraction
from typing import Optional

from backend.legacy_dual_subject_action_helpers import (
    _extract_dual_subject_transfer_action,
    _extract_named_subject_entries_from_text,
)
from backend.legacy_math_signals import _clean_text
from backend.legacy_question_flow_helpers import _question_text, _subject_token_key
from backend.legacy_count_unit_helpers import _lookup_question_noun_forms, _select_plural_by_count
from backend.legacy_school_helpers import _format_number, _to_fraction
from backend.legacy_sequential_action_helpers import _extract_sequential_actions


def _extract_initial_known_subject(text_lower: str) -> Optional[tuple[str, Fraction, str]]:
    match = re.search(r'\bу\s+([а-яёa-z-]+)\s+(?:было\s+)?(\d+(?:[.,]\d+)?)\s+([а-яёa-z/-]+)', text_lower)
    if not match:
        return None
    name = match.group(1).lower().replace('ё', 'е')
    key = _subject_token_key(name)
    if not key:
        return None
    return name.capitalize(), _to_fraction(match.group(2)), match.group(3).strip('.,!?')


def _extract_question_subject(question_lower: str) -> Optional[str]:
    match = re.search(r'\bу\s+([а-яёa-z-]+)\b', question_lower)
    if not match:
        return None
    return match.group(1).lower().replace('ё', 'е')


def build_simple_transfer_explanation(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    initial = _extract_initial_known_subject(lower)
    if not initial:
        return None
    subject_label, initial_value, answer_label = initial
    raw_question = _question_text(text).strip()
    question = raw_question.lower().replace('ё', 'е')
    question_subject = _extract_question_subject(question)
    if not question_subject or _subject_token_key(question_subject) != _subject_token_key(subject_label.lower()):
        return None

    actions, matches = _extract_sequential_actions(lower)
    if len(actions) != 1 or len(matches) != 1:
        return None

    subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None

    transfer = _extract_dual_subject_transfer_action(lower, matches[0], subject_entries, actions[0]['value'])
    if not transfer:
        return None

    source_label = subject_entries[transfer['source_index']]['label']
    target_label = subject_entries[transfer['target_index']]['label']
    source_key = _subject_token_key(source_label.lower())
    if source_key != _subject_token_key(subject_label.lower()):
        return None

    result_value = initial_value - transfer['value']
    if result_value < 0:
        return None

    question_text = raw_question.rstrip('?.!') or f'Сколько стало у {subject_label.lower()}'
    transfer_tail = lower[matches[0].end():]
    noun_match = re.search(r'(?:\d+(?:[.,]\d+)?)\s+([а-яёa-z/-]+)', transfer_tail)
    action_noun = noun_match.group(1).strip('.,!?') if noun_match else answer_label
    noun_forms = _lookup_question_noun_forms(action_noun) or _lookup_question_noun_forms(answer_label)
    result_noun = _select_plural_by_count(int(result_value), noun_forms) if noun_forms else action_noun
    pretty_task_text = text if text.endswith(('.', '!', '?')) else text + '.'
    lines = [
        'Задача.',
        pretty_task_text,
        'Решение.',
        f'Что известно: у {subject_label} было {_format_number(initial_value)} {answer_label}, потом другому человеку передали {_format_number(transfer["value"])} {action_noun}.',
        f'Что нужно найти: {question_text}.',
        f'1) Если от этого количества отдали {_format_number(transfer["value"])} {action_noun}, то у первого стало на {_format_number(transfer["value"])} {action_noun} меньше.',
        f'2) {_format_number(initial_value)} - {_format_number(transfer["value"])} = {_format_number(result_value)}.',
        f'Ответ: {_format_number(result_value)} {result_noun}',
        'Совет: если один отдал другому, у первого количество уменьшается, а у второго увеличивается.',
    ]
    return '\n'.join(lines)


def resolve_simple_transfer_problem(raw_text: str):
    explanation = build_simple_transfer_explanation(raw_text)
    if not explanation:
        return None, None
    return explanation, 'simple_transfer'


def build_simple_transfer_payload(raw_text: str):
    explanation = build_simple_transfer_explanation(raw_text)
    if not explanation:
        return None
    return {
        'result': explanation,
        'source': 'local-change:simple_transfer',
        'validated': True,
    }


__all__ = [
    'build_simple_transfer_explanation',
    'build_simple_transfer_payload',
    'resolve_simple_transfer_problem',
]
