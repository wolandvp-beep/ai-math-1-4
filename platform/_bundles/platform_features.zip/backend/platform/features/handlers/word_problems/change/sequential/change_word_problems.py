from __future__ import annotations

from backend.legacy_groups import available_group_handlers, build_grouped_legacy_payload, resolve_grouped_legacy_problem
from backend.reverse_number_change_word_problems import build_reverse_number_change_payload, resolve_reverse_number_change_problem
from backend.simple_transfer_word_problems import build_simple_transfer_payload, resolve_simple_transfer_problem

CHANGE_HANDLER_NAMES = (
    '_try_difference_after_change_problem',
    '_try_ratio_after_change_problem',
    '_try_reverse_transfer_problem',
    '_try_reverse_transfer_relation_problem',
    '_try_reverse_transfer_total_problem',
    '_try_reverse_transfer_mixed_total_problem',
    '_try_reverse_sequential_change_problem',
    '_try_sequential_change_word_problem',
    '_try_find_initial_number_after_change',
    '_try_find_initial_number_after_two_changes',
)

CHANGE_HANDLERS = available_group_handlers(CHANGE_HANDLER_NAMES)


def resolve_change_word_problem(raw_text: str):
    direct_explanation, direct_handler_name = resolve_simple_transfer_problem(raw_text)
    if direct_explanation:
        return direct_explanation, direct_handler_name

    reverse_number_explanation, reverse_number_handler_name = resolve_reverse_number_change_problem(raw_text)
    if reverse_number_explanation:
        return reverse_number_explanation, reverse_number_handler_name

    return resolve_grouped_legacy_problem(raw_text, CHANGE_HANDLERS)


def build_change_word_problem_payload(raw_text: str):
    direct_payload = build_simple_transfer_payload(raw_text)
    if direct_payload:
        return direct_payload

    reverse_number_payload = build_reverse_number_change_payload(raw_text)
    if reverse_number_payload:
        return reverse_number_payload

    return build_grouped_legacy_payload(raw_text, CHANGE_HANDLERS, 'legacy-change')


__all__ = [
    'CHANGE_HANDLER_NAMES',
    'CHANGE_HANDLERS',
    'resolve_change_word_problem',
    'build_change_word_problem_payload',
]
