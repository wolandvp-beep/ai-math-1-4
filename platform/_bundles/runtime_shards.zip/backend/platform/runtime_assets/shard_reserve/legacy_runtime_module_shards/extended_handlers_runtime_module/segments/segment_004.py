"""Auto-generated runtime module shard for extended_handlers_runtime_module.py, lines 2517-2631."""

from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_modules.extended_handlers_runtime_module', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _geo20260416ah_try_volume_surface_extended(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = normalize_dashes(text).lower().replace('м3', 'м³').replace('см3', 'см³').replace('дм3', 'дм³')
    lower = lower.replace('м 3', 'м³').replace('см 3', 'см³').replace('дм 3', 'дм³')
    lower = re.sub(r'\s+', ' ', lower).strip()

    m = re.search(r'проволочн[а-я ]+каркаса куба с ребром (\d+) см', lower)
    if m:
        edge_cm = int(m.group(1))
        total_cm = edge_cm * 12
        meters = total_cm / 100
        meters_text = str(int(meters)) if float(meters).is_integer() else str(meters).replace('.', ',')
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: ребро куба {edge_cm} см.',
            'Что нужно найти: сколько метров проволоки нужно для каркаса куба.',
            '1) У куба 12 рёбер.',
            f'2) Находим общую длину всех рёбер: {edge_cm} × 12 = {total_cm} см.',
            f'3) Переводим в метры: {total_cm} см = {meters_text} м.',
            f'Ответ: {meters_text} м',
            'Совет: каркас куба состоит из всех его рёбер, поэтому сначала считают сумму длин 12 рёбер',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'площадь полной поверхности параллелепипеда с измерениями:? а ?= ?(\d+) см,? в ?= ?(\d+) см,? с ?= ?(\d+) см', lower)
    if m:
        a, b, c = map(int, m.groups())
        ab = a * b; ac = a * c; bc = b * c
        total = 2 * (ab + ac + bc)
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь полной поверхности прямоугольного параллелепипеда находят по формуле S = 2 × (ab + ac + bc).',
            f'2) Находим площади трёх разных граней: {a} × {b} = {ab} см², {a} × {c} = {ac} см², {b} × {c} = {bc} см².',
            f'3) Складываем и умножаем на 2: 2 × ({ab} + {ac} + {bc}) = {total} см².',
            f'Ответ: {total} см²',
            'Совет: у прямоугольного параллелепипеда по две одинаковые грани каждого вида',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'найдите объем параллелепипеда с измерениями:? а ?= ?(\d+) см,? в ?= ?(\d+) см,? с ?= ?(\d+) см', lower)
    if m:
        a, b, c = map(int, m.groups())
        volume = a * b * c
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Объём прямоугольного параллелепипеда находят по формуле V = a × b × c.',
            f'2) Подставляем числа: {a} × {b} × {c} = {volume} см³.',
            f'Ответ: {volume} см³',
            'Совет: чтобы найти объём прямоугольного параллелепипеда, перемножают его длину, ширину и высоту',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'высотой потолка (\d+) м имеет объем (\d+) м³.*какова его площадь', lower)
    if m:
        height, volume = map(int, m.groups())
        if height > 0 and volume % height == 0:
            area = volume // height
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'1) Объём прямоугольного помещения равен площади пола, умноженной на высоту.',
                f'2) Чтобы найти площадь пола, объём делим на высоту: {volume} : {height} = {area} м².',
                f'Ответ: {area} м²',
                'Совет: если известны объём и высота, площадь основания находят делением объёма на высоту',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'во сколько раз объем куба с ребром (\d+) см (?:меньше|больше) объема параллелепипеда с измерениями (\d+) см, (\d+) см, (\d+) см', lower)
    if m:
        edge, a, b, c = map(int, m.groups())
        cube_v = edge ** 3
        prism_v = a * b * c
        if cube_v == 0 or prism_v == 0:
            return None
        if 'меньше' in lower:
            if prism_v % cube_v != 0:
                return None
            ratio = prism_v // cube_v
            relation = 'меньше'
        else:
            if cube_v % prism_v != 0:
                return None
            ratio = cube_v // prism_v
            relation = 'больше'
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим объём куба: {edge} × {edge} × {edge} = {cube_v} см³.',
            f'2) Находим объём параллелепипеда: {a} × {b} × {c} = {prism_v} см³.',
            f'3) Узнаём, во сколько раз один объём {relation} другого.',
        ]
        if relation == 'меньше':
            lines.append(f'4) {prism_v} : {cube_v} = {ratio}.')
        else:
            lines.append(f'4) {cube_v} : {prism_v} = {ratio}.')
        lines += [
            f'Ответ: в {ratio} раз',
            'Совет: чтобы узнать, во сколько раз одна величина больше или меньше другой, большее число делят на меньшее',
        ]
        return _mass20260416x_finalize(lines)
    return None
