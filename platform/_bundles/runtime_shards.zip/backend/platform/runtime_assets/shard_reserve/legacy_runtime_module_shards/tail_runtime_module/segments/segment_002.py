"""Auto-generated runtime module shard for tail_runtime_module.py, lines 865-1265."""

from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_modules.tail_runtime_module', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _parse_fraction_related_subject_problem(raw_text: str) -> Optional[dict[str, Any]]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _extract_compound_quantities(text):
        return None

    fractions = _extract_text_fractions(text)
    if not fractions:
        return None

    quantity_pattern = re.compile(
        r'у\s+([а-яёa-z-]+)\s+(?:было\s*)?(\d+(?:[.,]\d+)?)\s+([а-яёa-z/-]+)',
        re.IGNORECASE,
    )
    quantity_matches = list(quantity_pattern.finditer(lower))
    if not quantity_matches:
        return None

    subject_mentions = list(re.finditer(r'\bу\s+([а-яёa-z-]+)\b', lower, re.IGNORECASE))
    distinct_subjects: list[tuple[str, str]] = []
    for mention in subject_mentions:
        name = mention.group(1)
        key = _soft_person_key(name)
        if key and all(existing_key != key for existing_key, _ in distinct_subjects):
            distinct_subjects.append((key, name))
    if len(distinct_subjects) < 2:
        return None

    for fraction_item in fractions:
        fraction_value = fraction_item['value']
        if fraction_value <= 0:
            continue

        after = lower[fraction_item['end']: fraction_item['end'] + 96]
        before = lower[max(0, fraction_item['start'] - 96): fraction_item['start']]
        if not any(marker in after for marker in ('колич', 'числ', 'от ')) and 'это' not in before:
            continue

        relation_mention = None
        for mention in subject_mentions:
            if mention.start() < fraction_item['start']:
                relation_mention = mention
            else:
                break
        if relation_mention is None:
            continue

        relation_name = relation_mention.group(1)
        relation_key = _soft_person_key(relation_name)
        if not relation_key:
            continue

        known_match = next((match for match in quantity_matches if match.start() < fraction_item['start']), None)
        if known_match is None:
            continue

        known_name = known_match.group(1)
        known_key = _soft_person_key(known_name)
        known_value = _to_fraction(known_match.group(2))
        if known_value <= 0:
            continue
        answer_label = known_match.group(3).strip('.,!?')

        base_name = ''
        base_key = ''
        for pattern in (
            r'(?:от\s+)?(?:количества|числа)\s+([а-яёa-z-]+)',
            r'от\s+([а-яёa-z-]+)',
        ):
            candidate_match = re.search(pattern, after, re.IGNORECASE)
            if candidate_match:
                candidate_name = candidate_match.group(1)
                candidate_key = _soft_person_key(candidate_name)
                if candidate_key:
                    base_name = candidate_name
                    base_key = candidate_key
                    break

        if not base_key:
            other_subjects = [name for key, name in distinct_subjects if key != relation_key]
            if len(other_subjects) == 1:
                base_name = other_subjects[0]
                base_key = _soft_person_key(base_name)

        if not base_key or base_key == relation_key:
            continue

        if known_key == relation_key:
            mode = 'reverse'
            relation_value = known_value
            base_value = relation_value / fraction_value
        elif known_key == base_key:
            mode = 'forward'
            base_value = known_value
            relation_value = base_value * fraction_value
        else:
            continue

        if base_value < 0 or relation_value < 0:
            continue

        return {
            'text': text,
            'lower': lower,
            'question': _question_text(text).lower().replace('ё', 'е'),
            'fraction': fraction_value,
            'fraction_display': _format_fraction_value(fraction_value),
            'fraction_end': fraction_item['end'],
            'mode': mode,
            'answer_label': answer_label,
            'base_name': base_name.capitalize(),
            'base_key': base_key,
            'base_value': base_value,
            'relation_name': relation_name.capitalize(),
            'relation_key': relation_key,
            'relation_value': relation_value,
        }
    return None

def _looks_like_reverse_measured_change_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    if _looks_like_any_reverse_dual_subject_measured_total_after_changes_problem(text):
        return False
    lower = text.lower().replace('ё', 'е')
    quantities = _extract_compound_quantities(text)
    if len(quantities) < 2:
        return False
    if len({quantity['group'] for quantity in quantities}) != 1:
        return False
    if quantities[0]['group'] == 'length' and '/ч' in lower:
        return False
    question = _question_text(text).lower().replace('ё', 'е')
    if not _question_asks_initial_state(question):
        return False
    if not _measure_quantity_has_final_state_marker(lower, quantities[-1]):
        return False

    previous_end = 0
    action_count = 0
    for quantity in quantities[:-1]:
        sign = _infer_measure_change_sign(lower, quantity, previous_end)
        if sign is None:
            return False
        action_count += 1
        previous_end = quantity['end']
    return action_count > 0

def _direct_dual_subject_question_mode(question_lower: str, subject_entries: list[dict[str, Any]]) -> str:
    mode = _reverse_initial_question_mode(question_lower)
    if mode != 'target':
        return mode
    question = _normalize_space(question_lower).lower().replace('ё', 'е')
    order = _question_subject_order(question, subject_entries)
    if len(order) >= 2 and ' и ' in question:
        return 'both'
    return mode

def _subject_location_phrase(entry: dict[str, Any]) -> str:
    label = _normalize_space(str(entry.get('label') or _reverse_subject_phrase(entry)))
    lowered = label.lower().replace('ё', 'е')
    if lowered.startswith(('в ', 'во ', 'из ', 'на ', 'под ', 'над ', 'у ')):
        return label
    return f'у {label}'

def _format_measure_value_text(value: Fraction, group: str, base_unit: str, visible_units: list[str]) -> str:
    return _format_measure_total(value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)

def _looks_like_dual_subject_measured_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    question = _question_text(text).lower().replace('ё', 'е')
    if not question or _question_asks_initial_state(question):
        return False
    if not any(marker in question for marker in ('сколько', 'на сколько', 'во сколько')):
        return False
    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return False
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return False
    if any(info.get('quantity') is None for info in infos[:2]):
        return False
    groups = {info['quantity']['group'] for info in infos[:2]}
    if len(groups) != 1:
        return False
    return True

_PLAIN_NUMBER_RE = re.compile(r'(?<!/)\b(\d+(?:[.,]\d+)?)\b(?!\s*/)')
_FRACTION_RE = re.compile(r'(\d+)\s*/\s*(\d+)')
_FRACTION_CHANGE_ACTION_HINTS = (
    'отдал', 'отдала', 'отдали', 'съел', 'съела', 'съели', 'раздали', 'раздал', 'раздала',
    'продали', 'продал', 'продала', 'использовали', 'использовал', 'использовала',
    'отрезали', 'отрезал', 'отрезала', 'прошли', 'прошёл', 'прошел', 'прошла',
    'проехали', 'проехал', 'проехала', 'осталось', 'остался', 'осталась',
)
_TEMPERATURE_UP_HINTS = {'теплее', 'выше'}
_TEMPERATURE_DOWN_HINTS = {'холоднее', 'ниже'}

def _allowed_ai_extra_numbers_for_text(user_text: str) -> set[Fraction]:
    lower = _clean_text(user_text).lower().replace('ё', 'е')
    allowed: set[Fraction] = set()
    if 'периметр' in lower and any(shape in lower for shape in ('прямоугольник', 'квадрат')):
        allowed.add(Fraction(2))
    if re.search(r'\b(?:ч|час(?:а|ов)?|мин(?:ут(?:а|ы|у)?)?|сек(?:унд(?:а|ы|у)?)?|км/ч|км/мин|м/ч|м/мин|м/с|см/с)\b', lower):
        allowed.add(Fraction(60))
    if (re.search(r'\bм\b', lower) and re.search(r'\bсм\b', lower)) or re.search(r'процент|%', lower):
        allowed.add(Fraction(100))
    return allowed

class _AiMathValidationError(ValueError):
    pass

def _plain_number_matches(text: str) -> list[re.Match[str]]:
    return list(_PLAIN_NUMBER_RE.finditer(text))

def _looks_like_fraction_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower()
    return bool(_FRACTION_RE.search(lower)) and any(marker in lower for marker in _FRACTION_CHANGE_ACTION_HINTS)

def _looks_like_equal_parts_problem(text: str) -> bool:
    lower = _clean_text(text).lower()
    if 'равные части' in lower and bool(re.search(r'(?:разделили|разрезали|распилили|поделили)\s+на\s*\d+', lower)):
        return True
    return bool(
        re.search(
            r'(?:на|в)\s*\d+(?:[.,]\d+)?\s+[а-яёa-z-]+[^.!?]{0,120}?(?:поровну\s+)?(?:расставили|разложили|раздали|распределили|разместили|развесили|разделили)\s*\d+(?:[.,]\d+)?\s+[а-яёa-z-]+',
            lower,
        )
    )

def _looks_like_temperature_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower()
    return 'градус' in lower and any(word in lower for word in _TEMPERATURE_UP_HINTS | _TEMPERATURE_DOWN_HINTS)

def _looks_like_volume_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    return any(unit in lower for unit in (' л', ' мл', 'литр', 'миллилитр')) and any(marker in lower for marker in _NEGATIVE_CHANGE_MARKERS + _POSITIVE_CHANGE_MARKERS)

def _parse_fraction_like(value: Any) -> Optional[Fraction]:
    text = _normalize_space(str(value))
    if not text:
        return None
    if re.fullmatch(r'-?\d+\s+\d+/\d+', text):
        sign = -1 if text.startswith('-') else 1
        body = text[1:] if sign < 0 else text
        whole_part, fraction_part = body.split()
        numerator, denominator = fraction_part.split('/')
        return sign * (Fraction(int(whole_part), 1) + Fraction(int(numerator), int(denominator)))
    if re.fullmatch(r'-?\d+/\d+', text):
        numerator, denominator = text.split('/')
        return Fraction(int(numerator), int(denominator))
    if re.fullmatch(r'-?\d+(?:[.,]\d+)?', text):
        return Fraction(text.replace(',', '.'))
    return None

def _eval_fraction_ast(node: ast.AST) -> Fraction:
    if isinstance(node, ast.Expression):
        return _eval_fraction_ast(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return Fraction(str(node.value))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -_eval_fraction_ast(node.operand)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.UAdd):
        return _eval_fraction_ast(node.operand)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return _eval_fraction_ast(node.left) + _eval_fraction_ast(node.right)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Sub):
        return _eval_fraction_ast(node.left) - _eval_fraction_ast(node.right)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        return _eval_fraction_ast(node.left) * _eval_fraction_ast(node.right)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        denominator = _eval_fraction_ast(node.right)
        if denominator == 0:
            raise _AiMathValidationError('division by zero')
        return _eval_fraction_ast(node.left) / denominator
    raise _AiMathValidationError('unsupported expression')

def _safe_eval_fraction_expression(expression: str) -> Optional[Fraction]:
    cleaned = _normalize_ai_equation(expression)
    if not cleaned or not re.fullmatch(r'[0-9+\-*/().]+', cleaned):
        return None
    try:
        tree = ast.parse(cleaned, mode='eval')
        return _eval_fraction_ast(tree)
    except Exception:
        return None

def _equation_uses_only_prompt_numbers(expression: str, user_text: str) -> bool:
    equation_numbers = {_parse_fraction_like(token) for token in re.findall(r'\d+(?:\.\d+)?', _normalize_ai_equation(expression))}
    input_numbers = {_parse_fraction_like(token) for token in re.findall(r'\d+(?:[.,]\d+)?', _clean_text(user_text))}
    equation_numbers.discard(None)
    input_numbers.discard(None)
    return equation_numbers.issubset(input_numbers | _allowed_ai_extra_numbers_for_text(user_text))

def _validate_diagram_spec(spec: Any) -> Optional[dict[str, Any]]:
    if spec in (None, '', []):
        return None
    if not isinstance(spec, dict):
        return None
    diagram_type = str(spec.get('type') or '').strip()
    labels = spec.get('labels') if isinstance(spec.get('labels'), dict) else {}
    normalized_labels = {str(key): str(value) for key, value in labels.items() if str(key).strip() and str(value).strip()}
    highlight = str(spec.get('highlight') or '').strip() or None
    if not diagram_type:
        return None
    return {
        'type': diagram_type,
        'labels': normalized_labels,
        'highlight': highlight,
    }

def _should_prevent_old_price_solver(text: str) -> bool:
    return _looks_like_direct_price_problem(text)

def _should_prevent_old_motion_solver(text: str) -> bool:
    return _looks_like_relative_motion_distance(text)

def _should_prevent_old_fraction_change_solver(text: str) -> bool:
    return _looks_like_fraction_change_problem(text)

def _should_prevent_old_equal_parts_solver(text: str) -> bool:
    return _looks_like_equal_parts_problem(text)

def _should_prevent_old_post_change_equal_parts_solver(text: str) -> bool:
    return _looks_like_post_change_equal_parts_problem(text)

def _should_prevent_old_ratio_after_change_solver(text: str) -> bool:
    return _looks_like_ratio_after_change_problem(text)

def _should_prevent_old_difference_after_change_solver(text: str) -> bool:
    return _looks_like_difference_after_change_problem(text)

def _should_prevent_old_temperature_solver(text: str) -> bool:
    return _looks_like_temperature_change_problem(text)

def _looks_like_any_reverse_dual_subject_total_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _extract_compound_quantities(text):
        return False
    question = _question_text(text).lower().replace('ё', 'е')
    if not question or not any(marker in question for marker in ('сколько', 'на сколько', 'во сколько')):
        return False
    if not _question_asks_initial_state(question):
        return False
    if _extract_reverse_transfer_total_value(text) is None:
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return False

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return False

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified:
        return False
    return not any(item['kind'] == 'transfer' for item in classified)

def _looks_like_ambiguous_reverse_dual_subject_total_after_changes_problem(raw_text: str) -> bool:
    return (
        _looks_like_any_reverse_dual_subject_total_after_changes_problem(raw_text)
        and not _looks_like_reverse_dual_subject_total_relation_after_changes_problem(raw_text)
        and not _looks_like_reverse_dual_subject_total_after_changes_problem(raw_text)
    )
