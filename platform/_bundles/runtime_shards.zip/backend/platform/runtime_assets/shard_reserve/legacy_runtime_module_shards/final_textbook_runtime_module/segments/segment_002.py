"""Auto-generated runtime module shard for final_textbook_runtime_module.py, lines 870-1235."""

from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_modules.final_textbook_runtime_module', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _final_20260416e_try_geometry_textbook_patterns(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    # 1) Прямоугольник: известны длина и ширина напрямую.
    rect_direct = re.search(
        r'длин[а-яё ]{0,20}(?:которого|прямоугольника)?[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширин[а-яё ]{0,20}[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)',
        lower,
    )
    if rect_direct:
        length = int(rect_direct.group(1))
        length_unit = rect_direct.group(2)
        width = int(rect_direct.group(3))
        width_unit = rect_direct.group(4)
        if length_unit == width_unit:
            unit = length_unit
            area = length * width
            perimeter = (length + width) * 2
            asks_area = 'площад' in lower
            asks_perimeter = 'периметр' in lower
            target_area_unit = _final_20260416e_extract_target_area_unit(lower)
            if asks_area and target_area_unit and target_area_unit != unit:
                converted = _final_20260416e_convert_area_value(area, unit, target_area_unit)
                if converted is not None:
                    return join_explanation_lines(
                        'Задача.',
                        _audit_task_line(raw_text),
                        'Решение.',
                        f'Что известно: длина прямоугольника {with_unit(length, unit)}, ширина {with_unit(width, unit)}.',
                        'Что нужно найти: площадь прямоугольника и перевести её в другую единицу площади.',
                        f'1) Находим площадь прямоугольника: {length} × {width} = {area} {unit}².',
                        f'2) Переводим {area} {unit}² в {target_area_unit}²: {area} {unit}² = {converted} {target_area_unit}².',
                        f'Ответ: площадь прямоугольника равна {with_unit(converted, target_area_unit, square=True)}.'
                    )
            if asks_area and not asks_perimeter:
                return join_explanation_lines(
                    'Задача.',
                    _audit_task_line(raw_text),
                    'Решение.',
                    f'Что известно: длина прямоугольника {with_unit(length, unit)}, ширина {with_unit(width, unit)}.',
                    'Что нужно найти: площадь прямоугольника.',
                    f'1) Площадь прямоугольника равна длине, умноженной на ширину: {length} × {width} = {area}.',
                    f'Ответ: площадь прямоугольника равна {with_unit(area, unit, square=True)}.'
                )
            if asks_perimeter and not asks_area:
                return join_explanation_lines(
                    'Задача.',
                    _audit_task_line(raw_text),
                    'Решение.',
                    f'Что известно: длина прямоугольника {with_unit(length, unit)}, ширина {with_unit(width, unit)}.',
                    'Что нужно найти: периметр прямоугольника.',
                    f'1) Периметр прямоугольника равен сумме длины и ширины, умноженной на 2: ({length} + {width}) × 2 = {perimeter}.',
                    f'Ответ: периметр прямоугольника равен {with_unit(perimeter, unit)}.'
                )
            if asks_area and asks_perimeter:
                return join_explanation_lines(
                    'Задача.',
                    _audit_task_line(raw_text),
                    'Решение.',
                    f'Что известно: длина прямоугольника {with_unit(length, unit)}, ширина {with_unit(width, unit)}.',
                    'Что нужно найти: площадь и периметр прямоугольника.',
                    f'1) Находим площадь: {length} × {width} = {area} {unit}².',
                    f'2) Находим периметр: ({length} + {width}) × 2 = {perimeter} {unit}.',
                    f'Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}.'
                )

    # 2) Квадрат: известна сторона (в разных формулировках).
    square_side = re.search(
        r'квадрат[^.?!]{0,80}?(?:со\s+сторон(?:ой|ою)?|длина\s+которого|длина\s+стороны)[^\d]{0,20}(\d+)\s*(мм|см|дм|м|км)',
        lower,
    )
    if square_side:
        side = int(square_side.group(1))
        unit = square_side.group(2)
        area = side * side
        perimeter = side * 4
        asks_area = 'площад' in lower
        asks_perimeter = 'периметр' in lower
        if asks_area and not asks_perimeter:
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: сторона квадрата равна {with_unit(side, unit)}.',
                'Что нужно найти: площадь квадрата.',
                f'1) Площадь квадрата равна стороне, умноженной на сторону: {side} × {side} = {area}.',
                f'Ответ: площадь квадрата равна {with_unit(area, unit, square=True)}.'
            )
        if asks_perimeter and not asks_area:
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: сторона квадрата равна {with_unit(side, unit)}.',
                'Что нужно найти: периметр квадрата.',
                f'1) Периметр квадрата равен четырём сторонам: {side} × 4 = {perimeter}.',
                f'Ответ: периметр квадрата равен {with_unit(perimeter, unit)}.'
            )

    # 3) Прямоугольник: одна сторона известна, другая задана через «на ... больше/меньше» или «в ... раз ...».
    patterns = [
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*меньше', lower),
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+в\s+(\d+)\s+раза?\s+меньше', lower),
        re.search(r'ширина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}длина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*больше', lower),
        re.search(r'ширина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}длина\s+в\s+(\d+)\s+раза?\s+больше', lower),
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*короче', lower),
    ]
    for idx, match in enumerate(patterns):
        if not match:
            continue
        first = int(match.group(1))
        unit = match.group(2)
        second = int(match.group(3))
        if idx in {0, 4}:  # length known, width smaller by delta
            length = first
            width = first - second
            explanation_line = f'1) Сначала находим ширину: {length} - {second} = {width}.'
        elif idx == 1:  # length known, width less in ratio
            length = first
            if second == 0 or first % second != 0:
                return None
            width = first // second
            explanation_line = f'1) Сначала находим ширину: {length} : {second} = {width}.'
        elif idx == 2:  # width known, length greater by delta
            width = first
            length = first + second
            explanation_line = f'1) Сначала находим длину: {width} + {second} = {length}.'
        else:  # width known, length greater in ratio
            width = first
            length = first * second
            explanation_line = f'1) Сначала находим длину: {width} × {second} = {length}.'
        if width < 0:
            return None
        area = length * width
        perimeter = (length + width) * 2
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: длина и ширина прямоугольника связаны между собой.',
            'Что нужно найти: площадь и периметр прямоугольника.',
            explanation_line,
            f'2) Находим площадь: {length} × {width} = {area} {unit}².',
            f'3) Находим периметр: ({length} + {width}) × 2 = {perimeter} {unit}.',
            f'Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}.'
        )

    return None

def _final_20260416e_try_fraction_textbook_patterns(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace('ё', 'е')

    # Найти число по его дроби.
    match = re.search(r'найти\s+число[^.?!]*?(\d+)\s*/\s*(\d+)\s+его\s+(?:составляет|равна|равно|равны)\s*(\d+)', lower)
    if match:
        numerator = int(match.group(1))
        denominator = int(match.group(2))
        part_value = int(match.group(3))
        if numerator == 0 or (part_value * denominator) % numerator != 0:
            return None
        whole = part_value * denominator // numerator
        one_part = part_value // numerator if numerator != 0 and part_value % numerator == 0 else None
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {numerator}/{denominator} числа равны {part_value}.',
            'Что нужно найти: всё число.',
        ]
        if one_part is not None:
            lines.append(f'1) Находим одну долю: {part_value} : {numerator} = {one_part}.')
            lines.append(f'2) Находим всё число: {one_part} × {denominator} = {whole}.')
        else:
            lines.append(f'1) Чтобы найти всё число, умножаем значение части на знаменатель и делим на числитель: {part_value} × {denominator} : {numerator} = {whole}.')
        lines.append(f'Ответ: {whole}.')
        return join_explanation_lines(*lines)

    # Известно целое и дробная часть; спрашивают часть или остаток.
    first_number_match = re.search(r'(\d+)', re.sub(r'\b\d+\s*/\s*\d+\b', ' ', lower))
    fraction_match = re.search(r'(\d+)\s*/\s*(\d+)', lower)
    if first_number_match and fraction_match:
        total = int(first_number_match.group(1))
        numerator = int(fraction_match.group(1))
        denominator = int(fraction_match.group(2))
        if denominator == 0 or total * numerator % denominator != 0:
            return None
        one_part = total // denominator if total % denominator == 0 else None
        part_value = total * numerator // denominator

        if 'остальн' in lower:
            remaining = total - part_value
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: всего {total}, дробная часть {numerator}/{denominator}.',
                'Что нужно найти: сколько осталось после этой части.',
                f'1) Находим одну долю: {total} : {denominator} = {one_part if one_part is not None else total / denominator}.',
                f'2) Находим {numerator}/{denominator} от {total}: {one_part if one_part is not None else f"{total} : {denominator}"} × {numerator} = {part_value}.',
                f'3) Находим остаток: {total} - {part_value} = {remaining}.',
                f'Ответ: {remaining}.'
            )

        if contains_any_fragment(lower, ('составляет', 'составля', 'часть комнаты', 'часть всех', 'от ')) or ('чему равна' in lower and '/' in lower):
            result_label = 'часть'
            if 'площад' in lower:
                return join_explanation_lines(
                    'Задача.',
                    _audit_task_line(raw_text),
                    'Решение.',
                    f'Что известно: всё равно {total}, нужно найти {numerator}/{denominator} этого числа.',
                    'Что нужно найти: искомую часть.',
                    f'1) Находим одну долю: {total} : {denominator} = {one_part if one_part is not None else total / denominator}.',
                    f'2) Находим {numerator}/{denominator} от {total}: {one_part if one_part is not None else f"{total} : {denominator}"} × {numerator} = {part_value}.',
                    f'Ответ: {part_value}.'
                )
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: всё равно {total}, нужно найти {numerator}/{denominator} этого числа.',
                'Что нужно найти: искомую часть.',
                f'1) Находим одну долю: {total} : {denominator} = {one_part if one_part is not None else total / denominator}.',
                f'2) Находим {numerator}/{denominator} от {total}: {one_part if one_part is not None else f"{total} : {denominator}"} × {numerator} = {part_value}.',
                f'Ответ: {part_value}.'
            )

    return None


# --- FINAL PATCH 2026-04-16F: relation geometry before direct widths, and fraction area units ---


def _final_20260416f_detect_metric_unit(lower: str) -> str:
    if 'кв.м' in lower or 'м2' in lower or 'м²' in lower:
        return 'м'
    if 'кв.дм' in lower or 'дм2' in lower or 'дм²' in lower:
        return 'дм'
    if 'кв.см' in lower or 'см2' in lower or 'см²' in lower:
        return 'см'
    if 'кв.мм' in lower or 'мм2' in lower or 'мм²' in lower:
        return 'мм'
    return geometry_unit(lower)

def _final_20260416f_try_geometry_relations(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    relation_patterns = [
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*меньше', lower),
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+в\s+(\d+)\s+раза?\s+меньше', lower),
        re.search(r'ширина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}длина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*больше', lower),
        re.search(r'ширина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}длина\s+в\s+(\d+)\s+раза?\s+больше', lower),
        re.search(r'длина\s+прямоугольника[^\d]{0,12}(\d+)\s*(мм|см|дм|м|км)[^\d]{0,40}ширина\s+на\s+(\d+)\s*(?:мм|см|дм|м|км)?\s*короче', lower),
    ]
    for idx, match in enumerate(relation_patterns):
        if not match:
            continue
        first = int(match.group(1))
        unit = match.group(2)
        second = int(match.group(3))
        if idx in {0, 4}:
            length = first
            width = first - second
            first_step = f'1) Сначала находим ширину: {length} - {second} = {width}.'
        elif idx == 1:
            length = first
            if second == 0 or first % second != 0:
                return None
            width = first // second
            first_step = f'1) Сначала находим ширину: {length} : {second} = {width}.'
        elif idx == 2:
            width = first
            length = first + second
            first_step = f'1) Сначала находим длину: {width} + {second} = {length}.'
        else:
            width = first
            length = first * second
            first_step = f'1) Сначала находим длину: {width} × {second} = {length}.'
        if width < 0:
            return None
        area = length * width
        perimeter = (length + width) * 2
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'Что известно: одна сторона прямоугольника дана, а другая выражена через неё.',
            'Что нужно найти: площадь и периметр прямоугольника.',
            first_step,
            f'2) Находим площадь: {length} × {width} = {area} {unit}².',
            f'3) Находим периметр: ({length} + {width}) × 2 = {perimeter} {unit}.',
            f'Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}.'
        )
    return None

def _final_20260416f_try_fraction_area_part(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace('ё', 'е')
    if 'площад' not in lower or 'остальн' in lower:
        return None
    fraction_match = re.search(r'(\d+)\s*/\s*(\d+)', lower)
    total_match = re.search(r'(\d+)', re.sub(r'\b\d+\s*/\s*\d+\b', ' ', lower))
    if not fraction_match or not total_match:
        return None
    numerator = int(fraction_match.group(1))
    denominator = int(fraction_match.group(2))
    total = int(total_match.group(1))
    if denominator == 0 or total % denominator != 0:
        return None
    unit = _final_20260416f_detect_metric_unit(lower) or 'м'
    one_part = total // denominator
    result = one_part * numerator
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: всё равно {with_unit(total, unit, square=True)}, нужно найти {numerator}/{denominator} этого числа.',
        'Что нужно найти: площадь искомой части.',
        f'1) Находим одну долю: {total} : {denominator} = {one_part}.',
        f'2) Находим {numerator}/{denominator} от {total}: {one_part} × {numerator} = {result}.',
        f'Ответ: площадь равна {with_unit(result, unit, square=True)}.'
    )


# --- FINAL PATCH 2026-04-16G: fraction remainder wording like peel/pulp ---


def _final_20260416g_try_fraction_remainder_named_part(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace('ё', 'е')
    if 'мякот' not in lower:
        return None
    total_match = re.search(r'(\d+)\s*(?:г|кг)', lower)
    fraction_match = re.search(r'(\d+)\s*/\s*(\d+)', lower)
    if not total_match or not fraction_match:
        return None
    total = int(total_match.group(1))
    numerator = int(fraction_match.group(1))
    denominator = int(fraction_match.group(2))
    if denominator == 0 or total * numerator % denominator != 0:
        return None
    peel = total * numerator // denominator
    pulp = total - peel
    unit = 'г' if ' г' in lower else 'кг' if 'кг' in lower else ''
    one_part = total // denominator if total % denominator == 0 else None
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: масса банана {with_unit(total, unit)}, кожура составляет {numerator}/{denominator} всей массы.',
        'Что нужно найти: массу мякоти.',
        f'1) Находим одну долю: {total} : {denominator} = {one_part if one_part is not None else total / denominator}.',
        f'2) Находим массу кожуры: {one_part if one_part is not None else f"{total} : {denominator}"} × {numerator} = {peel}.',
        f'3) Находим массу мякоти: {total} - {peel} = {pulp}.',
        f'Ответ: масса мякоти равна {with_unit(pulp, unit)}.'
    )
