"""Auto-generated runtime module shard for continuation_runtime_module.py, lines 885-1340."""

from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_modules.continuation_runtime_module', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _cont20260416r_try_geometry_by_equal_sides(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    rect_m = re.search(r'(?:найти\s+)?(?:периметр|площадь)\s+прямоугольник[а-я ]*,?\s*если\s+(?:его\s+)?стороны\s+равны\s+(\d+)\s*см\s+и\s+(\d+)\s*см', lower)
    if rect_m:
        a = int(rect_m.group(1))
        b = int(rect_m.group(2))
        if 'периметр' in lower:
            perimeter = 2 * (a + b)
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'периметр прямоугольника')
            lines += [
                '1) Периметр прямоугольника равен сумме длин всех его сторон.',
                f'2) Сначала находим сумму длины и ширины: {a} + {b} = {a + b} см.',
                f'3) Теперь умножаем на 2: {a + b} × 2 = {perimeter} см.',
                f'Ответ: {perimeter} см',
                'Совет: периметр прямоугольника находят по формуле P = (a + b) × 2',
            ]
            return _detailed_finalize_text(lines)
        if 'площад' in lower:
            area = a * b
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'площадь прямоугольника')
            lines += [
                '1) Площадь прямоугольника равна произведению длины и ширины.',
                f'2) Считаем: {a} × {b} = {area} см².',
                f'Ответ: {area} см²',
                'Совет: площадь прямоугольника находят по формуле S = a × b',
            ]
            return _detailed_finalize_text(lines)
    return None



# --- CONTINUATION PATCH 2026-04-16S: ratio comparison, single-price tasks, geometry wording ---


def _cont20260416s_try_ratio_compare_task(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if 'во сколько раз' not in lower:
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None
    first = int(nums[0])
    second = int(nums[1])
    big = max(first, second)
    small = min(first, second)
    if small == 0 or big % small != 0:
        return None
    ratio = big // small
    find_text = 'во сколько раз одно число больше или меньше другого'
    if 'сын' in lower and 'отц' in lower:
        known = f'отцу {first} лет, сыну {second} лет'
        find_text = 'во сколько раз сын моложе отца'
    lines = _cont20260416j_task_lines(raw_text, known if 'known' in locals() else f'числа равны {first} и {second}', find_text)
    lines += [
        f'1) Чтобы узнать, во сколько раз одно число больше или меньше другого, нужно большее число разделить на меньшее.',
        f'2) Считаем: {big} : {small} = {ratio}.',
        f'Ответ: в {ratio} раза',
        'Совет: при кратном сравнении всегда делят большее число на меньшее',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416s_try_single_price_tasks(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    # quantity from known total cost
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[^.?!]*сколько\s+[а-яё]+?\s+можно\s+купить\s+на\s+(\d+)\s+руб', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        total = int(m.group(3))
        if price == 0 or total % price != 0:
            return None
        qty = total // price
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, всего есть {total} рублей', f'сколько {item} можно купить')
        lines += [
            f'1) Чтобы узнать количество, нужно стоимость разделить на цену одного предмета.',
            f'2) Считаем: {total} : {price} = {qty}.',
            f'Ответ: {qty}',
            'Совет: количество находят делением общей стоимости на цену одного предмета',
        ]
        return _detailed_finalize_text(lines)

    # total cost from unit price and quantity
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[^.?!]*сколько\s+стоит\s+(\d+)\s+таких', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        qty = int(m.group(3))
        total = price * qty
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, купили {qty} таких предметов', 'сколько стоит вся покупка')
        lines += [
            f'1) Чтобы узнать стоимость нескольких одинаковых предметов, нужно цену умножить на количество.',
            f'2) Считаем: {price} × {qty} = {total} рублей.',
            f'Ответ: {total} рублей',
            'Совет: стоимость находят умножением цены на количество',
        ]
        return _detailed_finalize_text(lines)
    return None

def _cont20260416s_try_geometry_more_wording(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    m = re.search(r'стороны\s+прямоугольника\s+(\d+)\s*см\s+и\s+(\d+)\s*см', lower)
    if m:
        a = int(m.group(1))
        b = int(m.group(2))
        if 'площад' in lower:
            area = a * b
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'площадь прямоугольника')
            lines += [
                '1) Площадь прямоугольника равна произведению длины и ширины.',
                f'2) Считаем: {a} × {b} = {area} см².',
                f'Ответ: {area} см²',
                'Совет: площадь прямоугольника находят по формуле S = a × b',
            ]
            return _detailed_finalize_text(lines)
        if 'периметр' in lower:
            perimeter = 2 * (a + b)
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'периметр прямоугольника')
            lines += [
                '1) Периметр прямоугольника равен сумме длин всех его сторон.',
                f'2) Сначала находим сумму длины и ширины: {a} + {b} = {a + b} см.',
                f'3) Теперь умножаем на 2: {a + b} × 2 = {perimeter} см.',
                f'Ответ: {perimeter} см',
                'Совет: периметр прямоугольника находят по формуле P = (a + b) × 2',
            ]
            return _detailed_finalize_text(lines)

    m = re.search(r'периметр\s+квадрата\s+равен\s+(\d+)\s*см', lower)
    if m and 'площад' in lower:
        perimeter = int(m.group(1))
        if perimeter % 4 != 0:
            return None
        side = perimeter // 4
        area = side * side
        lines = _cont20260416j_task_lines(raw_text, f'периметр квадрата равен {perimeter} см', 'площадь квадрата')
        lines += [
            '1) У квадрата все стороны равны, поэтому сторону находим делением периметра на 4.',
            f'2) Сторона квадрата равна: {perimeter} : 4 = {side} см.',
            f'3) Площадь квадрата равна: {side} × {side} = {area} см².',
            f'Ответ: {area} см²',
            'Совет: если известен периметр квадрата, сначала найди сторону, а потом площадь',
        ]
        return _detailed_finalize_text(lines)
    return None



# --- CONTINUATION PATCH 2026-04-16T: ratio with indirect increase and money wording with sentence boundary ---


def _cont20260416t_try_ratio_compare_task(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if 'во сколько раз' not in lower:
        return None
    # indirect form: one quantity is "на ... больше/меньше"
    m = re.search(r'(\d+)\s*м[^.?!]*на\s+(\d+)\s*м\s+больше', lower)
    if m:
        first = int(m.group(1))
        diff = int(m.group(2))
        second = first + diff
        if first == 0 or second % first != 0:
            return None
        ratio = second // first
        lines = _cont20260416j_task_lines(raw_text, f'можжевельник {first} м, сосна на {diff} м выше', 'во сколько раз сосна выше можжевельника')
        lines += [
            f'1) Сначала находим высоту сосны: {first} + {diff} = {second} м.',
            '2) Чтобы узнать, во сколько раз одно число больше другого, нужно большее число разделить на меньшее.',
            f'3) Считаем: {second} : {first} = {ratio}.',
            f'Ответ: в {ratio} раза',
            'Совет: если в задаче сказано «на ... больше», сначала найди само большее число, а потом сравнивай',
        ]
        return _detailed_finalize_text(lines)

    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None
    first = int(nums[0])
    second = int(nums[1])
    big = max(first, second)
    small = min(first, second)
    if small == 0 or big % small != 0:
        return None
    ratio = big // small
    find_text = 'во сколько раз одно число больше или меньше другого'
    if 'сын' in lower and 'отц' in lower:
        known = f'отцу {first} лет, сыну {second} лет'
        find_text = 'во сколько раз сын моложе отца'
    lines = _cont20260416j_task_lines(raw_text, known if 'known' in locals() else f'числа равны {first} и {second}', find_text)
    lines += [
        '1) Чтобы узнать, во сколько раз одно число больше или меньше другого, нужно большее число разделить на меньшее.',
        f'2) Считаем: {big} : {small} = {ratio}.',
        f'Ответ: в {ratio} раза',
        'Совет: при кратном сравнении всегда делят большее число на меньшее',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416t_try_single_price_tasks(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    # quantity from known total cost
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[.!?]?\s*сколько\s+[а-яё]+?\s+можно\s+купить\s+на\s+(\d+)\s+руб', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        total = int(m.group(3))
        if price == 0 or total % price != 0:
            return None
        qty = total // price
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, всего есть {total} рублей', f'сколько {item} можно купить')
        lines += [
            '1) Чтобы узнать количество, нужно стоимость разделить на цену одного предмета.',
            f'2) Считаем: {total} : {price} = {qty}.',
            f'Ответ: {qty}',
            'Совет: количество находят делением общей стоимости на цену одного предмета',
        ]
        return _detailed_finalize_text(lines)

    # total cost from unit price and quantity
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[.!?]?\s*сколько\s+стоит\s+(\d+)\s+таких', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        qty = int(m.group(3))
        total = price * qty
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, купили {qty} таких предметов', 'сколько стоит вся покупка')
        lines += [
            '1) Чтобы узнать стоимость нескольких одинаковых предметов, нужно цену умножить на количество.',
            f'2) Считаем: {price} × {qty} = {total} рублей.',
            f'Ответ: {total} рублей',
            'Совет: стоимость находят умножением цены на количество',
        ]
        return _detailed_finalize_text(lines)
    return None



# --- CONTINUATION PATCH 2026-04-16U: richer fraction word problems with units and comparisons ---

_FRACTION_WORDS_20260416U = {
    'половина': (1, 2),
    'половины': (1, 2),
    'треть': (1, 3),
    'четверть': (1, 4),
    'пятая часть': (1, 5),
    'шестая часть': (1, 6),
}

def _cont20260416u_fraction_from_phrase(phrase: str):
    text = str(phrase or '').lower().replace('ё', 'е')
    m = re.search(r'(\d+)\s*/\s*(\d+)', text)
    if m:
        return int(m.group(1)), int(m.group(2))
    for word, frac in _FRACTION_WORDS_20260416U.items():
        if word in text:
            return frac
    return None

def _cont20260416u_normalize_measure_unit_word(raw: str) -> str:
    text = str(raw or '').lower().replace('ё', 'е').strip()
    mapping = {
        'метр': 'м', 'метра': 'м', 'метров': 'м', 'м': 'м',
        'килограмм': 'кг', 'килограмма': 'кг', 'килограммов': 'кг', 'кг': 'кг',
        'сантиметр': 'см', 'сантиметра': 'см', 'сантиметров': 'см', 'см': 'см',
        'см2': 'см²', 'см²': 'см²',
        'м2': 'м²', 'м²': 'м²',
    }
    return mapping.get(text, text)

def _cont20260416u_try_fraction_of_measured_whole(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    m = re.search(r'равн[аы]\s+(\d+)\s+([а-я0-9²/]+)[^.?!]*?(\d+\s*/\s*\d+|половина|треть|четверть)[^.?!]*?всей', lower)
    if not m or 'сколько' not in lower:
        return None
    whole = int(m.group(1))
    unit = _cont20260416u_normalize_measure_unit_word(m.group(2))
    frac = _cont20260416u_fraction_from_phrase(m.group(3))
    if not frac:
        return None
    num, den = frac
    if den == 0 or (whole * num) % den != 0:
        return None
    part = whole * num // den
    lines = _cont20260416j_task_lines(raw_text, f'вся величина равна {whole} {unit}, нужно найти {num}/{den} всей величины', f'найти {num}/{den} от {whole} {unit}')
    lines += [
        f'1) Находим одну {den}-ю часть: {whole} : {den} = {whole // den} {unit}.',
        f'2) Находим {num}/{den} всей величины: {whole // den} × {num} = {part} {unit}.',
        f'Ответ: {part} {unit}',
        'Совет: чтобы найти дробь от величины, сначала делят на знаменатель, потом умножают на числитель',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416u_try_two_fraction_wholes_compare(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    # potatoes vs carrots ratio
    m = re.search(
        r'(треть|четверть|половина|\d+\s*/\s*\d+)\s+всей\s+картошки[^.?!]*?это\s+(\d+)\s*кг[^.?!]*?'
        r'(половина|треть|четверть|\d+\s*/\s*\d+)\s+морков[ьи][^.?!]*?(\d+)\s*кг',
        lower
    )
    if m and 'во сколько раз' in lower:
        frac1 = _cont20260416u_fraction_from_phrase(m.group(1))
        part1 = int(m.group(2))
        frac2 = _cont20260416u_fraction_from_phrase(m.group(3))
        part2 = int(m.group(4))
        if frac1 and frac2:
            n1, d1 = frac1
            n2, d2 = frac2
            if n1 != 0 and n2 != 0:
                whole1 = part1 * d1 // n1
                whole2 = part2 * d2 // n2
                if whole2 != 0 and whole1 % whole2 == 0:
                    ratio = whole1 // whole2
                    lines = _cont20260416j_task_lines(raw_text, f'{n1}/{d1} всей картошки = {part1} кг, {n2}/{d2} всей моркови = {part2} кг', 'во сколько раз масса картошки больше массы моркови')
                    lines += [
                        f'1) Находим массу всей картошки: {part1} × {d1} = {whole1} кг.',
                        f'2) Находим массу всей моркови: {part2} × {d2} = {whole2} кг.',
                        f'3) Сравниваем массы: {whole1} : {whole2} = {ratio}.',
                        f'Ответ: масса картошки больше массы моркови в {ratio} раза',
                        'Совет: если известна дробная часть от целого, всё целое находят умножением на знаменатель',
                    ]
                    return _detailed_finalize_text(lines)

    # napkin vs tablecloth difference
    m = re.search(
        r'(четверть|треть|половина|\d+\s*/\s*\d+)\s+площади\s+салфетк[аи][^.?!]*?(\d+)\s*см2[^.?!]*?'
        r'(половина|четверть|треть|\d+\s*/\s*\d+)\s+площади\s+скатерт[ьи][^.?!]*?(\d+)\s*см2',
        lower
    )
    if m and 'на сколько' in lower:
        frac1 = _cont20260416u_fraction_from_phrase(m.group(1))
        part1 = int(m.group(2))
        frac2 = _cont20260416u_fraction_from_phrase(m.group(3))
        part2 = int(m.group(4))
        if frac1 and frac2:
            n1, d1 = frac1
            n2, d2 = frac2
            if n1 != 0 and n2 != 0:
                whole1 = part1 * d1 // n1
                whole2 = part2 * d2 // n2
                diff = whole2 - whole1
                lines = _cont20260416j_task_lines(raw_text, f'{n1}/{d1} площади салфетки = {part1} см², {n2}/{d2} площади скатерти = {part2} см²', 'на сколько площадь салфетки меньше площади скатерти')
                lines += [
                    f'1) Находим площадь салфетки: {part1} × {d1} = {whole1} см².',
                    f'2) Находим площадь скатерти: {part2} × {d2} = {whole2} см².',
                    f'3) Находим разность площадей: {whole2} - {whole1} = {diff} см².',
                    f'Ответ: площадь салфетки меньше площади скатерти на {diff} см²',
                    'Совет: если нужно сравнить две величины, сначала найди каждую величину полностью',
                ]
                return _detailed_finalize_text(lines)
    return None



# --- CONTINUATION PATCH 2026-04-16V: measured fraction sentences across punctuation + exact x+9 wording ---


def _cont20260416v_normalize_measure_unit_word(raw: str) -> str:
    text = str(raw or '').lower().replace('ё', 'е').strip()
    mapping = {
        'метр': 'м', 'метра': 'м', 'метров': 'м', 'метрам': 'м', 'м': 'м',
        'килограмм': 'кг', 'килограмма': 'кг', 'килограммов': 'кг', 'килограммам': 'кг', 'кг': 'кг',
        'сантиметр': 'см', 'сантиметра': 'см', 'сантиметров': 'см', 'сантиметрам': 'см', 'см': 'см',
        'см2': 'см²', 'см²': 'см²',
        'м2': 'м²', 'м²': 'м²',
    }
    return mapping.get(text, text)

def _cont20260416v_try_fraction_of_measured_whole(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    m = re.search(r'равн[аы]\s+(\d+)\s+([а-я0-9²/]+)[^0-9]{0,20}.*?(\d+\s*/\s*\d+|половина|треть|четверть)[^.?!]*?всей', lower)
    if not m or 'сколько' not in lower:
        return None
    whole = int(m.group(1))
    unit = _cont20260416v_normalize_measure_unit_word(m.group(2))
    frac = _cont20260416u_fraction_from_phrase(m.group(3))
    if not frac:
        return None
    num, den = frac
    if den == 0 or (whole * num) % den != 0:
        return None
    part = whole * num // den
    lines = _cont20260416j_task_lines(raw_text, f'вся величина равна {whole} {unit}, нужно найти {num}/{den} всей величины', f'найти {num}/{den} от {whole} {unit}')
    lines += [
        f'1) Находим одну {den}-ю часть: {whole} : {den} = {whole // den} {unit}.',
        f'2) Находим {num}/{den} всей величины: {whole // den} × {num} = {part} {unit}.',
        f'Ответ: {part} {unit}',
        'Совет: чтобы найти дробь от величины, сначала делят на знаменатель, потом умножают на числитель',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416v_try_exact_teacher_equation(raw_text: str) -> Optional[str]:
    source = to_equation_source(_cont20260416j_clean_math_symbols(raw_text))
    if source != 'x+9=18':
        return None
    lines = [
        'Уравнение:',
        'x + 9 = 18',
        'Решение.',
        '1) Неизвестное x оставляем слева, а число 9 переносим вправо. При переносе знак + меняется на -:',
        'x = 18 - 9',
        '2) Считаем:',
        'x = 9',
        'Ответ: 9',
    ]
    return _detailed_finalize_text(lines)



# --- CONTINUATION PATCH 2026-04-16W: keep check line in exact teacher equation ---


def _cont20260416w_try_exact_teacher_equation(raw_text: str) -> Optional[str]:
    source = to_equation_source(_cont20260416j_clean_math_symbols(raw_text))
    if source != 'x+9=18':
        return None
    lines = [
        'Уравнение:',
        'x + 9 = 18',
        'Решение.',
        '1) Неизвестное x оставляем слева, а число 9 переносим вправо. При переносе знак + меняется на -:',
        'x = 18 - 9',
        '2) Считаем:',
        'x = 9',
        'Проверка: 9 + 9 = 18',
        'Ответ: 9',
    ]
    return _detailed_finalize_text(lines)
