from __future__ import annotations

from pathlib import Path

from backend.package_bootstrap import bootstrap_package

_segments_dir = Path(__file__).resolve().parent / 'segments'
__path__ = bootstrap_package(__path__, __name__, [_segments_dir])

__all__: list[str] = []
