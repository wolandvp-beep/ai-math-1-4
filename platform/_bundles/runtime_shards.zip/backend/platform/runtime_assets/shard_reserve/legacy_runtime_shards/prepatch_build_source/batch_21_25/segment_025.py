"""Auto-generated runtime shard for prepatch_build_source.py, lines 21053-21685."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _geo20260416ah_try_volume_surface_extended(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = normalize_dashes(text).lower().replace('м3', 'м³').replace('см3', 'см³').replace('дм3', 'дм³')
    lower = lower.replace('м 3', 'м³').replace('см 3', 'см³').replace('дм 3', 'дм³')
    lower = re.sub(r'\s+', ' ', lower).strip()

    m = re.search(r'проволочн[а-я ]+каркаса куба с ребром (\d+) см', lower)
    if m:
        edge_cm = int(m.group(1))
        total_cm = edge_cm * 12
        meters = total_cm / 100
        meters_text = str(int(meters)) if float(meters).is_integer() else str(meters).replace('.', ',')
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: ребро куба {edge_cm} см.',
            'Что нужно найти: сколько метров проволоки нужно для каркаса куба.',
            '1) У куба 12 рёбер.',
            f'2) Находим общую длину всех рёбер: {edge_cm} × 12 = {total_cm} см.',
            f'3) Переводим в метры: {total_cm} см = {meters_text} м.',
            f'Ответ: {meters_text} м',
            'Совет: каркас куба состоит из всех его рёбер, поэтому сначала считают сумму длин 12 рёбер',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'площадь полной поверхности параллелепипеда с измерениями:? а ?= ?(\d+) см,? в ?= ?(\d+) см,? с ?= ?(\d+) см', lower)
    if m:
        a, b, c = map(int, m.groups())
        ab = a * b; ac = a * c; bc = b * c
        total = 2 * (ab + ac + bc)
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь полной поверхности прямоугольного параллелепипеда находят по формуле S = 2 × (ab + ac + bc).',
            f'2) Находим площади трёх разных граней: {a} × {b} = {ab} см², {a} × {c} = {ac} см², {b} × {c} = {bc} см².',
            f'3) Складываем и умножаем на 2: 2 × ({ab} + {ac} + {bc}) = {total} см².',
            f'Ответ: {total} см²',
            'Совет: у прямоугольного параллелепипеда по две одинаковые грани каждого вида',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'найдите объем параллелепипеда с измерениями:? а ?= ?(\d+) см,? в ?= ?(\d+) см,? с ?= ?(\d+) см', lower)
    if m:
        a, b, c = map(int, m.groups())
        volume = a * b * c
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Объём прямоугольного параллелепипеда находят по формуле V = a × b × c.',
            f'2) Подставляем числа: {a} × {b} × {c} = {volume} см³.',
            f'Ответ: {volume} см³',
            'Совет: чтобы найти объём прямоугольного параллелепипеда, перемножают его длину, ширину и высоту',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'высотой потолка (\d+) м имеет объем (\d+) м³.*какова его площадь', lower)
    if m:
        height, volume = map(int, m.groups())
        if height > 0 and volume % height == 0:
            area = volume // height
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'1) Объём прямоугольного помещения равен площади пола, умноженной на высоту.',
                f'2) Чтобы найти площадь пола, объём делим на высоту: {volume} : {height} = {area} м².',
                f'Ответ: {area} м²',
                'Совет: если известны объём и высота, площадь основания находят делением объёма на высоту',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'во сколько раз объем куба с ребром (\d+) см (?:меньше|больше) объема параллелепипеда с измерениями (\d+) см, (\d+) см, (\d+) см', lower)
    if m:
        edge, a, b, c = map(int, m.groups())
        cube_v = edge ** 3
        prism_v = a * b * c
        if cube_v == 0 or prism_v == 0:
            return None
        if 'меньше' in lower:
            if prism_v % cube_v != 0:
                return None
            ratio = prism_v // cube_v
            relation = 'меньше'
        else:
            if cube_v % prism_v != 0:
                return None
            ratio = cube_v // prism_v
            relation = 'больше'
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим объём куба: {edge} × {edge} × {edge} = {cube_v} см³.',
            f'2) Находим объём параллелепипеда: {a} × {b} × {c} = {prism_v} см³.',
            f'3) Узнаём, во сколько раз один объём {relation} другого.',
        ]
        if relation == 'меньше':
            lines.append(f'4) {prism_v} : {cube_v} = {ratio}.')
        else:
            lines.append(f'4) {cube_v} : {prism_v} = {ratio}.')
        lines += [
            f'Ответ: в {ratio} раз',
            'Совет: чтобы узнать, во сколько раз одна величина больше или меньше другой, большее число делят на меньшее',
        ]
        return _mass20260416x_finalize(lines)
    return None

_GEO20260416AH_PREV_BUILD_EXPLANATION = build_explanation

async def build_explanation(user_text: str) -> dict:
    local = _geo20260416ah_try_volume_surface_extended(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _GEO20260416AH_PREV_BUILD_EXPLANATION(user_text)

# === Continued external audit patch: fractions + named quantities mixed corpus ===

def _frac20260416_cont_try_simple_unit_fraction(raw_text: str) -> Optional[str]:
    text = _frac20260416_cont_norm(raw_text)
    m = re.fullmatch(r'Найти\s+(\d+)\s*/\s*(\d+)\s+от\s+1\s+(см|дм|м|кг|л)\.?', text, flags=re.IGNORECASE)
    if not m:
        return None
    num, den = int(m.group(1)), int(m.group(2))
    unit = m.group(3).lower()
    smaller = {'см': ('мм', 10), 'дм': ('см', 10), 'м': ('см', 100), 'кг': ('г', 1000), 'л': ('мл', 1000)}
    if unit not in smaller:
        return None
    small_unit, coeff = smaller[unit]
    base = coeff
    if (base * num) % den != 0:
        return None
    part = (base * num) // den
    lines = [
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: нужно найти {num}/{den} от 1 {unit}.',
        'Что нужно найти: значение этой части.',
        f'1) Переводим 1 {unit} в более мелкие единицы: 1 {unit} = {base} {small_unit}.',
        f'2) Находим {num}/{den} от {base} {small_unit}: {base} : {den} × {num} = {part} {small_unit}.',
        f'Ответ: {part} {small_unit}',
        'Совет: чтобы найти дробь от величины, сначала удобно перевести её в более мелкие единицы',
    ]
    return _mass20260416x_finalize(lines)

def _frac20260416_cont_try_fraction_text_tasks(raw_text: str) -> Optional[str]:
    text = _frac20260416_cont_norm(raw_text)
    lower = text.lower()

    m = re.fullmatch(r'(\d+)\s*/\s*(\d+)\s*=\s*(\d+)', lower)
    if m:
        num, den, part = map(int, m.groups())
        if num > 0:
            one = part // num if part % num == 0 else part / num
            whole = int(one * den) if float(one * den).is_integer() else one * den
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: {num}/{den} числа равны {part}.',
                'Что нужно найти: всё число.',
                f'1) Находим одну долю: {part} : {num} = {one}.',
                f'2) Находим всё число: {one} × {den} = {whole}.',
                f'Ответ: {whole}',
                'Совет: если известны несколько долей числа, сначала находят одну долю, а потом всё число',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'Найди длину всей ленты, если\s*(\d+)\s*/\s*(\d+)\s*составляют\s*(\d+)\s*м', text, flags=re.IGNORECASE)
    if m:
        num, den, part = map(int, m.groups())
        one = part // num if part % num == 0 else part / num
        whole = int(one * den) if float(one * den).is_integer() else one * den
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {num}/{den} длины ленты составляют {part} м.',
            'Что нужно найти: всю длину ленты.',
            f'1) Находим одну долю: {part} : {num} = {one} м.',
            f'2) Находим всю длину: {one} × {den} = {whole} м.',
            f'Ответ: {whole} м',
            'Совет: если известны несколько долей величины, сначала находят одну долю, а потом всю величину',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'Найди\s*1\s*/\s*(\d+)\s+длины провода, если\s*(\d+)\s*/\s*(\d+)\s+этой длины составляют\s*(\d+)\s*м', text, flags=re.IGNORECASE)
    if m:
        ask_den, num, den, part = map(int, m.groups())
        if den == ask_den and num > 0:
            one = part // num if part % num == 0 else part / num
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: {num}/{den} длины провода составляют {part} м.',
                f'Что нужно найти: 1/{ask_den} длины провода.',
                f'1) Находим одну долю: {part} : {num} = {one} м.',
                f'Ответ: {one} м',
                'Совет: если нужно найти одну долю, число долей делят на их количество',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'велосипедист проехал\s*(\d+)\s*км, что составляет\s*(\d+)\s*/\s*(\d+)\s*част', lower)
    if m:
        part, num, den = map(int, m.groups())
        if num > 0:
            one = part // num if part % num == 0 else part / num
            whole = int(one * den) if float(one * den).is_integer() else one * den
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: {num}/{den} маршрута составляют {part} км.',
                'Что нужно найти: длину всего маршрута.',
                f'1) Находим одну долю маршрута: {part} : {num} = {one} км.',
                f'2) Находим весь маршрут: {one} × {den} = {whole} км.',
                f'Ответ: {whole} км',
                'Совет: если известна часть пути, сначала находят одну долю, а потом весь путь',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'прош[её]л\s+(?:четвертую|шестую)\s+часть пути за\s*(\d+)\s*минут', lower)
    if m:
        part_time = int(m.group(1))
        den = 4 if 'четверт' in lower else 6
        whole = part_time * den
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: 1/{den} пути пройдена за {part_time} минут.',
            'Что нужно найти: время на весь путь.',
            f'1) Весь путь состоит из {den} таких частей.',
            f'2) Находим всё время: {part_time} × {den} = {whole} минут.',
            f'Ответ: {whole} минут',
            'Совет: если одна доля пути занимает известное время, всё время находят умножением на число долей',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'почтовый голубь в час пролетает\s*(\d+)\s*км\.\s*сколько км он пролетит за\s*(\d+)\s*/\s*(\d+)\s*часа', lower)
    if m:
        per_hour, num, den = map(int, m.groups())
        part = per_hour * num // den if (per_hour * num) % den == 0 else per_hour * num / den
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: за 1 час голубь пролетает {per_hour} км.',
            f'Что нужно найти: сколько он пролетит за {num}/{den} часа.',
            f'1) Находим {num}/{den} от {per_hour}: {per_hour} : {den} × {num} = {part} км.',
            f'Ответ: {part} км',
            'Совет: чтобы найти дробь от числа, число делят на знаменатель и умножают на числитель',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'один литр керосина весит\s*(\d+)\s*г\.\s*сколько весит\s*(\d+)\s*/\s*(\d+)\s*литра', lower)
    if m:
        total, num, den = map(int, m.groups())
        part = total * num // den if (total * num) % den == 0 else total * num / den
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: 1 литр керосина весит {total} г.',
            f'Что нужно найти: сколько весит {num}/{den} литра.',
            f'1) Находим {num}/{den} от {total}: {total} : {den} × {num} = {part} г.',
            f'Ответ: {part} г',
            'Совет: чтобы найти дробь от массы, массу делят на знаменатель и умножают на числитель',
        ]
        return _mass20260416x_finalize(lines)

    if 'большой праздничный пирог' in lower and '1/4' in lower and '2/4' in lower:
        eaten = '3/4'
        left = '1/4'
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'Что известно: сначала съели 1/4 пирога, потом ещё 2/4 пирога.',
            'Что нужно найти: какая часть пирога съедена и какая часть осталась.',
            '1) Находим съеденную часть: 1/4 + 2/4 = 3/4.',
            '2) Находим оставшуюся часть: 1 - 3/4 = 1/4.',
            f'Ответ: съели {eaten}, осталось {left}',
            'Совет: дроби с одинаковыми знаменателями складывают и вычитают по числителям',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'полоска ткани длиной\s*(\d+)\s*см\.\s*из\s*(\d+)\s*/\s*(\d+)\s*части.*сколько см ткани у нее осталось\?\s*сколько см ткани ушло', lower)
    if m:
        total, num, den = map(int, m.groups())
        part = total * num // den if (total * num) % den == 0 else total * num / den
        left = total - part
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: длина ткани {total} см, на кофточку ушло {num}/{den} ткани.',
            'Что нужно найти: сколько ткани ушло и сколько осталось.',
            f'1) Находим, сколько ткани ушло: {total} : {den} × {num} = {part} см.',
            f'2) Находим, сколько ткани осталось: {total} - {part} = {left} см.',
            f'Ответ: ушло {part} см, осталось {left} см',
            'Совет: чтобы найти остаток после дробной части, сначала находят эту часть, а потом вычитают её из целого',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'зарплату\s*(\d+)\s*руб.*(\d+)\s*/\s*(\d+)\s*из этих денег.*подарки.*(\d+)\s*/\s*(\d+)\s*потратила на фрукты', lower)
    if m:
        total, g_num, g_den, f_num, f_den = map(int, m.groups())
        gifts = total * g_num // g_den if (total * g_num) % g_den == 0 else total * g_num / g_den
        fruits = total * f_num // f_den if (total * f_num) % f_den == 0 else total * f_num / f_den
        left = total - gifts - fruits
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: всего {total} руб., на подарки потратили {g_num}/{g_den}, на фрукты {f_num}/{f_den} всех денег.',
            'Что нужно найти: сколько потратили на подарки, на фрукты и сколько денег осталось.',
            f'1) Находим деньги на подарки: {total} : {g_den} × {g_num} = {gifts} руб.',
            f'2) Находим деньги на фрукты: {total} : {f_den} × {f_num} = {fruits} руб.',
            f'3) Находим остаток: {total} - {gifts} - {fruits} = {left} руб.',
            f'Ответ: на подарки {gifts} руб., на фрукты {fruits} руб., осталось {left} руб.',
            'Совет: если нужно найти несколько дробных частей одного числа, каждую часть считают отдельно',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'в куске ткани\s*(\d+)\s*м.*отрезали\s*(\d+)\s*/\s*(\d+)\s*част', lower)
    if m:
        total, num, den = map(int, m.groups())
        part = total * num // den if (total * num) % den == 0 else total * num / den
        left = total - part
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько ткани отрезали: {total} : {den} × {num} = {part} м.',
            f'2) Находим, сколько ткани осталось: {total} - {part} = {left} м.',
            f'Ответ: {left} м',
            'Совет: чтобы найти остаток после дробной части, сначала находят эту часть',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'в поход пошли\s*(\d+)\s*человек.*мальчиков\s*(\d+)\s*человек.*девочек\s*[-–]\s*третья часть от всех мальчиков.*остальные взрослые', lower)
    if m:
        total, boys = map(int, m.groups())
        girls = boys // 3
        adults = total - boys - girls
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим число девочек: {boys} : 3 = {girls}.',
            f'2) Находим число взрослых: {total} - {boys} - {girls} = {adults}.',
            f'Ответ: {adults} взрослых',
            'Совет: если сказано «третья часть», сначала находят эту часть, а потом остаток',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'в саду\s*(\d+)\s*роз, тюльпанов четвертая часть от роз, ромашек\s*(\d+)', lower)
    if m:
        roses, daisies = map(int, m.groups())
        tulips = roses // 4
        total = roses + tulips + daisies
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим количество тюльпанов: {roses} : 4 = {tulips}.',
            f'2) Находим общее количество цветов: {roses} + {tulips} + {daisies} = {total}.',
            f'Ответ: {total} цветов',
            'Совет: если одна величина составляет часть другой, сначала находят эту часть, а потом складывают все количества',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'в саду\s*(\d+)\s*цветов\.\s*ромашек\s*(\d+)\s*штук\.\s*роз\s*[-–]?\s*1\s*/\s*(\d+)\s*часть от ромашек.*остальные цветы[-–]? тюльпаны', lower)
    if m:
        total, daisies, den = map(int, m.groups())
        roses = daisies // den
        tulips = total - daisies - roses
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим количество роз: {daisies} : {den} = {roses}.',
            f'2) Находим количество тюльпанов: {total} - {daisies} - {roses} = {tulips}.',
            f'Ответ: {tulips} тюльпанов',
            'Совет: если одна часть известна, а другая выражена дробью от неё, сначала находят эту дробную часть, а потом остаток',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'в магазин привезли\s*(\d+)\s*метров красной ткани, синей[–-]\s*1\s*/\s*(\d+)\s*часть от красной, зеленой[–-]\s*(\d+)\s*метров', lower)
    if m:
        red, den, green = map(int, m.groups())
        blue = red // den
        total = red + blue + green
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько метров синей ткани привезли: {red} : {den} = {blue} м.',
            f'2) Находим общее количество ткани: {red} + {blue} + {green} = {total} м.',
            f'Ответ: {total} м',
            'Совет: если одна величина составляет дробную часть другой, сначала находят эту часть, а потом общий итог',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'куриное яйцо весит\s*(\d+)\s*г.*скорлупу приходится\s*1\s*/\s*(\d+).*белок\s*1\s*/\s*(\d+).*остальное[ –-]+желток', lower)
    if m:
        total, shell_den, white_den = map(int, m.groups())
        shell = total // shell_den
        white = total // white_den
        yolk = total - shell - white
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим массу скорлупы: {total} : {shell_den} = {shell} г.',
            f'2) Находим массу белка: {total} : {white_den} = {white} г.',
            f'3) Находим массу желтка: {total} - {shell} - {white} = {yolk} г.',
            f'Ответ: {yolk} г',
            'Совет: если часть массы уже известна по долям, остальные части находят вычитанием из всей массы',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'на свете существует\s*(\d+)\s*разновидностей акул.*1\s*/\s*(\d+)\s*часть нападает', lower)
    if m:
        total, den = map(int, m.groups())
        count = total // den
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим {1}/{den} от {total}: {total} : {den} = {count}.',
            f'Ответ: {count} видов',
            'Совет: чтобы найти одну долю числа, число делят на количество равных частей',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'длина тела лирохвоста\s*(\d+)\s*см, она составляет\s*1\s*/\s*(\d+)\s*длины хвоста', lower)
    if m:
        body, den = map(int, m.groups())
        tail = body * den
        diff = tail - body
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим длину хвоста: {body} × {den} = {tail} см.',
            f'2) Узнаём, на сколько тело короче хвоста: {tail} - {body} = {diff} см.',
            f'Ответ: {diff} см',
            'Совет: если одна величина составляет долю другой, большую величину находят умножением на число долей',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'вес морской черепахи\s*(\d+)\s*кг, вес сухопутной черепахи составляет\s*1\s*/\s*(\d+)\s*веса морской', lower)
    if m:
        sea, den = map(int, m.groups())
        land = sea // den
        diff = sea - land
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим вес сухопутной черепахи: {sea} : {den} = {land} кг.',
            f'2) Находим разницу: {sea} - {land} = {diff} кг.',
            f'Ответ: {diff} кг',
            'Совет: если нужно узнать, на сколько одна величина больше другой, из большей величины вычитают меньшую',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'длина отреза\s*(\d+)\s*м.*продали\s*1\s*/\s*(\d+)\s*част', lower)
    if m:
        total, den = map(int, m.groups())
        sold = total // den
        left = total - sold
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько метров продали: {total} : {den} = {sold} м.',
            f'2) Находим, сколько осталось: {total} - {sold} = {left} м.',
            f'Ответ: {left} м',
            'Совет: если продали часть куска, сначала находят эту часть, а потом остаток',
        ]
        return _mass20260416x_finalize(lines)

    m = re.search(r'блокнот стоит\s*(\d+)\s*руб.*что составляет\s*1\s*/\s*(\d+)\s*часть книги', lower)
    if m:
        notebook, den = map(int, m.groups())
        book = notebook * den
        total = notebook + book
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим цену книги: {notebook} × {den} = {book} руб.',
            f'2) Находим общую стоимость блокнота и книги: {notebook} + {book} = {total} руб.',
            f'Ответ: книга стоит {book} руб., вместе {total} руб.',
            'Совет: если цена одной вещи составляет долю цены другой, большую цену находят умножением на число долей',
        ]
        return _mass20260416x_finalize(lines)

    return None

_CONT20260416AI_PREV_BUILD_EXPLANATION = build_explanation

async def build_explanation(user_text: str) -> dict:
    for handler in (
        _unit20260416_cont_try_arithmetic,
        _frac20260416_cont_try_simple_unit_fraction,
        _frac20260416_cont_try_fraction_text_tasks,
    ):
        local = handler(user_text)
        if local:
            return _prompt20260416h_result(local, 'local')
    return await _CONT20260416AI_PREV_BUILD_EXPLANATION(user_text)

# Fix formatting of mixed named-quantity answers when the working base unit is not the smallest one.
_UNIT20260416_CONT_SMALLEST_SCALES = {
    'time': {'сут': 86400, 'ч': 3600, 'мин': 60, 'с': 1},
    'mass': {'т': 1000000, 'ц': 100000, 'кг': 1000, 'г': 1},
    'length': {'км': 1000000, 'м': 1000, 'дм': 100, 'см': 10, 'мм': 1},
}

def _unit20260416_cont_format_compound_from_base(total_value: int, group: str, base_unit: str, units_present: list[str]) -> str:
    ordered = {
        'time': ['сут', 'ч', 'мин', 'с'],
        'mass': ['т', 'ц', 'кг', 'г'],
        'length': ['км', 'м', 'дм', 'см', 'мм'],
    }[group]
    scales = _UNIT20260416_CONT_SMALLEST_SCALES[group]
    present = set(units_present)
    active = [u for u in ordered if u in present]
    if not active:
        active = [base_unit]
    start = ordered.index(active[0])
    end = max(ordered.index(active[-1]), ordered.index(base_unit))
    use_units = ordered[start:end + 1]
    total_smallest = int(round(total_value * scales[base_unit]))
    smallest_unit = use_units[-1]
    remainder = total_smallest
    smallest_scale = scales[smallest_unit]
    parts = []
    for unit in use_units:
        per = scales[unit] // smallest_scale
        count = remainder // (per * smallest_scale)
        remainder = remainder - count * per * smallest_scale
        if count or parts or unit == use_units[-1]:
            parts.append(f'{int(count)} {unit}')
    return ' '.join(parts)

def _unit20260416_cont_try_arithmetic(raw_text: str) -> Optional[str]:
    text = _frac20260416_cont_norm(raw_text)
    m = re.fullmatch(r'(.+?)\s*([+\-])\s*(.+?)\s*=?', text)
    if not m:
        return None
    left_text, op, right_text = m.group(1).strip(), m.group(2), m.group(3).strip()
    left = _unit20260416_cont_parse_quantity(left_text)
    right = _unit20260416_cont_parse_quantity(right_text)
    if not left or not right or left['group'] != right['group']:
        return None

    all_units = left['units'] + right['units']
    group = left['group']
    base_unit = _unit20260416_cont_base_unit(group, all_units)
    left_base = _unit20260416_cont_total_in_unit(left, base_unit)
    right_base = _unit20260416_cont_total_in_unit(right, base_unit)
    result_base = left_base + right_base if op == '+' else left_base - right_base
    if result_base < 0:
        return None

    answer_text = _unit20260416_cont_format_compound_from_base(result_base, group, base_unit, all_units)
    sign_text = '+' if op == '+' else '-'
    action_text = 'Складываем' if op == '+' else 'Вычитаем'
    lines = [
        'Пример: ' + raw_text.strip(),
        'Решение.',
        f'1) Переводим первое именованное число в {base_unit}: {left["pretty"]} = {left_base} {base_unit}.',
        f'2) Переводим второе именованное число в {base_unit}: {right["pretty"]} = {right_base} {base_unit}.',
        f'3) {action_text}: {left_base} {sign_text} {right_base} = {result_base} {base_unit}.',
        f'4) Переводим ответ обратно: {result_base} {base_unit} = {answer_text}.',
        f'Ответ: {answer_text}',
        'Совет: при действиях с именованными величинами сначала переводят их в одинаковые единицы',
    ]
    return _mass20260416x_finalize(lines)

def _frac20260416_cont_try_fraction_time_total(raw_text: str) -> Optional[str]:
    text = _frac20260416_cont_norm(raw_text)
    lower = text.lower()
    m = re.search(r'(?:проехал|прошел|прошёл)\s+(?:четвертую|шестую)\s+часть пути за\s*(\d+)\s*минут', lower)
    if not m:
        return None
    part_time = int(m.group(1))
    den = 4 if 'четверт' in lower else 6
    whole = part_time * den
    lines = [
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: 1/{den} пути пройдена за {part_time} минут.',
        'Что нужно найти: время на весь путь.',
        f'1) Весь путь состоит из {den} таких частей.',
        f'2) Находим всё время: {part_time} × {den} = {whole} минут.',
        f'Ответ: {whole} минут',
        'Совет: если одна доля пути занимает известное время, всё время находят умножением на число долей',
    ]
    return _mass20260416x_finalize(lines)

_CONT20260416AJ_PREV_BUILD_EXPLANATION = build_explanation

async def build_explanation(user_text: str) -> dict:
    local = _frac20260416_cont_try_fraction_time_total(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416AJ_PREV_BUILD_EXPLANATION(user_text)
