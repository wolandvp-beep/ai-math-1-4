"""Auto-generated runtime shard for prepatch_build_source.py, lines 13325-14214."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _final_20260415_normalize_fraction_expression_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(normalize_cyrillic_x(text))
    text = text.replace('×', '*').replace('·', '*').replace('÷', '/').replace(':', '/')
    text = re.sub(r'\s+', '', text)
    if not text or re.search(r'[A-Za-zА-Яа-яЁё]', text):
        return None
    if re.search(r'[^0-9+\-*/()]', text):
        return None
    if not re.search(r'\d+/\d+', text):
        return None
    if re.fullmatch(r'\d+/\d+', text):
        return None

    all_numbers = [int(value) for value in re.findall(r'\d+', text)]
    if not all_numbers:
        return None
    if max(abs(value) for value in all_numbers) > 1000:
        return None

    fraction_matches = list(re.finditer(r'(\d+)/(\d+)', text))
    if not fraction_matches:
        return None

    placeholder = re.sub(r'\d+/\d+', 'F', text)
    if not re.fullmatch(r'[F0-9+\-*/()]+', placeholder):
        return None
    if placeholder == 'F':
        return None

    if len(fraction_matches) == 1:
        numerator = int(fraction_matches[0].group(1))
        denominator = int(fraction_matches[0].group(2))
        if denominator == 0:
            return None
        if not re.search(r'[+\-*()]', placeholder):
            return None
        if max(abs(numerator), abs(denominator)) > 50:
            return None

    return text

def _final_20260415_tokenize_fraction_expression(source: str) -> Optional[List[dict]]:
    tokens: List[dict] = []
    index = 0
    length = len(source)

    while index < length:
        char = source[index]
        if char.isdigit():
            start = index
            while index < length and source[index].isdigit():
                index += 1
            integer_text = source[start:index]
            if index < length and source[index] == '/' and index + 1 < length and source[index + 1].isdigit():
                index += 1
                denominator_start = index
                while index < length and source[index].isdigit():
                    index += 1
                denominator_text = source[denominator_start:index]
                denominator = int(denominator_text)
                if denominator == 0:
                    raise ZeroDivisionError('fraction denominator is zero')
                tokens.append({
                    'type': 'value',
                    'text': f"{integer_text}/{denominator_text}",
                    'value': Fraction(int(integer_text), denominator),
                    'is_fraction_literal': True,
                    'pos': start,
                })
                continue

            tokens.append({
                'type': 'value',
                'text': integer_text,
                'value': Fraction(int(integer_text), 1),
                'is_fraction_literal': False,
                'pos': start,
            })
            continue

        if char in '+-*/()':
            tokens.append({'type': char, 'value': char, 'pos': index})
            index += 1
            continue

        return None

    if not tokens:
        return None

    with_implicit_mul: List[dict] = []
    previous: Optional[dict] = None
    for token in tokens:
        if previous and previous['type'] in {'value', ')'} and token['type'] in {'value', '('}:
            with_implicit_mul.append({'type': '*', 'value': '*', 'pos': token['pos']})
        with_implicit_mul.append(token)
        previous = token

    return with_implicit_mul

def _final_20260415_parse_fraction_expression(source: str) -> Optional[dict]:
    try:
        tokens = _final_20260415_tokenize_fraction_expression(source)
    except ZeroDivisionError:
        raise
    if not tokens:
        return None

    cursor = 0
    node_counter = 1

    def peek() -> Optional[dict]:
        return tokens[cursor] if cursor < len(tokens) else None

    def consume(expected: Optional[str] = None) -> Optional[dict]:
        nonlocal cursor
        token = peek()
        if token is None:
            return None
        if expected is not None and token['type'] != expected:
            return None
        cursor += 1
        return token

    def make_binary(operator: str, left: dict, right: dict, pos: int) -> dict:
        nonlocal node_counter
        node = {
            'type': 'binary',
            'operator': operator,
            'left': left,
            'right': right,
            'pos': pos,
            'id': node_counter,
        }
        node_counter += 1
        return node

    def parse_primary() -> Optional[dict]:
        token = peek()
        if token is None:
            return None

        if token['type'] == 'value':
            consume('value')
            return {
                'type': 'value',
                'value': token['value'],
                'text': token['text'],
                'is_fraction_literal': token.get('is_fraction_literal', False),
                'pos': token.get('pos', 0),
            }

        if token['type'] == '(':
            open_token = consume('(')
            inner = parse_add_sub()
            if inner is None or not consume(')'):
                return None
            return {
                'type': 'group',
                'inner': inner,
                'pos': open_token.get('pos', 0),
            }

        if token['type'] in {'+', '-'}:
            consume(token['type'])
            operand = parse_primary()
            if operand is None:
                return None
            return {
                'type': 'unary',
                'operator': token['type'],
                'operand': operand,
                'pos': token.get('pos', 0),
            }

        return None

    def parse_mul_div() -> Optional[dict]:
        node = parse_primary()
        if node is None:
            return None
        while True:
            token = peek()
            if token is None or token['type'] not in {'*', '/'}:
                break
            consume(token['type'])
            right = parse_primary()
            if right is None:
                return None
            node = make_binary(token['type'], node, right, token.get('pos', 0))
        return node

    def parse_add_sub() -> Optional[dict]:
        node = parse_mul_div()
        if node is None:
            return None
        while True:
            token = peek()
            if token is None or token['type'] not in {'+', '-'}:
                break
            consume(token['type'])
            right = parse_mul_div()
            if right is None:
                return None
            node = make_binary(token['type'], node, right, token.get('pos', 0))
        return node

    root = parse_add_sub()
    if root is None or cursor != len(tokens):
        return None
    return root

def _final_20260415_fraction_precedence(operator: str) -> int:
    return 1 if operator in {'+', '-'} else 2

def _final_20260415_fraction_op_symbol(operator: str) -> str:
    return {'+': '+', '-': '-', '*': '×', '/': '÷'}.get(operator, operator)

def _final_20260415_format_fraction_value(value: Fraction, force_fraction: bool = False) -> str:
    simplified = Fraction(value.numerator, value.denominator)
    if force_fraction or simplified.denominator != 1:
        return f"{simplified.numerator}/{simplified.denominator}"
    return str(simplified.numerator)

def _final_20260415_render_fraction_node(node: dict, solved: Optional[dict] = None, parent_precedence: int = 0, is_right_child: bool = False) -> str:
    solved = solved or {}
    if node.get('type') == 'value':
        return node.get('text', _final_20260415_format_fraction_value(node.get('value', Fraction(0, 1))))
    if node.get('type') == 'group':
        return f"({_final_20260415_render_fraction_node(node['inner'], solved)})"
    if node.get('type') == 'unary':
        inner = _final_20260415_render_fraction_node(node['operand'], solved, 3)
        return inner if node.get('operator') == '+' else f"-{inner}"
    if node.get('type') == 'binary':
        node_id = node.get('id')
        if node_id in solved:
            return solved[node_id]
        operator = node.get('operator', '+')
        precedence = _final_20260415_fraction_precedence(operator)
        left_text = _final_20260415_render_fraction_node(node['left'], solved, precedence, False)
        right_text = _final_20260415_render_fraction_node(node['right'], solved, precedence, True)
        text = f"{left_text} {_final_20260415_fraction_op_symbol(operator)} {right_text}"
        needs_brackets = precedence < parent_precedence or (
            is_right_child and operator in {'+', '-'} and precedence == parent_precedence
        )
        return f"({text})" if needs_brackets else text
    return ''

def _final_20260415_apply_fraction_operator(operator: str, left: Fraction, right: Fraction) -> Fraction:
    if operator == '+':
        return left + right
    if operator == '-':
        return left - right
    if operator == '*':
        return left * right
    if operator == '/':
        if right == 0:
            raise ZeroDivisionError('division by zero')
        return left / right
    raise ValueError('Unsupported operator')

def _final_20260415_flatten_fraction_chain(node: dict, operators_to_flatten: Tuple[str, ...], operands: List[dict], op_nodes: List[dict]):
    if node.get('type') == 'group':
        operands.append(node['inner'])
        return
    if node.get('type') == 'binary' and node.get('operator') in operators_to_flatten:
        _final_20260415_flatten_fraction_chain(node['left'], operators_to_flatten, operands, op_nodes)
        op_nodes.append(node)
        operands.append(node['right'])
        return
    operands.append(node)

def _final_20260415_eval_fraction_steps(node: dict) -> Tuple[Fraction, List[dict]]:
    node_type = node.get('type')
    if node_type == 'value':
        return node['value'], []
    if node_type == 'group':
        return _final_20260415_eval_fraction_steps(node['inner'])
    if node_type == 'unary':
        operand_value, operand_steps = _final_20260415_eval_fraction_steps(node['operand'])
        return (-operand_value if node.get('operator') == '-' else operand_value), operand_steps
    if node_type != 'binary':
        raise ValueError('Unsupported fraction expression node')

    operator = node.get('operator')
    chain_operators = ('+', '-') if operator in {'+', '-'} else ('*', '/')
    operands: List[dict] = []
    op_nodes: List[dict] = []
    _final_20260415_flatten_fraction_chain(node, chain_operators, operands, op_nodes)

    values: List[Fraction] = []
    steps: List[dict] = []
    for operand in operands:
        operand_value, operand_steps = _final_20260415_eval_fraction_steps(operand)
        steps.extend(operand_steps)
        values.append(operand_value)

    current = values[0]
    for op_node, next_value in zip(op_nodes, values[1:]):
        result = _final_20260415_apply_fraction_operator(op_node['operator'], current, next_value)
        steps.append({
            'id': op_node['id'],
            'operator': op_node['operator'],
            'left': current,
            'right': next_value,
            'result': result,
        })
        current = result

    return current, steps

def _final_20260415_prepare_fraction_operand(value: Fraction) -> Tuple[List[str], Fraction]:
    if value.denominator == 1:
        integer_text = str(value.numerator)
        return [f"Представляем число {integer_text} в виде дроби: {integer_text} = {integer_text}/1"], Fraction(value.numerator, 1)
    return [], Fraction(value.numerator, value.denominator)

def _final_20260415_append_fraction_reduction(lines: List[str], raw_numerator: int, raw_denominator: int, simplified: Fraction):
    raw_text = f"{raw_numerator}/{raw_denominator}"
    simple_text = _final_20260415_format_fraction_value(simplified)
    if raw_denominator != simplified.denominator or raw_numerator != simplified.numerator:
        lines.append(f"Сокращаем: {raw_text} = {simple_text}")

def _final_20260415_fraction_add_sub_lines(step_number: int, left: Fraction, right: Fraction, operator: str, result: Fraction) -> List[str]:
    symbol = '+' if operator == '+' else '-'
    action_word = 'Складываем' if operator == '+' else 'Вычитаем'
    action_word_lower = action_word.lower()
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} {symbol} {right_text} = {result_text}"]

    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)

    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)

    if left_fraction.denominator == right_fraction.denominator:
        raw_numerator = left_fraction.numerator + right_fraction.numerator if operator == '+' else left_fraction.numerator - right_fraction.numerator
        lines.append(f"Знаменатели уже одинаковые: {left_fraction.denominator} и {right_fraction.denominator}")
        lines.append(f"Значит, {action_word_lower} только числители: {left_fraction.numerator} {symbol} {right_fraction.numerator} = {raw_numerator}")
        lines.append(f"Получаем: {left_work_text} {symbol} {right_work_text} = {raw_numerator}/{left_fraction.denominator}")
        _final_20260415_append_fraction_reduction(lines, raw_numerator, left_fraction.denominator, result)
        return lines

    common = math.lcm(left_fraction.denominator, right_fraction.denominator)
    left_multiplier = common // left_fraction.denominator
    right_multiplier = common // right_fraction.denominator
    left_scaled = left_fraction.numerator * left_multiplier
    right_scaled = right_fraction.numerator * right_multiplier
    raw_numerator = left_scaled + right_scaled if operator == '+' else left_scaled - right_scaled

    lines.append(
        f"Находим общий знаменатель. Знаменатели: {left_fraction.denominator} и {right_fraction.denominator}. Общий знаменатель = {common}, потому что {common} делится на {left_fraction.denominator} и на {right_fraction.denominator}"
    )

    if left_fraction.denominator == common:
        lines.append(f"Первая дробь уже имеет знаменатель {common}: {left_work_text} = {left_fraction.numerator}/{common}")
    else:
        lines.extend([
            f"Приводим первую дробь {left_work_text} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {left_fraction.denominator}, чтобы получить {common}?",
            f"{left_fraction.denominator} × {left_multiplier} = {common}",
            f"Нужно умножить на {left_multiplier}",
            f"Получаем: {left_work_text} = (умножаем числитель и знаменатель на {left_multiplier}) = {left_scaled}/{common}",
        ])

    if right_fraction.denominator == common:
        lines.append(f"Вторая дробь уже имеет знаменатель {common}: {right_work_text} = {right_fraction.numerator}/{common}")
    else:
        lines.extend([
            f"Приводим вторую дробь {right_work_text} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {right_fraction.denominator}, чтобы получить {common}?",
            f"{right_fraction.denominator} × {right_multiplier} = {common}",
            f"Нужно умножить на {right_multiplier}",
            f"Получаем: {right_work_text} = (умножаем числитель и знаменатель на {right_multiplier}) = {right_scaled}/{common}",
        ])

    lines.append(f"Теперь {action_word_lower} дроби с одинаковыми знаменателями")
    lines.append(f"{left_scaled} {symbol} {right_scaled} = {raw_numerator}")
    lines.append(f"Получаем: {left_scaled}/{common} {symbol} {right_scaled}/{common} = {raw_numerator}/{common}")
    _final_20260415_append_fraction_reduction(lines, raw_numerator, common, result)
    return lines

def _final_20260415_fraction_mul_body_lines(left_fraction: Fraction, right_fraction: Fraction, result: Fraction, left_work_text: str, right_work_text: str) -> List[str]:
    raw_numerator = left_fraction.numerator * right_fraction.numerator
    raw_denominator = left_fraction.denominator * right_fraction.denominator
    lines = [
        'Чтобы умножить дроби, умножаем числители и знаменатели',
        f"{left_fraction.numerator} × {right_fraction.numerator} = {raw_numerator}",
        f"{left_fraction.denominator} × {right_fraction.denominator} = {raw_denominator}",
        f"Получаем: {left_work_text} × {right_work_text} = {raw_numerator}/{raw_denominator}",
    ]
    _final_20260415_append_fraction_reduction(lines, raw_numerator, raw_denominator, result)
    return lines

def _final_20260415_fraction_mul_lines(step_number: int, left: Fraction, right: Fraction, result: Fraction) -> List[str]:
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} × {right_text} = {result_text}"]
    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)
    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)
    lines.extend(_final_20260415_fraction_mul_body_lines(left_fraction, right_fraction, result, left_work_text, right_work_text))
    return lines

def _final_20260415_fraction_div_lines(step_number: int, left: Fraction, right: Fraction, result: Fraction) -> List[str]:
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} ÷ {right_text} = {result_text}"]
    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)
    if right_fraction == 0:
        raise ZeroDivisionError('division by zero')
    reciprocal = Fraction(right_fraction.denominator, right_fraction.numerator)
    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)
    reciprocal_text = _final_20260415_format_fraction_value(reciprocal, force_fraction=True)
    lines.append('Чтобы разделить на дробь, первую дробь умножаем на дробь, обратную второй')
    lines.append(f"{left_work_text} ÷ {right_work_text} = {left_work_text} × {reciprocal_text}")
    lines.extend(_final_20260415_fraction_mul_body_lines(left_fraction, reciprocal, result, left_work_text, reciprocal_text))
    return lines

def _final_20260415_fraction_step_lines(step_number: int, step: dict) -> List[str]:
    operator = step['operator']
    left = step['left']
    right = step['right']
    result = step['result']
    if operator in {'+', '-'}:
        return _final_20260415_fraction_add_sub_lines(step_number, left, right, operator, result)
    if operator == '*':
        return _final_20260415_fraction_mul_lines(step_number, left, right, result)
    if operator == '/':
        return _final_20260415_fraction_div_lines(step_number, left, right, result)
    return [f"{step_number}) {_final_20260415_format_fraction_value(left)} {_final_20260415_fraction_op_symbol(operator)} {_final_20260415_format_fraction_value(right)} = {_final_20260415_format_fraction_value(result)}"]

def _final_20260415_fraction_answer_chain(root: dict, steps: List[dict], result: Fraction) -> str:
    solved: dict = {}
    chain: List[str] = [_final_20260415_render_fraction_node(root)]
    for step in steps:
        solved[step['id']] = _final_20260415_format_fraction_value(step['result'])
        current = _final_20260415_render_fraction_node(root, solved)
        if current and current != chain[-1]:
            chain.append(current)
    mixed_text = _fraction_school_mixed_text(result)
    if mixed_text and mixed_text != chain[-1]:
        chain.append(mixed_text)
    return ' = '.join(chain)

def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    source = _final_20260415_normalize_fraction_expression_source(raw_text)
    if not source:
        return None

    # Простые случаи вида 1/4+1/6 и 1/4-1/6 уже объясняются отдельным шаблоном.
    if re.fullmatch(r'\d+/\d+[+\-]\d+/\d+', source):
        return None

    try:
        root = _final_20260415_parse_fraction_expression(source)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')

    if not root:
        return None

    try:
        result, steps = _final_20260415_eval_fraction_steps(root)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')
    except Exception:
        return None

    if not steps:
        return None

    lines: List[str] = [
        f"Пример: {_final_20260415_render_fraction_node(root)}",
        'Решение.',
    ]
    for index, step in enumerate(steps, 1):
        lines.extend(_final_20260415_fraction_step_lines(index, step))
    lines.append(f"Ответ: {_final_20260415_fraction_answer_chain(root, steps, result)}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_20260415_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL USER PATCH 2026-04-15AB: order guide + full answer chain for mixed fraction expressions ---

_FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION = _audit_try_final_local_explanation

def _final_user_fraction_eval_steps_with_positions(node: dict) -> Tuple[Fraction, List[dict]]:
    node_type = node.get('type')
    if node_type == 'value':
        return node['value'], []
    if node_type == 'group':
        return _final_user_fraction_eval_steps_with_positions(node['inner'])
    if node_type == 'unary':
        operand_value, operand_steps = _final_user_fraction_eval_steps_with_positions(node['operand'])
        return (-operand_value if node.get('operator') == '-' else operand_value), operand_steps
    if node_type != 'binary':
        raise ValueError('Unsupported fraction expression node')

    operator = node.get('operator')
    chain_operators = ('+', '-') if operator in {'+', '-'} else ('*', '/')
    operands: List[dict] = []
    op_nodes: List[dict] = []
    _final_20260415_flatten_fraction_chain(node, chain_operators, operands, op_nodes)

    values: List[Fraction] = []
    steps: List[dict] = []
    for operand in operands:
        operand_value, operand_steps = _final_user_fraction_eval_steps_with_positions(operand)
        steps.extend(operand_steps)
        values.append(operand_value)

    current = values[0]
    for op_node, next_value in zip(op_nodes, values[1:]):
        result = _final_20260415_apply_fraction_operator(op_node['operator'], current, next_value)
        steps.append({
            'id': op_node['id'],
            'operator': op_node['operator'],
            'left': current,
            'right': next_value,
            'result': result,
            'index': op_node.get('pos', 0),
        })
        current = result

    return current, steps

def _final_user_fraction_order_lines(source: str, steps: List[dict]) -> List[str]:
    try:
        tokens = _final_20260415_tokenize_fraction_expression(source)
    except ZeroDivisionError:
        return []
    if not tokens or len(steps) < 2:
        return []

    pretty_expr = ''
    operator_positions: dict[int, int] = {}
    for token in tokens:
        token_type = token.get('type')
        if token_type == 'value':
            pretty_expr += token.get('text', '')
            continue
        if token_type in {'+', '-', '*', '/'}:
            operator_positions[token.get('pos', 0)] = len(pretty_expr) + 1
            pretty_expr += f" {_final_20260415_fraction_op_symbol(token_type)} "
            continue
        pretty_expr += token_type

    if not pretty_expr:
        return []

    marks = [' '] * len(pretty_expr)
    for step_index, step in enumerate(steps, 1):
        pretty_pos = operator_positions.get(step.get('index', 0))
        if pretty_pos is None:
            continue
        label = str(step_index)
        start = max(0, pretty_pos - (len(label) - 1) // 2)
        for offset, char in enumerate(label):
            target = start + offset
            if 0 <= target < len(marks):
                marks[target] = char

    return ['Порядок действий:', ''.join(marks).rstrip(), pretty_expr]

def _final_user_fraction_expanded_step_text(step: dict) -> Optional[str]:
    operator = step.get('operator')
    if operator not in {'+', '-'}:
        return None

    left = Fraction(step.get('left', Fraction(0, 1)))
    right = Fraction(step.get('right', Fraction(0, 1)))
    common = math.lcm(left.denominator, right.denominator)
    if not common or (left.denominator == common and right.denominator == common):
        return None

    left_multiplier = common // left.denominator
    right_multiplier = common // right.denominator
    left_scaled = left.numerator * left_multiplier
    right_scaled = right.numerator * right_multiplier
    symbol = '+' if operator == '+' else '-'
    return f"{left_scaled}/{common} {symbol} {right_scaled}/{common}"

def _final_user_fraction_answer_chain(root: dict, steps: List[dict], result: Fraction) -> str:
    solved: dict[int, str] = {}
    chain: List[str] = [_final_20260415_render_fraction_node(root)]

    for step in steps:
        expanded = _final_user_fraction_expanded_step_text(step)
        if expanded:
            solved[step['id']] = expanded
            expanded_view = _final_20260415_render_fraction_node(root, solved)
            if expanded_view and expanded_view != chain[-1]:
                chain.append(expanded_view)

        solved[step['id']] = _final_20260415_format_fraction_value(step['result'])
        current = _final_20260415_render_fraction_node(root, solved)
        if current and current != chain[-1]:
            chain.append(current)

    mixed_text = _fraction_school_mixed_text(result)
    if mixed_text and mixed_text != chain[-1]:
        chain.append(mixed_text)
    return ' = '.join(chain)

def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    source = _final_20260415_normalize_fraction_expression_source(raw_text)
    if not source:
        return None

    if re.fullmatch(r'\d+/\d+[+\-]\d+/\d+', source):
        return None

    try:
        root = _final_20260415_parse_fraction_expression(source)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')

    if not root:
        return None

    try:
        result, steps = _final_user_fraction_eval_steps_with_positions(root)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')
    except Exception:
        return None

    if not steps:
        return None

    lines: List[str] = [f"Пример: {_final_20260415_render_fraction_node(root)}"]
    if len(steps) > 1:
        lines.extend(_final_user_fraction_order_lines(source, steps))
        lines.append('Решение по действиям:')
    else:
        lines.append('Решение.')

    for index, step in enumerate(steps, 1):
        lines.extend(_final_20260415_fraction_step_lines(index, step))

    lines.append(f"Ответ: {_final_user_fraction_answer_chain(root, steps, result)}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL USER PATCH 2026-04-15AC: keep order-marker lines without trailing dot in mixed fraction expressions ---

_FINAL_USER_20260415AC_PREV_BUILD_FRACTION_MIXED = _build_fraction_mixed_expression_explanation

def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    text = _FINAL_USER_20260415AC_PREV_BUILD_FRACTION_MIXED(raw_text)
    if not text:
        return text
    return re.sub(r'(?m)^([0-9 ]+)\.$', r'\1', text)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL PATCH 2026-04-15AD: textbook word problems and simple systems ---

_FINAL_20260415AD_PREV_BUILD_EXPLANATION = build_explanation

def _final_20260415ad_prepare_word_text(raw_text: str) -> Tuple[str, str, List[int]]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    return text, lower, nums

def _final_20260415ad_result_dict(text: str, source: str = 'local-textbook-fix') -> dict:
    return {'result': text, 'source': source, 'validated': True}

def _final_20260415ad_try_garage_indirect_counts(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'автобус' not in lower or 'грузов' not in lower or 'легков' not in lower:
        return None
    if 'сколько всего' not in lower or 'гараж' not in lower:
        return None
    if 'это на' not in lower or 'больше, чем грузов' not in lower:
        return None
    if 'меньше, чем грузов' not in lower:
        return None

    buses, diff_to_trucks, diff_to_cars = nums[:3]
    trucks = buses - diff_to_trucks
    cars = trucks - diff_to_cars
    if min(buses, trucks, cars) < 0:
        return None
    total = buses + trucks + cars

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: автобусов {buses}. Это на {diff_to_trucks} больше, чем грузовых машин. Легковых машин на {diff_to_cars} меньше, чем грузовых.',
        'Что нужно найти: сколько всего машин в гараже.',
        f'1) Сначала найдём количество грузовых машин. Если автобусов на {diff_to_trucks} больше, чем грузовых, то грузовых на {diff_to_trucks} меньше: {buses} - {diff_to_trucks} = {trucks}.',
        f'2) Потом найдём количество легковых машин. Если легковых на {diff_to_cars} меньше, чем грузовых, то {trucks} - {diff_to_cars} = {cars}.',
        f'3) Теперь найдём, сколько всего машин в гараже: {buses} + {trucks} + {cars} = {total}.',
        f'Ответ: всего {total} машин.'
    )

def _final_20260415ad_try_times_more_and_equal_groups(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'разлож' not in lower and 'разложили' not in lower and 'поровну' not in lower:
        return None
    if 'в каждой' not in lower and 'в одной' not in lower:
        return None
    if 'в ' not in lower or 'раза больше' not in lower:
        return None
    if 'с другой' not in lower and 'со второй' not in lower:
        return None

    first, multiplier, groups = nums[:3]
    if multiplier <= 1 or groups <= 0:
        return None

    second = first * multiplier
    total = first + second
    if total % groups != 0:
        return None
    each = total // groups

    unit = 'кг'
    if 'литр' in lower:
        unit = 'л'
    elif 'книга' in lower:
        unit = 'книг'

    object_label = 'во второй группе'
    if 'яблок' in lower:
        object_label = 'со второй яблони'
    elif 'груш' in lower:
        object_label = 'со второй груши'

    container_label = 'в каждой корзине'
    if 'корзин' in lower:
        container_label = 'в каждой корзине'
    elif 'ящик' in lower:
        container_label = 'в каждом ящике'
    elif 'пакет' in lower:
        container_label = 'в каждом пакете'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: сначала получили {first} {unit}, потом ещё в {multiplier} раза больше, чем сначала. Всё разложили поровну в {groups} групп.',
        f'Что нужно найти: сколько {unit} {container_label}.',
        f'1) Сначала узнаем, сколько получилось {object_label}: {first} × {multiplier} = {second} {unit}.',
        f'2) Потом узнаем, сколько получилось всего: {first} + {second} = {total} {unit}.',
        f'3) Теперь делим всё поровну на {groups} групп: {total} : {groups} = {each} {unit}.',
        f'Ответ: {container_label} {each} {unit}.'
    )

def _final_20260415ad_try_each_brought_then_total(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'каждый' not in lower and 'каждая' not in lower and 'каждое' not in lower:
        return None
    if 'по' not in lower or 'стало' not in lower:
        return None
    if 'сколько' not in lower or 'было' not in lower:
        return None
    if not (('принес' in lower or 'принёс' in lower or 'принесли' in lower) and ('библиотек' in lower or 'книг' in lower)):
        return None

    people, per_person, total_after = nums[:3]
    added = people * per_person
    initial = total_after - added
    if min(people, per_person, total_after, initial) < 0:
        return None

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {people} учеников принесли по {per_person} книги, и после этого стало {total_after} книг.',
        'Что нужно найти: сколько книг было сначала.',
        f'1) Сначала найдём, сколько книг принесли ученики: {people} × {per_person} = {added}.',
        f'2) Потом найдём, сколько книг было в библиотеке сначала: {total_after} - {added} = {initial}.',
        f'Ответ: в библиотеке было {initial} книг.'
    )

def _final_20260415ad_try_first_day_second_more_remaining(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'в первый день' not in lower or 'во второй' not in lower:
        return None
    if 'на' not in lower or 'больше' not in lower:
        return None
    if 'осталось' not in lower and 'сколько тонн' not in lower and 'сколько осталось' not in lower:
        return None
    if not contains_any_fragment(lower, ('отправили', 'отправил', 'израсходовали', 'продали', 'увезли', 'вывезли')):
        return None

    total_before, first_day, diff = nums[:3]
    second_day = first_day + diff
    total_sent = first_day + second_day
    left = total_before - total_sent
    if min(total_before, first_day, second_day, total_sent, left) < 0:
        return None

    unit = 'т'
    if 'кг' in lower:
        unit = 'кг'
    elif 'мешк' in lower:
        unit = 'мешков'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: сначала было {total_before} {unit}. В первый день отправили {first_day} {unit}, а во второй день — на {diff} {unit} больше.',
        f'Что нужно найти: сколько {unit} осталось.',
        f'1) Сначала найдём, сколько отправили во второй день: {first_day} + {diff} = {second_day} {unit}.',
        f'2) Потом найдём, сколько отправили за два дня: {first_day} + {second_day} = {total_sent} {unit}.',
        f'3) Теперь найдём, сколько осталось: {total_before} - {total_sent} = {left} {unit}.',
        f'Ответ: осталось {left} {unit}.'
    )
