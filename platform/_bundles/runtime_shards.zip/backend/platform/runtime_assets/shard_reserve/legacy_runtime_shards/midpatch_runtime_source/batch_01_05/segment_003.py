"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 1704-2567."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_local_compound_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if not re.search(r"[а-я]", lower):
        return None
    numbers = extract_ordered_numbers(lower)
    if len(numbers) < 2:
        return None

    asks_total = asks_total_like(lower)
    asks_current = bool(re.search(r"сколько[^.?!]*\b(стало|теперь|осталось)\b", lower))
    asks_plain_quantity = "сколько" in lower and not asks_total and not asks_current and "на сколько" not in lower and "во сколько" not in lower
    asks_initial = "сколько было" in lower or "сколько было сначала" in lower or "сначала" in lower
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    multiple = has_multiple_questions(text)
    pairs_after_po = extract_pairs_after_po(lower)
    has_indirect_hint = bool(re.search(r"\b(?:это|что|он|она)\b[^.?!]{0,30}(?:на\s+\d+|в\s+\d+\s+раз(?:а)?)", lower))

    if len(pairs_after_po) == 2 and "сколько" in lower and ("покупк" in lower or "всего" in lower or "заплат" in lower):
        (count1, value1), (count2, value2) = pairs_after_po[0], pairs_after_po[1]
        return explain_sum_of_two_products_word_problem(count1, value1, count2, value2)

    if len(numbers) == 3 and contains_any_fragment(lower, ("таких же", "такие же")):
        unit = explain_bring_to_unit_total_word_problem(numbers[0], numbers[1], numbers[2])
        if unit:
            return unit

    if len(numbers) == 3 and asks_plain_quantity and ("несколько" in lower or "осталь" in lower):
        third = explain_find_third_addend_word_problem(numbers[0], numbers[1], numbers[2])
        if third:
            return third

    if len(numbers) == 3 and asks_initial and ("остал" in lower or "осталось" in lower) and contains_any_fragment(lower, WORD_LOSS_HINTS):
        initial = explain_initial_from_taken_and_left_word_problem(numbers[0], numbers[1], numbers[2])
        if initial:
            return initial

    if len(numbers) == 2 and len(relation_pairs) == 1 and "столько, сколько" in lower:
        delta, mode = relation_pairs[0]
        if delta == numbers[1]:
            second = apply_more_less(numbers[0], delta, mode)
            if second is not None:
                third = numbers[0] + second
                if multiple and asks_total:
                    total = numbers[0] + second + third
                    return join_explanation_lines(
                        f"Сначала находим маки: {numbers[0]} {'+' if mode == 'больше' else '-'} {delta} = {second}",
                        f"Потом находим астры: {numbers[0]} + {second} = {third}",
                        f"Теперь находим все цветы: {numbers[0]} + {second} + {third} = {total}",
                        f"Ответ: астр — {third}; всего — {total}",
                        "Совет: если сказано «столько, сколько вместе», сначала найди сумму этих частей",
                    )
                return join_explanation_lines(
                    f"Сначала находим второе количество: {numbers[0]} {'+' if mode == 'больше' else '-'} {delta} = {second}",
                    f"Потом находим третье количество: {numbers[0]} + {second} = {third}",
                    f"Ответ: {third}",
                    "Совет: если сказано «столько, сколько вместе», сначала найди сумму этих частей",
                )

    if len(numbers) == 3 and asks_total and len(relation_pairs) == 2:
        (delta1, mode1), (delta2, mode2) = relation_pairs
        if delta1 == numbers[1] and delta2 == numbers[2]:
            chain = explain_relation_chain_total_word_problem(numbers[0], delta1, mode1, delta2, mode2)
            if chain:
                return chain

    if len(numbers) == 3 and len(scale_pairs) == 2 and asks_total:
        (factor1, mode1), (factor2, mode2) = scale_pairs
        if factor1 == numbers[1] and factor2 == numbers[2]:
            chain = explain_relation_chain_times_total_word_problem(numbers[0], factor1, mode1, factor2, mode2)
            if chain:
                return chain

    if len(numbers) == 2 and len(relation_pairs) == 1 and not has_indirect_hint:
        delta, mode = relation_pairs[0]
        if delta == numbers[1]:
            if multiple and asks_total:
                rel = explain_related_quantity_and_total_word_problem(numbers[0], delta, mode)
                if rel:
                    return rel
            if asks_total:
                rel = explain_related_total_word_problem(numbers[0], delta, mode)
                if rel:
                    return rel
            if asks_plain_quantity:
                rel = explain_related_quantity_word_problem(numbers[0], delta, mode)
                if rel:
                    return rel

    if len(numbers) == 2 and len(scale_pairs) == 1 and not has_indirect_hint:
        factor, mode = scale_pairs[0]
        if factor == numbers[1]:
            if multiple and asks_total:
                rel = explain_related_quantity_and_total_times_word_problem(numbers[0], factor, mode)
                if rel:
                    return rel
            if asks_total:
                rel = explain_related_total_times_word_problem(numbers[0], factor, mode)
                if rel:
                    return rel
            if asks_plain_quantity:
                rel = explain_related_quantity_times_word_problem(numbers[0], factor, mode)
                if rel:
                    return rel

    if len(numbers) == 3 and (asks_total or asks_current):
        fragments = re.split(r"\d+", lower)
        if len(fragments) >= 4:
            first_following, second_leading = split_between_change_fragment(fragments[2])
            first_mode = classify_change_fragment(fragments[1]) or classify_change_fragment(first_following)
            second_mode = classify_change_fragment(second_leading) or classify_change_fragment(fragments[3])
            if first_mode and second_mode:
                mid = numbers[0] + numbers[1] if first_mode == "gain" else numbers[0] - numbers[1]
                end = mid + numbers[2] if second_mode == "gain" else mid - numbers[2]
                return join_explanation_lines(
                    f"Сначала меняем число первый раз: {numbers[0]} {'+' if first_mode == 'gain' else '-'} {numbers[1]} = {mid}",
                    f"Потом меняем число второй раз: {mid} {'+' if second_mode == 'gain' else '-'} {numbers[2]} = {end}",
                    f"Ответ: {end}",
                    "Совет: если в задаче два изменения, считай их по порядку",
                )

    if len(numbers) == 3 and asks_total and ("по" in lower) and ("еще" in lower or "ещё" in lower or "отдельно" in lower):
        groups_match = re.search(r"\b(?:в|на)?\s*(\d+)\s+[а-я]+\s+по\s+(\d+)\b", lower)
        if groups_match:
            groups = int(groups_match.group(1))
            per_group = int(groups_match.group(2))
            remaining = list(numbers)
            for value in (groups, per_group):
                if value in remaining:
                    remaining.remove(value)
            if len(remaining) == 1:
                return explain_groups_plus_extra_word_problem(groups, per_group, remaining[0])
    return None

def try_local_indirect_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None

    asks_total = asks_total_like(lower)
    multiple = has_multiple_questions(text)
    base, delta_or_factor = nums

    match = re.search(r"(?:это|что|он|она)\s+на\s+(\d+)(?:\s+[а-я]+){0,4}\s+(старше|младше|больше|меньше)", lower)
    if match and int(match.group(1)) == delta_or_factor:
        relation = match.group(2)
        if asks_total and multiple:
            return explain_indirect_plus_minus_total_problem(base, delta_or_factor, relation)
        return explain_indirect_plus_minus_problem(base, delta_or_factor, relation)

    match = re.search(r"(?:это|что)\s+(старше|младше|больше|меньше).*?на\s+(\d+)", lower)
    if match and int(match.group(2)) == delta_or_factor:
        relation = match.group(1)
        if asks_total and multiple:
            return explain_indirect_plus_minus_total_problem(base, delta_or_factor, relation)
        return explain_indirect_plus_minus_problem(base, delta_or_factor, relation)

    match = re.search(r"(?:это|что|он|она)\s+в\s+(\d+)\s+раз(?:а)?\s+(больше|меньше)", lower)
    if match and int(match.group(1)) == delta_or_factor:
        relation = match.group(2)
        if asks_total and multiple:
            return explain_indirect_times_total_problem(base, delta_or_factor, relation)
        return explain_indirect_times_problem(base, delta_or_factor, relation)
    return None

def try_local_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if not re.search(r"[а-я]", lower):
        return None
    numbers = extract_ordered_numbers(lower)
    if len(numbers) != 2:
        return None

    first, second = numbers
    per_group_match = re.search(r"\bпо\s+(\d+)\b", lower)
    per_group = int(per_group_match.group(1)) if per_group_match else None
    other_numbers = list(numbers)
    if per_group is not None and per_group in other_numbers:
        other_numbers.remove(per_group)
    other_value = other_numbers[0] if other_numbers else None

    asks_ratio = "во сколько" in lower and ("больше" in lower or "меньше" in lower)
    asks_compare = contains_any_fragment(lower, WORD_COMPARISON_HINTS) or ("на сколько" in lower and ("больше" in lower or "меньше" in lower))
    asks_initial = "сколько было" in lower
    asks_left = bool(re.search(r"сколько[^.?!]*\bосталось\b", lower))
    asks_now = bool(re.search(r"сколько[^.?!]*\b(стало|теперь)\b", lower))
    asks_total = asks_total_like(lower)
    asks_each = "кажд" in lower or "поровну" in lower
    asks_added = contains_any_fragment(lower, ("сколько добав", "сколько подар", "сколько куп", "сколько прин", "сколько полож"))
    asks_removed = contains_any_fragment(lower, ("сколько отдал", "сколько съел", "сколько убрал", "сколько забрал", "сколько потрат", "сколько продал", "сколько потер"))
    asks_groups = contains_any_fragment(lower, ("сколько короб", "сколько корзин", "сколько пакет", "сколько ряд", "сколько групп", "сколько ящик", "сколько сет"))
    asks_remainder = "остат" in lower or "сколько остан" in lower or "полных" in lower
    needs_extra_group = contains_any_fragment(lower, ("нужно", "нужны", "понадоб", "потребует"))
    has_gain = contains_any_fragment(lower, WORD_GAIN_HINTS)
    has_loss = contains_any_fragment(lower, WORD_LOSS_HINTS)
    has_grouping = contains_any_fragment(lower, GROUPING_VERBS)
    scale_pairs = extract_scale_pairs(lower)

    if "осталь" in lower and asks_compare:
        total = max(first, second)
        part = min(first, second)
        comparison = explain_compare_from_total_and_part_word_problem(total, part)
        if comparison:
            return comparison

    if "осталь" in lower and "сколько" in lower:
        total = max(first, second)
        part = min(first, second)
        other = explain_other_from_total_and_part_word_problem(total, part)
        if other:
            return other

    if asks_ratio:
        ratio = explain_ratio_word_problem(first, second)
        if ratio:
            return ratio

    relation_pairs = extract_relation_pairs(lower)
    if relation_pairs:
        return None

    if asks_compare:
        return explain_comparison_word_problem(first, second)

    if asks_initial and has_loss:
        return explain_find_initial_after_loss_problem(first, second)

    if asks_initial and has_gain:
        explanation = explain_find_initial_after_gain_problem(max(first, second), min(first, second))
        return explanation or None

    if asks_added:
        return explain_find_added_problem(first, second)

    if asks_removed:
        return explain_find_removed_problem(first, second)

    if asks_each:
        bigger = max(first, second)
        smaller = min(first, second)
        share = explain_sharing_word_problem(bigger, smaller)
        if share:
            return share

    if scale_pairs and len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        if factor == second and "во сколько" not in lower and "это" not in lower and " что " not in f" {lower} " and " он " not in f" {lower} " and " она " not in f" {lower} ":
            if "по" not in lower and not asks_total and "сколько" in lower:
                return explain_related_quantity_times_word_problem(first, factor, mode)

    if "по" in lower and (asks_groups or has_grouping):
        total = other_value if other_value is not None and per_group is not None else first
        size = per_group if per_group is not None else second
        grouped = explain_group_count_word_problem(total, size, needs_extra_group=needs_extra_group, explicit_remainder=asks_remainder)
        if grouped:
            return grouped

    if "по" in lower and asks_total:
        groups = other_value if other_value is not None and per_group is not None else first
        size = per_group if per_group is not None else second
        return explain_multiplication_word_problem(groups, size)

    if has_loss and (asks_left or asks_now):
        explanation = explain_subtraction_word_problem(first, second)
        return explanation or None
    if (has_gain and (asks_total or asks_now)) or (asks_total and not has_loss and "по" not in lower):
        return explain_addition_word_problem(first, second)

    if contains_any_fragment(lower, ("нашел", "нашёл", "всего")) and "сколько" in lower:
        bigger = max(first, second)
        smaller = min(first, second)
        if bigger - smaller >= 0:
            return join_explanation_lines(
                "Нужно найти неизвестное слагаемое",
                f"Из суммы вычитаем известное слагаемое: {bigger} - {smaller} = {bigger - smaller}",
                f"Ответ: {bigger - smaller}",
                "Совет: неизвестное слагаемое находим вычитанием",
            )
    return None



# --- PATCH: enhanced primary school methods ---

SYSTEM_PROMPT = """
Ты — спокойный, очень понятный и точный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Каждая строка — одна законченная полезная мысль.

Формат ответа:
Для текстовой задачи сначала дай 1–2 строки:
"Что известно: ..."
"Что нужно найти: ..."
Потом решай по действиям, лучше нумерованными шагами: 1), 2), 3)...
Не пропускай промежуточные вычисления.
Если это уравнение, после решения обязательно дай строку "Проверка: ...".
Потом строка "Ответ: ...".
Последняя строка "Совет: ...".

Общие правила:
Не называй готовый ответ в первой строке.
Не меняй числа из условия и не добавляй свои данные.
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Если в задаче два вопроса, ответь на оба по порядку в одной строке "Ответ: ...; ...".
Совет должен быть коротким, школьным и полезным.

Как объяснять:
Для текстовой задачи сначала выдели условие и вопрос.
Если нельзя сразу ответить на главный вопрос, скажи, что нужно узнать сначала.
Решай задачу по действиям.
После каждого действия пиши, что именно нашли.
Каждое вычисление записывай полностью.

Используй школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу сначала найди скорость сближения.
При движении в противоположных направлениях сначала найди скорость удаления.
Если это выражение, сначала назови порядок действий.
Если это уравнение, оставляй x отдельно и объясняй обратное действие.
Если это дроби, сначала смотри на знаменатели.
Если это геометрия, сначала назови формулу, потом подставь числа.
Если это именованные величины, сначала переведи их в одинаковые единицы.

Используй школьные приёмы:
сложение через десяток — разложи число так, чтобы сначала получить 10;
вычитание через десяток — вычитай по частям через 10;
двузначные числа раскладывай на десятки и единицы;
если числа большие, объясняй по разрядам;
для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

BODY_LIMITS = {
    "expression": 12,
    "equation": 8,
    "fraction": 10,
    "geometry": 12,
    "word": 16,
    "other": 10,
}

SMALL_NUMBER_WORDS = {
    "ноль": 0,
    "один": 1,
    "одна": 1,
    "одно": 1,
    "два": 2,
    "две": 2,
    "три": 3,
    "четыре": 4,
    "пять": 5,
    "шесть": 6,
    "семь": 7,
    "восемь": 8,
    "девять": 9,
    "десять": 10,
}
_NUMBER_WORD_PATTERN = "|".join(sorted((re.escape(word) for word in SMALL_NUMBER_WORDS), key=len, reverse=True))

_COMMON_FRACTION_PATTERNS = [
    (re.compile(r"\bполовин(?:а|у|ы|е|ой)\b", re.IGNORECASE), "1/2"),
    (re.compile(r"\bтреть\b|\bтретью\s+часть\b|\bтретьей\s+части\b", re.IGNORECASE), "1/3"),
    (re.compile(r"\bчетверть\b|\bчетвертую\s+часть\b|\bчетвертой\s+части\b", re.IGNORECASE), "1/4"),
    (re.compile(r"\bпятую\s+часть\b|\bпятой\s+части\b", re.IGNORECASE), "1/5"),
    (re.compile(r"\bшестую\s+часть\b|\bшестой\s+части\b", re.IGNORECASE), "1/6"),
    (re.compile(r"\bседьмую\s+часть\b|\bседьмой\s+части\b", re.IGNORECASE), "1/7"),
    (re.compile(r"\bвосьмую\s+часть\b|\bвосьмой\s+части\b", re.IGNORECASE), "1/8"),
    (re.compile(r"\bдевятую\s+часть\b|\bдевятой\s+части\b", re.IGNORECASE), "1/9"),
    (re.compile(r"\bдесятую\s+часть\b|\bдесятой\s+части\b", re.IGNORECASE), "1/10"),
]

def parse_number_token(token: str) -> Optional[int]:
    value = str(token or "").strip().lower().replace("ё", "е")
    if not value:
        return None
    if value.isdigit():
        return int(value)
    return SMALL_NUMBER_WORDS.get(value)

def extract_number_values_before_units(text: str, unit_pattern: str) -> List[int]:
    values: List[int] = []
    for match in re.finditer(fr"(\d+|{_NUMBER_WORD_PATTERN})\s*(?:{unit_pattern})\b", str(text or "").lower()):
        value = parse_number_token(match.group(1))
        if value is not None:
            values.append(value)
    return values

def replace_common_fraction_words(text: str) -> str:
    cleaned = str(text or "")
    for pattern, replacement in _COMMON_FRACTION_PATTERNS:
        cleaned = pattern.sub(replacement, cleaned)
    return cleaned

def extract_all_fraction_pairs(text: str) -> List[Tuple[int, int]]:
    return [(int(a), int(b)) for a, b in re.findall(r"(\d+)\s*/\s*(\d+)", str(text or ""))]

def extract_non_fraction_numbers(text: str) -> List[int]:
    base = re.sub(r"\d+\s*/\s*\d+", " ", str(text or ""))
    return extract_ordered_numbers(base)

def add_task_context_lines(text: str, raw_text: str, kind: str) -> str:
    if kind not in {"word", "geometry"} and not (kind == "fraction" and re.search(r"[А-Яа-я]", str(raw_text or ""))):
        return text
    lines = [line.strip() for line in str(text or "").split("\n") if line.strip()]
    lowered = [line.lower() for line in lines]
    if any(line.startswith("что известно:") or line.startswith("известно:") for line in lowered):
        return text
    condition, question = extract_condition_and_question(raw_text)
    prefix: List[str] = []
    if condition:
        prefix.append(f"Что известно: {condition}")
    if question:
        prefix.append(f"Что нужно найти: {question}")
    if not prefix:
        return text
    return join_explanation_lines(*prefix, *lines)



def explain_fraction_part_and_remaining(total: int, numerator: int, denominator: int, remaining_label: str = "осталось") -> Optional[str]:
    if denominator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    part = one_part * numerator
    remaining = total - part
    return join_explanation_lines(
        f"Сначала находим одну долю: {total} : {denominator} = {one_part}",
        f"Потом находим {numerator}/{denominator} числа: {one_part} × {numerator} = {part}",
        f"Теперь находим, сколько {remaining_label}: {total} - {part} = {remaining}",
        f"Ответ: {remaining}",
        "Совет: чтобы найти остаток после дробной части, сначала найди эту часть",
    )













def explain_bag_counts_from_mass_difference(first_mass: int, second_mass: int, diff_bags: int, first_name: str = "первого", second_name: str = "второго") -> Optional[str]:
    diff_mass = abs(second_mass - first_mass)
    if diff_bags == 0 or diff_mass % diff_bags != 0:
        return None
    per_bag = diff_mass // diff_bags
    if per_bag == 0 or first_mass % per_bag != 0 or second_mass % per_bag != 0:
        return None
    first_count = first_mass // per_bag
    second_count = second_mass // per_bag
    return join_explanation_lines(
        f"Сначала находим разность масс: {max(first_mass, second_mass)} - {min(first_mass, second_mass)} = {diff_mass}",
        f"Эта разность приходится на {diff_bags} мешков, значит в одном мешке: {diff_mass} : {diff_bags} = {per_bag}",
        f"Теперь находим количество мешков {first_name} урожая: {first_mass} : {per_bag} = {first_count}",
        f"И количество мешков {second_name} урожая: {second_mass} : {per_bag} = {second_count}",
        f"Ответ: {first_count}; {second_count}",
        "Совет: в задачах по двум разностям сначала находят, чему соответствует одна равная часть",
    )











def try_local_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower()
    fracs = extract_all_fraction_pairs(lower)
    values = extract_non_fraction_numbers(lower)
    if not fracs:
        return None

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower):
        total = max(values) if values else None
        if total is not None:
            solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
            if solved:
                return solved

    if len(fracs) == 1:
        numerator, denominator = fracs[0]

        if ("израсход" in lower or "потрат" in lower) and "остал" in lower and values:
            remaining_value = max(values)
            solved = explain_whole_by_remaining_fraction(remaining_value, numerator, denominator)
            if solved:
                return solved

        if re.search(r"это\s+\d+\s*/\s*\d+\s+(?:всего\s+)?", lower) and values:
            part_value = max(values)
            return explain_number_by_fraction_word_problem(part_value, numerator, denominator)

        if ("во 2 день" in lower or "во второй день" in lower or "остал" in lower) and values:
            total = max(values)
            solved = explain_second_part_after_fraction(total, numerator, denominator)
            if solved:
                return solved

        if contains_any_fragment(lower, ("сколько потрат", "сколько выпил", "сколько израсход", "сколько взяли", "сколько состав", "сколько железа")) and values:
            total = max(values)
            return explain_fraction_of_number_word_problem(total, numerator, denominator, ask_remaining=False)

        if "остал" in lower and values:
            total = max(values)
            solved = explain_fraction_part_and_remaining(total, numerator, denominator)
            if solved:
                return solved

        if "сколько" in lower and values:
            total = max(values)
            if contains_any_fragment(lower, ("всего", "какое расстояние", "какова длина", "какое число")) and re.search(r"это\s+\d+\s*/\s*\d+", lower):
                return explain_number_by_fraction_word_problem(total, numerator, denominator)
            return explain_fraction_of_number_word_problem(total, numerator, denominator, ask_remaining=False)
    return None

def try_local_motion_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 1 and not re.search(_NUMBER_WORD_PATTERN, lower):
        return None

    distance_unit = "км" if "км" in lower else "м" if re.search(r"\bм\b", lower) else ""
    time_unit = "ч" if re.search(r"\bч\b|час", lower) else "мин" if "мин" in lower else ""
    speed_unit = "км/ч" if "км/ч" in lower else "м/с" if "м/с" in lower else ("м/мин" if "м/мин" in lower else ("км/ч" if distance_unit == "км" and time_unit == "ч" else ""))

    speed_values = [int(v) for v in re.findall(r"(\d+)\s*(?:км/ч|м/с|м/мин)", lower)] or [int(v) for v in re.findall(r"скорост[ьяию][^\d]{0,20}(\d+)", lower)]
    distance_values = [int(v) for v in re.findall(r"(\d+)\s*(?:км|м)(?!/)", lower)]
    time_values = extract_number_values_before_units(lower, r"ч|час(?:а|ов)?|мин(?:ут[аы]?)?")

    through_match = re.search(fr"через\s+(\d+|{_NUMBER_WORD_PATTERN})\s*(?:ч|час(?:а|ов)?|мин(?:ут[аы]?)?)", lower)
    through_value = parse_number_token(through_match.group(1)) if through_match else None
    speed_delta_match = re.search(r"на\s+(\d+)\s*км/ч\s+(больше|меньше)", lower)

    if "навстречу" in lower and "расстояние между" in lower and "до встречи" in lower:
        total_match = re.search(r"расстояние между[^\d]{0,40}(\d+)", lower)
        path_match = re.search(r"прош[её]л[^\d]{0,20}(\d+)\s*(?:км|м)", lower)
        if total_match and path_match and speed_values:
            total_distance = int(total_match.group(1))
            first_path = int(path_match.group(1))
            solved = explain_meeting_other_speed_word_problem(total_distance, speed_values[0], first_path, distance_unit, speed_unit)
            if solved:
                return solved

    if "в противоположных направлениях" in lower and through_value is not None and "расстояние между" in lower:
        distance_match = re.search(r"расстояние между[^\d]{0,40}(\d+)", lower)
        first_speed_match = re.search(r"скорост[ьяию] первого[^\d]{0,20}(\d+)", lower)
        first_speed = int(first_speed_match.group(1)) if first_speed_match else (speed_values[0] if speed_values else None)
        if distance_match and first_speed is not None:
            solved = explain_opposite_other_speed_word_problem(int(distance_match.group(1)), through_value, first_speed, speed_unit)
            if solved:
                return solved

    if "навстречу" in lower and through_value is not None and speed_delta_match and speed_values:
        delta = int(speed_delta_match.group(1))
        mode = speed_delta_match.group(2)
        solved = explain_meeting_distance_with_related_speed_word_problem(through_value, speed_values[0], delta, mode, distance_unit)
        if solved:
            return solved

    if "навстречу" in lower and len(speed_values) >= 2 and through_value is not None and not speed_delta_match:
        return explain_meeting_motion(speed_values[0], speed_values[1], through_value, distance_unit)
    if "в противоположных направлениях" in lower and len(speed_values) >= 2 and through_value is not None and not speed_delta_match:
        return explain_opposite_motion(speed_values[0], speed_values[1], through_value, distance_unit)
    if contains_any_fragment(lower, ("догонит", "догонку")) and len(nums) >= 2:
        return explain_catch_up_motion(nums[0], nums[1], time_unit or "ч")

    asks_distance = contains_any_fragment(lower, ("какое расстояние", "сколько километров", "какое расстояние пройдет", "какое расстояние он пройдет"))
    asks_speed = contains_any_fragment(lower, ("с какой скоростью", "какова скорость"))
    asks_time = contains_any_fragment(lower, ("сколько часов", "сколько времени", "за какое время"))

    if asks_time and len(speed_values) >= 2 and time_values:
        solved = explain_trip_time_for_same_distance(speed_values[0], time_values[0], speed_values[1])
        if solved and contains_any_fragment(lower, ("велосипедист", "тот же путь", "этот путь", "до посёлка", "до поселка")):
            return solved

    if asks_time and len(distance_values) >= 1 and len(speed_values) >= 2 and time_values and ("за два дня" in lower or "во второй" in lower):
        total_distance = max(distance_values)
        solved = explain_second_day_motion_time(total_distance, speed_values[0], time_values[0], speed_values[1])
        if solved:
            return solved

    if asks_speed and len(distance_values) >= 1 and speed_values and len(time_values) >= 2 and "остальную часть пути" in lower:
        total_distance = max(distance_values)
        solved = explain_remaining_part_speed(total_distance, speed_values[0], time_values[0], time_values[1])
        if solved:
            return solved

    faster_match = re.search(r"в\s+(\d+)\s+раз(?:а)?\s+быстре[её]", lower)
    if asks_time and faster_match and distance_values and speed_values and "обратно" in lower:
        factor = int(faster_match.group(1))
        solved = explain_return_trip_time_by_faster_speed(distance_values[0], speed_values[0], factor)
        if solved:
            return solved

    if asks_distance and speed_values and time_values:
        return explain_simple_motion_distance(speed_values[0], time_values[0], distance_unit)
    if asks_speed and distance_values and time_values:
        return explain_simple_motion_speed(distance_values[0], time_values[0], speed_unit)
    if asks_time and distance_values and speed_values:
        return explain_simple_motion_time(distance_values[0], speed_values[0], time_unit or "ч")
    return None

def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)

    if len(nums) >= 4 and "за всю покупку заплатили" in lower and "по" in lower and contains_any_fragment(lower, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        solved = explain_unknown_red_price(nums[0], nums[1], nums[2], nums[3])
        if solved:
            return solved

    if len(nums) == 2 and contains_any_fragment(lower, ("сколько стоит 1", "сколько стоит одна", "сколько стоит один", "сколько стоит 1 ")):
        solved = explain_simple_price_per_item(nums[0], nums[1])
        if solved:
            return solved

    if len(nums) == 2 and contains_any_fragment(lower, ("сколько стоят", "сколько стоила вся покупка", "сколько стоит вся покупка")):
        return explain_simple_total_cost(nums[0], nums[1])

    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    if contains_any_fragment(lower, ("сколько таких коробок", "сколько можно купить", "сколько коробок можно купить")):
        return explain_price_quantity_cost_problem(nums[0], nums[1], nums[2])
    return None

def try_local_sum_and_divide_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None

    if "в каждой клетке" in lower and "всего" in lower:
        solved = explain_cages_with_two_parts(nums[0], nums[1], nums[-1])
        if solved:
            return solved

    if contains_any_fragment(lower, ("сколько корзин", "сколько пакетов", "сколько булочек", "сколько клеток", "сколько потребуется", "сколько потребовалось")):
        if "по" in lower or "стоит" in lower or "поровну" in lower:
            solved = explain_sum_then_divide_word_problem(nums[0], nums[1], nums[2])
            if solved:
                return solved
    return None

def try_local_proportional_division_word_problem(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None

    if contains_any_fragment(lower, ("цена наборов одинаковая", "цена одинаковая", "если цена наборов одинаковая", "если цена одинаковая")):
        counts = nums[:2]
        total = nums[-1]
        solved = explain_equal_rate_distribution(total, counts[0], counts[1], "первую часть", "вторую часть")
        if solved:
            return solved

    if "бригада" in lower and contains_any_fragment(lower, ("сколько деталей изготовила каждая", "сколько деталей изготовила каждая бригада")):
        total = max(nums)
        counts = [n for n in nums if n != total]
        if len(counts) >= 2:
            solved = explain_equal_rate_distribution(total, counts[0], counts[1], "первая бригада", "вторая бригада")
            if solved:
                return solved

    if re.search(r"в двух кусках\s+\d+\s*м", lower) and contains_any_fragment(lower, ("сколько метров", "сколько м")):
        total_length_match = re.search(r"в двух кусках\s+(\d+)\s*м", lower)
        if total_length_match and len(nums) >= 3:
            total_length = int(total_length_match.group(1))
            costs = [n for n in nums if n != total_length]
            if len(costs) >= 2:
                solved = explain_piece_lengths_from_total_and_costs(total_length, costs[0], costs[1])
                if solved:
                    return solved
    return None

def try_local_difference_unknown_word_problem(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None

    if contains_any_fragment(lower, ("мешков больше", "мешков меньше")) and "кг" in lower and len(nums) >= 3:
        first_name = "моркови" if "морков" in lower else "первого"
        second_name = "картофеля" if "картоф" in lower else "второго"
        solved = explain_bag_counts_from_mass_difference(nums[0], nums[1], nums[2], first_name, second_name)
        if solved:
            return solved

    if contains_any_fragment(lower, ("на 360 кг меньше", "на 360 кг больше", "на 240 рублей дороже", "на 240 руб", "на 240 долларов дороже")) and "мешков" in lower:
        solved = explain_masses_from_bag_difference(nums[0], nums[1], nums[2])
        if solved:
            return solved

    if "ведром" in lower and contains_any_fragment(lower, ("одинаковое количество ходок", "одинаковое количество", "одинаковое число ходок")):
        big_bucket = max(nums[0], nums[1])
        small_bucket = min(nums[0], nums[1])
        diff_total = nums[2]
        solved = explain_water_buckets_difference(big_bucket, small_bucket, diff_total)
        if solved:
            return solved

    if "кус" in lower and contains_any_fragment(lower, ("дороже", "дешевле")) and len(nums) >= 3:
        solved = explain_costs_from_length_difference(nums[0], nums[1], nums[2])
        if solved:
            return solved
    return None

def try_local_measurement_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    window_match = re.search(r"высота окна\s+(\d+)\s*м[^\d]{0,30}ширина\s+(\d+)\s*м\s*(\d+)\s*дм", lower)
    if window_match and "площад" in lower:
        height_m = int(window_match.group(1))
        width_m = int(window_match.group(2))
        width_dm = int(window_match.group(3))
        height_in_dm = height_m * 10
        width_in_dm = width_m * 10 + width_dm
        area = height_in_dm * width_in_dm
        return join_explanation_lines(
            f"Сначала переводим высоту в дециметры: {height_m} м = {height_in_dm} дм",
            f"Потом переводим ширину в дециметры: {width_m} м {width_dm} дм = {width_in_dm} дм",
            f"Теперь находим площадь окна: {height_in_dm} × {width_in_dm} = {area}",
            f"Ответ: {area} дм²",
            "Совет: перед вычислением площади переводи длину и ширину в одинаковые единицы",
        )

    thickness_match = re.search(r"толщина стены\s+(\d+)\s*см", lower)
    frame_match = re.search(r"рама[^\d]{0,40}в\s+(\d+)\s+раз(?:а)?\s+тоньше", lower)
    glass_match = re.search(r"стекл[^\d]{0,40}в\s+(\d+)\s+раз(?:а)?\s+тоньше", lower)
    if thickness_match and frame_match and glass_match and "мм" in lower:
        wall_cm = int(thickness_match.group(1))
        frame_factor = int(frame_match.group(1))
        glass_factor = int(glass_match.group(1))
        if frame_factor != 0 and wall_cm % frame_factor == 0:
            frame_cm = wall_cm // frame_factor
            frame_mm = frame_cm * 10
            if glass_factor != 0 and frame_mm % glass_factor == 0:
                glass_mm = frame_mm // glass_factor
                return join_explanation_lines(
                    f"Сначала находим толщину рамы: {wall_cm} : {frame_factor} = {frame_cm} см",
                    f"Потом переводим толщину рамы в миллиметры: {frame_cm} см = {frame_mm} мм",
                    f"Теперь находим толщину стекла: {frame_mm} : {glass_factor} = {glass_mm} мм",
                    f"Ответ: {glass_mm} мм",
                    "Совет: если в ответе нужна другая единица длины, сначала сделай перевод единиц",
                )
    return None




# --- PATCH: detail fixes ---









def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)

    if len(nums) >= 4 and "за всю покупку заплатили" in lower and "по" in lower and contains_any_fragment(lower, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        solved = explain_unknown_red_price(nums[0], nums[1], nums[2], nums[3])
        if solved:
            return solved

    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоит 1", "сколько стоит одна", "сколько стоит один", "сколько стоит 1 ")):
        solved = explain_simple_price_per_item(nums[0], nums[1])
        if solved:
            return solved

    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоят", "сколько стоила вся покупка", "сколько стоит вся покупка")):
        return explain_simple_total_cost(nums[0], nums[1])

    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    if contains_any_fragment(lower, ("сколько таких коробок", "сколько можно купить", "сколько коробок можно купить")):
        return explain_price_quantity_cost_problem(nums[0], nums[1], nums[2])
    return None

# --- PATCH: context extraction fixes ---

# --- FINAL PATCH: detailed school-style formatting, safer fallback, richer step output ---

DEEPSEEK_API_KEY = (os.environ.get("myapp_ai_math_1_4_API_key") or "").strip()
