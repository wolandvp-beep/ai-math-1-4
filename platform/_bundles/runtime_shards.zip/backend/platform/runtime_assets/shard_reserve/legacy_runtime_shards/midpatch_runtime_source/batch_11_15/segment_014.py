"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 11396-12292."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _audit_try_common_word_problems(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    numbers = extract_ordered_numbers(lower)
    if len(numbers) < 2:
        return None

    first_noun = _audit_extract_first_quantity_noun(text)
    asked_noun = _audit_extract_question_noun(text)

    if ('сначала' in lower or 'было сначала' in lower) and 'стало' in lower and any(stem in lower for stem in WORD_GAIN_HINTS):
        added_match = re.search(r"добав[а-я]*\s*(\d+)", lower)
        total_match = re.search(r"стало\s*(\d+)", lower)
        if added_match and total_match:
            added = int(added_match.group(1))
            total = int(total_match.group(1))
            initial = total - added
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: добавили {added}, стало {total}.",
                "Что нужно найти: сколько было сначала.",
                f"1) После того как добавили {added}, стало {total}.",
                f"2) Чтобы узнать, сколько было сначала, из {total} вычитаем {added}: {total} - {added} = {initial}.",
                f"Ответ: {initial}"
            )

    if any(verb in lower for verb in GROUPING_VERBS) and 'по' in lower and 'сколько' in lower and 'в каждом' not in lower:
        match = re.search(r"(\d+)[^\d]{0,40}по\s*(\d+)", lower)
        if match:
            total = int(match.group(1))
            per_group = int(match.group(2))
            if per_group == 0:
                return None
            groups = Fraction(total, per_group)
            answer_noun = asked_noun or 'групп'
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: всего {total}{(' ' + first_noun) if first_noun else ''}, в одной группе по {per_group}.",
                f"Что нужно найти: сколько {answer_noun} нужно.",
                f"1) Чтобы узнать, сколько получится групп, делим общее количество на количество в одной группе: {total} : {per_group} = {format_fraction(groups)}.",
                f"Ответ: {_audit_add_answer_noun(format_fraction(groups), answer_noun)}"
            )

    if ('поровну' in lower or 'в каждом' in lower) and 'сколько' in lower:
        total = numbers[0]
        groups = numbers[1]
        if groups != 0 and ('в каждом' in lower or 'каждом пакете' in lower or 'каждой' in lower):
            per_group = Fraction(total, groups)
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: всего {total}{(' ' + first_noun) if first_noun else ''}, групп {groups}.",
                "Что нужно найти: сколько будет в каждой группе.",
                f"1) Чтобы узнать, сколько будет в каждой группе, делим общее количество на число групп: {total} : {groups} = {format_fraction(per_group)}.",
                f"Ответ: {'в каждой группе по ' + format_fraction(per_group) + (' ' + first_noun if first_noun else '')}"
            )

    if 'сколько стало' in lower and any(stem in lower for stem in WORD_GAIN_HINTS):
        first = numbers[0]
        added = numbers[1]
        total = first + added
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: сначала было {first}{(' ' + first_noun) if first_noun else ''}, добавили ещё {added}.",
            "Что нужно найти: сколько стало.",
            f"1) Чтобы узнать, сколько стало, складываем: {first} + {added} = {total}.",
            f"Ответ: {_audit_add_answer_noun(str(total), first_noun)}"
        )

    if 'сколько осталось' in lower and any(stem in lower for stem in WORD_LOSS_HINTS):
        first = numbers[0]
        removed = numbers[1]
        left = first - removed
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: было {first}{(' ' + first_noun) if first_noun else ''}, убрали {removed}.",
            "Что нужно найти: сколько осталось.",
            f"1) Чтобы узнать, сколько осталось, вычитаем: {first} - {removed} = {left}.",
            f"Ответ: {_audit_add_answer_noun(str(left), first_noun)}"
        )
    return None

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _audit_try_simple_addition_explanation(raw_text)
        or _audit_try_one_step_equation_explanation(raw_text)
        or _audit_try_fraction_number_tasks(raw_text)
        or _audit_try_motion_shorthand(raw_text)
        or _audit_try_price_short_tasks(raw_text)
        or _audit_try_rectangle_geometry(raw_text)
        or _audit_try_common_word_problems(raw_text)
    )


# --- FINAL PATCH 2026-04-15 FRACTIONS SCHOOL STYLE ---
_AUDIT_20260415_PREV_FINAL_LOCAL_EXPLANATION = _audit_try_final_local_explanation

def _fraction_school_action_symbol(operator: str) -> str:
    return '+' if operator == '+' else '-'

def _fraction_school_action_word(operator: str) -> str:
    return 'Складываем' if operator == '+' else 'Вычитаем'

def _fraction_school_mixed_text(value: Fraction) -> Optional[str]:
    if value.denominator == 1:
        return None
    sign = '-' if value < 0 else ''
    numerator = abs(value.numerator)
    denominator = value.denominator
    if numerator < denominator:
        return None
    whole = numerator // denominator
    remainder = numerator % denominator
    if remainder == 0:
        return f"{sign}{whole}"
    return f"{sign}{whole} {remainder}/{denominator}"

def _build_fraction_school_explanation(raw_text: str) -> Optional[str]:
    source = to_fraction_source(raw_text)
    if not source:
        return None

    match = re.fullmatch(r"\s*(\d+)\s*/\s*(\d+)\s*([+\-])\s*(\d+)\s*/\s*(\d+)\s*", source)
    if not match:
        return None

    a, b, operator, c, d = match.groups()
    a, b, c, d = int(a), int(b), int(c), int(d)
    if b == 0 or d == 0:
        return join_explanation_lines(
            "У дроби знаменатель не может быть равен нулю",
            "Ответ: запись дроби неверная"
        )

    action_symbol = _fraction_school_action_symbol(operator)
    action_word = _fraction_school_action_word(operator)
    result = Fraction(a, b) + Fraction(c, d) if operator == '+' else Fraction(a, b) - Fraction(c, d)
    result_text = format_fraction(result)
    mixed_text = _fraction_school_mixed_text(result)
    lines: List[str] = [
        f"Пример: {a}/{b} {action_symbol} {c}/{d}",
        "Решение."
    ]

    def extend_with_optional_result_steps(current_step_number: int, raw_fraction_text: str, answer_chain: str):
        local_step_number = current_step_number
        local_answer_chain = answer_chain
        if raw_fraction_text != result_text:
            lines.append(f"{local_step_number}) Сокращаем дробь: {raw_fraction_text} = {result_text}")
            local_answer_chain += f" = {result_text}"
            local_step_number += 1
        if mixed_text and mixed_text != result_text:
            lines.append(f"{local_step_number}) Выделяем целую часть: {result_text} = {mixed_text}")
            local_answer_chain += f" = {mixed_text}"
            local_step_number += 1
        return local_step_number, local_answer_chain

    if b == d:
        top_result = a + c if operator == '+' else a - c
        raw_result = f"{top_result}/{b}"
        lines.extend([
            f"1) Находим общий знаменатель. Знаменатели уже одинаковые: {b} и {d}",
            f"2) Дроби уже имеют одинаковый знаменатель. Значит, {action_word.lower()} только числители, а знаменатель оставляем прежним: {a} {action_symbol} {c} = {top_result}",
            f"3) Получаем: {raw_result}"
        ])
        _, answer_chain = extend_with_optional_result_steps(4, raw_result, f"{a}/{b} {action_symbol} {c}/{d} = {raw_result}")
        lines.append(f"Ответ: {answer_chain}")
        return join_explanation_lines(*lines)

    common = math.lcm(b, d)
    a_multiplier = common // b
    c_multiplier = common // d
    a_scaled = a * a_multiplier
    c_scaled = c * c_multiplier
    raw_numerator = a_scaled + c_scaled if operator == '+' else a_scaled - c_scaled
    raw_result = f"{raw_numerator}/{common}"

    lines.append(
        f"1) Находим общий знаменатель. Знаменатели: {b} и {d}. Общий знаменатель = {common}, потому что {common} делится на {b} и на {d}"
    )

    step_number = 2
    if b == common:
        lines.append(f"{step_number}) Первая дробь уже имеет знаменатель {common}: {a}/{b} = {a}/{common}")
    else:
        lines.extend([
            f"{step_number}) Приводим первую дробь {a}/{b} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {b}, чтобы получить {common}?",
            f"{b} × {a_multiplier} = {common}",
            f"Нужно умножить на {a_multiplier}",
            f"Получаем: {a}/{b} = (умножаем числитель и знаменатель на {a_multiplier}) = {a_scaled}/{common}"
        ])
    step_number += 1

    if d == common:
        lines.append(f"{step_number}) Вторая дробь уже имеет знаменатель {common}: {c}/{d} = {c}/{common}")
    else:
        lines.extend([
            f"{step_number}) Приводим вторую дробь {c}/{d} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {d}, чтобы получить {common}?",
            f"{d} × {c_multiplier} = {common}",
            f"Нужно умножить на {c_multiplier}",
            f"Получаем: {c}/{d} = (умножаем числитель и знаменатель на {c_multiplier}) = {c_scaled}/{common}"
        ])
    step_number += 1

    numerator_action = '+' if operator == '+' else '-'
    numerator_result = a_scaled + c_scaled if operator == '+' else a_scaled - c_scaled
    lines.extend([
        f"{step_number}) {action_word} дроби с одинаковыми знаменателями. Знаменатель {common} оставляем прежним, а числители {action_word.lower()}: {a_scaled} {numerator_action} {c_scaled} = {numerator_result}",
        f"Получаем: {raw_result}"
    ])
    step_number += 1

    base_chain = f"{a}/{b} {action_symbol} {c}/{d} = {a_scaled}/{common} {action_symbol} {c_scaled}/{common} = {raw_result}"
    _, answer_chain = extend_with_optional_result_steps(step_number, raw_result, base_chain)
    lines.append(f"Ответ: {answer_chain}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_school_explanation(raw_text)
        or _AUDIT_20260415_PREV_FINAL_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL PATCH 2026-04-15: mixed fraction expressions are fraction tasks, not plain division ---

_FINAL_20260415_PREV_AUDIT_LOCAL_EXPLANATION = _audit_try_final_local_explanation

def _final_20260415_normalize_fraction_expression_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(normalize_cyrillic_x(text))
    text = text.replace('×', '*').replace('·', '*').replace('÷', '/').replace(':', '/')
    text = re.sub(r'\s+', '', text)
    if not text or re.search(r'[A-Za-zА-Яа-яЁё]', text):
        return None
    if re.search(r'[^0-9+\-*/()]', text):
        return None
    if not re.search(r'\d+/\d+', text):
        return None
    if re.fullmatch(r'\d+/\d+', text):
        return None

    all_numbers = [int(value) for value in re.findall(r'\d+', text)]
    if not all_numbers:
        return None
    if max(abs(value) for value in all_numbers) > 1000:
        return None

    fraction_matches = list(re.finditer(r'(\d+)/(\d+)', text))
    if not fraction_matches:
        return None

    placeholder = re.sub(r'\d+/\d+', 'F', text)
    if not re.fullmatch(r'[F0-9+\-*/()]+', placeholder):
        return None
    if placeholder == 'F':
        return None

    if len(fraction_matches) == 1:
        numerator = int(fraction_matches[0].group(1))
        denominator = int(fraction_matches[0].group(2))
        if denominator == 0:
            return None
        if not re.search(r'[+\-*()]', placeholder):
            return None
        if max(abs(numerator), abs(denominator)) > 50:
            return None

    return text

def _final_20260415_tokenize_fraction_expression(source: str) -> Optional[List[dict]]:
    tokens: List[dict] = []
    index = 0
    length = len(source)

    while index < length:
        char = source[index]
        if char.isdigit():
            start = index
            while index < length and source[index].isdigit():
                index += 1
            integer_text = source[start:index]
            if index < length and source[index] == '/' and index + 1 < length and source[index + 1].isdigit():
                index += 1
                denominator_start = index
                while index < length and source[index].isdigit():
                    index += 1
                denominator_text = source[denominator_start:index]
                denominator = int(denominator_text)
                if denominator == 0:
                    raise ZeroDivisionError('fraction denominator is zero')
                tokens.append({
                    'type': 'value',
                    'text': f"{integer_text}/{denominator_text}",
                    'value': Fraction(int(integer_text), denominator),
                    'is_fraction_literal': True,
                    'pos': start,
                })
                continue

            tokens.append({
                'type': 'value',
                'text': integer_text,
                'value': Fraction(int(integer_text), 1),
                'is_fraction_literal': False,
                'pos': start,
            })
            continue

        if char in '+-*/()':
            tokens.append({'type': char, 'value': char, 'pos': index})
            index += 1
            continue

        return None

    if not tokens:
        return None

    with_implicit_mul: List[dict] = []
    previous: Optional[dict] = None
    for token in tokens:
        if previous and previous['type'] in {'value', ')'} and token['type'] in {'value', '('}:
            with_implicit_mul.append({'type': '*', 'value': '*', 'pos': token['pos']})
        with_implicit_mul.append(token)
        previous = token

    return with_implicit_mul

def _final_20260415_parse_fraction_expression(source: str) -> Optional[dict]:
    try:
        tokens = _final_20260415_tokenize_fraction_expression(source)
    except ZeroDivisionError:
        raise
    if not tokens:
        return None

    cursor = 0
    node_counter = 1

    def peek() -> Optional[dict]:
        return tokens[cursor] if cursor < len(tokens) else None

    def consume(expected: Optional[str] = None) -> Optional[dict]:
        nonlocal cursor
        token = peek()
        if token is None:
            return None
        if expected is not None and token['type'] != expected:
            return None
        cursor += 1
        return token

    def make_binary(operator: str, left: dict, right: dict, pos: int) -> dict:
        nonlocal node_counter
        node = {
            'type': 'binary',
            'operator': operator,
            'left': left,
            'right': right,
            'pos': pos,
            'id': node_counter,
        }
        node_counter += 1
        return node

    def parse_primary() -> Optional[dict]:
        token = peek()
        if token is None:
            return None

        if token['type'] == 'value':
            consume('value')
            return {
                'type': 'value',
                'value': token['value'],
                'text': token['text'],
                'is_fraction_literal': token.get('is_fraction_literal', False),
                'pos': token.get('pos', 0),
            }

        if token['type'] == '(':
            open_token = consume('(')
            inner = parse_add_sub()
            if inner is None or not consume(')'):
                return None
            return {
                'type': 'group',
                'inner': inner,
                'pos': open_token.get('pos', 0),
            }

        if token['type'] in {'+', '-'}:
            consume(token['type'])
            operand = parse_primary()
            if operand is None:
                return None
            return {
                'type': 'unary',
                'operator': token['type'],
                'operand': operand,
                'pos': token.get('pos', 0),
            }

        return None

    def parse_mul_div() -> Optional[dict]:
        node = parse_primary()
        if node is None:
            return None
        while True:
            token = peek()
            if token is None or token['type'] not in {'*', '/'}:
                break
            consume(token['type'])
            right = parse_primary()
            if right is None:
                return None
            node = make_binary(token['type'], node, right, token.get('pos', 0))
        return node

    def parse_add_sub() -> Optional[dict]:
        node = parse_mul_div()
        if node is None:
            return None
        while True:
            token = peek()
            if token is None or token['type'] not in {'+', '-'}:
                break
            consume(token['type'])
            right = parse_mul_div()
            if right is None:
                return None
            node = make_binary(token['type'], node, right, token.get('pos', 0))
        return node

    root = parse_add_sub()
    if root is None or cursor != len(tokens):
        return None
    return root

def _final_20260415_fraction_precedence(operator: str) -> int:
    return 1 if operator in {'+', '-'} else 2

def _final_20260415_fraction_op_symbol(operator: str) -> str:
    return {'+': '+', '-': '-', '*': '×', '/': '÷'}.get(operator, operator)

def _final_20260415_format_fraction_value(value: Fraction, force_fraction: bool = False) -> str:
    simplified = Fraction(value.numerator, value.denominator)
    if force_fraction or simplified.denominator != 1:
        return f"{simplified.numerator}/{simplified.denominator}"
    return str(simplified.numerator)

def _final_20260415_render_fraction_node(node: dict, solved: Optional[dict] = None, parent_precedence: int = 0, is_right_child: bool = False) -> str:
    solved = solved or {}
    if node.get('type') == 'value':
        return node.get('text', _final_20260415_format_fraction_value(node.get('value', Fraction(0, 1))))
    if node.get('type') == 'group':
        return f"({_final_20260415_render_fraction_node(node['inner'], solved)})"
    if node.get('type') == 'unary':
        inner = _final_20260415_render_fraction_node(node['operand'], solved, 3)
        return inner if node.get('operator') == '+' else f"-{inner}"
    if node.get('type') == 'binary':
        node_id = node.get('id')
        if node_id in solved:
            return solved[node_id]
        operator = node.get('operator', '+')
        precedence = _final_20260415_fraction_precedence(operator)
        left_text = _final_20260415_render_fraction_node(node['left'], solved, precedence, False)
        right_text = _final_20260415_render_fraction_node(node['right'], solved, precedence, True)
        text = f"{left_text} {_final_20260415_fraction_op_symbol(operator)} {right_text}"
        needs_brackets = precedence < parent_precedence or (
            is_right_child and operator in {'+', '-'} and precedence == parent_precedence
        )
        return f"({text})" if needs_brackets else text
    return ''

def _final_20260415_apply_fraction_operator(operator: str, left: Fraction, right: Fraction) -> Fraction:
    if operator == '+':
        return left + right
    if operator == '-':
        return left - right
    if operator == '*':
        return left * right
    if operator == '/':
        if right == 0:
            raise ZeroDivisionError('division by zero')
        return left / right
    raise ValueError('Unsupported operator')

def _final_20260415_flatten_fraction_chain(node: dict, operators_to_flatten: Tuple[str, ...], operands: List[dict], op_nodes: List[dict]):
    if node.get('type') == 'group':
        operands.append(node['inner'])
        return
    if node.get('type') == 'binary' and node.get('operator') in operators_to_flatten:
        _final_20260415_flatten_fraction_chain(node['left'], operators_to_flatten, operands, op_nodes)
        op_nodes.append(node)
        operands.append(node['right'])
        return
    operands.append(node)

def _final_20260415_eval_fraction_steps(node: dict) -> Tuple[Fraction, List[dict]]:
    node_type = node.get('type')
    if node_type == 'value':
        return node['value'], []
    if node_type == 'group':
        return _final_20260415_eval_fraction_steps(node['inner'])
    if node_type == 'unary':
        operand_value, operand_steps = _final_20260415_eval_fraction_steps(node['operand'])
        return (-operand_value if node.get('operator') == '-' else operand_value), operand_steps
    if node_type != 'binary':
        raise ValueError('Unsupported fraction expression node')

    operator = node.get('operator')
    chain_operators = ('+', '-') if operator in {'+', '-'} else ('*', '/')
    operands: List[dict] = []
    op_nodes: List[dict] = []
    _final_20260415_flatten_fraction_chain(node, chain_operators, operands, op_nodes)

    values: List[Fraction] = []
    steps: List[dict] = []
    for operand in operands:
        operand_value, operand_steps = _final_20260415_eval_fraction_steps(operand)
        steps.extend(operand_steps)
        values.append(operand_value)

    current = values[0]
    for op_node, next_value in zip(op_nodes, values[1:]):
        result = _final_20260415_apply_fraction_operator(op_node['operator'], current, next_value)
        steps.append({
            'id': op_node['id'],
            'operator': op_node['operator'],
            'left': current,
            'right': next_value,
            'result': result,
        })
        current = result

    return current, steps

def _final_20260415_prepare_fraction_operand(value: Fraction) -> Tuple[List[str], Fraction]:
    if value.denominator == 1:
        integer_text = str(value.numerator)
        return [f"Представляем число {integer_text} в виде дроби: {integer_text} = {integer_text}/1"], Fraction(value.numerator, 1)
    return [], Fraction(value.numerator, value.denominator)

def _final_20260415_append_fraction_reduction(lines: List[str], raw_numerator: int, raw_denominator: int, simplified: Fraction):
    raw_text = f"{raw_numerator}/{raw_denominator}"
    simple_text = _final_20260415_format_fraction_value(simplified)
    if raw_denominator != simplified.denominator or raw_numerator != simplified.numerator:
        lines.append(f"Сокращаем: {raw_text} = {simple_text}")

def _final_20260415_fraction_add_sub_lines(step_number: int, left: Fraction, right: Fraction, operator: str, result: Fraction) -> List[str]:
    symbol = '+' if operator == '+' else '-'
    action_word = 'Складываем' if operator == '+' else 'Вычитаем'
    action_word_lower = action_word.lower()
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} {symbol} {right_text} = {result_text}"]

    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)

    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)

    if left_fraction.denominator == right_fraction.denominator:
        raw_numerator = left_fraction.numerator + right_fraction.numerator if operator == '+' else left_fraction.numerator - right_fraction.numerator
        lines.append(f"Знаменатели уже одинаковые: {left_fraction.denominator} и {right_fraction.denominator}")
        lines.append(f"Значит, {action_word_lower} только числители: {left_fraction.numerator} {symbol} {right_fraction.numerator} = {raw_numerator}")
        lines.append(f"Получаем: {left_work_text} {symbol} {right_work_text} = {raw_numerator}/{left_fraction.denominator}")
        _final_20260415_append_fraction_reduction(lines, raw_numerator, left_fraction.denominator, result)
        return lines

    common = math.lcm(left_fraction.denominator, right_fraction.denominator)
    left_multiplier = common // left_fraction.denominator
    right_multiplier = common // right_fraction.denominator
    left_scaled = left_fraction.numerator * left_multiplier
    right_scaled = right_fraction.numerator * right_multiplier
    raw_numerator = left_scaled + right_scaled if operator == '+' else left_scaled - right_scaled

    lines.append(
        f"Находим общий знаменатель. Знаменатели: {left_fraction.denominator} и {right_fraction.denominator}. Общий знаменатель = {common}, потому что {common} делится на {left_fraction.denominator} и на {right_fraction.denominator}"
    )

    if left_fraction.denominator == common:
        lines.append(f"Первая дробь уже имеет знаменатель {common}: {left_work_text} = {left_fraction.numerator}/{common}")
    else:
        lines.extend([
            f"Приводим первую дробь {left_work_text} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {left_fraction.denominator}, чтобы получить {common}?",
            f"{left_fraction.denominator} × {left_multiplier} = {common}",
            f"Нужно умножить на {left_multiplier}",
            f"Получаем: {left_work_text} = (умножаем числитель и знаменатель на {left_multiplier}) = {left_scaled}/{common}",
        ])

    if right_fraction.denominator == common:
        lines.append(f"Вторая дробь уже имеет знаменатель {common}: {right_work_text} = {right_fraction.numerator}/{common}")
    else:
        lines.extend([
            f"Приводим вторую дробь {right_work_text} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {right_fraction.denominator}, чтобы получить {common}?",
            f"{right_fraction.denominator} × {right_multiplier} = {common}",
            f"Нужно умножить на {right_multiplier}",
            f"Получаем: {right_work_text} = (умножаем числитель и знаменатель на {right_multiplier}) = {right_scaled}/{common}",
        ])

    lines.append(f"Теперь {action_word_lower} дроби с одинаковыми знаменателями")
    lines.append(f"{left_scaled} {symbol} {right_scaled} = {raw_numerator}")
    lines.append(f"Получаем: {left_scaled}/{common} {symbol} {right_scaled}/{common} = {raw_numerator}/{common}")
    _final_20260415_append_fraction_reduction(lines, raw_numerator, common, result)
    return lines

def _final_20260415_fraction_mul_body_lines(left_fraction: Fraction, right_fraction: Fraction, result: Fraction, left_work_text: str, right_work_text: str) -> List[str]:
    raw_numerator = left_fraction.numerator * right_fraction.numerator
    raw_denominator = left_fraction.denominator * right_fraction.denominator
    lines = [
        'Чтобы умножить дроби, умножаем числители и знаменатели',
        f"{left_fraction.numerator} × {right_fraction.numerator} = {raw_numerator}",
        f"{left_fraction.denominator} × {right_fraction.denominator} = {raw_denominator}",
        f"Получаем: {left_work_text} × {right_work_text} = {raw_numerator}/{raw_denominator}",
    ]
    _final_20260415_append_fraction_reduction(lines, raw_numerator, raw_denominator, result)
    return lines

def _final_20260415_fraction_mul_lines(step_number: int, left: Fraction, right: Fraction, result: Fraction) -> List[str]:
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} × {right_text} = {result_text}"]
    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)
    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)
    lines.extend(_final_20260415_fraction_mul_body_lines(left_fraction, right_fraction, result, left_work_text, right_work_text))
    return lines

def _final_20260415_fraction_div_lines(step_number: int, left: Fraction, right: Fraction, result: Fraction) -> List[str]:
    left_text = _final_20260415_format_fraction_value(left)
    right_text = _final_20260415_format_fraction_value(right)
    result_text = _final_20260415_format_fraction_value(result)
    lines = [f"{step_number}) {left_text} ÷ {right_text} = {result_text}"]
    left_prep_lines, left_fraction = _final_20260415_prepare_fraction_operand(left)
    right_prep_lines, right_fraction = _final_20260415_prepare_fraction_operand(right)
    lines.extend(left_prep_lines)
    lines.extend(right_prep_lines)
    if right_fraction == 0:
        raise ZeroDivisionError('division by zero')
    reciprocal = Fraction(right_fraction.denominator, right_fraction.numerator)
    left_work_text = _final_20260415_format_fraction_value(left_fraction, force_fraction=True)
    right_work_text = _final_20260415_format_fraction_value(right_fraction, force_fraction=True)
    reciprocal_text = _final_20260415_format_fraction_value(reciprocal, force_fraction=True)
    lines.append('Чтобы разделить на дробь, первую дробь умножаем на дробь, обратную второй')
    lines.append(f"{left_work_text} ÷ {right_work_text} = {left_work_text} × {reciprocal_text}")
    lines.extend(_final_20260415_fraction_mul_body_lines(left_fraction, reciprocal, result, left_work_text, reciprocal_text))
    return lines

def _final_20260415_fraction_step_lines(step_number: int, step: dict) -> List[str]:
    operator = step['operator']
    left = step['left']
    right = step['right']
    result = step['result']
    if operator in {'+', '-'}:
        return _final_20260415_fraction_add_sub_lines(step_number, left, right, operator, result)
    if operator == '*':
        return _final_20260415_fraction_mul_lines(step_number, left, right, result)
    if operator == '/':
        return _final_20260415_fraction_div_lines(step_number, left, right, result)
    return [f"{step_number}) {_final_20260415_format_fraction_value(left)} {_final_20260415_fraction_op_symbol(operator)} {_final_20260415_format_fraction_value(right)} = {_final_20260415_format_fraction_value(result)}"]

def _final_20260415_fraction_answer_chain(root: dict, steps: List[dict], result: Fraction) -> str:
    solved: dict = {}
    chain: List[str] = [_final_20260415_render_fraction_node(root)]
    for step in steps:
        solved[step['id']] = _final_20260415_format_fraction_value(step['result'])
        current = _final_20260415_render_fraction_node(root, solved)
        if current and current != chain[-1]:
            chain.append(current)
    mixed_text = _fraction_school_mixed_text(result)
    if mixed_text and mixed_text != chain[-1]:
        chain.append(mixed_text)
    return ' = '.join(chain)

def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    source = _final_20260415_normalize_fraction_expression_source(raw_text)
    if not source:
        return None

    # Простые случаи вида 1/4+1/6 и 1/4-1/6 уже объясняются отдельным шаблоном.
    if re.fullmatch(r'\d+/\d+[+\-]\d+/\d+', source):
        return None

    try:
        root = _final_20260415_parse_fraction_expression(source)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')

    if not root:
        return None

    try:
        result, steps = _final_20260415_eval_fraction_steps(root)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')
    except Exception:
        return None

    if not steps:
        return None

    lines: List[str] = [
        f"Пример: {_final_20260415_render_fraction_node(root)}",
        'Решение.',
    ]
    for index, step in enumerate(steps, 1):
        lines.extend(_final_20260415_fraction_step_lines(index, step))
    lines.append(f"Ответ: {_final_20260415_fraction_answer_chain(root, steps, result)}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_20260415_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL USER PATCH 2026-04-15AB: order guide + full answer chain for mixed fraction expressions ---

_FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION = _audit_try_final_local_explanation

def _final_user_fraction_eval_steps_with_positions(node: dict) -> Tuple[Fraction, List[dict]]:
    node_type = node.get('type')
    if node_type == 'value':
        return node['value'], []
    if node_type == 'group':
        return _final_user_fraction_eval_steps_with_positions(node['inner'])
    if node_type == 'unary':
        operand_value, operand_steps = _final_user_fraction_eval_steps_with_positions(node['operand'])
        return (-operand_value if node.get('operator') == '-' else operand_value), operand_steps
    if node_type != 'binary':
        raise ValueError('Unsupported fraction expression node')

    operator = node.get('operator')
    chain_operators = ('+', '-') if operator in {'+', '-'} else ('*', '/')
    operands: List[dict] = []
    op_nodes: List[dict] = []
    _final_20260415_flatten_fraction_chain(node, chain_operators, operands, op_nodes)

    values: List[Fraction] = []
    steps: List[dict] = []
    for operand in operands:
        operand_value, operand_steps = _final_user_fraction_eval_steps_with_positions(operand)
        steps.extend(operand_steps)
        values.append(operand_value)

    current = values[0]
    for op_node, next_value in zip(op_nodes, values[1:]):
        result = _final_20260415_apply_fraction_operator(op_node['operator'], current, next_value)
        steps.append({
            'id': op_node['id'],
            'operator': op_node['operator'],
            'left': current,
            'right': next_value,
            'result': result,
            'index': op_node.get('pos', 0),
        })
        current = result

    return current, steps

def _final_user_fraction_order_lines(source: str, steps: List[dict]) -> List[str]:
    try:
        tokens = _final_20260415_tokenize_fraction_expression(source)
    except ZeroDivisionError:
        return []
    if not tokens or len(steps) < 2:
        return []

    pretty_expr = ''
    operator_positions: dict[int, int] = {}
    for token in tokens:
        token_type = token.get('type')
        if token_type == 'value':
            pretty_expr += token.get('text', '')
            continue
        if token_type in {'+', '-', '*', '/'}:
            operator_positions[token.get('pos', 0)] = len(pretty_expr) + 1
            pretty_expr += f" {_final_20260415_fraction_op_symbol(token_type)} "
            continue
        pretty_expr += token_type

    if not pretty_expr:
        return []

    marks = [' '] * len(pretty_expr)
    for step_index, step in enumerate(steps, 1):
        pretty_pos = operator_positions.get(step.get('index', 0))
        if pretty_pos is None:
            continue
        label = str(step_index)
        start = max(0, pretty_pos - (len(label) - 1) // 2)
        for offset, char in enumerate(label):
            target = start + offset
            if 0 <= target < len(marks):
                marks[target] = char

    return ['Порядок действий:', ''.join(marks).rstrip(), pretty_expr]

def _final_user_fraction_expanded_step_text(step: dict) -> Optional[str]:
    operator = step.get('operator')
    if operator not in {'+', '-'}:
        return None

    left = Fraction(step.get('left', Fraction(0, 1)))
    right = Fraction(step.get('right', Fraction(0, 1)))
    common = math.lcm(left.denominator, right.denominator)
    if not common or (left.denominator == common and right.denominator == common):
        return None

    left_multiplier = common // left.denominator
    right_multiplier = common // right.denominator
    left_scaled = left.numerator * left_multiplier
    right_scaled = right.numerator * right_multiplier
    symbol = '+' if operator == '+' else '-'
    return f"{left_scaled}/{common} {symbol} {right_scaled}/{common}"

def _final_user_fraction_answer_chain(root: dict, steps: List[dict], result: Fraction) -> str:
    solved: dict[int, str] = {}
    chain: List[str] = [_final_20260415_render_fraction_node(root)]

    for step in steps:
        expanded = _final_user_fraction_expanded_step_text(step)
        if expanded:
            solved[step['id']] = expanded
            expanded_view = _final_20260415_render_fraction_node(root, solved)
            if expanded_view and expanded_view != chain[-1]:
                chain.append(expanded_view)

        solved[step['id']] = _final_20260415_format_fraction_value(step['result'])
        current = _final_20260415_render_fraction_node(root, solved)
        if current and current != chain[-1]:
            chain.append(current)

    mixed_text = _fraction_school_mixed_text(result)
    if mixed_text and mixed_text != chain[-1]:
        chain.append(mixed_text)
    return ' = '.join(chain)
