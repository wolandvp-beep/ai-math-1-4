"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 6073-6970."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_consolidation_direct_relation_multianswer_explanation_z(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if not has_multiple_questions(raw_text):
        return None
    if "на сколько" not in question and "во сколько" not in question:
        return None

    if re.search(r"\b(?:это|что|он|она)\b[^?.!]{0,40}(?:на\s+\d+|в\s+\d+\s+раз(?:а)?)", lower):
        return None

    numbers = extract_ordered_numbers(lower)
    if len(numbers) != 2:
        return None

    question_parts = _consolidation_split_question_parts_z(raw_text)
    first_question = question_parts[0] if question_parts else ""
    second_question = question_parts[1] if len(question_parts) > 1 else ""
    noun_hint = ""
    try:
        noun_hint = _extract_count_question_noun(raw_text) or _extract_question_noun(raw_text)
    except Exception:
        noun_hint = ""

    relation_pairs = extract_relation_pairs(lower)
    if len(relation_pairs) == 1:
        base = numbers[0]
        delta, mode = relation_pairs[0]
        if numbers[1] != delta:
            return None
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None

        first_answer = _consolidation_answer_from_first_question_z(first_question, related, noun_hint)

        if "на сколько" in question:
            diff = abs(base - related)
            second_answer = _consolidation_answer_from_compare_question_z(second_question, diff, noun_hint)
            return join_explanation_lines(
                f"1) Если первое количество равно {base}, а второе на {delta} {mode}, то второе количество равно {base} {'+' if mode == 'больше' else '-'} {delta} = {related}",
                f"2) Если первое количество равно {base}, а второе равно {related}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
                f"Ответ: {first_answer}; {second_answer}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )

        smaller = min(base, related)
        bigger = max(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        second_answer = _consolidation_answer_from_compare_question_z(second_question, ratio, noun_hint)
        return join_explanation_lines(
            f"1) Если первое количество равно {base}, а второе на {delta} {mode}, то второе количество равно {base} {'+' if mode == 'больше' else '-'} {delta} = {related}",
            f"2) Если первое количество равно {base}, а второе равно {related}, то большее число делим на меньшее: {bigger} : {smaller} = {ratio}",
            f"Ответ: {first_answer}; {second_answer}",
            "Совет: если нужно сначала найти второе число, а потом узнать во сколько раз одно больше другого, выполняй действия по порядку",
        )

    scale_pairs = extract_scale_pairs(lower)
    if len(scale_pairs) == 1:
        base = numbers[0]
        factor, mode = scale_pairs[0]
        if numbers[1] != factor:
            return None
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None

        first_answer = _consolidation_answer_from_first_question_z(first_question, related, noun_hint)

        if "на сколько" in question:
            diff = abs(base - related)
            second_answer = _consolidation_answer_from_compare_question_z(second_question, diff, noun_hint)
            return join_explanation_lines(
                f"1) Если первое количество равно {base}, а второе в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} {mode}, то второе количество равно {base} {'×' if mode == 'больше' else ':'} {factor} = {related}",
                f"2) Если первое количество равно {base}, а второе равно {related}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
                f"Ответ: {first_answer}; {second_answer}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )

        smaller = min(base, related)
        bigger = max(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        second_answer = _consolidation_answer_from_compare_question_z(second_question, ratio, noun_hint)
        return join_explanation_lines(
            f"1) Если первое количество равно {base}, а второе в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} {mode}, то второе количество равно {base} {'×' if mode == 'больше' else ':'} {factor} = {related}",
            f"2) Если первое количество равно {base}, а второе равно {related}, то большее число делим на меньшее: {bigger} : {smaller} = {ratio}",
            f"Ответ: {first_answer}; {second_answer}",
            "Совет: если сначала нужно найти второе число, а потом узнать во сколько раз одно больше другого, выполняй действия по порядку",
        )

    return None



def try_consolidation_return_trip_faster_explanation_z(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "обратно" not in lower or "быстр" not in lower or "сколько" not in question:
        return None

    factor_match = re.search(r"в\s+(\d+)\s+раз(?:а)?\s+быстр", lower)
    if not factor_match:
        return None
    factor = int(factor_match.group(1))
    if factor <= 0:
        return None

    distance_match = re.search(r"\b(\d+)\s*(км|м)\b", lower)
    speed_match = re.search(r"скорост[ьяию][^\d]{0,20}(\d+)\s*(км/ч|м/с|м/мин)?", lower)
    if not distance_match or not speed_match:
        return None

    distance_value = int(distance_match.group(1))
    distance_unit = distance_match.group(2)
    speed_value = int(speed_match.group(1))
    speed_unit = speed_match.group(2) or ("км/ч" if distance_unit == "км" else "")
    if speed_value <= 0 or distance_value % speed_value != 0:
        return None

    one_way_time = distance_value // speed_value
    time_unit = "ч" if "/ч" in speed_unit or "час" in question else "мин" if "/мин" in speed_unit or "мин" in question else ""

    if one_way_time % factor == 0:
        return_time = one_way_time // factor
        return join_explanation_lines(
            f"1) Если путь до пункта равен {distance_value} {distance_unit}, а скорость была {speed_value} {speed_unit}, то время в одну сторону равно {distance_value} : {speed_value} = {one_way_time}{(' ' + time_unit) if time_unit else ''}",
            f"2) Если обратно ехали в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} быстрее, то время в обратную сторону в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} меньше: {one_way_time} : {factor} = {return_time}{(' ' + time_unit) if time_unit else ''}",
            f"Ответ: {return_time}{(' ' + time_unit) if time_unit else ''}",
            "Совет: если скорость на том же пути увеличилась в несколько раз, то время уменьшается во столько же раз",
        )

    faster_speed = speed_value * factor
    if distance_value % faster_speed != 0:
        return None
    return_time = distance_value // faster_speed

    return join_explanation_lines(
        f"1) Если скорость на обратном пути в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} больше, то новая скорость равна {speed_value} × {factor} = {faster_speed}{(' ' + speed_unit) if speed_unit else ''}",
        f"2) Если расстояние равно {distance_value} {distance_unit}, а новая скорость равна {faster_speed}{(' ' + speed_unit) if speed_unit else ''}, то время обратно равно {distance_value} : {faster_speed} = {return_time}{(' ' + time_unit) if time_unit else ''}",
        f"Ответ: {return_time}{(' ' + time_unit) if time_unit else ''}",
        "Совет: для одного и того же пути время находят делением расстояния на скорость",
    )



# --- OPENAI HOTFIX 2026-04-11ZA: narrow named-unit fraction patch to real conversion cases ---

def try_consolidation_fraction_named_unit_explanation_z(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    fractions = extract_all_fraction_pairs(lower)
    if len(fractions) != 1 or "сколько" not in question:
        return None

    # Этот локальный обработчик нужен именно для задач, где требуется перевод единиц,
    # в первую очередь для тонн -> килограммы. Остальные дробные текстовые задачи
    # лучше оставлять более ранним специализированным объяснителям.
    ton_match = re.search(r"\b(\d+)\s*т\b", lower)
    if not ton_match:
        return None

    numerator, denominator = fractions[0]
    if denominator == 0:
        return None

    tons = int(ton_match.group(1))
    total_value = tons * 1000
    if total_value % denominator != 0:
        return None

    one_part = total_value // denominator
    part_value = one_part * numerator

    return join_explanation_lines(
        f"1) Сначала переводим тонны в килограммы: {tons} т = {total_value} кг",
        f"2) Если всё число равно {total_value} кг, то одна доля равна {total_value} : {denominator} = {one_part} кг",
        f"3) Если нужно найти {numerator}/{denominator} числа, то берём {numerator} такие доли: {one_part} × {numerator} = {part_value} кг",
        f"Ответ: {part_value} кг",
        "Совет: если задача с дробью дана в тоннах, сначала переведи тонны в килограммы",
    )

# --- CONSOLIDATION PATCH 2026-04-11AA: named measurement expressions from textbook ---

_PREV_20260411AA_INFER_TASK_KIND = infer_task_kind
_PREV_20260411AA_DETAILED_FORMAT_SOLUTION = _detailed_format_solution

_MEASURE_BASE_UNITS_20260411AA = {
    "length": [("км", 1_000_000), ("м", 1_000), ("дм", 100), ("см", 10), ("мм", 1)],
    "mass": [("т", 1_000_000), ("ц", 100_000), ("кг", 1_000), ("г", 1)],
    "time": [("ч", 3_600), ("мин", 60), ("с", 1)],
    "volume": [("л", 1_000), ("мл", 1)],
}

_MEASURE_UNIT_ALIASES_20260411AA = {
    "км": "км",
    "м": "м",
    "дм": "дм",
    "см": "см",
    "мм": "мм",
    "т": "т",
    "ц": "ц",
    "кг": "кг",
    "г": "г",
    "ч": "ч",
    "час": "ч",
    "часа": "ч",
    "часов": "ч",
    "мин": "мин",
    "минута": "мин",
    "минуты": "мин",
    "минут": "мин",
    "с": "с",
    "сек": "с",
    "секунда": "с",
    "секунды": "с",
    "секунд": "с",
    "л": "л",
    "мл": "мл",
}

_MEASURE_UNIT_PATTERN_20260411AA = "|".join(
    sorted((re.escape(unit) for unit in _MEASURE_UNIT_ALIASES_20260411AA), key=len, reverse=True)
)
_MEASURE_TOKEN_RE_20260411AA = re.compile(rf"(\d+)\s*({_MEASURE_UNIT_PATTERN_20260411AA})\b", re.IGNORECASE)

def _measure_canon_20260411AA(unit_text: str) -> str:
    return _MEASURE_UNIT_ALIASES_20260411AA.get(str(unit_text or "").strip().lower().replace("ё", "е"), "")

def _measure_family_20260411AA(unit_text: str) -> str:
    unit = _measure_canon_20260411AA(unit_text)
    for family, items in _MEASURE_BASE_UNITS_20260411AA.items():
        if any(name == unit for name, _ in items):
            return family
    return ""

def _measure_factor_20260411AA(family: str, unit_text: str) -> int:
    unit = _measure_canon_20260411AA(unit_text)
    for name, factor in _MEASURE_BASE_UNITS_20260411AA.get(family, []):
        if name == unit:
            return factor
    raise KeyError(unit)

def _measure_parse_value_20260411AA(text: str) -> Optional[dict]:
    raw = re.sub(r"\s+", " ", str(text or "").strip().lower().replace("ё", "е"))
    if not raw:
        return None
    matches = list(_MEASURE_TOKEN_RE_20260411AA.finditer(raw))
    if not matches:
        return None

    rebuilt_parts = []
    family = ""
    total = 0
    units_used = []
    normalized_tokens = []
    for match in matches:
        value = int(match.group(1))
        unit = _measure_canon_20260411AA(match.group(2))
        token_family = _measure_family_20260411AA(unit)
        if not token_family:
            return None
        if family and family != token_family:
            return None
        family = token_family
        rebuilt_parts.append(f"{value} {unit}")
        factor = _measure_factor_20260411AA(family, unit)
        total += value * factor
        if unit not in units_used:
            units_used.append(unit)
        normalized_tokens.append((value, unit))

    normalized = " ".join(rebuilt_parts)
    if re.sub(r"\s+", " ", normalized) != raw:
        return None

    preferred_units = sorted(units_used, key=lambda u: _measure_factor_20260411AA(family, u), reverse=True)
    return {
        "text": normalized,
        "family": family,
        "total": total,
        "units": preferred_units,
        "tokens": normalized_tokens,
    }

def _measure_format_from_base_20260411AA(total: int, family: str, preferred_units: List[str]) -> str:
    units = [u for u in preferred_units if _measure_family_20260411AA(u) == family]
    if not units:
        units = [name for name, _ in _MEASURE_BASE_UNITS_20260411AA[family]]
    units = sorted(units, key=lambda u: _measure_factor_20260411AA(family, u), reverse=True)

    if len(units) >= 2:
        first, second = units[0], units[1]
        first_factor = _measure_factor_20260411AA(family, first)
        second_factor = _measure_factor_20260411AA(family, second)
        first_value = total // first_factor
        remainder = total % first_factor
        second_value = remainder // second_factor
        parts = []
        if first_value:
            parts.append(f"{first_value} {first}")
        if second_value or not parts:
            parts.append(f"{second_value} {second}")
        return " ".join(parts)

    unit = units[0]
    factor = _measure_factor_20260411AA(family, unit)
    value = total // factor
    return f"{value} {unit}"

def _measure_base_unit_name_20260411AA(family: str) -> str:
    return _MEASURE_BASE_UNITS_20260411AA[family][-1][0]

def _parse_named_measurement_expression_20260411AA(raw_text: str) -> Optional[dict]:
    text = normalize_dashes(str(raw_text or "")).replace("×", " * ").replace(":", " / ").replace("÷", " / ")
    text = re.sub(r"\s+", " ", text).strip().lower().replace("ё", "е")
    if not text:
        return None

    measure_pattern = rf"(?:\d+\s*(?:{_MEASURE_UNIT_PATTERN_20260411AA})(?:\s+\d+\s*(?:{_MEASURE_UNIT_PATTERN_20260411AA}))*)"

    patterns = [
        (re.compile(rf"^({measure_pattern})\s*([+\-])\s*({measure_pattern})$", re.IGNORECASE), "measure_measure"),
        (re.compile(rf"^({measure_pattern})\s*([*/])\s*(\d+)$", re.IGNORECASE), "measure_number"),
        (re.compile(rf"^(\d+)\s*([*])\s*({measure_pattern})$", re.IGNORECASE), "number_measure"),
    ]

    for pattern, mode in patterns:
        match = pattern.fullmatch(text)
        if not match:
            continue
        if mode == "measure_measure":
            left = _measure_parse_value_20260411AA(match.group(1))
            right = _measure_parse_value_20260411AA(match.group(3))
            operator = "+" if match.group(2) == "+" else "-"
            if not left or not right or left["family"] != right["family"]:
                return None
            preferred = sorted(list(dict.fromkeys(left["units"] + right["units"])), key=lambda u: _measure_factor_20260411AA(left["family"], u), reverse=True)
            return {"mode": mode, "left": left, "right": right, "operator": operator, "family": left["family"], "preferred_units": preferred}
        if mode == "measure_number":
            left = _measure_parse_value_20260411AA(match.group(1))
            operator = "×" if match.group(2) == "*" else ":"
            number = int(match.group(3))
            if not left:
                return None
            return {"mode": mode, "left": left, "number": number, "operator": operator, "family": left["family"], "preferred_units": left["units"]}
        if mode == "number_measure":
            number = int(match.group(1))
            right = _measure_parse_value_20260411AA(match.group(3))
            if not right:
                return None
            return {"mode": mode, "left_number": number, "right": right, "number": number, "operator": "×", "family": right["family"], "preferred_units": right["units"]}
    return None

def _pretty_named_measurement_expression_20260411AA(parsed: dict) -> str:
    if parsed["mode"] == "measure_measure":
        return f"{parsed['left']['text']} {parsed['operator']} {parsed['right']['text']}"
    if parsed["mode"] == "measure_number":
        return f"{parsed['left']['text']} {parsed['operator']} {parsed['number']}"
    return f"{parsed['left_number']} × {parsed['right']['text']}"



def infer_task_kind(text: str) -> str:
    if _parse_named_measurement_expression_20260411AA(text):
        return "expression"
    return _PREV_20260411AA_INFER_TASK_KIND(text)



def _format_named_measurement_expression_solution_20260411AA(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    parsed = _parse_named_measurement_expression_20260411AA(raw_text)
    pretty = _pretty_named_measurement_expression_20260411AA(parsed) if parsed else strip_known_prefix(raw_text)
    answer = parts["answer"] or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("пример:", "решение"))]
    lines: List[str] = [f"Пример: {pretty} = {answer}", "Решение."]
    lines.extend(_detailed_number_lines(body_lines))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or "сначала переводи составное именованное число в простое, потом выполняй вычисление"
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if _parse_named_measurement_expression_20260411AA(raw_text):
        return _format_named_measurement_expression_solution_20260411AA(raw_text, text)
    return _PREV_20260411AA_DETAILED_FORMAT_SOLUTION(raw_text, text, kind)

# --- HOTFIX 2026-04-11AB: use the smallest unit from the expression, not always family base ---

def _measure_conversion_unit_20260411AB(units: List[str], family: str) -> str:
    relevant = [u for u in units if _measure_family_20260411AA(u) == family]
    if not relevant:
        return _measure_base_unit_name_20260411AA(family)
    return min(relevant, key=lambda u: _measure_factor_20260411AA(family, u))

def _build_named_measurement_expression_explanation_20260411AA(raw_text: str) -> Optional[str]:
    parsed = _parse_named_measurement_expression_20260411AA(raw_text)
    if not parsed:
        return None

    family = parsed["family"]
    if parsed["mode"] == "measure_measure":
        left = parsed["left"]
        right = parsed["right"]
        conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
        if parsed["operator"] == "-" and left["total"] < right["total"]:
            return None
        result_total = left["total"] + right["total"] if parsed["operator"] == "+" else left["total"] - right["total"]
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        left_simple = left["total"] // _measure_factor_20260411AA(family, conversion_unit)
        right_simple = right["total"] // _measure_factor_20260411AA(family, conversion_unit)
        result_simple = result_total // _measure_factor_20260411AA(family, conversion_unit)
        verb = "Складываем" if parsed["operator"] == "+" else "Вычитаем"
        return join_explanation_lines(
            f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
            "Решение.",
            f"1) Переводим первое именованное число в {conversion_unit}: {left['text']} = {left_simple} {conversion_unit}",
            f"2) Переводим второе именованное число в {conversion_unit}: {right['text']} = {right_simple} {conversion_unit}",
            f"3) {verb}: {left_simple} {'+' if parsed['operator'] == '+' else '-'} {right_simple} = {result_simple} {conversion_unit}",
            f"4) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при сложении и вычитании именованных чисел сначала переводи их в одинаковые единицы",
        )

    if parsed["mode"] == "measure_number":
        left = parsed["left"]
        number = parsed["number"]
        conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
        left_simple = left["total"] // _measure_factor_20260411AA(family, conversion_unit)
        if parsed["operator"] == ":":
            if number == 0 or left_simple % number != 0:
                return None
            result_simple = left_simple // number
            action_line = f"2) Делим: {left_simple} : {number} = {result_simple} {conversion_unit}"
        else:
            result_simple = left_simple * number
            action_line = f"2) Умножаем: {left_simple} × {number} = {result_simple} {conversion_unit}"
        result_total = result_simple * _measure_factor_20260411AA(family, conversion_unit)
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        return join_explanation_lines(
            f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
            "Решение.",
            f"1) Переводим составное именованное число в {conversion_unit}: {left['text']} = {left_simple} {conversion_unit}",
            action_line,
            f"3) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при умножении и делении составные именованные числа сначала заменяют простыми, а потом выполняют вычисление",
        )

    right = parsed["right"]
    number = parsed["left_number"]
    conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
    right_simple = right["total"] // _measure_factor_20260411AA(family, conversion_unit)
    result_simple = right_simple * number
    result_total = result_simple * _measure_factor_20260411AA(family, conversion_unit)
    answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
    return join_explanation_lines(
        f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
        "Решение.",
        f"1) Переводим составное именованное число в {conversion_unit}: {right['text']} = {right_simple} {conversion_unit}",
        f"2) Умножаем: {number} × {right_simple} = {result_simple} {conversion_unit}",
        f"3) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
        f"Ответ: {answer}",
        "Совет: при умножении составного именованного числа сначала переводи его в простое именованное число",
    )

# --- USER FINAL CONSOLIDATION PATCH 2026-04-11: generic equations + clearer textbook answers ---

_PATCH_USER_FINAL_PREV_INFER_TASK_KIND = infer_task_kind

def _user_final_equation_variable_name(source: str) -> str:
    match = re.search(r"[A-Za-zА-Яа-я]", str(source or ""))
    return match.group(0) if match else "x"

def to_equation_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(text)
    text = normalize_cyrillic_x(text)
    text = text.replace("X", "x").replace("×", "*").replace("·", "*").replace("÷", "/").replace(":", "/")
    text = re.sub(r"\s+", "", text)
    if text.count("=") != 1:
        return None
    if not re.fullmatch(r"[\dA-Za-zА-Яа-я=+\-*/]+", text):
        return None
    letters = re.findall(r"[A-Za-zА-Яа-я]", text)
    if not letters:
        return None
    unique_letters = {letter.lower() for letter in letters}
    if len(unique_letters) != 1:
        return None
    variable = letters[0]
    if text.count(variable) + text.lower().count(variable.lower()) < 1:
        return None
    return text

def infer_task_kind(text: str) -> str:
    if to_equation_source(text):
        return "equation"
    return _PATCH_USER_FINAL_PREV_INFER_TASK_KIND(text)

def _user_final_format_equation_check(template: str, variable_name: str, value_text: str, expected_text: str) -> str:
    expression = template.replace(variable_name, value_text)
    return f"Проверка: {expression} = {expected_text}"

def try_local_equation_explanation(raw_text: str) -> Optional[str]:
    source = to_equation_source(raw_text)
    if not source:
        return None

    variable_name = _user_final_equation_variable_name(source)
    lhs, rhs = source.split("=", 1)
    if variable_name not in lhs and variable_name in rhs:
        lhs, rhs = rhs, lhs

    try:
        rhs_value = Fraction(int(rhs), 1)
    except ValueError:
        return None

    variable_re = re.escape(variable_name)
    patterns = [
        (rf"^{variable_re}\+(\d+)$", "var_plus"),
        (rf"^{variable_re}-(\d+)$", "var_minus"),
        (rf"^{variable_re}\*(\d+)$", "var_mul"),
        (rf"^{variable_re}/(\d+)$", "var_div"),
        (rf"^(\d+)\+{variable_re}$", "plus_var"),
        (rf"^(\d+)-{variable_re}$", "minus_var"),
        (rf"^(\d+)\*{variable_re}$", "mul_var"),
        (rf"^(\d+)/{variable_re}$", "div_var"),
    ]

    for pattern, kind in patterns:
        match = re.fullmatch(pattern, lhs)
        if not match:
            continue

        number = Fraction(int(match.group(1)), 1)
        number_text = format_fraction(number)
        rhs_text = format_fraction(rhs_value)

        if kind in {"var_plus", "plus_var"}:
            answer = rhs_value - number
            check_template = f"{variable_name} + {number_text}" if kind == "var_plus" else f"{number_text} + {variable_name}"
            return join_explanation_lines(
                "Ищем неизвестное слагаемое",
                f"Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: {rhs_text} - {number_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(check_template, variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное слагаемое находим вычитанием",
            )

        if kind == "var_minus":
            answer = rhs_value + number
            return join_explanation_lines(
                "Ищем неизвестное уменьшаемое",
                f"Чтобы найти неизвестное уменьшаемое, к разности прибавляем вычитаемое: {rhs_text} + {number_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(f"{variable_name} - {number_text}", variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное уменьшаемое находим сложением",
            )

        if kind == "minus_var":
            answer = number - rhs_value
            return join_explanation_lines(
                "Ищем неизвестное вычитаемое",
                f"Чтобы найти неизвестное вычитаемое, из уменьшаемого вычитаем разность: {number_text} - {rhs_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(f"{number_text} - {variable_name}", variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное вычитаемое находим вычитанием",
            )

        if kind in {"var_mul", "mul_var"}:
            if number == 0:
                if rhs_value == 0:
                    return join_explanation_lines(
                        "При умножении на 0 всегда получается 0",
                        "Значит, подходит любое число",
                        "Ответ: подходит любое число",
                        "Совет: 0 × любое число = 0",
                    )
                return join_explanation_lines(
                    "При умножении на 0 нельзя получить другое число",
                    "Ответ: решения нет",
                    "Совет: проверь уравнение ещё раз",
                )
            answer = rhs_value / number
            check_template = f"{variable_name} × {number_text}" if kind == "var_mul" else f"{number_text} × {variable_name}"
            return join_explanation_lines(
                "Ищем неизвестный множитель",
                f"Чтобы найти неизвестный множитель, произведение делим на известный множитель: {rhs_text} : {number_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(check_template, variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестный множитель находим делением",
            )

        if kind == "var_div":
            if number == 0:
                return join_explanation_lines(
                    "На ноль делить нельзя",
                    "Ответ: решения нет",
                    "Совет: проверь делитель",
                )
            answer = rhs_value * number
            return join_explanation_lines(
                "Ищем неизвестное делимое",
                f"Чтобы найти неизвестное делимое, делитель умножаем на частное: {rhs_text} × {number_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(f"{variable_name} : {number_text}", variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное делимое находим умножением",
            )

        if kind == "div_var":
            if rhs_value == 0:
                return join_explanation_lines(
                    "На ноль делить нельзя, а частное здесь равно 0",
                    "Ответ: решения нет",
                    "Совет: проверь уравнение ещё раз",
                )
            answer = number / rhs_value
            return join_explanation_lines(
                "Ищем неизвестный делитель",
                f"Чтобы найти неизвестный делитель, делимое делим на частное: {number_text} : {rhs_text} = {format_fraction(answer)}",
                _user_final_format_equation_check(f"{number_text} : {variable_name}", variable_name, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестный делитель находим делением",
            )
    return None



def _user_final_question_text(raw_text: str) -> str:
    try:
        _, question = extract_condition_and_question(raw_text)
    except Exception:
        question = ""
    return str(question or "").lower().replace("ё", "е")

def try_patch_textbook_two_products_money_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _user_final_question_text(raw_text)
    if "сколько" not in lower:
        return None
    if not contains_any_fragment(question, ("сколько денег", "сколько заплат", "сколько стоила вся покупка", "сколько стоит вся покупка", "сколько стоила покупка", "сколько стоит покупка")):
        return None

    matches = list(re.finditer(r"(\d+)\s+[^?.!,]{1,40}?\s+по\s+(\d+)\s*(?:руб|руб\.|рубля|рублей)?", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_price = int(matches[0].group(2))
    second_count = int(matches[1].group(1))
    second_price = int(matches[1].group(2))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если первая покупка состоит из {first_count} предметов по {first_price} руб., то её стоимость равна {first_count} × {first_price} = {first_total} руб.",
        f"2) Если вторая покупка состоит из {second_count} предметов по {second_price} руб., то её стоимость равна {second_count} × {second_price} = {second_total} руб.",
        f"3) Если первая покупка стоит {first_total} руб., а вторая {second_total} руб., то вся покупка стоит {first_total} + {second_total} = {total} руб.",
        f"Ответ: за всю покупку заплатили {total} руб.",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно.",
    )






# --- USER CONSOLIDATION PATCH 2026-04-11: textbook wording, safer precedence, preserved architecture ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку «Порядок действий:».
3. Ниже пиши тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
4. Потом пиши строку «Решение по действиям:».
5. Ниже пиши действия по порядку: 1) ... 2) ... 3) ...
6. В конце пиши строку «Ответ: ...».

Для текстовых задач:
1. Сначала пиши «Задача.» и само условие без изменения чисел.
2. Потом пиши «Решение.»
3. Затем обязательно пиши «Что известно: ...» и «Что нужно найти: ...».
4. Дальше решай по действиям.
5. После каждого действия коротко говори, что нашли.
6. По возможности используй школьную форму «Если ..., то ...».
7. В конце пиши «Ответ: ...».

Для уравнений:
1. Пиши строку «Уравнение: ...».
2. Потом «Решение.»
3. Решай по шагам.
4. Обязательно пиши «Проверка: ...».
5. Потом «Ответ: ...».

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии и величин:
1. Сначала назови правило или формулу.
2. Если нужно, сначала переведи величины в одинаковые единицы.
3. Потом решай по действиям.
4. В ответе обязательно пиши единицы измерения.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Сохраняй вычисления в столбик и подробные пояснения.
Сложение или вычитание в столбик особенно уместно, если в вычислениях больше двух двузначных чисел или есть хотя бы одно трёхзначное число.
""".strip()




























def try_local_expression_explanation(raw_text: str) -> Optional[str]:
    source = to_expression_source(raw_text)
    if not source:
        return None
    node = parse_expression_ast(source)
    if node is None:
        return None

    # Важно: цепочку сложения упрощаем только без скобок, чтобы не ломать школьный порядок действий.
    if "(" not in source and ")" not in source:
        add_chain = flatten_add_chain(node)
        if add_chain and all(n >= 0 for n in add_chain):
            if should_use_column_for_sum(add_chain):
                return explain_column_addition(add_chain)
            if len(add_chain) == 2:
                return explain_simple_addition(add_chain[0], add_chain[1])
            current = add_chain[0]
            lines = ["Нужно найти сумму нескольких чисел."]
            for idx, n in enumerate(add_chain[1:], start=1):
                new_total = current + n
                if idx == 1:
                    lines.append(f"Сначала складываем: {current} + {n} = {new_total}.")
                elif idx == 2:
                    lines.append(f"Потом складываем: {current} + {n} = {new_total}.")
                else:
                    lines.append(f"Дальше складываем: {current} + {n} = {new_total}.")
                current = new_total
            lines.extend([f"Ответ: {current}", "Совет: при нескольких действиях считай по порядку"])
            return join_explanation_lines(*lines)

    simple = try_simple_binary_int_expression(node)
    if simple:
        operator = simple["operator"]
        left = simple["left"]
        right = simple["right"]
        if operator is ast.Add:
            return explain_simple_addition(left, right)
        if operator is ast.Sub:
            return explain_simple_subtraction(left, right)
        if operator is ast.Mult:
            return explain_simple_multiplication(left, right)
        if operator is ast.Div:
            return explain_simple_division(left, right)

    try:
        value, steps = build_eval_steps(node, source)
    except ZeroDivisionError:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: сначала смотри на делитель")
    except Exception:
        return None

    if not steps:
        return None

    body_lines = []
    has_brackets = "(" in source or ")" in source
    for index, step in enumerate(steps, start=1):
        text = f"{step['left']} {step['operator']} {step['right']} = {step['result']}"
        if index == 1 and has_brackets and len(steps) > 1:
            body_lines.append(f"{index}) Сначала выполняем действие в скобках: {text}")
        elif index == 1:
            body_lines.append(f"{index}) Сначала {step['verb']}: {text}")
        elif index == 2:
            body_lines.append(f"{index}) Потом {step['verb']}: {text}")
        else:
            body_lines.append(f"{index}) Дальше {step['verb']}: {text}")

    answer = format_fraction(value)
    advice = "сначала выполняй умножение и деление, потом сложение и вычитание" if re.search(r"[+\-].*[*/]|[*/].*[+\-]", source) else default_advice("expression")
    return join_explanation_lines(*body_lines, f"Ответ: {answer}", f"Совет: {advice}")

# --- USER TEXTBOOK PATCH 2026-04-11B: shelf/book templates from the uploaded methodology ---

def _user_patch_lower_text_20260411b(raw_text: str) -> str:
    return normalize_word_problem_text(raw_text).lower().replace("ё", "е")
