"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 12293-12902."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    source = _final_20260415_normalize_fraction_expression_source(raw_text)
    if not source:
        return None

    if re.fullmatch(r'\d+/\d+[+\-]\d+/\d+', source):
        return None

    try:
        root = _final_20260415_parse_fraction_expression(source)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')

    if not root:
        return None

    try:
        result, steps = _final_user_fraction_eval_steps_with_positions(root)
    except ZeroDivisionError:
        return join_explanation_lines('На ноль делить нельзя', 'Ответ: деление на ноль невозможно')
    except Exception:
        return None

    if not steps:
        return None

    lines: List[str] = [f"Пример: {_final_20260415_render_fraction_node(root)}"]
    if len(steps) > 1:
        lines.extend(_final_user_fraction_order_lines(source, steps))
        lines.append('Решение по действиям:')
    else:
        lines.append('Решение.')

    for index, step in enumerate(steps, 1):
        lines.extend(_final_20260415_fraction_step_lines(index, step))

    lines.append(f"Ответ: {_final_user_fraction_answer_chain(root, steps, result)}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL USER PATCH 2026-04-15AC: keep order-marker lines without trailing dot in mixed fraction expressions ---

_FINAL_USER_20260415AC_PREV_BUILD_FRACTION_MIXED = _build_fraction_mixed_expression_explanation

def _build_fraction_mixed_expression_explanation(raw_text: str) -> Optional[str]:
    text = _FINAL_USER_20260415AC_PREV_BUILD_FRACTION_MIXED(raw_text)
    if not text:
        return text
    return re.sub(r'(?m)^([0-9 ]+)\.$', r'\1', text)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_mixed_expression_explanation(raw_text)
        or _FINAL_USER_20260415AB_PREV_AUDIT_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL PATCH 2026-04-15AD: textbook word problems and simple systems ---


def _final_20260415ad_prepare_word_text(raw_text: str) -> Tuple[str, str, List[int]]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    return text, lower, nums

def _final_20260415ad_result_dict(text: str, source: str = 'local-textbook-fix') -> dict:
    return {'result': text, 'source': source, 'validated': True}



def _final_20260415ad_try_times_more_and_equal_groups(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'разлож' not in lower and 'разложили' not in lower and 'поровну' not in lower:
        return None
    if 'в каждой' not in lower and 'в одной' not in lower:
        return None
    if 'в ' not in lower or 'раза больше' not in lower:
        return None
    if 'с другой' not in lower and 'со второй' not in lower:
        return None

    first, multiplier, groups = nums[:3]
    if multiplier <= 1 or groups <= 0:
        return None

    second = first * multiplier
    total = first + second
    if total % groups != 0:
        return None
    each = total // groups

    unit = 'кг'
    if 'литр' in lower:
        unit = 'л'
    elif 'книга' in lower:
        unit = 'книг'

    object_label = 'во второй группе'
    if 'яблок' in lower:
        object_label = 'со второй яблони'
    elif 'груш' in lower:
        object_label = 'со второй груши'

    container_label = 'в каждой корзине'
    if 'корзин' in lower:
        container_label = 'в каждой корзине'
    elif 'ящик' in lower:
        container_label = 'в каждом ящике'
    elif 'пакет' in lower:
        container_label = 'в каждом пакете'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: сначала получили {first} {unit}, потом ещё в {multiplier} раза больше, чем сначала. Всё разложили поровну в {groups} групп.',
        f'Что нужно найти: сколько {unit} {container_label}.',
        f'1) Сначала узнаем, сколько получилось {object_label}: {first} × {multiplier} = {second} {unit}.',
        f'2) Потом узнаем, сколько получилось всего: {first} + {second} = {total} {unit}.',
        f'3) Теперь делим всё поровну на {groups} групп: {total} : {groups} = {each} {unit}.',
        f'Ответ: {container_label} {each} {unit}.'
    )

def _final_20260415ad_try_each_brought_then_total(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'каждый' not in lower and 'каждая' not in lower and 'каждое' not in lower:
        return None
    if 'по' not in lower or 'стало' not in lower:
        return None
    if 'сколько' not in lower or 'было' not in lower:
        return None
    if not (('принес' in lower or 'принёс' in lower or 'принесли' in lower) and ('библиотек' in lower or 'книг' in lower)):
        return None

    people, per_person, total_after = nums[:3]
    added = people * per_person
    initial = total_after - added
    if min(people, per_person, total_after, initial) < 0:
        return None

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {people} учеников принесли по {per_person} книги, и после этого стало {total_after} книг.',
        'Что нужно найти: сколько книг было сначала.',
        f'1) Сначала найдём, сколько книг принесли ученики: {people} × {per_person} = {added}.',
        f'2) Потом найдём, сколько книг было в библиотеке сначала: {total_after} - {added} = {initial}.',
        f'Ответ: в библиотеке было {initial} книг.'
    )

def _final_20260415ad_try_first_day_second_more_remaining(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'в первый день' not in lower or 'во второй' not in lower:
        return None
    if 'на' not in lower or 'больше' not in lower:
        return None
    if 'осталось' not in lower and 'сколько тонн' not in lower and 'сколько осталось' not in lower:
        return None
    if not contains_any_fragment(lower, ('отправили', 'отправил', 'израсходовали', 'продали', 'увезли', 'вывезли')):
        return None

    total_before, first_day, diff = nums[:3]
    second_day = first_day + diff
    total_sent = first_day + second_day
    left = total_before - total_sent
    if min(total_before, first_day, second_day, total_sent, left) < 0:
        return None

    unit = 'т'
    if 'кг' in lower:
        unit = 'кг'
    elif 'мешк' in lower:
        unit = 'мешков'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: сначала было {total_before} {unit}. В первый день отправили {first_day} {unit}, а во второй день — на {diff} {unit} больше.',
        f'Что нужно найти: сколько {unit} осталось.',
        f'1) Сначала найдём, сколько отправили во второй день: {first_day} + {diff} = {second_day} {unit}.',
        f'2) Потом найдём, сколько отправили за два дня: {first_day} + {second_day} = {total_sent} {unit}.',
        f'3) Теперь найдём, сколько осталось: {total_before} - {total_sent} = {left} {unit}.',
        f'Ответ: осталось {left} {unit}.'
    )





def _final_20260415ad_try_read_and_remaining(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'прочитал' not in lower or 'осталось' not in lower:
        return None
    if 'на' not in lower or ('меньше' not in lower and 'больше' not in lower):
        return None
    if 'сколько страниц в книге' not in lower and 'сколько страниц' not in lower:
        return None

    read_pages, diff = nums[:2]
    if 'меньше' in lower:
        left = read_pages - diff
        compare_text = 'меньше'
        expr = f'{read_pages} - {diff}'
    else:
        left = read_pages + diff
        compare_text = 'больше'
        expr = f'{read_pages} + {diff}'
    if left < 0:
        return None
    total = read_pages + left

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: мальчик прочитал {read_pages} страниц. До конца книги осталось на {diff} страниц {compare_text}.',
        'Что нужно найти: сколько страниц в книге.',
        f'1) Сначала найдём, сколько страниц осталось прочитать: {expr} = {left}.',
        f'2) Потом найдём, сколько страниц в книге всего: {read_pages} + {left} = {total}.',
        f'Ответ: в книге {total} страниц.'
    )

def _final_20260415ad_try_relation_times_bigger(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'в ' not in lower or 'раза больше' not in lower:
        return None
    if 'чем' not in lower:
        return None
    if not contains_any_fragment(lower, ('сколько километров в час', 'какая скорость', 'с какой скоростью', 'сколько проходит')):
        return None

    bigger_value, times = nums[:2]
    if times <= 0 or bigger_value % times != 0:
        return None
    smaller = bigger_value // times
    unit = 'км/ч' if ('км/ч' in lower or 'километров в час' in lower) else ''

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: одно расстояние или скорость равно {bigger_value} {unit}'.strip() + f'. Это в {times} раза больше, чем другое.',
        'Что нужно найти: меньшее значение.',
        f'1) Если одно значение в {times} раза больше другого, то меньшее значение находим делением.',
        f'2) Считаем: {bigger_value} : {times} = {smaller} {unit}'.rstrip(),
        f'Ответ: {smaller} {unit}'.rstrip() + '.'.replace(' .','.')
    ).replace(' .', '.').replace('..', '.')

def _final_20260415ad_try_rectangle_width_from_perimeter(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'периметр прямоугольника' not in lower or 'длина' not in lower:
        return None
    if 'ширин' not in lower:
        return None

    perimeter, length = nums[:2]
    if perimeter % 2 != 0:
        return None
    half = perimeter // 2
    width = half - length
    if width < 0:
        return None
    unit = 'см'
    if 'дм' in lower:
        unit = 'дм'
    elif re.search(r'\bм\b', lower):
        unit = 'м'
    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: периметр прямоугольника {perimeter} {unit}, длина {length} {unit}.',
        'Что нужно найти: ширину прямоугольника.',
        '1) Периметр прямоугольника равен сумме длины и ширины, умноженной на 2: P = 2 × (a + b).',
        f'2) Найдём сумму длины и ширины: {perimeter} : 2 = {half}.',
        f'3) Теперь найдём ширину: {half} - {length} = {width}.',
        f'Ответ: ширина прямоугольника {width} {unit}.'
    )

def _final_20260415ad_parse_simple_linear_equation(eq: str):
    match = re.fullmatch(r'([A-Za-zА-Яа-я])([+\-])([A-Za-zА-Яа-я])=(-?\d+)', eq)
    if not match:
        return None
    left, operator, right, value = match.groups()
    return left, operator, right, int(value)

def _final_20260415ad_try_simple_system(raw_text: str) -> Optional[str]:
    compact = normalize_cyrillic_x(strip_known_prefix(raw_text)).replace(' ', '').replace(';', ',')
    if compact.count('=') != 2 or ',' not in compact:
        return None
    parts = [part for part in compact.split(',') if part]
    if len(parts) != 2:
        return None
    parsed = [_final_20260415ad_parse_simple_linear_equation(part) for part in parts]
    if any(item is None for item in parsed):
        return None

    plus_eq = next((item for item in parsed if item[1] == '+'), None)
    minus_eq = next((item for item in parsed if item[1] == '-'), None)
    if plus_eq is None or minus_eq is None:
        return None

    a1, _, b1, total_sum = plus_eq
    a2, _, b2, diff_value = minus_eq
    if {a1.lower(), b1.lower()} != {a2.lower(), b2.lower()}:
        return None

    if a2.lower() == a1.lower() and b2.lower() == b1.lower():
        x_name, y_name = a1, b1
        x_value = Fraction(total_sum + diff_value, 2)
        y_value = Fraction(total_sum, 1) - x_value
    elif a2.lower() == b1.lower() and b2.lower() == a1.lower():
        y_name, x_name = a2, b2
        y_value = Fraction(total_sum + diff_value, 2)
        x_value = Fraction(total_sum, 1) - y_value
    else:
        return None

    if x_value.denominator != 1 or y_value.denominator != 1:
        return None
    x_int = x_value.numerator
    y_int = y_value.numerator

    return _audit_join_lines(
        'Система уравнений:',
        f'{a1} + {b1} = {total_sum}',
        f'{a2} - {b2} = {diff_value}' if a2.lower() == a1.lower() and b2.lower() == b1.lower() else f'{a2} - {b2} = {diff_value}',
        'Решение.',
        f'1) Сложим правые части и учтём, что в одном уравнении {y_name} прибавляется, а в другом вычитается.',
        f'2) Получаем: 2{x_name} = {total_sum} + {diff_value} = {total_sum + diff_value}.',
        f'3) Находим {x_name}: {total_sum + diff_value} : 2 = {x_int}.',
        f'4) Подставляем {x_name} в первое уравнение: {x_int} + {y_name} = {total_sum}.',
        f'5) Находим {y_name}: {total_sum} - {x_int} = {y_int}.',
        f'Ответ: {x_name} = {x_int}, {y_name} = {y_int}.'
    )

def _final_20260415ad_try_textbook_fixes(raw_text: str) -> Optional[str]:
    return (
        _final_20260415ad_try_garage_indirect_counts(raw_text)
        or _final_20260415ad_try_times_more_and_equal_groups(raw_text)
        or _final_20260415ad_try_each_brought_then_total(raw_text)
        or _final_20260415ad_try_first_day_second_more_remaining(raw_text)
        or _final_20260415ad_try_leftover_then_group_count(raw_text)
        or _final_20260415ad_try_money_part_to_whole(raw_text)
        or _final_20260415ad_try_three_pair_sums(raw_text)
        or _final_20260415ad_try_read_and_remaining(raw_text)
        or _final_20260415ad_try_relation_times_bigger(raw_text)
        or _final_20260415ad_try_rectangle_width_from_perimeter(raw_text)
        or _final_20260415ad_try_simple_system(raw_text)
    )



# --- FINAL PATCH 2026-04-15AE: cleaner textbook wording and answer grammar ---

def _final_20260415ae_plural(number: int, one: str, few: str, many: str) -> str:
    number = abs(int(number))
    mod100 = number % 100
    mod10 = number % 10
    if 11 <= mod100 <= 14:
        return many
    if mod10 == 1:
        return one
    if 2 <= mod10 <= 4:
        return few
    return many

def _final_20260415ad_try_garage_indirect_counts(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'автобус' not in lower or 'грузов' not in lower or 'легков' not in lower:
        return None
    if 'сколько всего' not in lower or 'гараж' not in lower:
        return None
    if 'это на' not in lower or 'больше, чем грузов' not in lower:
        return None
    if 'меньше, чем грузов' not in lower:
        return None

    buses, diff_to_trucks, diff_to_cars = nums[:3]
    trucks = buses - diff_to_trucks
    cars = trucks - diff_to_cars
    if min(buses, trucks, cars) < 0:
        return None
    total = buses + trucks + cars
    machine_word = _final_20260415ae_plural(total, 'машина', 'машины', 'машин')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: автобусов {buses}. Это на {diff_to_trucks} больше, чем грузовых машин. Легковых машин на {diff_to_cars} меньше, чем грузовых.',
        'Что нужно найти: сколько всего машин в гараже.',
        f'1) Сначала найдём количество грузовых машин. Если автобусов на {diff_to_trucks} больше, чем грузовых, то грузовых на {diff_to_trucks} меньше: {buses} - {diff_to_trucks} = {trucks}.',
        f'2) Потом найдём количество легковых машин. Если легковых на {diff_to_cars} меньше, чем грузовых, то {trucks} - {diff_to_cars} = {cars}.',
        f'3) Теперь найдём, сколько всего машин в гараже: {buses} + {trucks} + {cars} = {total}.',
        f'Ответ: всего {total} {machine_word}.'
    )



def _final_20260415ad_try_money_part_to_whole(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if not nums:
        return None
    if 'денег' not in lower and 'руб' not in lower:
        return None
    if 'сколько денег было' not in lower and 'сколько было денег' not in lower and 'сколько денег у' not in lower:
        return None

    multiplier = None
    fraction_label = None
    if 'половин' in lower:
        multiplier = 2
        fraction_label = 'половина'
    elif 'треть' in lower:
        multiplier = 3
        fraction_label = 'треть'
    elif 'четверт' in lower:
        multiplier = 4
        fraction_label = 'четверть'
    if multiplier is None:
        return None
    if not contains_any_fragment(lower, ('заплат', 'израсход', 'потрат', 'покупк')):
        return None

    part_value = nums[-1]
    total = part_value * multiplier

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {part_value} руб. — это {fraction_label} всех денег.',
        'Что нужно найти: сколько денег было сначала.',
        f'1) {part_value} руб. — это {fraction_label} всех денег.',
        f'2) Чтобы найти все деньги, умножаем {part_value} на {multiplier}: {part_value} × {multiplier} = {total} руб.',
        f'Ответ: было {total} руб.'
    )



# --- FINAL PATCH 2026-04-15AF: wording cleanup for watering and age-sum tasks ---

def _final_20260415ad_try_leftover_then_group_count(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'осталось' not in lower and 'ещё осталось' not in lower and 'еще осталось' not in lower:
        return None
    if 'на кажд' not in lower or 'по' not in lower:
        return None
    if not ('сколько' in lower and contains_any_fragment(lower, ('грядок', 'корзин', 'пакетов', 'ящиков', 'рядов'))):
        return None

    total, per_group, leftover = nums[:3]
    used = total - leftover
    if per_group <= 0 or used < 0 or used % per_group != 0:
        return None
    groups = used // per_group

    ask_phrase = 'сколько грядок полили'
    known_phrase = f'На каждую грядку вылили по {per_group} ведра.'
    answer_phrase = f'Ответ: полили {groups} грядок.'
    unit_name = 'ведер'

    if 'корзин' in lower:
        ask_phrase = 'сколько корзин получилось'
        known_phrase = f'В каждую корзину положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} корзин.'
        unit_name = 'единиц'
    elif 'ящик' in lower:
        ask_phrase = 'сколько ящиков получилось'
        known_phrase = f'В каждый ящик положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} ящиков.'
        unit_name = 'единиц'
    elif 'пакет' in lower:
        ask_phrase = 'сколько пакетов получилось'
        known_phrase = f'В каждый пакет положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} пакетов.'
        unit_name = 'единиц'
    elif 'ряд' in lower and 'гряд' not in lower:
        ask_phrase = 'сколько рядов получилось'
        known_phrase = f'В каждый ряд положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} рядов.'
        unit_name = 'единиц'

    if 'вёдер' in lower or 'ведер' in lower:
        unit_name = 'ведер'
    elif 'литр' in lower:
        unit_name = 'литров'
        if 'гряд' in lower:
            known_phrase = f'На каждую грядку вылили по {per_group} литра.'
    elif 'килограмм' in lower or 'кг' in lower:
        unit_name = 'килограммов'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: всего было {total} {unit_name}. {known_phrase} После этого осталось {leftover} {unit_name}.',
        f'Что нужно найти: {ask_phrase}.',
        f'1) Сначала найдём, сколько {unit_name} израсходовали: {total} - {leftover} = {used}.',
        f'2) Потом найдём число групп: {used} : {per_group} = {groups}.',
        answer_phrase
    )



# --- FINAL PATCH 2026-04-15AG: neutral wording for age-pair sums ---

def _final_20260415ad_try_three_pair_sums(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    pairs = re.findall(r'([а-яё-]+)\s+и\s+([а-яё-]+)\s+вместе\s+(\d+)', lower)
    if len(pairs) != 3:
        return None
    if 'сколько им лет' not in lower and 'сколько лет' not in lower:
        return None

    first_a, first_b, first_sum = pairs[0][0], pairs[0][1], int(pairs[0][2])
    second_a, second_b, second_sum = pairs[1][0], pairs[1][1], int(pairs[1][2])
    third_a, third_b, third_sum = pairs[2][0], pairs[2][1], int(pairs[2][2])

    common = set((first_a, first_b)).intersection((second_a, second_b))
    if len(common) != 1:
        return None
    common_name = list(common)[0]
    other_first = first_b if first_a == common_name else first_a
    other_second = second_b if second_a == common_name else second_a
    if set((other_first, other_second)) != set((third_a, third_b)):
        return None

    double_common = first_sum + second_sum - third_sum
    if double_common < 0 or double_common % 2 != 0:
        return None
    common_age = double_common // 2
    first_age = first_sum - common_age
    second_age = second_sum - common_age
    if min(common_age, first_age, second_age) < 0:
        return None

    first_sum_word = _final_20260415ae_plural(first_sum, 'год', 'года', 'лет')
    second_sum_word = _final_20260415ae_plural(second_sum, 'год', 'года', 'лет')
    third_sum_word = _final_20260415ae_plural(third_sum, 'год', 'года', 'лет')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {first_a} и {first_b} вместе {first_sum} {first_sum_word}, {second_a} и {second_b} вместе {second_sum} {second_sum_word}, {third_a} и {third_b} вместе {third_sum} {third_sum_word}.',
        'Что нужно найти: сколько лет каждому.',
        f'1) Сложим первую и вторую суммы: {first_sum} + {second_sum} = {first_sum + second_sum}.',
        f'2) Вычтем третью сумму: {first_sum + second_sum} - {third_sum} = {double_common}. Получили возраст одного человека два раза.',
        f'3) Найдём этот возраст: {double_common} : 2 = {common_age}.',
        f'4) По первой сумме найдём второй возраст: {first_sum} - {common_age} = {first_age}.',
        f'5) По второй сумме найдём третий возраст: {second_sum} - {common_age} = {second_age}.',
        f'Ответ: {common_name} {common_age} {_final_20260415ae_plural(common_age, "год", "года", "лет")}, {other_first} {first_age} {_final_20260415ae_plural(first_age, "год", "года", "лет")}, {other_second} {second_age} {_final_20260415ae_plural(second_age, "год", "года", "лет")}.'
    )

# --- FINAL PATCH 2026-04-16: eliminate remaining textbook audit failures without touching stable flows ---

_FINAL_20260416_PREV_GEOMETRY = try_local_geometry_explanation
