"""Auto-generated runtime shard for prepatch_build_source.py, lines 15107-15975."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _final_20260416_try_same_price_two_days(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 3:
        return None
    if 'в первый день' not in lower or 'во второй' not in lower:
        return None
    if 'по той же цене' not in lower and 'по одинаковой цене' not in lower:
        return None
    if 'за все' not in lower and 'за все полки' not in lower:
        return None
    if not contains_any_fragment(lower, ('сколько денег истратили', 'сколько денег потратили', 'сколько заплатили в первый день')):
        return None

    first_qty, second_qty, total_cost = nums[:3]
    total_qty = first_qty + second_qty
    if total_qty <= 0 or total_cost % total_qty != 0:
        return None
    price = total_cost // total_qty
    first_cost = first_qty * price
    second_cost = second_qty * price

    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: в первый день купили {first_qty} полок, во второй — {second_qty} таких же полок по той же цене. За все полки заплатили {total_cost} р.',
        'Что нужно найти: сколько денег истратили в первый день и сколько — во второй день.',
        f'1) Сначала найдём, сколько полок купили всего: {first_qty} + {second_qty} = {total_qty}.',
        f'2) Теперь найдём цену одной полки: {total_cost} : {total_qty} = {price} р.',
        f'3) Узнаем, сколько заплатили в первый день: {first_qty} × {price} = {first_cost} р.',
        f'4) Узнаем, сколько заплатили во второй день: {second_qty} × {price} = {second_cost} р.',
        f'Ответ: в первый день — {first_cost} р, во второй день — {second_cost} р.'
    )

def _final_20260416_try_red_green_apples_half_taken(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 2:
        return None
    if 'красн' not in lower or 'зелен' not in lower or 'яблок' not in lower:
        return None
    if 'половину всех яблок' not in lower or 'осталось' not in lower:
        return None
    if 'сначала' not in lower:
        return None

    green_added, remained_after_taking = nums[:2]
    total_before_taking = remained_after_taking * 2
    red_initial = total_before_taking - green_added
    if min(green_added, remained_after_taking, total_before_taking, red_initial) < 0:
        return None

    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: в корзину положили ещё {green_added} зелёных яблок. После того как взяли половину всех яблок, осталось {remained_after_taking} яблок.',
        'Что нужно найти: сколько красных яблок было в корзине сначала.',
        f'1) Если после того как взяли половину, осталось {remained_after_taking} яблок, значит это вторая половина всех яблок.',
        f'2) Тогда до того как взяли половину, в корзине было {remained_after_taking} × 2 = {total_before_taking} яблок.',
        f'3) Из этих яблок {green_added} были зелёные, значит красных было {total_before_taking} - {green_added} = {red_initial}.',
        f'Ответ: сначала в корзине было {red_initial} красных яблок.'
    )

def _final_20260416_try_fraction_whole_comparison(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 2:
        return None
    fraction_hits = list(re.finditer(r'(половина|треть|четверть)[^0-9]{0,60}?это\s*(\d+)', lower))
    if len(fraction_hits) != 2:
        return None

    parts = []
    for match in fraction_hits:
        frac_word = match.group(1)
        value = int(match.group(2))
        pair = _final_20260416_fraction_word_to_pair(frac_word)
        if not pair:
            return None
        num, den = pair
        whole = value * den // num
        if value * den % num != 0:
            return None
        parts.append({'word': frac_word, 'value': value, 'num': num, 'den': den, 'whole': whole})

    first_whole = parts[0]['whole']
    second_whole = parts[1]['whole']

    if 'во сколько раз' in lower and ('больше' in lower or 'меньше' in lower):
        bigger = max(first_whole, second_whole)
        smaller = min(first_whole, second_whole)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        unit = 'кг' if 'кг' in lower else ''
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {parts[0]["word"]} первого количества — это {parts[0]["value"]} {unit}. {parts[1]["word"]} второго количества — это {parts[1]["value"]} {unit}.',
            'Что нужно найти: во сколько раз одно количество больше другого.',
            f'1) Найдём всё первое количество: {parts[0]["value"]} × {parts[0]["den"]} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {parts[1]["value"]} × {parts[1]["den"]} = {second_whole} {unit}.',
            f'3) Сравним количества: {bigger} : {smaller} = {ratio}.',
            f'Ответ: в {ratio} раза.'
        )

    if 'на сколько' in lower and ('больше' in lower or 'меньше' in lower):
        difference = abs(second_whole - first_whole)
        unit = ''
        if 'см2' in lower or 'см²' in lower:
            unit = 'см²'
        elif 'кг' in lower:
            unit = 'кг'
        elif 'м2' in lower or 'м²' in lower:
            unit = 'м²'
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {parts[0]["word"]} первого количества — это {parts[0]["value"]} {unit}. {parts[1]["word"]} второго количества — это {parts[1]["value"]} {unit}.',
            'Что нужно найти: на сколько одно количество отличается от другого.',
            f'1) Найдём всё первое количество: {parts[0]["value"]} × {parts[0]["den"]} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {parts[1]["value"]} × {parts[1]["den"]} = {second_whole} {unit}.',
            f'3) Найдём разность: {max(first_whole, second_whole)} - {min(first_whole, second_whole)} = {difference} {unit}.',
            f'Ответ: на {difference} {unit}.'.replace('  ', ' ')
        )

    return None

def _final_20260416_try_ratio_difference_full_answer(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) != 2:
        return None
    if 'в 3 раза больше' not in lower and not re.search(r'в\s+\d+\s+раз(?:а)?\s+больше', lower):
        return None
    if 'на сколько' not in lower:
        return None
    if 'рек' not in lower or 'город' not in lower:
        return None
    first, factor = nums
    second = first * factor
    diff = second - first
    if diff < 0:
        return None
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: названий рек {first}, названий городов в {factor} раза больше.',
        'Что нужно найти: на сколько названий рек меньше, чем названий городов.',
        f'1) Сначала найдём, сколько названий городов: {first} × {factor} = {second}.',
        f'2) Теперь найдём, на сколько названий рек меньше: {second} - {first} = {diff}.',
        f'Ответ: названий рек на {diff} меньше, чем названий городов.'
    )

def _final_20260416_try_all_remaining_fixes(raw_text: str) -> Optional[str]:
    return (
        _final_20260416_try_pickles_two_days(raw_text)
        or _final_20260416_try_motion_compare_two_distances(raw_text)
        or _final_20260416_try_same_price_two_days(raw_text)
        or _final_20260416_try_red_green_apples_half_taken(raw_text)
        or _final_20260416_try_fraction_whole_comparison(raw_text)
        or _final_20260416_try_ratio_difference_full_answer(raw_text)
    )

async def build_explanation(user_text: str) -> dict:
    local = _final_20260416_try_all_remaining_fixes(user_text)
    if local:
        return _final_20260416_result_dict(local)
    return await _FINAL_20260416_PREV_BUILD_EXPLANATION(user_text)

# --- FINAL PATCH 2026-04-16B: direct geometry/textbook handlers and cleaner fraction-word parsing ---

_FINAL_20260416B_PREV_BUILD_EXPLANATION = build_explanation

def _final_20260416b_try_geometry_direct(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    unit = geometry_unit(lower)

    square_side_match = re.search(
        r'(?:квадрат[^.?!]{0,80}?со\s+сторон(?:ой|ою)?[^\d]{0,20}(\d+))|(?:сторона\s+квадрата[^\d]{0,20}(\d+))',
        lower,
    )
    square_side_val = int(next(group for group in square_side_match.groups() if group)) if square_side_match else None

    if 'квадрат' in lower and 'периметр' in lower and square_side_val is not None:
        result = square_side_val * 4
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: сторона квадрата равна {square_side_val} {unit}.',
            'Что нужно найти: периметр квадрата.',
            '1) У квадрата все четыре стороны равны.',
            f'2) Периметр квадрата — это сумма четырёх равных сторон: {square_side_val} × 4 = {result}.',
            f'Ответ: {with_unit(result, unit)}.'
        )

    area_val = extract_keyword_number(lower, 'площад')
    length_val = extract_keyword_number(lower, 'длина')
    width_val = extract_keyword_number(lower, 'ширина')
    asks_width = 'найдите ширину' in lower or 'найди ширину' in lower or 'какова ширина' in lower
    asks_length = ('найдите длину' in lower or 'найди длину' in lower or 'какова длина' in lower) and not asks_width

    if 'прямоугольн' in lower and area_val is not None and length_val is not None and asks_width and length_val != 0 and area_val % length_val == 0:
        width = area_val // length_val
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, длина {with_unit(length_val, unit)}.',
            'Что нужно найти: ширину прямоугольника.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти ширину, делим площадь на длину: {area_val} : {length_val} = {width}.',
            f'Ответ: {with_unit(width, unit)}.'
        )

    if 'прямоугольн' in lower and area_val is not None and width_val is not None and asks_length and width_val != 0 and area_val % width_val == 0:
        length = area_val // width_val
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, ширина {with_unit(width_val, unit)}.',
            'Что нужно найти: длину прямоугольника.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти длину, делим площадь на ширину: {area_val} : {width_val} = {length}.',
            f'Ответ: {with_unit(length, unit)}.'
        )

    return None

def _final_20260416b_try_fraction_whole_comparison(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 2:
        return None

    fraction_hits = []
    for match in re.finditer(r'(половина|треть|четверть)[^0-9]{0,80}?(?:это\s*)?(\d+)', lower):
        frac_word = match.group(1)
        value = int(match.group(2))
        pair = _final_20260416_fraction_word_to_pair(frac_word)
        if not pair:
            continue
        fraction_hits.append((frac_word, value, pair[0], pair[1]))
    if len(fraction_hits) < 2:
        return None
    fraction_hits = fraction_hits[:2]

    first_word, first_value, first_num, first_den = fraction_hits[0]
    second_word, second_value, second_num, second_den = fraction_hits[1]
    if first_value * first_den % first_num != 0 or second_value * second_den % second_num != 0:
        return None
    first_whole = first_value * first_den // first_num
    second_whole = second_value * second_den // second_num

    unit = ''
    if 'см2' in lower or 'см²' in lower:
        unit = 'см²'
    elif 'м2' in lower or 'м²' in lower:
        unit = 'м²'
    elif 'кг' in lower:
        unit = 'кг'

    if 'во сколько раз' in lower and ('больше' in lower or 'меньше' in lower):
        bigger = max(first_whole, second_whole)
        smaller = min(first_whole, second_whole)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {first_word} первого количества — это {first_value} {unit}. {second_word} второго количества — это {second_value} {unit}.',
            'Что нужно найти: во сколько раз одно количество больше другого.',
            f'1) Найдём всё первое количество: {first_value} × {first_den} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {second_value} × {second_den} = {second_whole} {unit}.',
            f'3) Сравним количества: {bigger} : {smaller} = {ratio}.',
            f'Ответ: в {ratio} раза.'
        )

    if 'на сколько' in lower and ('больше' in lower or 'меньше' in lower):
        difference = abs(second_whole - first_whole)
        big = max(first_whole, second_whole)
        small = min(first_whole, second_whole)
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {first_word} первого количества — это {first_value} {unit}. {second_word} второго количества — это {second_value} {unit}.',
            'Что нужно найти: на сколько одно количество отличается от другого.',
            f'1) Найдём всё первое количество: {first_value} × {first_den} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {second_value} × {second_den} = {second_whole} {unit}.',
            f'3) Найдём разность: {big} - {small} = {difference} {unit}.',
            f'Ответ: на {difference} {unit}.'.replace('  ', ' ')
        )

    return None

def _final_20260416b_try_red_green_apples_half_taken(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 2:
        return None
    if 'красн' not in lower or 'зелен' not in lower or 'яблок' not in lower:
        return None
    if 'половину всех яблок' not in lower or 'осталось' not in lower or 'сначала' not in lower:
        return None
    green_added, remained_after_taking = nums[:2]
    total_before_taking = remained_after_taking * 2
    red_initial = total_before_taking - green_added
    if min(green_added, remained_after_taking, total_before_taking, red_initial) < 0:
        return None
    apple_word = _final_20260415ae_plural(red_initial, 'красное яблоко', 'красных яблока', 'красных яблок')
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: в корзину положили ещё {green_added} зелёных яблок. После того как взяли половину всех яблок, осталось {remained_after_taking} яблок.',
        'Что нужно найти: сколько красных яблок было в корзине сначала.',
        f'1) Если после того как взяли половину, осталось {remained_after_taking} яблок, значит это половина всех яблок.',
        f'2) Тогда до того как взяли половину, в корзине было {remained_after_taking} × 2 = {total_before_taking} яблок.',
        f'3) Из этих яблок {green_added} были зелёные, значит красных было {total_before_taking} - {green_added} = {red_initial}.',
        f'Ответ: сначала в корзине было {red_initial} {apple_word}.'
    )

def _final_20260416_try_all_remaining_fixes(raw_text: str) -> Optional[str]:
    return (
        _final_20260416b_try_geometry_direct(raw_text)
        or _final_20260416_try_pickles_two_days(raw_text)
        or _final_20260416_try_motion_compare_two_distances(raw_text)
        or _final_20260416_try_same_price_two_days(raw_text)
        or _final_20260416b_try_red_green_apples_half_taken(raw_text)
        or _final_20260416b_try_fraction_whole_comparison(raw_text)
        or _final_20260416_try_ratio_difference_full_answer(raw_text)
    )

async def build_explanation(user_text: str) -> dict:
    local = _final_20260416_try_all_remaining_fixes(user_text)
    if local:
        return _final_20260416_result_dict(local, 'local-final-20260416b')
    return await _FINAL_20260416B_PREV_BUILD_EXPLANATION(user_text)

# --- FINAL PATCH 2026-04-16C: robust numeric extraction for geometry wording ---

_FINAL_20260416C_PREV_BUILD_EXPLANATION = build_explanation

def _final_20260416c_find_geometry_number(lower: str, keyword: str) -> Optional[int]:
    patterns = {
        'площадь': [
            r'площад[а-яё ]{0,20}(?:равна|=|составляет|имеет)?[^\d]{0,12}(\d+)\s*(?:мм2|см2|дм2|м2|км2|мм²|см²|дм²|м²|км²)?',
            r'(\d+)\s*(?:мм2|см2|дм2|м2|км2|мм²|см²|дм²|м²|км²)[^.?!]{0,30}площад',
        ],
        'длина': [
            r'длин[а-яё ]{0,20}(?:равна|=|имеет)?[^\d]{0,12}(\d+)\s*(?:мм|см|дм|м|км)\b',
            r'(\d+)\s*(?:мм|см|дм|м|км)\b[^.?!]{0,30}длин',
        ],
        'ширина': [
            r'ширин[а-яё ]{0,20}(?:равна|=|имеет)?[^\d]{0,12}(\d+)\s*(?:мм|см|дм|м|км)\b',
            r'(\d+)\s*(?:мм|см|дм|м|км)\b[^.?!]{0,30}ширин',
        ],
    }
    key = 'площадь' if keyword.startswith('площад') else 'длина' if keyword.startswith('длина') else 'ширина'
    for pattern in patterns[key]:
        match = re.search(pattern, lower)
        if match:
            return int(match.group(1))
    return None

def _final_20260416b_try_geometry_direct(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    unit = geometry_unit(lower)

    square_side_match = re.search(
        r'(?:квадрат[^.?!]{0,80}?со\s+сторон(?:ой|ою)?[^\d]{0,20}(\d+))|(?:сторона\s+квадрата[^\d]{0,20}(\d+))',
        lower,
    )
    square_side_val = int(next(group for group in square_side_match.groups() if group)) if square_side_match else None

    if 'квадрат' in lower and 'периметр' in lower and square_side_val is not None:
        result = square_side_val * 4
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: сторона квадрата равна {square_side_val} {unit}.',
            'Что нужно найти: периметр квадрата.',
            '1) У квадрата все четыре стороны равны.',
            f'2) Периметр квадрата — это сумма четырёх равных сторон: {square_side_val} × 4 = {result}.',
            f'Ответ: {with_unit(result, unit)}.'
        )

    area_val = _final_20260416c_find_geometry_number(lower, 'площадь')
    length_val = _final_20260416c_find_geometry_number(lower, 'длина')
    width_val = _final_20260416c_find_geometry_number(lower, 'ширина')
    asks_width = 'найдите ширину' in lower or 'найди ширину' in lower or 'какова ширина' in lower
    asks_length = ('найдите длину' in lower or 'найди длину' in lower or 'какова длина' in lower) and not asks_width

    if 'прямоугольн' in lower and area_val is not None and length_val is not None and asks_width and length_val != 0 and area_val % length_val == 0:
        width = area_val // length_val
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, длина {with_unit(length_val, unit)}.',
            'Что нужно найти: ширину прямоугольника.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти ширину, делим площадь на длину: {area_val} : {length_val} = {width}.',
            f'Ответ: {with_unit(width, unit)}.'
        )

    if 'прямоугольн' in lower and area_val is not None and width_val is not None and asks_length and width_val != 0 and area_val % width_val == 0:
        length = area_val // width_val
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, ширина {with_unit(width_val, unit)}.',
            'Что нужно найти: длину прямоугольника.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти длину, делим площадь на ширину: {area_val} : {width_val} = {length}.',
            f'Ответ: {with_unit(length, unit)}.'
        )

    return None

async def build_explanation(user_text: str) -> dict:
    local = _final_20260416_try_all_remaining_fixes(user_text)
    if local:
        return _final_20260416_result_dict(local, 'local-final-20260416c')
    return await _FINAL_20260416C_PREV_BUILD_EXPLANATION(user_text)

# --- FINAL PATCH 2026-04-16D: fuller textbook-style answers in new direct handlers ---

_FINAL_20260416D_PREV_BUILD_EXPLANATION = build_explanation

def _final_20260416b_try_geometry_direct(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    unit = geometry_unit(lower)

    square_side_match = re.search(
        r'(?:квадрат[^.?!]{0,80}?со\s+сторон(?:ой|ою)?[^\d]{0,20}(\d+))|(?:сторона\s+квадрата[^\d]{0,20}(\d+))',
        lower,
    )
    square_side_val = int(next(group for group in square_side_match.groups() if group)) if square_side_match else None

    if 'квадрат' in lower and 'периметр' in lower and square_side_val is not None:
        result = square_side_val * 4
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: сторона квадрата равна {square_side_val} {unit}.',
            'Что нужно найти: периметр квадрата.',
            '1) У квадрата все четыре стороны равны.',
            f'2) Периметр квадрата — это сумма четырёх равных сторон: {square_side_val} × 4 = {result}.',
            f'Ответ: периметр квадрата равен {with_unit(result, unit)}.'
        )

    area_val = _final_20260416c_find_geometry_number(lower, 'площадь')
    length_val = _final_20260416c_find_geometry_number(lower, 'длина')
    width_val = _final_20260416c_find_geometry_number(lower, 'ширина')
    asks_width = 'найдите ширину' in lower or 'найди ширину' in lower or 'какова ширина' in lower
    asks_length = ('найдите длину' in lower or 'найди длину' in lower or 'какова длина' in lower) and not asks_width

    if 'прямоугольн' in lower and area_val is not None and length_val is not None and asks_width and length_val != 0 and area_val % length_val == 0:
        width = area_val // length_val
        object_name = 'прямоугольника'
        if 'пруд' in lower:
            object_name = 'пруда'
        elif 'площадк' in lower:
            object_name = 'площадки'
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, длина {with_unit(length_val, unit)}.',
            f'Что нужно найти: ширину {object_name}.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти ширину, делим площадь на длину: {area_val} : {length_val} = {width}.',
            f'Ответ: ширина {object_name} равна {with_unit(width, unit)}.'
        )

    if 'прямоугольн' in lower and area_val is not None and width_val is not None and asks_length and width_val != 0 and area_val % width_val == 0:
        length = area_val // width_val
        object_name = 'прямоугольника'
        if 'площадк' in lower:
            object_name = 'площадки'
        elif 'пруд' in lower:
            object_name = 'пруда'
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, ширина {with_unit(width_val, unit)}.',
            f'Что нужно найти: длину {object_name}.',
            '1) Площадь прямоугольника равна длине, умноженной на ширину.',
            f'2) Чтобы найти длину, делим площадь на ширину: {area_val} : {width_val} = {length}.',
            f'Ответ: длина {object_name} равна {with_unit(length, unit)}.'
        )

    return None

def _final_20260416b_try_fraction_whole_comparison(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 2:
        return None

    fraction_hits = []
    for match in re.finditer(r'(половина|треть|четверть)([^0-9]{0,80}?)(?:это\s*)?(\d+)', lower):
        frac_word = match.group(1)
        object_fragment = (match.group(2) or '').strip(' ,-–—')
        value = int(match.group(3))
        pair = _final_20260416_fraction_word_to_pair(frac_word)
        if not pair:
            continue
        fraction_hits.append((frac_word, object_fragment, value, pair[0], pair[1]))
    if len(fraction_hits) < 2:
        return None
    fraction_hits = fraction_hits[:2]

    first_word, first_object, first_value, first_num, first_den = fraction_hits[0]
    second_word, second_object, second_value, second_num, second_den = fraction_hits[1]
    if first_value * first_den % first_num != 0 or second_value * second_den % second_num != 0:
        return None
    first_whole = first_value * first_den // first_num
    second_whole = second_value * second_den // second_num

    unit = ''
    if 'см2' in lower or 'см²' in lower:
        unit = 'см²'
    elif 'м2' in lower or 'м²' in lower:
        unit = 'м²'
    elif 'кг' in lower:
        unit = 'кг'

    first_label = first_object or 'первого количества'
    second_label = second_object or 'второго количества'
    first_label = re.sub(r'\s+', ' ', first_label).strip()
    second_label = re.sub(r'\s+', ' ', second_label).strip()

    if 'во сколько раз' in lower and ('больше' in lower or 'меньше' in lower):
        bigger = max(first_whole, second_whole)
        smaller = min(first_whole, second_whole)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        answer = f'Ответ: первое количество больше второго в {ratio} раза.'
        if 'картошк' in lower and 'морков' in lower:
            answer = f'Ответ: масса картошки больше массы моркови в {ratio} раза.'
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {first_word} {first_label} — это {first_value} {unit}. {second_word} {second_label} — это {second_value} {unit}.',
            'Что нужно найти: во сколько раз одно количество больше другого.',
            f'1) Найдём всё первое количество: {first_value} × {first_den} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {second_value} × {second_den} = {second_whole} {unit}.',
            f'3) Сравним количества: {bigger} : {smaller} = {ratio}.',
            answer
        )

    if 'на сколько' in lower and ('больше' in lower or 'меньше' in lower):
        difference = abs(second_whole - first_whole)
        big = max(first_whole, second_whole)
        small = min(first_whole, second_whole)
        answer = f'Ответ: одно количество отличается от другого на {difference} {unit}.'.replace('  ', ' ')
        if 'салфет' in lower and 'скатерт' in lower:
            answer = f'Ответ: площадь салфетки меньше площади скатерти на {difference} {unit}.'
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: {first_word} {first_label} — это {first_value} {unit}. {second_word} {second_label} — это {second_value} {unit}.',
            'Что нужно найти: на сколько одно количество отличается от другого.',
            f'1) Найдём всё первое количество: {first_value} × {first_den} = {first_whole} {unit}.',
            f'2) Найдём всё второе количество: {second_value} × {second_den} = {second_whole} {unit}.',
            f'3) Найдём разность: {big} - {small} = {difference} {unit}.',
            answer
        )

    return None

async def build_explanation(user_text: str) -> dict:
    local = _final_20260416_try_all_remaining_fixes(user_text)
    if local:
        return _final_20260416_result_dict(local, 'local-final-20260416d')
    return await _FINAL_20260416D_PREV_BUILD_EXPLANATION(user_text)

# --- FINAL PATCH 2026-04-16E: new-source audit fixes without touching stable UI logic ---

_FINAL_20260416E_PREV_BUILD_EXPLANATION = build_explanation

_FINAL_20260416E_LINEAR_UNITS = {
    'мм': 1,
    'см': 10,
    'дм': 100,
    'м': 1000,
    'км': 1000000,
}

def _final_20260416e_norm_math_text(raw_text: str) -> str:
    return strip_known_prefix(str(raw_text or '')).strip()

def _final_20260416e_pretty_ops(text: str) -> str:
    return (
        str(text or '')
        .replace('**', '^')
        .replace('*', ' × ')
        .replace('/', ' : ')
        .replace('+', ' + ')
        .replace('-', ' - ')
    )

def _final_20260416e_eval_integer_expression(expr: str) -> Optional[int]:
    source = to_expression_source(expr) or str(expr or '').strip()
    node = parse_expression_ast(source)
    if node is None:
        return None
    try:
        value = eval_fraction_node(node)
    except Exception:
        return None
    if isinstance(value, Fraction):
        if value.denominator != 1:
            return None
        return int(value.numerator)
    try:
        value = Fraction(value)
    except Exception:
        return None
    if value.denominator != 1:
        return None
    return int(value.numerator)

def _final_20260416e_try_force_detailed_expression(raw_text: str) -> Optional[str]:
    text = _final_20260416e_norm_math_text(raw_text)
    if not text or '=' in text or re.search(r'[A-Za-zА-Яа-я]', text):
        return None
    source = to_expression_source(text)
    if not source:
        return None
    if _final_20260416_normalize_fraction_expression_source(text):
        return None
    node = parse_expression_ast(source)
    if node is None:
        return None
    steps = _detailed_collect_expression_steps(node, source)
    if len(steps) <= 1:
        return None
    rendered = _patch_20260412c_render_mixed_expression_solution(source)
    return rendered if rendered else None

def _final_20260416e_try_motion_per_hour_speed(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not contains_any_fragment(lower, ('с какой скоростью', 'какова скорость')):
        return None
    match = re.search(r'кажд(?:ый|ую|ое)\s+час[^\d]{0,20}(\d+)\s*км', lower)
    if not match:
        match = re.search(r'(\d+)\s*км[^.?!]{0,30}кажд(?:ый|ую|ое)\s+час', lower)
    if not match:
        return None
    speed = int(match.group(1))
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: за 1 час проходят {speed} км.',
        'Что нужно найти: скорость.',
        '1) Скорость показывает, какое расстояние проходят за один час.',
        f'2) За один час проходят {speed} км, значит скорость равна {speed} км/ч.',
        f'Ответ: скорость равна {speed} км/ч.'
    )

def _final_20260416e_try_equation_with_side_expression(raw_text: str) -> Optional[str]:
    text = _final_20260416e_norm_math_text(raw_text)
    compact = text.replace('×', '*').replace('÷', '/').replace(':', '/').replace('−', '-').replace('–', '-').replace('—', '-')
    if compact.count('=') != 1:
        return None
    if ',' in compact or ';' in compact or '\n' in compact:
        return None
    letters = re.findall(r'[A-Za-zА-Яа-я]', compact)
    if not letters:
        return None
    unique_letters = {ch.lower() for ch in letters}
    if len(unique_letters) != 1:
        return None
    variable = letters[0]
    left_raw, right_raw = [part.strip() for part in compact.split('=', 1)]
    left_has_var = bool(re.search(r'[A-Za-zА-Яа-я]', left_raw))
    right_has_var = bool(re.search(r'[A-Za-zА-Яа-я]', right_raw))
    if left_has_var == right_has_var:
        return None
    variable_side = left_raw if left_has_var else right_raw
    numeric_side = right_raw if left_has_var else left_raw
    if not re.search(r'[+\-*/]', numeric_side):
        return None
    numeric_value = _final_20260416e_eval_integer_expression(numeric_side)
    if numeric_value is None:
        return None

    compact_var = variable_side.replace(' ', '')
    pretty_numeric = _final_20260416e_pretty_ops(numeric_side).replace('  ', ' ').strip()
    pretty_variable_side = _final_20260416e_pretty_ops(variable_side).replace('  ', ' ').strip()

    def build_lines(new_equation: str, solve_line: str, final_value: int, component_text: str, operation_text: str) -> str:
        original_pretty = _final_20260416e_pretty_ops(compact.replace('=', ' = ')).replace('  ', ' ').strip()
        return join_explanation_lines(
            'Уравнение:',
            original_pretty,
            'Решение.',
            '1) Сначала вычисляем значение выражения в той части уравнения, где нет неизвестного:',
            f'{pretty_numeric} = {numeric_value}',
            '2) Получаем более простое уравнение:',
            new_equation,
            component_text,
            operation_text,
            f'3) Считаем: {solve_line}',
            f'Ответ: {final_value}'
        )

    m = re.fullmatch(rf'{re.escape(variable)}\+(\d+)', compact_var)
    if m:
        number = int(m.group(1))
        answer = numeric_value - number
        return build_lines(
            f'{variable} + {number} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестное слагаемое.',
            f'Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: {variable} = {numeric_value} - {number}.'
        )
    m = re.fullmatch(rf'(\d+)\+{re.escape(variable)}', compact_var)
    if m:
        number = int(m.group(1))
        answer = numeric_value - number
        return build_lines(
            f'{number} + {variable} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестное слагаемое.',
            f'Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: {variable} = {numeric_value} - {number}.'
        )
    m = re.fullmatch(rf'{re.escape(variable)}-(\d+)', compact_var)
    if m:
        number = int(m.group(1))
        answer = numeric_value + number
        return build_lines(
            f'{variable} - {number} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестное уменьшаемое.',
            f'Чтобы найти неизвестное уменьшаемое, к разности прибавляем вычитаемое: {variable} = {numeric_value} + {number}.'
        )
    m = re.fullmatch(rf'(\d+)-{re.escape(variable)}', compact_var)
    if m:
        number = int(m.group(1))
        answer = number - numeric_value
        return build_lines(
            f'{number} - {variable} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестное вычитаемое.',
            f'Чтобы найти неизвестное вычитаемое, из уменьшаемого вычитаем разность: {variable} = {number} - {numeric_value}.'
        )
    m = re.fullmatch(rf'{re.escape(variable)}\*(\d+)', compact_var)
    if m:
        number = int(m.group(1))
        if number == 0 or numeric_value % number != 0:
            return None
        answer = numeric_value // number
        return build_lines(
            f'{variable} × {number} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестный множитель.',
            f'Чтобы найти неизвестный множитель, произведение делим на известный множитель: {variable} = {numeric_value} : {number}.'
        )
    m = re.fullmatch(rf'(\d+)\*{re.escape(variable)}', compact_var)
    if m:
        number = int(m.group(1))
        if number == 0 or numeric_value % number != 0:
            return None
        answer = numeric_value // number
        return build_lines(
            f'{number} × {variable} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестный множитель.',
            f'Чтобы найти неизвестный множитель, произведение делим на известный множитель: {variable} = {numeric_value} : {number}.'
        )
    m = re.fullmatch(rf'{re.escape(variable)}/(\d+)', compact_var)
    if m:
        number = int(m.group(1))
        answer = numeric_value * number
        return build_lines(
            f'{variable} : {number} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестное делимое.',
            f'Чтобы найти неизвестное делимое, делитель умножаем на частное: {variable} = {numeric_value} × {number}.'
        )
    m = re.fullmatch(rf'(\d+)/{re.escape(variable)}', compact_var)
    if m:
        number = int(m.group(1))
        if numeric_value == 0 or number % numeric_value != 0:
            return None
        answer = number // numeric_value
        return build_lines(
            f'{number} : {variable} = {numeric_value}',
            f'{variable} = {answer}',
            answer,
            f'{variable} — неизвестный делитель.',
            f'Чтобы найти неизвестный делитель, делимое делим на частное: {variable} = {number} : {numeric_value}.'
        )
    return None

def _final_20260416e_extract_target_area_unit(lower: str) -> Optional[str]:
    if 'мм2' in lower or 'мм²' in lower:
        return 'мм'
    if 'см2' in lower or 'см²' in lower:
        return 'см'
    if 'дм2' in lower or 'дм²' in lower:
        return 'дм'
    if 'м2' in lower or 'м²' in lower:
        return 'м'
    if 'км2' in lower or 'км²' in lower:
        return 'км'
    return None

def _final_20260416e_convert_area_value(value: int, from_unit: str, to_unit: str) -> Optional[int]:
    if from_unit not in _FINAL_20260416E_LINEAR_UNITS or to_unit not in _FINAL_20260416E_LINEAR_UNITS:
        return None
    base_from = _FINAL_20260416E_LINEAR_UNITS[from_unit]
    base_to = _FINAL_20260416E_LINEAR_UNITS[to_unit]
    total_in_mm2 = value * (base_from ** 2)
    if total_in_mm2 % (base_to ** 2) != 0:
        return None
    return total_in_mm2 // (base_to ** 2)
