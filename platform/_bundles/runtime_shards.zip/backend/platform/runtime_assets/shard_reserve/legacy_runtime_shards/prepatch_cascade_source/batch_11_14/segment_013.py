"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 10508-11393."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def explain_find_third_addend_word_problem(total: int, first: int, second: int) -> Optional[str]:
    known = first + second
    result = total - known
    if result < 0:
        return None
    return join_explanation_lines(
        f"1) Если первая известная часть равна {first}, а вторая известная часть равна {second}, то вместе они составляют {first} + {second} = {known}",
        f"2) Если всего было {total}, а две известные части составляют {known}, то неизвестная часть равна {total} - {known} = {result}",
        f"Ответ: {result}",
        "Совет: неизвестную часть находят вычитанием суммы известных частей из целого",
    )

def explain_initial_from_taken_and_left_word_problem(first_taken: int, second_taken: int, left: int) -> Optional[str]:
    taken = first_taken + second_taken
    total = taken + left
    return join_explanation_lines(
        f"1) Если взяли {first_taken} и ещё {second_taken}, то всего взяли {first_taken} + {second_taken} = {taken}",
        f"2) Если взяли {taken}, а осталось {left}, то сначала было {taken} + {left} = {total}",
        f"Ответ: {total}",
        "Совет: если известно, сколько взяли и сколько осталось, начальное количество находят сложением",
    )

def explain_compare_from_total_and_part_word_problem(total: int, known_part: int) -> Optional[str]:
    other = total - known_part
    if other < 0:
        return None
    bigger = max(known_part, other)
    smaller = min(known_part, other)
    diff = bigger - smaller
    return join_explanation_lines(
        f"1) Если всего было {total}, а известная часть равна {known_part}, то другая часть равна {total} - {known_part} = {other}",
        f"2) Если одна часть равна {bigger}, а другая равна {smaller}, то разность равна {bigger} - {smaller} = {diff}",
        f"Ответ: {diff}",
        "Совет: если сначала нужно найти неизвестную часть, а потом сравнить части, действия выполняют по порядку",
    )

def explain_sum_of_two_products_word_problem(first_count: int, first_value: int, second_count: int, second_value: int) -> str:
    first_total = first_count * first_value
    second_total = second_count * second_value
    total = first_total + second_total
    return join_explanation_lines(
        f"1) Если первая покупка состоит из {first_count} предметов по {first_value}, то её стоимость равна {first_count} × {first_value} = {first_total}",
        f"2) Если вторая покупка состоит из {second_count} предметов по {second_value}, то её стоимость равна {second_count} × {second_value} = {second_total}",
        f"3) Если первая покупка стоит {first_total}, а вторая стоит {second_total}, то вся покупка стоит {first_total} + {second_total} = {total}",
        f"Ответ: {total}",
        "Совет: если в задаче есть две группы вида «по столько-то», сначала находят каждую группу отдельно",
    )

def explain_groups_plus_extra_word_problem(groups: int, per_group: int, extra: int) -> str:
    grouped_total = groups * per_group
    result = grouped_total + extra
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group}, то сначала находим, сколько предметов в этих группах: {groups} × {per_group} = {grouped_total}",
        f"2) Если в одинаковых группах {grouped_total}, а потом добавили ещё {extra}, то стало {grouped_total} + {extra} = {result}",
        f"Ответ: {result}",
        "Совет: если сначала считают одинаковые группы, а потом что-то добавляют, сначала выполняют умножение",
    )

def explain_sum_then_subtract_word_problem(first: int, second: int, removed: int) -> Optional[str]:
    total = first + second
    remaining = total - removed
    if remaining < 0:
        return None
    return join_explanation_lines(
        f"1) Если сначала было {first} и ещё {second}, то всего было {first} + {second} = {total}",
        f"2) Если всего было {total}, а потом убрали {removed}, то осталось {total} - {removed} = {remaining}",
        f"Ответ: {remaining}",
        "Совет: если сначала объединяют две группы, а потом часть убирают, сначала находят сумму",
    )

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        f"1) Если {count} одинаковых предметов стоят {total_cost} руб., то один предмет стоит {total_cost} : {count} = {price} руб.",
        f"Ответ: один предмет стоит {price} руб.",
        "Совет: цену одной штуки находят делением общей стоимости на количество",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        f"1) Если один предмет стоит {price} руб., а купили {count} предметов, то вся покупка стоит {price} × {count} = {total} руб.",
        f"Ответ: вся покупка стоит {total} руб.",
        "Совет: стоимость находят умножением цены на количество",
    )

def explain_unknown_red_price(known_count: int, known_price: int, unknown_count: int, total_cost: int) -> Optional[str]:
    known_total = known_count * known_price
    other_total = total_cost - known_total
    if unknown_count == 0 or other_total < 0 or other_total % unknown_count != 0:
        return None
    unit_price = other_total // unknown_count
    return join_explanation_lines(
        f"1) Если купили {known_count} известных предметов по {known_price} руб., то за них заплатили {known_count} × {known_price} = {known_total} руб.",
        f"2) Если за всю покупку заплатили {total_cost} руб., а за известную часть {known_total} руб., то за вторую часть заплатили {total_cost} - {known_total} = {other_total} руб.",
        f"3) Если за {unknown_count} предметов заплатили {other_total} руб., то один предмет стоит {other_total} : {unknown_count} = {unit_price} руб.",
        f"Ответ: один предмет стоит {unit_price} руб.",
        "Совет: если известна общая стоимость покупки, сначала вычитают известную часть",
    )

def explain_price_difference_problem(quantity: int, total_a: int, total_b: int) -> Optional[str]:
    if quantity == 0 or total_a % quantity != 0 or total_b % quantity != 0:
        return None
    price_a = total_a // quantity
    price_b = total_b // quantity
    diff = abs(price_a - price_b)
    relation = "дороже" if price_a > price_b else "дешевле"
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых товаров заплатили {total_a} руб., то цена одного товара равна {total_a} : {quantity} = {price_a} руб.",
        f"2) Если за {quantity} таких же товаров заплатили {total_b} руб., то цена одного товара равна {total_b} : {quantity} = {price_b} руб.",
        f"3) Если одна цена {price_a} руб., а другая {price_b} руб., то разность цен равна {max(price_a, price_b)} - {min(price_a, price_b)} = {diff} руб.",
        f"Ответ: на {diff} руб. {relation}.",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

def explain_price_quantity_cost_problem(quantity: int, total_cost: int, wanted_cost: int) -> Optional[str]:
    if quantity == 0 or total_cost % quantity != 0:
        return None
    price = total_cost // quantity
    if price == 0 or wanted_cost % price != 0:
        return None
    result = wanted_cost // price
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых коробок заплатили {total_cost} руб., то цена одной коробки равна {total_cost} : {quantity} = {price} руб.",
        f"2) Если одна коробка стоит {price} руб., то на {wanted_cost} руб. можно купить {wanted_cost} : {price} = {result} коробок.",
        f"Ответ: {result}",
        "Совет: если цена одинаковая, сначала находят цену одной коробки",
    )

def explain_fraction_of_number_word_problem(total: int, numerator: int, denominator: int, ask_remaining: bool = False) -> Optional[str]:
    if denominator == 0 or numerator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    taken = one_part * numerator
    if ask_remaining:
        remaining = total - taken
        return join_explanation_lines(
            f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}",
            f"3) Если всего было {total}, а использовали {taken}, то осталось {total} - {taken} = {remaining}",
            f"Ответ: {remaining}",
            "Совет: чтобы найти остаток после дробной части, сначала находят эту дробную часть",
        )
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}",
        f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}",
        f"Ответ: {taken}",
        "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
    )

def explain_number_by_fraction_word_problem(part_value: int, numerator: int, denominator: int) -> Optional[str]:
    if numerator == 0 or part_value % numerator != 0:
        return None
    one_part = part_value // numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если {numerator}/{denominator} числа равны {part_value}, то сначала найдём одну долю: {part_value} : {numerator} = {one_part}",
        f"2) Если одна доля равна {one_part}, то всё число равно {one_part} × {denominator} = {whole}",
        f"Ответ: {whole}",
        "Совет: чтобы найти всё число по его доле, сначала находят одну долю",
    )

def explain_whole_by_remaining_fraction(remaining_value: int, spent_numerator: int, denominator: int) -> Optional[str]:
    remaining_numerator = denominator - spent_numerator
    if denominator == 0 or remaining_numerator <= 0:
        return None
    if remaining_value % remaining_numerator != 0:
        return None
    one_part = remaining_value // remaining_numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег.",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part}.",
        f"3) Если одна доля равна {one_part}, то все деньги равны {one_part} × {denominator} = {whole}.",
        f"Ответ: {whole}",
        "Совет: если известен остаток после расхода части, сначала находят оставшуюся долю",
    )

def explain_simple_motion_distance(speed: int, time_value: int, unit: str = "") -> str:
    result = speed * time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти расстояние, нужно скорость умножить на время.",
        f"2) Если скорость равна {speed}, а время равно {time_value}, то расстояние равно {speed} × {time_value} = {answer}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом S = v × t",
    )

def explain_simple_motion_speed(distance: int, time_value: int, unit: str = "") -> Optional[str]:
    if time_value == 0 or distance % time_value != 0:
        return None
    result = distance // time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти скорость, нужно расстояние разделить на время.",
        f"2) Если расстояние равно {distance}, а время равно {time_value}, то скорость равна {distance} : {time_value} = {answer}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом v = S : t",
    )

def explain_simple_motion_time(distance: int, speed: int, unit: str = "") -> Optional[str]:
    if speed == 0 or distance % speed != 0:
        return None
    result = distance // speed
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти время, нужно расстояние разделить на скорость.",
        f"2) Если расстояние равно {distance}, а скорость равна {speed}, то время равно {distance} : {speed} = {answer}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом t = S : v",
    )

def explain_meeting_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    closing_speed = v1 + v2
    distance = closing_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2}, то скорость сближения равна {v1} + {v2} = {closing_speed}",
        f"2) Если скорость сближения равна {closing_speed}, а время равно {time_value}, то расстояние равно {closing_speed} × {time_value} = {answer}",
        f"Ответ: {answer}",
        "Совет: при встречном движении сначала находят скорость сближения",
    )

def explain_opposite_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    removal_speed = v1 + v2
    distance = removal_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2} в противоположных направлениях, то скорость удаления равна {v1} + {v2} = {removal_speed}",
        f"2) Если скорость удаления равна {removal_speed}, а время равно {time_value}, то расстояние между ними равно {removal_speed} × {time_value} = {answer}",
        f"Ответ: {answer}",
        "Совет: при движении в противоположных направлениях сначала находят скорость удаления",
    )

def explain_trip_time_for_same_distance(speed1: int, time1: int, speed2: int) -> Optional[str]:
    distance = speed1 * time1
    if speed2 == 0 or distance % speed2 != 0:
        return None
    time2 = distance // speed2
    return join_explanation_lines(
        f"1) Если первый участник ехал со скоростью {speed1} и был в пути {time1}, то расстояние равно {speed1} × {time1} = {distance}",
        f"2) Если это же расстояние равно {distance}, а скорость второго участника {speed2}, то ему понадобится {distance} : {speed2} = {time2} ч.",
        f"Ответ: {time2} ч.",
        "Совет: если путь один и тот же, сначала находят расстояние, потом новое время",
    )

def explain_second_day_motion_time(total_distance: int, first_speed: int, first_time: int, second_speed: int) -> Optional[str]:
    first_distance = first_speed * first_time
    second_distance = total_distance - first_distance
    if second_speed == 0 or second_distance < 0 or second_distance % second_speed != 0:
        return None
    second_time = second_distance // second_speed
    total_time = first_time + second_time
    return join_explanation_lines(
        f"1) Если в первый день скорость была {first_speed}, а время в пути {first_time}, то в первый день проехали {first_speed} × {first_time} = {first_distance} км.",
        f"2) Если всего нужно проехать {total_distance} км, а в первый день проехали {first_distance} км, то во второй день осталось {total_distance} - {first_distance} = {second_distance} км.",
        f"3) Если во второй день проехали {second_distance} км со скоростью {second_speed}, то время во второй день равно {second_distance} : {second_speed} = {second_time} ч.",
        f"4) Если в первый день были в пути {first_time} ч., а во второй день {second_time} ч., то всего были в пути {first_time} + {second_time} = {total_time} ч.",
        f"Ответ: во второй день — {second_time} ч.; всего — {total_time} ч.",
        "Совет: в составной задаче на движение сначала находят путь, потом время",
    )

def explain_remaining_part_speed(total_distance: int, first_speed: int, first_time: int, second_time: int) -> Optional[str]:
    first_distance = first_speed * first_time
    remaining_distance = total_distance - first_distance
    if second_time == 0 or remaining_distance < 0 or remaining_distance % second_time != 0:
        return None
    second_speed = remaining_distance // second_time
    return join_explanation_lines(
        f"1) Если сначала ехали со скоростью {first_speed} {first_time} ч., то первая часть пути равна {first_speed} × {first_time} = {first_distance} км.",
        f"2) Если весь путь равен {total_distance} км, а первая часть пути равна {first_distance} км, то оставшаяся часть пути равна {total_distance} - {first_distance} = {remaining_distance} км.",
        f"3) Если оставшаяся часть пути равна {remaining_distance} км, а прошли её за {second_time} ч., то скорость равна {remaining_distance} : {second_time} = {second_speed} км/ч.",
        f"Ответ: {second_speed} км/ч.",
        "Совет: если известны путь и время, скорость находят делением",
    )

def explain_return_trip_time_by_faster_speed(distance: int, speed: int, factor: int) -> Optional[str]:
    if speed == 0 or factor == 0 or distance % speed != 0:
        return None
    first_time = distance // speed
    faster_speed = speed * factor
    if faster_speed == 0 or distance % faster_speed != 0:
        return None
    return_time = distance // faster_speed
    return join_explanation_lines(
        f"1) Если расстояние равно {distance} км, а скорость в одну сторону {speed} км/ч, то время в одну сторону равно {distance} : {speed} = {first_time} ч.",
        f"2) Если обратно едут в {factor} раза быстрее, то скорость обратно равна {speed} × {factor} = {faster_speed} км/ч.",
        f"3) Если расстояние равно {distance} км, а скорость обратно {faster_speed} км/ч, то время на обратный путь равно {distance} : {faster_speed} = {return_time} ч.",
        f"Ответ: {return_time} ч.",
        "Совет: если на обратном пути скорость увеличилась в несколько раз, сначала находят новую скорость",
    )

# --- FINAL USER CONSOLIDATION PATCH 2026-04-12D: extra textbook motion case, fuller count nouns, stable final routing ---

# Добавляем несколько часто встречающихся школьных существительных,
# чтобы ответы чаще были полными, а не только числом.
try:
    QUESTION_NOUN_FORMS.update({
        "шарик": ("шарик", "шарика", "шариков"),
        "шарика": ("шарик", "шарика", "шариков"),
        "шариков": ("шарик", "шарика", "шариков"),
        "утенок": ("утёнок", "утёнка", "утят"),
        "утёнок": ("утёнок", "утёнка", "утят"),
        "утёнка": ("утёнок", "утёнка", "утят"),
        "утят": ("утёнок", "утёнка", "утят"),
        "гусенок": ("гусёнок", "гусёнка", "гусят"),
        "гусёнок": ("гусёнок", "гусёнка", "гусят"),
        "гусёнка": ("гусёнок", "гусёнка", "гусят"),
        "гусят": ("гусёнок", "гусёнка", "гусят"),
        "тюльпан": ("тюльпан", "тюльпана", "тюльпанов"),
        "тюльпана": ("тюльпан", "тюльпана", "тюльпанов"),
        "тюльпанов": ("тюльпан", "тюльпана", "тюльпанов"),
        "орешек": ("орешек", "орешка", "орешков"),
        "орешка": ("орешек", "орешка", "орешков"),
        "орешков": ("орешек", "орешка", "орешков"),
        "гостинец": ("гостинец", "гостинца", "гостинцев"),
        "гостинца": ("гостинец", "гостинца", "гостинцев"),
        "гостинцев": ("гостинец", "гостинца", "гостинцев"),
        "тетрадка": ("тетрадка", "тетрадки", "тетрадок"),
        "тетрадки": ("тетрадка", "тетрадки", "тетрадок"),
        "тетрадок": ("тетрадка", "тетрадки", "тетрадок"),
    })
except Exception:
    pass

def _final_user_20260412d_equal_speed_head_start_meeting_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    # Шаблон из книги:
    # "скорости одинаковые", "встретились через ... часов",
    # "первый ... выехал на ... часа раньше", "проехал на ... км больше".
    if "навстречу" not in lower:
        return None
    if "одинаков" not in lower:
        return None
    if "раньше" not in lower or "больше" not in lower:
        return None

    hour_pattern = fr"(\d+|{_NUMBER_WORD_PATTERN})\s*(?:ч|час(?:а|ов)?)"
    meet_match = re.search(fr"встретил(?:ся|ась|ось|ись)?\s+через\s+{hour_pattern}", lower)
    head_start_match = re.search(fr"на\s+{hour_pattern}\s+раньше", lower)
    extra_distance_match = re.search(r"на\s+(\d+)\s*(км|м)\s+больше", lower)

    if not meet_match or not head_start_match or not extra_distance_match:
        return None

    meet_time = parse_number_token(meet_match.group(1))
    head_start_time = parse_number_token(head_start_match.group(1))
    extra_distance = int(extra_distance_match.group(1))
    distance_unit = extra_distance_match.group(2)

    if meet_time is None or head_start_time is None:
        return None
    if head_start_time == 0 or extra_distance % head_start_time != 0:
        return None

    speed = extra_distance // head_start_time
    second_path = speed * meet_time
    first_time = meet_time + head_start_time
    first_path = speed * first_time
    total_distance = first_path + second_path
    speed_unit = f"{distance_unit}/ч"

    return join_explanation_lines(
        f"1) Если скорости одинаковые, а первый участник выехал на {head_start_time} ч. раньше и поэтому прошёл на {extra_distance} {distance_unit} больше, то скорость каждого равна {extra_distance} : {head_start_time} = {speed} {speed_unit}",
        f"2) Так как скорости одинаковые, скорость второго участника тоже равна {speed} {speed_unit}",
        f"3) Если второй участник ехал {meet_time} ч. со скоростью {speed} {speed_unit}, то он прошёл {speed} × {meet_time} = {second_path} {distance_unit}",
        f"4) Если первый участник выехал на {head_start_time} ч. раньше, то он был в пути {meet_time} + {head_start_time} = {first_time} ч.",
        f"5) Если первый участник ехал {first_time} ч. со скоростью {speed} {speed_unit}, то он прошёл {speed} × {first_time} = {first_path} {distance_unit}",
        f"6) Если один участник прошёл {second_path} {distance_unit}, а другой {first_path} {distance_unit}, то расстояние между пунктами равно {second_path} + {first_path} = {total_distance} {distance_unit}",
        f"Ответ: расстояние между пунктами равно {total_distance} {distance_unit}",
        "Совет: если скорости одинаковые, а один участник выехал раньше, его лишний путь помогает найти общую скорость",
    )

_FINAL_USER_20260412D_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_user_20260412d_equal_speed_head_start_meeting_explanation(user_text)
        or _FINAL_USER_20260412D_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL USER PATCH 2026-04-12E: fuller school wording, stable final prompt, preserved architecture ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку «Порядок действий:».
3. Ниже пиши тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
4. Потом пиши строку «Решение по действиям:».
5. Ниже пиши все вычисления по действиям:
1) ...
2) ...
3) ...
6. Если вычисление удобно выполнять в столбик, сохраняй запись столбиком и подробное пояснение по шагам.
7. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.
8. В конце пиши строку «Ответ: ...».

Для текстовых задач:
1. Сначала пиши «Задача.» и без изменения чисел переписывай условие.
2. Потом пиши «Решение.»
3. Затем обязательно пиши строки:
«Что известно: ...»
«Что нужно найти: ...»
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. Для школьного стиля по возможности используй форму «Если..., то ...».
8. После каждого действия коротко говори, что нашли.
9. Если в задаче несколько вопросов, отвечай на все вопросы по порядку.
10. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку «Уравнение: ...».
2. Потом «Решение.»
3. Решай по шагам.
4. Обязательно пиши строку «Проверка: ...».
5. Потом пиши «Ответ: ...».

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи дроби к общему знаменателю.
4. Если задача дана с величинами, сначала переведи величины в одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.
5. В ответе обязательно пиши единицы измерения.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Сохраняй вычисления в столбик и подробные пояснения.
Для деления столбиком обязательно называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

try:
    QUESTION_NOUN_FORMS.update({
        "год": ("год", "года", "лет"),
        "года": ("год", "года", "лет"),
        "лет": ("год", "года", "лет"),
        "книга": ("книга", "книги", "книг"),
        "книги": ("книга", "книги", "книг"),
        "книг": ("книга", "книги", "книг"),
        "машина": ("машина", "машины", "машин"),
        "машины": ("машина", "машины", "машин"),
        "машин": ("машина", "машины", "машин"),
        "дерево": ("дерево", "дерева", "деревьев"),
        "дерева": ("дерево", "дерева", "деревьев"),
        "деревьев": ("дерево", "дерева", "деревьев"),
        "глазок": ("глазок", "глазка", "глазков"),
        "глазка": ("глазок", "глазка", "глазков"),
        "глазков": ("глазок", "глазка", "глазков"),
        "страница": ("страница", "страницы", "страниц"),
        "страницы": ("страница", "страницы", "страниц"),
        "страниц": ("страница", "страницы", "страниц"),
        "перо": ("перо", "пера", "перьев"),
        "пера": ("перо", "пера", "перьев"),
        "перьев": ("перо", "пера", "перьев"),
        "яблоко": ("яблоко", "яблока", "яблок"),
        "яблока": ("яблоко", "яблока", "яблок"),
        "яблок": ("яблоко", "яблока", "яблок"),
        "гвоздика": ("гвоздика", "гвоздики", "гвоздик"),
        "гвоздики": ("гвоздика", "гвоздики", "гвоздик"),
        "гвоздик": ("гвоздика", "гвоздики", "гвоздик"),
        "ягода": ("ягода", "ягоды", "ягод"),
        "ягоды": ("ягода", "ягоды", "ягод"),
        "ягод": ("ягода", "ягоды", "ягод"),
        "ложка": ("ложка", "ложки", "ложек"),
        "ложки": ("ложка", "ложки", "ложек"),
        "ложек": ("ложка", "ложки", "ложек"),
        "куст": ("куст", "куста", "кустов"),
        "куста": ("куст", "куста", "кустов"),
        "кустов": ("куст", "куста", "кустов"),
        "цветок": ("цветок", "цветка", "цветов"),
        "цветка": ("цветок", "цветка", "цветов"),
        "цветов": ("цветок", "цветка", "цветов"),
        "мешок": ("мешок", "мешка", "мешков"),
        "мешка": ("мешок", "мешка", "мешков"),
        "мешков": ("мешок", "мешка", "мешков"),
        "клетка": ("клетка", "клетки", "клеток"),
        "клетки": ("клетка", "клетки", "клеток"),
        "клеток": ("клетка", "клетки", "клеток"),
        "полка": ("полка", "полки", "полок"),
        "полки": ("полка", "полки", "полок"),
        "полок": ("полка", "полки", "полок"),
        "ведро": ("ведро", "ведра", "вёдер"),
        "ведра": ("ведро", "ведра", "вёдер"),
        "вёдер": ("ведро", "ведра", "вёдер"),
        "корзина": ("корзина", "корзины", "корзин"),
        "корзины": ("корзина", "корзины", "корзин"),
        "корзин": ("корзина", "корзины", "корзин"),
        "сетка": ("сетка", "сетки", "сеток"),
        "сетки": ("сетка", "сетки", "сеток"),
        "сеток": ("сетка", "сетки", "сеток"),
        "попугай": ("попугай", "попугая", "попугаев"),
        "попугая": ("попугай", "попугая", "попугаев"),
        "попугаев": ("попугай", "попугая", "попугаев"),
        "ученик": ("ученик", "ученика", "учеников"),
        "ученика": ("ученик", "ученика", "учеников"),
        "учеников": ("ученик", "ученика", "учеников"),
        "пассажир": ("пассажир", "пассажира", "пассажиров"),
        "пассажира": ("пассажир", "пассажира", "пассажиров"),
        "пассажиров": ("пассажир", "пассажира", "пассажиров"),
        "участок": ("участок", "участка", "участков"),
        "участка": ("участок", "участка", "участков"),
        "участков": ("участок", "участка", "участков"),
        "рыба": ("рыба", "рыбы", "рыб"),
        "рыбы": ("рыба", "рыбы", "рыб"),
        "рыб": ("рыба", "рыбы", "рыб"),
        "булочка": ("булочка", "булочки", "булочек"),
        "булочки": ("булочка", "булочки", "булочек"),
        "булочек": ("булочка", "булочки", "булочек"),
        "карандаш": ("карандаш", "карандаша", "карандашей"),
        "карандаша": ("карандаш", "карандаша", "карандашей"),
        "карандашей": ("карандаш", "карандаша", "карандашей"),
    })
except Exception:
    pass

_FINAL_20260412E_PREV_DETAILED_MAYBE_ENRICH_ANSWER = _detailed_maybe_enrich_answer

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    return _external_final_detailed_maybe_enrich_answer(
        answer,
        raw_text,
        _FINAL_20260412E_PREV_DETAILED_MAYBE_ENRICH_ANSWER,
        _patch_answer_with_question_noun,
        kind,
    )

    result = first + second
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе количество равно {second}, то всего будет {first} + {second} = {result}.",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько всего или сколько стало, обычно нужно сложение",
    )

def explain_subtraction_word_problem(first: int, second: int) -> str:
    result = first - second
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если сначала было {first}, а потом убрали {second}, то осталось {first} - {second} = {result}.",
        f"Ответ: {result}",
        "Совет: если нужно узнать, сколько осталось, обычно используют вычитание",
    )

def explain_comparison_word_problem(first: int, second: int) -> str:
    bigger = max(first, second)
    smaller = min(first, second)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если одно количество равно {bigger}, а другое равно {smaller}, то чтобы узнать, на сколько одно больше другого, нужно вычислить {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: вопрос «на сколько» решают вычитанием: из большего числа вычитают меньшее",
    )

def explain_find_initial_after_loss_problem(remaining: int, removed: int) -> str:
    result = remaining + removed
    return join_explanation_lines(
        f"1) Если после того, как убрали {removed}, осталось {remaining}, то сначала было {remaining} + {removed} = {result}.",
        f"Ответ: {result}",
        "Совет: неизвестное уменьшаемое находят сложением",
    )

def explain_find_initial_after_gain_problem(final_total: int, added: int) -> str:
    result = final_total - added
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если стало {final_total}, а прибавили {added}, то сначала было {final_total} - {added} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы найти число до прибавления, из нового числа вычитают то, что прибавили",
    )

def explain_find_added_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {smaller}, а потом стало {bigger}, то добавили {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
    )

def explain_find_removed_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {bigger}, а потом осталось {smaller}, то убрали {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
    )

def explain_multiplication_word_problem(groups: int, per_group: int) -> str:
    result = groups * per_group
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего будет {groups} × {per_group} = {result}.",
        f"Ответ: {result}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def explain_sharing_word_problem(total: int, groups: int) -> Optional[str]:
    if groups == 0:
        return join_explanation_lines("На ноль делить нельзя.", "Ответ: деление на ноль невозможно", "Совет: сначала проверь делитель")
    quotient, remainder = divmod(total, groups)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если {total} предметов разделили на {groups} равные части, то в каждой части будет {total} : {groups} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: слова «поровну» и «каждый» подсказывают деление",
        )
    return join_explanation_lines(
        f"1) Если {total} разделить на {groups}, то получится {quotient}, остаток {remainder}.",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: остаток всегда должен быть меньше делителя",
    )

def explain_group_count_word_problem(total: int, per_group: int, needs_extra_group: bool = False, explicit_remainder: bool = False) -> Optional[str]:
    if per_group == 0:
        return join_explanation_lines("В одной группе не может быть 0 предметов.", "Ответ: запись задачи неверная", "Совет: проверь размер одной группы")
    quotient, remainder = divmod(total, per_group)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то число групп равно {total} : {per_group} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: число групп находят делением",
        )
    if needs_extra_group:
        return join_explanation_lines(
            f"1) Полных групп получится {quotient}, потому что {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"2) Так как предметы ещё остались, нужна ещё одна группа. Всего групп будет {quotient + 1}.",
            f"Ответ: {quotient + 1}",
            "Совет: если после деления ещё есть остаток, иногда нужна ещё одна коробка или корзина",
        )
    if explicit_remainder:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше размера одной группы",
        )
    return None

def explain_related_quantity_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    result = apply_more_less(base, delta, mode)
    if result is None:
        return None
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то его находим так: {base} {sign} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: если число на несколько единиц больше, прибавляют; если меньше, вычитают",
    )

def explain_related_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {sign} {delta} = {related}.",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего будет {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: если нельзя сразу ответить на главный вопрос, сначала находят неизвестное количество",
    )

def explain_related_quantity_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    result = apply_times_relation(base, factor, mode)
    if result is None:
        return None
    op = "×" if mode == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то его находим так: {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: если число в несколько раз больше, умножают; если в несколько раз меньше, делят",
    )

def explain_related_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}.",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего будет {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: сначала найди число, которое дано через отношение, потом считай общее количество",
    )

def explain_indirect_plus_minus_problem(base: int, delta: int, relation: str) -> Optional[str]:
    if relation in {"старше", "больше"}:
        result = base - delta
        if result < 0:
            return None
        transformed = "значит, другое число на столько же меньше"
        op = "-"
    else:
        result = base + delta
        transformed = "значит, другое число на столько же больше"
        op = "+"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число на {delta} {relation}, то {transformed}.",
        f"2) Тогда искомое число равно {base} {op} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переводят условие в прямую форму",
    )

def explain_indirect_times_problem(base: int, factor: int, relation: str) -> Optional[str]:
    if relation == "больше":
        if factor == 0 or base % factor != 0:
            return None
        result = base // factor
        transformed = "значит, другое число во столько же раз меньше"
        op = ":"
    else:
        result = base * factor
        transformed = "значит, другое число во столько же раз больше"
        op = "×"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то {transformed}.",
        f"2) Тогда искомое число равно {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переводят условие в прямую форму",
    )

def explain_bring_to_unit_total_word_problem(groups: int, total_amount: int, target_groups: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    one_group = total_amount // groups
    result = one_group * target_groups
    return join_explanation_lines(
        f"1) Если в {groups} одинаковых группах всего {total_amount}, то в одной группе {total_amount} : {groups} = {one_group}.",
        f"2) Если в одной группе {one_group}, то в {target_groups} таких же группах {one_group} × {target_groups} = {result}.",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну группу",
    )

def explain_price_difference_problem(quantity: int, total_a: int, total_b: int) -> Optional[str]:
    if quantity == 0 or total_a % quantity != 0 or total_b % quantity != 0:
        return None
    price_a = total_a // quantity
    price_b = total_b // quantity
    diff = abs(price_a - price_b)
    return join_explanation_lines(
        f"1) Если {quantity} одинаковых товаров стоят {total_a} руб., то один товар стоит {total_a} : {quantity} = {price_a} руб.",
        f"2) Если такие же {quantity} товаров стоят {total_b} руб., то один товар стоит {total_b} : {quantity} = {price_b} руб.",
        f"3) Тогда разность цен равна {max(price_a, price_b)} - {min(price_a, price_b)} = {diff} руб.",
        f"Ответ: {diff} руб.",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

def explain_price_quantity_cost_problem(quantity: int, total_cost: int, wanted_cost: int) -> Optional[str]:
    if quantity == 0 or total_cost % quantity != 0:
        return None
    price = total_cost // quantity
    if price == 0 or wanted_cost % price != 0:
        return None
    result = wanted_cost // price
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых коробок заплатили {total_cost} руб., то одна коробка стоит {total_cost} : {quantity} = {price} руб.",
        f"2) Если одна коробка стоит {price} руб., то на {wanted_cost} руб. можно купить {wanted_cost} : {price} = {result}.",
        f"Ответ: {result}",
        "Совет: если цена одинаковая, сначала находят цену одной коробки",
    )

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        f"1) Если {count} одинаковых предметов стоят {total_cost} руб., то один предмет стоит {total_cost} : {count} = {price} руб.",
        f"Ответ: один предмет стоит {price} руб.",
        "Совет: цену одной штуки находят делением общей стоимости на количество",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        f"1) Если один предмет стоит {price} руб., а купили {count} предметов, то вся покупка стоит {price} × {count} = {total} руб.",
        f"Ответ: вся покупка стоит {total} руб.",
        "Совет: стоимость находят умножением цены на количество",
    )

def explain_unknown_red_price(known_count: int, known_price: int, unknown_count: int, total_cost: int) -> Optional[str]:
    known_total = known_count * known_price
    other_total = total_cost - known_total
    if unknown_count == 0 or other_total < 0 or other_total % unknown_count != 0:
        return None
    unit_price = other_total // unknown_count
    return join_explanation_lines(
        f"1) Если купили {known_count} белых гвоздики по {known_price} руб., то за белые гвоздики заплатили {known_count} × {known_price} = {known_total} руб.",
        f"2) Если за всю покупку заплатили {total_cost} руб., а за белые гвоздики {known_total} руб., то за красные гвоздики заплатили {total_cost} - {known_total} = {other_total} руб.",
        f"3) Если за {unknown_count} красных гвоздик заплатили {other_total} руб., то одна красная гвоздика стоила {other_total} : {unknown_count} = {unit_price} руб.",
        f"Ответ: одна красная гвоздика стоила {unit_price} руб.",
        "Совет: если известна общая стоимость покупки, сначала вычти известную часть",
    )
