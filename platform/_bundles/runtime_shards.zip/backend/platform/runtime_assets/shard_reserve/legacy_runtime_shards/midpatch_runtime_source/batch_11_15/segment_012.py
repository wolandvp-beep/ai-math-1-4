"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 9637-10514."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def explain_sharing_word_problem(total: int, groups: int) -> Optional[str]:
    if groups == 0:
        return join_explanation_lines("На ноль делить нельзя.", "Ответ: деление на ноль невозможно", "Совет: сначала проверь делитель")
    quotient, remainder = divmod(total, groups)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если {total} предметов разделили на {groups} равные части, то в каждой части будет {total} : {groups} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: слова «поровну» и «каждый» подсказывают деление",
        )
    return join_explanation_lines(
        f"1) Если {total} разделить на {groups}, то получится {quotient}, остаток {remainder}.",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: остаток всегда должен быть меньше делителя",
    )

def explain_group_count_word_problem(total: int, per_group: int, needs_extra_group: bool = False, explicit_remainder: bool = False) -> Optional[str]:
    if per_group == 0:
        return join_explanation_lines("В одной группе не может быть 0 предметов.", "Ответ: запись задачи неверная", "Совет: проверь размер одной группы")
    quotient, remainder = divmod(total, per_group)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то число групп равно {total} : {per_group} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: число групп находят делением",
        )
    if needs_extra_group:
        return join_explanation_lines(
            f"1) Полных групп получится {quotient}, потому что {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"2) Так как предметы ещё остались, нужна ещё одна группа. Всего групп будет {quotient + 1}.",
            f"Ответ: {quotient + 1}",
            "Совет: если после деления ещё есть остаток, иногда нужна ещё одна коробка или корзина",
        )
    if explicit_remainder:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше размера одной группы",
        )
    return None

def explain_related_quantity_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    result = apply_more_less(base, delta, mode)
    if result is None:
        return None
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то его находим так: {base} {sign} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: если число на несколько единиц больше, прибавляют; если меньше, вычитают",
    )

def explain_related_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {sign} {delta} = {related}.",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего будет {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: если нельзя сразу ответить на главный вопрос, сначала находят неизвестное количество",
    )

def explain_related_quantity_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    result = apply_times_relation(base, factor, mode)
    if result is None:
        return None
    op = "×" if mode == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то его находим так: {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: если число в несколько раз больше, умножают; если в несколько раз меньше, делят",
    )

def explain_related_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}.",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего будет {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: сначала найди число, которое дано через отношение, потом считай общее количество",
    )

def explain_indirect_plus_minus_problem(base: int, delta: int, relation: str) -> Optional[str]:
    if relation in {"старше", "больше"}:
        result = base - delta
        if result < 0:
            return None
        transformed = "значит, другое число на столько же меньше"
        op = "-"
    else:
        result = base + delta
        transformed = "значит, другое число на столько же больше"
        op = "+"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число на {delta} {relation}, то {transformed}.",
        f"2) Тогда искомое число равно {base} {op} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переводят условие в прямую форму",
    )

def explain_indirect_times_problem(base: int, factor: int, relation: str) -> Optional[str]:
    if relation == "больше":
        if factor == 0 or base % factor != 0:
            return None
        result = base // factor
        transformed = "значит, другое число во столько же раз меньше"
        op = ":"
    else:
        result = base * factor
        transformed = "значит, другое число во столько же раз больше"
        op = "×"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то {transformed}.",
        f"2) Тогда искомое число равно {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переводят условие в прямую форму",
    )

def explain_bring_to_unit_total_word_problem(groups: int, total_amount: int, target_groups: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    one_group = total_amount // groups
    result = one_group * target_groups
    return join_explanation_lines(
        f"1) Если в {groups} одинаковых группах всего {total_amount}, то в одной группе {total_amount} : {groups} = {one_group}.",
        f"2) Если в одной группе {one_group}, то в {target_groups} таких же группах {one_group} × {target_groups} = {result}.",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну группу",
    )

def explain_price_difference_problem(quantity: int, total_a: int, total_b: int) -> Optional[str]:
    if quantity == 0 or total_a % quantity != 0 or total_b % quantity != 0:
        return None
    price_a = total_a // quantity
    price_b = total_b // quantity
    diff = abs(price_a - price_b)
    return join_explanation_lines(
        f"1) Если {quantity} одинаковых товаров стоят {total_a} руб., то один товар стоит {total_a} : {quantity} = {price_a} руб.",
        f"2) Если такие же {quantity} товаров стоят {total_b} руб., то один товар стоит {total_b} : {quantity} = {price_b} руб.",
        f"3) Тогда разность цен равна {max(price_a, price_b)} - {min(price_a, price_b)} = {diff} руб.",
        f"Ответ: {diff} руб.",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

def explain_price_quantity_cost_problem(quantity: int, total_cost: int, wanted_cost: int) -> Optional[str]:
    if quantity == 0 or total_cost % quantity != 0:
        return None
    price = total_cost // quantity
    if price == 0 or wanted_cost % price != 0:
        return None
    result = wanted_cost // price
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых коробок заплатили {total_cost} руб., то одна коробка стоит {total_cost} : {quantity} = {price} руб.",
        f"2) Если одна коробка стоит {price} руб., то на {wanted_cost} руб. можно купить {wanted_cost} : {price} = {result}.",
        f"Ответ: {result}",
        "Совет: если цена одинаковая, сначала находят цену одной коробки",
    )

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        f"1) Если {count} одинаковых предметов стоят {total_cost} руб., то один предмет стоит {total_cost} : {count} = {price} руб.",
        f"Ответ: один предмет стоит {price} руб.",
        "Совет: цену одной штуки находят делением общей стоимости на количество",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        f"1) Если один предмет стоит {price} руб., а купили {count} предметов, то вся покупка стоит {price} × {count} = {total} руб.",
        f"Ответ: вся покупка стоит {total} руб.",
        "Совет: стоимость находят умножением цены на количество",
    )

def explain_unknown_red_price(known_count: int, known_price: int, unknown_count: int, total_cost: int) -> Optional[str]:
    known_total = known_count * known_price
    other_total = total_cost - known_total
    if unknown_count == 0 or other_total < 0 or other_total % unknown_count != 0:
        return None
    unit_price = other_total // unknown_count
    return join_explanation_lines(
        f"1) Если купили {known_count} белых гвоздики по {known_price} руб., то за белые гвоздики заплатили {known_count} × {known_price} = {known_total} руб.",
        f"2) Если за всю покупку заплатили {total_cost} руб., а за белые гвоздики {known_total} руб., то за красные гвоздики заплатили {total_cost} - {known_total} = {other_total} руб.",
        f"3) Если за {unknown_count} красных гвоздик заплатили {other_total} руб., то одна красная гвоздика стоила {other_total} : {unknown_count} = {unit_price} руб.",
        f"Ответ: одна красная гвоздика стоила {unit_price} руб.",
        "Совет: если известна общая стоимость покупки, сначала вычти известную часть",
    )

def explain_whole_by_remaining_fraction(remaining_value: int, spent_numerator: int, denominator: int) -> Optional[str]:
    remaining_numerator = denominator - spent_numerator
    if denominator == 0 or remaining_numerator <= 0:
        return None
    if remaining_value % remaining_numerator != 0:
        return None
    one_part = remaining_value // remaining_numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег.",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part}.",
        f"3) Если одна доля равна {one_part}, то все деньги равны {one_part} × {denominator} = {whole}.",
        f"Ответ: всего было {whole}",
        "Совет: если известен остаток после расхода части, сначала находят оставшуюся долю",
    )

def explain_fraction_of_number_word_problem(total: int, numerator: int, denominator: int, ask_remaining: bool = False) -> Optional[str]:
    if denominator == 0 or numerator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    taken = one_part * numerator
    if ask_remaining:
        remaining = total - taken
        return join_explanation_lines(
            f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}.",
            f"3) Если всего было {total}, а использовали {taken}, то осталось {total} - {taken} = {remaining}.",
            f"Ответ: {remaining}",
            "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
        )
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
        f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}.",
        f"Ответ: {taken}",
        "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
    )

def explain_number_by_fraction_word_problem(part_value: int, numerator: int, denominator: int) -> Optional[str]:
    if numerator == 0 or part_value % numerator != 0:
        return None
    one_part = part_value // numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если {numerator}/{denominator} числа равны {part_value}, то сначала найдём одну долю: {part_value} : {numerator} = {one_part}.",
        f"2) Если одна доля равна {one_part}, то всё число равно {one_part} × {denominator} = {whole}.",
        f"Ответ: {whole}",
        "Совет: чтобы найти всё число по его доле, сначала находят одну долю",
    )

def explain_two_fraction_parts_remaining(total: int, first_fraction: Tuple[int, int], second_fraction: Tuple[int, int]) -> Optional[str]:
    n1, d1 = first_fraction
    n2, d2 = second_fraction
    if d1 == 0 or d2 == 0 or total % math.lcm(d1, d2) != 0:
        return None
    first_part = total * n1 // d1
    second_part = total * n2 // d2
    used = first_part + second_part
    remaining = total - used
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то первая часть равна {total} : {d1} × {n1} = {first_part}.",
        f"2) Если всё число равно {total}, то вторая часть равна {total} : {d2} × {n2} = {second_part}.",
        f"3) Если использовали {first_part} и {second_part}, то всего использовали {first_part} + {second_part} = {used}.",
        f"4) Тогда осталось {total} - {used} = {remaining}.",
        f"Ответ: {remaining}",
        "Совет: если от одного и того же целого берут две части, каждую часть находят отдельно",
    )

def explain_second_part_after_fraction(total: int, numerator: int, denominator: int) -> Optional[str]:
    if denominator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    first_part = one_part * numerator
    second_part = total - first_part
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
        f"2) Если первая часть составляет {numerator}/{denominator}, то первая часть равна {one_part} × {numerator} = {first_part}.",
        f"3) Тогда вторая часть равна {total} - {first_part} = {second_part}.",
        f"Ответ: {second_part}",
        "Совет: чтобы найти другую часть, сначала находят известную часть, потом вычитают её из целого",
    )

def explain_simple_motion_distance(speed: int, time_value: int, unit: str = "") -> str:
    result = speed * time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти расстояние, нужно скорость умножить на время.",
        f"2) Если скорость равна {speed}, а время равно {time_value}, то расстояние равно {speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом S = v × t",
    )

def explain_simple_motion_speed(distance: int, time_value: int, unit: str = "") -> Optional[str]:
    if time_value == 0 or distance % time_value != 0:
        return None
    result = distance // time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти скорость, нужно расстояние разделить на время.",
        f"2) Если расстояние равно {distance}, а время равно {time_value}, то скорость равна {distance} : {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом v = S : t",
    )

def explain_simple_motion_time(distance: int, speed: int, unit: str = "") -> Optional[str]:
    if speed == 0 or distance % speed != 0:
        return None
    result = distance // speed
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти время, нужно расстояние разделить на скорость.",
        f"2) Если расстояние равно {distance}, а скорость равна {speed}, то время равно {distance} : {speed} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом t = S : v",
    )

def explain_meeting_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    closing_speed = v1 + v2
    distance = closing_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2}, то скорость сближения равна {v1} + {v2} = {closing_speed}.",
        f"2) Если скорость сближения равна {closing_speed}, а время равно {time_value}, то расстояние равно {closing_speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: при встречном движении сначала находят скорость сближения",
    )

def explain_opposite_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    removal_speed = v1 + v2
    distance = removal_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2} в противоположных направлениях, то скорость удаления равна {v1} + {v2} = {removal_speed}.",
        f"2) Если скорость удаления равна {removal_speed}, а время равно {time_value}, то расстояние между ними равно {removal_speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: при движении в противоположных направлениях сначала находят скорость удаления",
    )

def _final_20260412e_together_as_much_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if "столько, сколько" not in lower:
        return None
    if not has_multiple_questions(text):
        return None
    relation_pairs = extract_relation_pairs(lower)
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2 or not relation_pairs:
        return None
    base = nums[0]
    delta, mode = relation_pairs[0]
    second = apply_more_less(base, delta, mode)
    if second is None:
        return None
    third = base + second
    total = base + second + third
    sign = "+" if mode == "больше" else "-"
    third_name = ""
    m = re.search(r"а\s+([а-яё]+)\s+столько,\s+сколько", lower)
    if m:
        third_name = m.group(1)
    all_name = ""
    if "цвет" in lower:
        all_name = "цветов"
    answer_third = f"{third_name} было {third}" if third_name else f"третье количество равно {third}"
    answer_total = f"всего было {total} {all_name}".strip()
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {sign} {delta} = {second}.",
        f"2) Если третье количество равно первому и второму вместе, то оно равно {base} + {second} = {third}.",
        f"3) Если первое количество равно {base}, второе равно {second}, а третье равно {third}, то всего {base} + {second} + {third} = {total}.",
        f"Ответ: {answer_third}; {answer_total}",
        "Совет: если сказано «столько, сколько вместе», сначала находят сумму этих частей",
    )





# --- FINAL CONSOLIDATION PATCH 2026-04-12F: broader math guard + tasks with letters ---

MATH_INPUT_HINTS = (
    "сколько", "сколько всего", "сколько стало", "сколько осталось", "на сколько", "во сколько",
    "больше", "меньше", "поровну", "по ", "стоимость", "цена", "количество", "купили",
    "скорость", "расстояние", "время", "площадь", "периметр", "доля", "часть",
    "уравнение", "пример", "выражение", "реши", "найди", "найдите",
)

def looks_like_math_input(text: str) -> bool:
    base = normalize_word_problem_text(text).lower()
    if re.search(r"\d|x|х|[+\-*/=×÷:]", base):
        return True
    if re.search(r"\b[a-z]\b", base) and any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    # допускаем словесные задачи без цифр, если в них есть школьные математические маркеры
    if any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    return False

def _final_letter_task_shelf_more_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"на первой полке\s+([a-z])\s+книг[^.?!]*на\s+([a-z])\s+больше[^.?!]*на второй",
        lower,
    )
    if not match:
        return None
    total_symbol = match.group(1)
    delta_symbol = match.group(2)
    return join_explanation_lines(
        f"1) Если на первой полке {total_symbol} книг и это на {delta_symbol} больше, чем на второй, то на второй полке на {delta_symbol} книг меньше.",
        f"2) Если на первой полке {total_symbol} книг, а на второй на {delta_symbol} книг меньше, то на второй полке {total_symbol} - {delta_symbol} книг.",
        f"Ответ: на второй полке {total_symbol} - {delta_symbol} книг.",
        "Совет: в задаче с буквами действуй так же, как в задаче с числами: сначала переведи косвенную форму в прямую.",
    )



def _final_letter_task_trains_passengers_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"прибыл[ао]?|прибыло", lower
    )
    if not match:
        return None
    match = re.search(
        r"на вокзал прибыл[ао]?\s+([a-z])\s+поезд[ао]в?\s+по\s+([a-z])\s+пассажир",
        lower,
    )
    if not match:
        return None
    trains_symbol, passengers_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если на вокзал прибыло {trains_symbol} поездов по {passengers_symbol} пассажиров в каждом, то всего прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        f"Ответ: прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        "Совет: если одно и то же количество повторяется несколько раз, используют умножение.",
    )

def _final_letter_task_garland_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зеленых|гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зелёных",
        lower,
    )
    if not match:
        return None
    groups = [g for g in match.groups() if g]
    if len(groups) != 2:
        return None
    red_symbol, green_symbol = groups
    return join_explanation_lines(
        f"1) Чтобы узнать, во сколько раз зелёных лампочек больше, чем красных, нужно количество зелёных разделить на количество красных.",
        f"2) Значит, нужно вычислить {green_symbol} : {red_symbol}.",
        f"Ответ: в {green_symbol} : {red_symbol} раза.",
        "Совет: вопрос «во сколько раз» решают делением большего количества на меньшее.",
    )

def _final_letter_task_factories_total_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"один завод выпустил\s+([a-z])\s+станков[^.?!]*в\s+([a-z])\s+раз\s+меньше",
        lower,
    )
    if not match:
        return None
    first_symbol, factor_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если один завод выпустил {first_symbol} станков, а второй в {factor_symbol} раз меньше, то второй завод выпустил {first_symbol} : {factor_symbol} станков.",
        f"2) Если первый завод выпустил {first_symbol} станков, а второй {first_symbol} : {factor_symbol} станков, то вместе они выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        f"Ответ: вместе заводы выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        "Совет: если число дано через «в несколько раз меньше», сначала делят, а потом находят сумму.",
    )

def _final_letter_word_problem_explanation(raw_text: str) -> Optional[str]:
    return (
        _final_letter_task_shelf_more_explanation(raw_text)
        or _final_letter_task_tourist_remaining_explanation(raw_text)
        or _final_letter_task_trains_passengers_explanation(raw_text)
        or _final_letter_task_garland_ratio_explanation(raw_text)
        or _final_letter_task_factories_total_explanation(raw_text)
    )

SYSTEM_PROMPT = SYSTEM_PROMPT + "\nЕсли в задаче вместо чисел стоят буквы, решай её теми же школьными методами и давай ответ буквенным выражением."




# --- PATCH 2026-04-12F1: robust tourist-letter task ---

def _final_letter_task_tourist_remaining_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"турист должен пройти\s+([a-z])\s+км[\s\S]*?в первый день[\s\S]*?прош[её]л\s+([a-z])\s+км[\s\S]*?во второй[\s\S]*?([a-z])\s+км",
        lower,
    )
    if not match:
        return None
    total_symbol, first_symbol, second_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если в первый день турист прошёл {first_symbol} км, а во второй {second_symbol} км, то за два дня он прошёл {first_symbol} + {second_symbol} км.",
        f"2) Если турист должен пройти {total_symbol} км, а уже прошёл {first_symbol} + {second_symbol} км, то ему осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        f"Ответ: туристу осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        "Совет: в буквенной задаче сначала находят уже пройденный путь, потом вычитают его из всего пути.",
    )

# --- USER FINAL CONSOLIDATION PATCH 2026-04-12G: fuller textbook answers, better known/question extraction ---


SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку:
Порядок действий:
и ниже тот же пример, где над математическими знаками стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши строку:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. Если пример удобнее решать в столбик, сохраняй запись столбиком и подробное пояснение по шагам.
6. Вычисления в столбик используй, когда в выражении больше двух двузначных чисел или когда есть число из трёх и более цифр.
7. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом перепиши условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно пиши:
Что известно: ...
Что нужно найти: ...
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. В каждом действии, где это уместно, используй школьную форму:
Если ..., то ...
8. После каждого действия коротко говори, что нашли.
9. Если решение записывается по действиям, то в каждом действии, кроме последнего, полезно писать пояснение, что именно нашли.
10. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Если задача дана с именованными величинами, сначала переведи их в удобные одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если это выражение, сначала назови порядок действий.
Если это уравнение, оставляй x отдельно и объясняй обратное действие.
Если это геометрия, сначала назови формулу, потом подставь числа.
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
""".strip()

def _user_final_is_short_answer_value(text: str) -> bool:
    value = str(text or "").strip().rstrip(".")
    if not value:
        return False
    return bool(re.fullmatch(r"-?\d+(?:/\d+)?(?:\s+[A-Za-zА-Яа-яЁё./²%-]+){0,3}", value))

def _user_final_answer_phrase_from_question(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip().rstrip(".")
    if not value:
        return value
    if not _user_final_is_short_answer_value(value):
        return value

    question = _question_lower_text(raw_text).lower().replace("ё", "е")

    if question.startswith("во сколько раз"):
        return value if value.startswith("в ") else f"в {value}"

    if re.search(r"\bсколько[^.?!]*\bзабрали\b", question):
        return f"забрали {value}"
    if re.search(r"\bсколько[^.?!]*\bотдали\b", question):
        return f"отдали {value}"
    if re.search(r"\bсколько[^.?!]*\bсъели\b", question):
        return f"съели {value}"
    if re.search(r"\bсколько[^.?!]*\bпродали\b", question):
        return f"продали {value}"
    if re.search(r"\bсколько[^.?!]*\bдобавили\b", question):
        return f"добавили {value}"
    if re.search(r"\bсколько[^.?!]*\bзаболел[аои]?\b", question):
        return f"заболело {value}"
    if re.search(r"\bсколько[^.?!]*\bостал(?:ось|ись|ся)\b", question):
        return f"осталось {value}"
    if re.search(r"\bсколько[^.?!]*\bстал(?:о|и)\b", question):
        return f"стало {value}"
    if re.search(r"\bсколько[^.?!]*\bпотребуется\b", question) or re.search(r"\bсколько[^.?!]*\bпотребовалось\b", question):
        return f"потребуется {value}"
    if re.search(r"\bсколько[^.?!]*\bможно купить\b", question):
        return f"можно купить {value}"

    price_one = re.search(r"\bсколько\s+стоит\s+(?:1|один|одна|одно)\s+([а-яё-]+)", question)
    if price_one:
        return f"{price_one.group(1)} стоит {value}"

    price_many = re.search(r"\bсколько\s+стоят\s+(.+)$", question)
    if price_many:
        subject = price_many.group(1).strip(" ?")
        if subject:
            return f"{subject} стоят {value}"

    if re.search(r"\bс какой скоростью\b|\bкакова скорость\b|\bчему равна скорость\b", question):
        return f"скорость равна {value}"
    if re.search(r"\bкакое расстояние\b|\bкаково расстояние\b|\bчему равно расстояние\b", question):
        return f"расстояние равно {value}"
    if re.search(r"\bсколько времени\b|\bза какое время\b|\bсколько часов\b", question):
        return f"время равно {value}"
    if re.search(r"\bчему равна площадь\b|\bнайти площадь\b|\bузнайте площадь\b", question):
        return f"площадь равна {value}"
    if re.search(r"\bчему равен периметр\b|\bнайти периметр\b|\bузнайте периметр\b", question):
        return f"периметр равен {value}"

    shelf_match = re.search(r"\bсколько[^.?!]*\bна\s+(первой|второй|третьей)\s+полке\b", question)
    if shelf_match:
        return f"на {shelf_match.group(1)} полке было {value}"

    day_match = re.search(r"\bсколько[^.?!]*\bво\s+(первый|второй|третий)\s+день\b", question)
    if day_match:
        return f"в {day_match.group(1)} день {value}"

    if question.startswith("сколько денег"):
        return f"заплатили {value}"

    return value

def _detailed_format_word_like_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    statement = _detailed_statement_text(raw_text)
    info_lines: List[str] = []
    body_lines: List[str] = []

    for line in parts["body"]:
        lower = line.lower()
        if lower.startswith("что известно:") or lower.startswith("что нужно найти:"):
            info_lines.append(line)
        else:
            body_lines.append(line)

    if not info_lines:
        condition, question = extract_condition_and_question(raw_text)
        if condition:
            info_lines.append(f"Что известно: {condition}")
        if question:
            info_lines.append(f"Что нужно найти: {question}")

    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    answer = _user_final_answer_phrase_from_question(answer, raw_text, kind)

    lines: List[str] = []
    if statement:
        lines.append("Задача.")
        lines.append(statement)
    lines.append("Решение.")
    lines.extend(info_lines)
    lines.extend(_detailed_number_lines(body_lines))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind if kind in DEFAULT_ADVICE else "other")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_generic_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    lines: List[str] = []
    statement = _detailed_statement_text(raw_text)
    if statement and kind in {"word", "geometry"}:
        lines.append("Задача.")
        lines.append(statement)
        lines.append("Решение.")
    else:
        lines.append("Решение.")
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    answer = _user_final_answer_phrase_from_question(answer, raw_text, kind)
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind)
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)



# --- USER FINAL HOTFIX 2026-04-12H: geometry known-line extraction for "найти ..." formulations ---


# --- USER DELIVERY PATCH 2026-04-13: fuller final answers, architecture preserved ---

_PREV_USER_DELIVERY_ANSWER_PHRASE = _user_final_answer_phrase_from_question

def _user_final_answer_phrase_from_question(answer: str, raw_text: str, kind: str) -> str:
    original_value = str(answer or '').strip().rstrip('.')
    base = _PREV_USER_DELIVERY_ANSWER_PHRASE(answer, raw_text, kind)
    if not original_value:
        return base
    if not _user_final_is_short_answer_value(original_value):
        return base
    if str(base).strip().rstrip('.') != original_value:
        return base

    question = _question_lower_text(raw_text).lower().replace('ё', 'е').strip(' ?.')

    if question.startswith('сколько'):
        if ' было ' in f' {question} ' or question.endswith(' было'):
            if re.search(r'\b(кг|г|л|м|см|дм|мм|км|руб|листов|книг|клеток|деревьев|фруктов|деталей)\b', question) or 'всего' in question:
                return f'всего было {original_value}'
            return f'было {original_value}'
        if ' осталось ' in f' {question} ' or question.endswith(' осталось'):
            return f'осталось {original_value}'
        if ' стало ' in f' {question} ' or question.endswith(' стало'):
            return f'стало {original_value}'
        if re.search(r'\bсколько[^?]*\bклеток\b', question):
            return f'было {original_value}'
        if re.search(r'\bсколько[^?]*\bкоробок\b', question):
            return f'получилось {original_value}'
        if re.search(r'\bсколько[^?]*\bмешков\b', question):
            return f'было {original_value}'
        if re.search(r'\bсколько[^?]*\bкниг\b', question) and ('на полках' in question or 'на двух полках' in question or 'на трех полках' in question or 'на трёх полках' in question):
            return f'всего было {original_value}'
        if re.search(r'\bсколько[^?]*\bфруктов\b', question) and ('в ларьке' in question or 'в магазине' in question or 'было' in question):
            return f'всего было {original_value}'

    return base

# --- USER PATCH 2026-04-13I: DeepSeek-only topic rules + detailed first incomplete dividend ---

_RULE_STYLE_HINTS = (
    "Сформулируй правило как короткое определение.",
    "Сформулируй правило как краткое правило действия.",
    "Сформулируй правило как учебное напоминание по теме.",
)

def _strip_rule_lines(text: str) -> str:
    kept: List[str] = []
    for raw in str(text or "").replace("\r", "").split("\n"):
        line = raw.strip()
        if re.match(r"^(?:совет|правило)\s*:\s*", line, flags=re.IGNORECASE):
            continue
        kept.append(raw.rstrip())
    while kept and not kept[-1].strip():
        kept.pop()
    return "\n".join(kept).strip()

def _normalize_rule_text(text: str) -> str:
    cleaned = sanitize_model_text(str(text or ""))
    for raw in cleaned.replace("\r", "").split("\n"):
        line = raw.strip().strip('"').strip("' ")
        if not line:
            continue
        line = re.sub(r"^(?:совет|правило)\s*:\s*", "", line, flags=re.IGNORECASE).strip()
        line = re.sub(r"\s+", " ", line)
        line = line.rstrip(" .!?")
        if not line:
            continue
        if len(line) > 220:
            line = line[:220].rstrip(" ,;:")
        return line
    return ""

def _append_rule_line(text: str, rule: str) -> str:
    base = _strip_rule_lines(text)
    normalized_rule = _normalize_rule_text(rule)
    if not normalized_rule:
        return base
    rule_line = _detailed_finalize_line(f"Совет: {normalized_rule}")
    if not base:
        return rule_line
    return f"{base}\n{rule_line}".strip()

def _compare_first_incomplete_candidate(candidate: int, divisor: int) -> str:
    if candidate < divisor:
        return f"{candidate} меньше {divisor} – не подходит"
    if candidate == divisor:
        return f"{candidate} равно {divisor} – подходит"
    return f"{candidate} больше {divisor} – подходит"
