"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 1-899."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_local_fraction_word_problem_explanation(user_text)
        or try_local_motion_word_problem_explanation(user_text)
        or try_local_price_word_problem_explanation(user_text)
        or try_local_unit_rate_word_problem_explanation(user_text)
        or try_local_sum_and_divide_word_problem_explanation(user_text)
        or try_local_proportional_division_word_problem(user_text)
        or try_local_difference_unknown_word_problem(user_text)
        or try_local_indirect_word_problem_explanation(user_text)
        or try_local_compound_word_problem_explanation(user_text)
        or try_local_word_problem_explanation(user_text)
    )

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        prepared = add_task_context_lines(local_explanation, user_text, kind)
        return {"result": shape_explanation(prepared, kind), "source": "local", "validated": True}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 1400,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    prepared = add_task_context_lines(llm_result["result"], user_text, kind)
    shaped = shape_explanation(prepared, kind)
    return {"result": shaped, "source": "llm", "validated": False}

# --- PATCH: detail fixes ---

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        "Сначала вспоминаем правило: цена = стоимость : количество",
        f"Находим цену одной штуки: {total_cost} : {count} = {price}",
        f"Ответ: {price} руб.",
        "Совет: цену одного предмета находят делением общей стоимости на количество",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        "Сначала вспоминаем правило: стоимость = цена × количество",
        f"Находим стоимость покупки: {price} × {count} = {total}",
        f"Ответ: {total} руб.",
        "Совет: стоимость находят умножением цены на количество",
    )

def explain_trip_time_for_same_distance(speed1: int, time1: int, speed2: int) -> Optional[str]:
    distance = speed1 * time1
    if speed2 == 0 or distance % speed2 != 0:
        return None
    time2 = distance // speed2
    return join_explanation_lines(
        f"Сначала находим расстояние между пунктами: {speed1} × {time1} = {distance}",
        f"Потом находим время для второго участника: {distance} : {speed2} = {time2}",
        f"Ответ: {time2} ч",
        "Совет: если путь один и тот же, сначала найди расстояние, потом дели его на новую скорость",
    )

def explain_second_day_motion_time(total_distance: int, first_speed: int, first_time: int, second_speed: int) -> Optional[str]:
    first_distance = first_speed * first_time
    second_distance = total_distance - first_distance
    if second_speed == 0 or second_distance < 0 or second_distance % second_speed != 0:
        return None
    second_time = second_distance // second_speed
    total_time = first_time + second_time
    return join_explanation_lines(
        f"Сначала находим путь в первый день: {first_speed} × {first_time} = {first_distance}",
        f"Потом находим путь во второй день: {total_distance} - {first_distance} = {second_distance}",
        f"Теперь находим время во второй день: {second_distance} : {second_speed} = {second_time}",
        f"И находим всё время: {first_time} + {second_time} = {total_time}",
        f"Ответ: во второй день — {second_time} ч; всего — {total_time} ч",
        "Совет: в составной задаче на движение сначала находят путь, потом время",
    )

def explain_remaining_part_speed(total_distance: int, first_speed: int, first_time: int, second_time: int) -> Optional[str]:
    first_distance = first_speed * first_time
    remaining_distance = total_distance - first_distance
    if second_time == 0 or remaining_distance < 0 or remaining_distance % second_time != 0:
        return None
    second_speed = remaining_distance // second_time
    return join_explanation_lines(
        f"Сначала находим первую часть пути: {first_speed} × {first_time} = {first_distance}",
        f"Потом находим оставшийся путь: {total_distance} - {first_distance} = {remaining_distance}",
        f"Теперь находим скорость на оставшейся части пути: {remaining_distance} : {second_time} = {second_speed}",
        f"Ответ: {second_speed} км/ч",
        "Совет: если известны оставшийся путь и время, скорость находят делением",
    )

def explain_return_trip_time_by_faster_speed(distance: int, speed: int, factor: int) -> Optional[str]:
    if speed == 0 or factor == 0 or distance % speed != 0:
        return None
    first_time = distance // speed
    faster_speed = speed * factor
    if faster_speed == 0 or distance % faster_speed != 0:
        return None
    return_time = distance // faster_speed
    return join_explanation_lines(
        f"Сначала находим время в одну сторону: {distance} : {speed} = {first_time}",
        f"Потом находим скорость на обратном пути: {speed} × {factor} = {faster_speed}",
        f"Теперь находим время на обратный путь: {distance} : {faster_speed} = {return_time}",
        f"Ответ: {return_time} ч",
        "Совет: если на обратном пути скорость увеличилась в несколько раз, сначала найди новую скорость",
    )

def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)

    if len(nums) >= 4 and "за всю покупку заплатили" in lower and "по" in lower and contains_any_fragment(lower, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        solved = explain_unknown_red_price(nums[0], nums[1], nums[2], nums[3])
        if solved:
            return solved

    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоит 1", "сколько стоит одна", "сколько стоит один", "сколько стоит 1 ")):
        solved = explain_simple_price_per_item(nums[0], nums[1])
        if solved:
            return solved

    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоят", "сколько стоила вся покупка", "сколько стоит вся покупка")):
        return explain_simple_total_cost(nums[0], nums[1])

    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    if contains_any_fragment(lower, ("сколько таких коробок", "сколько можно купить", "сколько коробок можно купить")):
        return explain_price_quantity_cost_problem(nums[0], nums[1], nums[2])
    return None

# --- PATCH: context extraction fixes ---

# --- FINAL PATCH: detailed school-style formatting, safer fallback, richer step output ---

DEEPSEEK_API_KEY = (os.environ.get("myapp_ai_math_1_4_API_key") or "").strip()

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать очень подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой содержательной строке пиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, пиши строку:
Порядок действий:
Потом сам пример и над знаками действий цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши строку:
Решение по действиям:
4. Ниже обязательно пиши:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. По возможности используй школьную форму:
Если ..., то ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Важные требования:
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Если в задаче два вопроса, ответь на оба по порядку.
Для многодейственных задач не перескакивай сразу к ответу.
Сначала действие, потом пояснение, потом следующее действие.
""".strip()

BODY_LIMITS = {
    "expression": 40,
    "equation": 20,
    "fraction": 24,
    "geometry": 30,
    "word": 40,
    "other": 20,
}

_ORIGINAL_try_local_expression_explanation = try_local_expression_explanation
_ORIGINAL_try_local_equation_explanation = try_local_equation_explanation
_ORIGINAL_try_local_fraction_explanation = try_local_fraction_explanation
_ORIGINAL_try_local_geometry_explanation = try_local_geometry_explanation
_ORIGINAL_try_local_fraction_word_problem_explanation = try_local_fraction_word_problem_explanation
_ORIGINAL_try_local_motion_word_problem_explanation = try_local_motion_word_problem_explanation
_ORIGINAL_try_local_price_word_problem_explanation = try_local_price_word_problem_explanation
_ORIGINAL_try_local_unit_rate_word_problem_explanation = try_local_unit_rate_word_problem_explanation
_ORIGINAL_try_local_sum_and_divide_word_problem_explanation = try_local_sum_and_divide_word_problem_explanation
_ORIGINAL_try_local_proportional_division_word_problem = try_local_proportional_division_word_problem
_ORIGINAL_try_local_difference_unknown_word_problem = try_local_difference_unknown_word_problem
_ORIGINAL_try_local_indirect_word_problem_explanation = try_local_indirect_word_problem_explanation
_ORIGINAL_try_local_compound_word_problem_explanation = try_local_compound_word_problem_explanation
_ORIGINAL_try_local_word_problem_explanation = try_local_word_problem_explanation

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    lower = str(raw_text or "").lower().replace("ё", "е")
    if "руб" in lower or "денег" in lower:
        return f"{value} руб."
    return value

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")
    node = parse_expression_ast(source)
    pretty_expression = render_node(node) if node is not None else _detailed_compact_expression(source)
    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("что известно:", "что нужно найти:"))]
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]
    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block and not _detailed_is_column_like(body_lines):
        lines.extend(order_block)
        lines.append("Решение по действиям:")
    else:
        lines.append("Решение.")
    lines.extend(_detailed_number_lines(body_lines))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_equation_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_equation_source(raw_text) or normalize_cyrillic_x(strip_known_prefix(raw_text))
    pretty = _detailed_pretty_equation(source)
    answer = parts["answer"] or "проверь запись"
    if re.fullmatch(r"-?\d+(?:/\d+)?", answer):
        answer = f"x = {answer}"
    lines: List[str] = [f"Уравнение: {pretty}", "Решение."]
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("equation")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_fraction_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_fraction_source(raw_text) or strip_known_prefix(raw_text)
    pretty = _detailed_pretty_fraction_expression(source)
    answer = parts["answer"] or "проверь запись"
    lines: List[str] = [f"Пример: {pretty} = {answer}", "Решение"]
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("fraction")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_word_like_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    statement = _detailed_statement_text(raw_text)
    info_lines: List[str] = []
    body_lines: List[str] = []
    for line in parts["body"]:
        lower = line.lower()
        if lower.startswith("что известно:") or lower.startswith("что нужно найти:"):
            info_lines.append(line)
        else:
            body_lines.append(line)
    if not info_lines:
        condition, question = extract_condition_and_question(raw_text)
        if condition:
            info_lines.append(f"Что известно: {condition}")
        if question:
            info_lines.append(f"Что нужно найти: {question}")
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    lines: List[str] = []
    if statement:
        lines.append("Задача.")
        lines.append(statement)
    lines.append("Решение.")
    lines.extend(info_lines)
    lines.extend(_detailed_number_lines(body_lines))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind if kind in DEFAULT_ADVICE else "other")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_generic_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    lines: List[str] = []
    statement = _detailed_statement_text(raw_text)
    if statement and kind in {"word", "geometry"}:
        lines.append("Задача.")
        lines.append(statement)
        lines.append("Решение.")
    else:
        lines.append("Решение.")
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind)
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if kind == "expression" and to_expression_source(raw_text):
        return _detailed_format_expression_solution(raw_text, text)
    if kind == "equation" and to_equation_source(raw_text):
        return _detailed_format_equation_solution(raw_text, text)
    if kind == "fraction" and to_fraction_source(raw_text) and not re.search(r"[А-Яа-я]", raw_text):
        return _detailed_format_fraction_solution(raw_text, text)
    if kind in {"word", "geometry"} or re.search(r"[А-Яа-я]", raw_text):
        return _detailed_format_word_like_solution(raw_text, text, kind)
    return _detailed_format_generic_solution(raw_text, text, kind)

def shape_explanation(text: str, kind: str, forced_answer: Optional[str] = None, forced_advice: Optional[str] = None) -> str:
    parts = _detailed_split_sections(text)
    answer = forced_answer or parts["answer"] or "проверь запись"
    advice = forced_advice or parts["advice"] or default_advice(kind)
    lines = list(parts["body"])
    if kind == "equation" and parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def explain_sum_then_subtract_word_problem(first: int, second: int, removed: int) -> Optional[str]:
    total = first + second
    remaining = total - removed
    if remaining < 0:
        return None
    return join_explanation_lines(
        f"Сначала находим, сколько было всего: {first} + {second} = {total}",
        f"Потом находим, сколько осталось: {total} - {removed} = {remaining}",
        f"Ответ: {remaining}",
        "Совет: если сначала объединяют две группы, а потом часть убирают, сначала находят сумму",
    )

def try_local_sum_then_subtract_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3:
        return None
    asks_left = bool(re.search(r"сколько[^.?!]*\b(осталось|останется)\b", lower))
    loss_markers = WORD_LOSS_HINTS + ("уехал", "уехала", "уехали", "уехало", "ушел", "ушла", "ушли", "ушло", "забрали")
    has_loss = contains_any_fragment(lower, loss_markers)
    if asks_left and has_loss:
        return explain_sum_then_subtract_word_problem(nums[0], nums[1], nums[2])
    return None

def try_local_named_sum_of_two_products_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower or ("заплат" not in lower and "стоил" not in lower and "стоят" not in lower and "стоимость" not in lower):
        return None

    matches = list(re.finditer(r"(\d+)\s+([^?.!,]{1,30}?)\s+по\s+(\d+)", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_name = matches[0].group(2).strip()
    first_price = int(matches[0].group(3))
    second_count = int(matches[1].group(1))
    second_name = matches[1].group(2).strip()
    second_price = int(matches[1].group(3))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"Если купили {first_count} {first_name} по {first_price} руб., то стоимость первой покупки равна {first_count} × {first_price} = {first_total} руб",
        f"Если купили {second_count} {second_name} по {second_price} руб., то стоимость второй покупки равна {second_count} × {second_price} = {second_total} руб",
        f"Если стоимость первой покупки {first_total} руб., а стоимость второй покупки {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала найди стоимость каждой покупки отдельно",
    )

def try_local_expression_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_expression_explanation(raw_text)

def try_local_equation_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_equation_explanation(raw_text)

def try_local_fraction_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_fraction_explanation(raw_text)

def try_local_geometry_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_geometry_explanation(raw_text)

def try_local_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_fraction_word_problem_explanation(raw_text)

def try_local_motion_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_motion_word_problem_explanation(raw_text)

def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_price_word_problem_explanation(raw_text)

def try_local_unit_rate_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_unit_rate_word_problem_explanation(raw_text)

def try_local_sum_and_divide_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_sum_and_divide_word_problem_explanation(raw_text)

def try_local_proportional_division_word_problem(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_proportional_division_word_problem(raw_text)

def try_local_difference_unknown_word_problem(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_difference_unknown_word_problem(raw_text)

def try_local_indirect_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_indirect_word_problem_explanation(raw_text)

def try_local_compound_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_compound_word_problem_explanation(raw_text)

def try_local_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_word_problem_explanation(raw_text)

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_local_fraction_word_problem_explanation(user_text)
        or try_local_motion_word_problem_explanation(user_text)
        or try_local_price_word_problem_explanation(user_text)
        or try_local_unit_rate_word_problem_explanation(user_text)
        or try_local_sum_and_divide_word_problem_explanation(user_text)
        or try_local_named_sum_of_two_products_word_problem_explanation(user_text)
        or try_local_sum_then_subtract_word_problem_explanation(user_text)
        or try_local_proportional_division_word_problem(user_text)
        or try_local_difference_unknown_word_problem(user_text)
        or try_local_indirect_word_problem_explanation(user_text)
        or try_local_compound_word_problem_explanation(user_text)
        or try_local_word_problem_explanation(user_text)
    )

async def call_deepseek(payload: dict, timeout_seconds: float = 45.0):
    if not DEEPSEEK_API_KEY:
        return {"error": "DeepSeek API key is not configured"}
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
    if response.status_code != 200:
        return {"error": f"DeepSeek API error {response.status_code}", "details": response.text[:1500]}
    try:
        result = response.json()
    except Exception:
        return {"error": "DeepSeek вернул не JSON", "details": response.text[:1500]}
    if "choices" not in result or not result["choices"]:
        return {"error": "DeepSeek вернул неожиданный формат ответа", "details": str(result)[:1500]}
    message = result["choices"][0].get("message", {})
    answer = (message.get("content") or "").strip()
    if not answer:
        return {"error": "DeepSeek вернул пустой ответ", "details": str(result)[:1500]}
    return {"result": answer}

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи",
            "Запишите пример или задачу полнее и без сокращений",
            "Ответ: пока нужен более понятный ввод",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": fallback, "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 1800,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- FINAL SCHOOL PATCH: textbook-style word problems, clearer order marks, bug fixes ---

_PREVIOUS_build_explanation_local_first = build_explanation_local_first

def _has_total_like_question(raw_text: str) -> bool:
    return asks_total_like(normalize_word_problem_text(raw_text).lower()) or "сколько всего" in normalize_word_problem_text(raw_text).lower()

def _has_group_count_question(text_lower: str) -> bool:
    return contains_any_fragment(
        text_lower,
        ("сколько короб", "сколько пакетов", "сколько корзин", "сколько клеток", "сколько сеток", "сколько потребуется", "сколько потребовалось", "сколько ведер", "сколько вёдер"),
    )

def _first_po_pair(text_lower: str) -> Optional[Tuple[int, int]]:
    match = re.search(r"(\d+)\s+[^\d?.!]{0,40}?\bпо\s+(\d+)\b", text_lower)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))

def _fraction_numbers_and_text(raw_text: str):
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower()
    fracs = extract_all_fraction_pairs(lower)
    values = extract_non_fraction_numbers(lower)
    return text, lower, fracs, values

def explain_whole_by_remaining_fraction(remaining_value: int, spent_numerator: int, denominator: int) -> Optional[str]:
    remaining_numerator = denominator - spent_numerator
    if denominator == 0 or remaining_numerator <= 0:
        return None
    if remaining_value % remaining_numerator != 0:
        return None
    one_part = remaining_value // remaining_numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part}",
        f"3) Если одна доля равна {one_part}, то все деньги равны {one_part} × {denominator} = {whole}",
        f"Ответ: всего было {whole}",
        "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
    )

def explain_addition_word_problem(first: int, second: int) -> str:
    result = first + second
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе равно {second}, то всего {first} + {second} = {result}",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько всего или сколько стало, обычно нужно сложение",
    )

def explain_subtraction_word_problem(first: int, second: int) -> str:
    result = first - second
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если сначала было {first}, а потом осталось {second}, то убрали {first} - {second} = {result}",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько осталось или сколько убрали, обычно нужно вычитание",
    )

def explain_comparison_word_problem(first: int, second: int) -> str:
    bigger = max(first, second)
    smaller = min(first, second)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если одно число равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: вопрос «на сколько» решают вычитанием",
    )

def explain_find_initial_after_loss_problem(remaining: int, removed: int) -> str:
    result = remaining + removed
    return join_explanation_lines(
        f"1) Если осталось {remaining}, а убрали {removed}, то сначала было {remaining} + {removed} = {result}",
        f"Ответ: {result}",
        "Совет: неизвестное уменьшаемое находят сложением",
    )

def explain_find_initial_after_gain_problem(final_total: int, added: int) -> str:
    result = final_total - added
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если стало {final_total}, а прибавили {added}, то сначала было {final_total} - {added} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы найти число до прибавления, из нового числа вычитают то, что прибавили",
    )

def explain_find_added_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {smaller}, а потом стало {bigger}, то добавили {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
    )

def explain_find_removed_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {bigger}, а потом осталось {smaller}, то убрали {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
    )

def explain_multiplication_word_problem(groups: int, per_group: int) -> str:
    result = groups * per_group
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {result}",
        f"Ответ: {result}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def explain_sharing_word_problem(total: int, groups: int) -> Optional[str]:
    if groups == 0:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: проверь, на сколько частей делят")
    quotient, remainder = divmod(total, groups)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если всего {total} предметов разделили на {groups} равные части, то {total} : {groups} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: слова «поровну» и «каждый» подсказывают деление",
        )
    return join_explanation_lines(
        f"1) Если {total} разделить на {groups}, то получится {quotient}, остаток {remainder}",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: остаток всегда должен быть меньше делителя",
    )

def explain_group_count_word_problem(total: int, per_group: int, needs_extra_group: bool = False, explicit_remainder: bool = False) -> Optional[str]:
    if per_group == 0:
        return join_explanation_lines("В одной группе не может быть 0 предметов", "Ответ: запись задачи неверная", "Совет: проверь размер одной группы")
    quotient, remainder = divmod(total, per_group)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то групп будет {total} : {per_group} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: число групп находят делением",
        )
    if needs_extra_group:
        return join_explanation_lines(
            f"1) Полных групп получится {quotient}, потому что {total} : {per_group} = {quotient}, остаток {remainder}",
            f"2) Так как предметы ещё остались, нужна ещё одна группа, всего {quotient + 1}",
            f"Ответ: {quotient + 1}",
            "Совет: если после деления ещё есть остаток, иногда нужна ещё одна коробка или место",
        )
    if explicit_remainder:
        return join_explanation_lines(
            f"1) Если {total} разделить на группы по {per_group}, то получится {quotient}, остаток {remainder}",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше размера одной группы",
        )
    return None

def explain_related_quantity_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    result = apply_more_less(base, delta, mode)
    if result is None:
        return None
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то {base} {sign} {delta} = {result}",
        f"Ответ: {result}",
        "Совет: если число на несколько единиц больше, прибавляют; если меньше, вычитают",
    )

def explain_related_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {sign} {delta} = {related}",
        f"2) Если первое количество {base}, а второе количество {related}, то всего {base} + {related} = {total}",
        f"Ответ: {total}",
        "Совет: в составной задаче сначала находят неизвестное количество, потом сумму",
    )

def explain_related_quantity_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    result = apply_times_relation(base, factor, mode)
    if result is None:
        return None
    op = "×" if mode == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то {base} {op} {factor} = {result}",
        f"Ответ: {result}",
        "Совет: если число в несколько раз больше, умножают; если в несколько раз меньше, делят",
    )

def explain_related_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}",
        f"2) Если первое количество {base}, а второе количество {related}, то всего {base} + {related} = {total}",
        f"Ответ: {total}",
        "Совет: сначала найди число, которое дано через отношение, потом считай общее количество",
    )

def explain_indirect_plus_minus_problem(base: int, delta: int, relation: str) -> Optional[str]:
    if relation in {"старше", "больше"}:
        result = base - delta
        if result < 0:
            return None
        relation_text = "значит, другое число на столько же меньше"
        op = "-"
    else:
        result = base + delta
        relation_text = "значит, другое число на столько же больше"
        op = "+"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число на {delta} {relation}, то {relation_text}",
        f"2) Находим искомое число: {base} {op} {delta} = {result}",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переведи условие в прямую форму",
    )

def explain_indirect_times_problem(base: int, factor: int, relation: str) -> Optional[str]:
    if relation == "больше":
        if factor == 0 or base % factor != 0:
            return None
        result = base // factor
        op = ":"
        relation_text = "значит, другое число во столько же раз меньше"
    else:
        result = base * factor
        op = "×"
        relation_text = "значит, другое число во столько же раз больше"
    return join_explanation_lines(
        f"1) Это задача в косвенной форме: если одно число в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то {relation_text}",
        f"2) Находим искомое число: {base} {op} {factor} = {result}",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переведи условие в прямую форму",
    )

def explain_bring_to_unit_total_word_problem(groups: int, total_amount: int, target_groups: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    one_group = total_amount // groups
    result = one_group * target_groups
    return join_explanation_lines(
        f"1) Если в {groups} группах {total_amount}, то в одной группе {total_amount} : {groups} = {one_group}",
        f"2) Если в одной группе {one_group}, то в {target_groups} группах {one_group} × {target_groups} = {result}",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну группу",
    )
