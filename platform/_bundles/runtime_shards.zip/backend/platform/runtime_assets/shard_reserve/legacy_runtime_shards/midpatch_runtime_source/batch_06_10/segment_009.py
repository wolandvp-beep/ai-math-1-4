"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 6971-7839."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _user_patch_books_word_20260411b(count: int) -> str:
    return plural_form(count, "книга", "книги", "книг")

def try_user_patch_shelf_total_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*(обеих|двух) полк", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,40}на второй(?: полке)?(?: было)?\s*(\d+)\b", lower)
    if not match:
        return None
    first = int(match.group(1))
    second = int(match.group(2))
    total = first + second
    return join_explanation_lines(
        f"1) Если на первой полке было {first} {_user_patch_books_word_20260411b(first)}, а на второй {second} {_user_patch_books_word_20260411b(second)}, то на обеих полках было {first} + {second} = {total} книг.",
        f"Ответ: на двух полках было {total} книг.",
        "Совет: если спрашивают, сколько на обеих полках, складывают количества на первой и второй полке.",
    )

def try_user_patch_shelf_more_less_total_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*(обеих|двух) полк", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,40}на второй(?: полке)?\s*на\s*(\d+)\s*(больше|меньше)", lower)
    if not match:
        return None
    first = int(match.group(1))
    delta = int(match.group(2))
    mode = match.group(3)
    second = first + delta if mode == "больше" else first - delta
    if second < 0:
        return None
    total = first + second
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если на первой полке {first} {_user_patch_books_word_20260411b(first)}, а на второй на {delta} {mode}, то на второй полке было {first} {sign} {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
        f"2) Если на первой полке {first} {_user_patch_books_word_20260411b(first)}, а на второй {second} {_user_patch_books_word_20260411b(second)}, то на двух полках было {first} + {second} = {total} книг.",
        f"Ответ: на двух полках было {total} книг.",
        "Совет: в составной задаче сначала находят неизвестное количество, потом сумму.",
    )

def try_user_patch_shelf_unknown_second_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*второй полке", lower):
        return None
    match = re.search(r"на двух полках(?: было)?\s*(\d+)\s*книг[^\d]{0,80}на первой полке(?: было)?\s*(\d+)\s*книг", lower)
    if not match:
        return None
    total = int(match.group(1))
    first = int(match.group(2))
    second = total - first
    if second < 0:
        return None
    return join_explanation_lines(
        f"1) Если на двух полках было {total} книг, а на первой полке было {first} {_user_patch_books_word_20260411b(first)}, то на второй полке было {total} - {first} = {second} {_user_patch_books_word_20260411b(second)}.",
        f"Ответ: на второй полке было {second} {_user_patch_books_word_20260411b(second)}.",
        "Совет: чтобы найти, сколько было на второй полке, из общего количества вычитают количество на первой полке.",
    )

def try_user_patch_shelf_indirect_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*второй полке", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,30}это\s+на\s*(\d+)\s*книг[^\d]{0,20}(больше|меньше),?\s+чем\s+на\s+второй", lower)
    if match:
        first = int(match.group(1))
        delta = int(match.group(2))
        relation = match.group(3)
        if relation == "больше":
            second = first - delta
            if second < 0:
                return None
            return join_explanation_lines(
                f"1) Если на первой полке книг на {delta} больше, чем на второй, то на второй полке книг на {delta} меньше, чем на первой.",
                f"2) Если на первой полке {first} книг, а на второй на {delta} меньше, то на второй полке было {first} - {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
                f"Ответ: на второй полке было {second} {_user_patch_books_word_20260411b(second)}.",
                "Совет: в косвенной задаче сначала переведи условие в прямую форму.",
            )
        second = first + delta
        return join_explanation_lines(
            f"1) Если на первой полке книг на {delta} меньше, чем на второй, то на второй полке книг на {delta} больше, чем на первой.",
            f"2) Если на первой полке {first} книг, а на второй на {delta} больше, то на второй полке было {first} + {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
            f"Ответ: на второй полке было {second} книг.",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму.",
        )

    match = re.search(r"на второй полке(?: было)?\s*(\d+)\s*книг[^\d]{0,30}это\s+в\s*(\d+)\s*раз(?:а)?\s*больше,?\s+чем\s+на\s+первой", lower)
    if match:
        second = int(match.group(1))
        factor = int(match.group(2))
        if factor == 0 or second % factor != 0:
            return None
        first = second // factor
        return join_explanation_lines(
            f"1) Если на второй полке книг в {factor} раза больше, чем на первой, то на первой полке книг в {factor} раза меньше, чем на второй.",
            f"2) Если на второй полке {second} книг, а на первой в {factor} раза меньше, то на первой полке было {second} : {factor} = {first} {_user_patch_books_word_20260411b(first)}.",
            f"Ответ: на первой полке было {first} {_user_patch_books_word_20260411b(first)}.",
            "Совет: если сказано «в несколько раз больше» в косвенной форме, сначала переведи это в «в несколько раз меньше».",
        )
    return None

__OAI_20260411_USER_PREV_BUILD_LOCAL_SAFE = build_explanation_local_first



# --- OAI FINAL CLEAN PATCH 2026-04-11C: formatting cleanup, stable compare answers, textbook polish ---

_OAI_20260411C_PREV_DETAILED_FORMAT_SOLUTION = _detailed_format_solution



def _oai_20260411c_expression_body_lines(body_lines: List[str]) -> List[str]:
    cleaned: List[str] = []
    seen = set()
    for raw in body_lines:
        line = str(raw or "").strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("частное:"):
            continue
        if lower.startswith("пример:"):
            continue
        key = lower.rstrip(". ")
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(line)
    return cleaned

def _oai_20260411c_pretty_expr_with_map(source: str) -> Tuple[str, dict]:
    pretty_parts: List[str] = []
    op_map = {}
    current_len = 0
    for index, ch in enumerate(source):
        if ch in "+-*/":
            symbol = "×" if ch == "*" else ":" if ch == "/" else ch
            token = f" {symbol} "
            pretty_parts.append(token)
            op_map[index] = current_len + 1
            current_len += len(token)
        else:
            pretty_parts.append(ch)
            current_len += 1
    return "".join(pretty_parts), op_map

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")

    node = parse_expression_ast(source)
    if node is not None:
        pretty_expression = render_node(node)
    else:
        pretty_expression, _ = _oai_20260411c_pretty_expr_with_map(source)

    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = _oai_20260411c_expression_body_lines(parts["body"])
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]

    if _detailed_is_column_like(body_lines) or any("столбик" in line.lower() for line in body_lines):
        lines.append("Решение.")
        before_expl: List[str] = []
        expl: List[str] = []
        in_expl = False
        for line in body_lines:
            low = line.lower()
            if low.startswith("пояснение"):
                in_expl = True
                continue
            if not in_expl:
                before_expl.append(line)
            else:
                expl.append(line)
        if before_expl:
            lines.extend(before_expl)
        if expl:
            lines.append("Пояснение по шагам:")
            lines.extend(_detailed_number_lines(expl))
        else:
            remaining = [line for line in body_lines if not line.lower().startswith("запись столбиком")]
            lines.extend(_detailed_number_lines(remaining))
    else:
        order_block = _detailed_build_order_block(source)
        if order_block:
            lines.extend(order_block)
            lines.append("Решение по действиям:")
        else:
            lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))

    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if kind == "expression" and to_expression_source(raw_text):
        return _detailed_format_expression_solution(raw_text, text)
    return _OAI_20260411C_PREV_DETAILED_FORMAT_SOLUTION(raw_text, text, kind)

# --- OAI FINAL CLEAN PATCH 2026-04-11D: preferred routing for price tasks and cleaner column formatting ---


def _oai_20260411d_is_visual_column_line(line: str) -> bool:
    value = str(line or "").strip()
    if not value:
        return False
    if re.search(r"[А-Яа-яЁё]", value):
        return False
    return True

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")

    node = parse_expression_ast(source)
    if node is not None:
        pretty_expression = render_node(node)
    else:
        pretty_expression, _ = _oai_20260411c_pretty_expr_with_map(source)

    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = _oai_20260411c_expression_body_lines(parts["body"])
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]

    if body_lines and body_lines[0].lower().startswith("запись столбиком"):
        lines.append("Решение.")
        lines.append("Запись столбиком:")
        visual_lines: List[str] = []
        idx = 1
        while idx < len(body_lines):
            current = body_lines[idx]
            lower = current.lower()
            if lower.startswith("частное:"):
                idx += 1
                continue
            if _oai_20260411d_is_visual_column_line(current):
                visual_lines.append(current)
                idx += 1
                continue
            break
        lines.extend(visual_lines)
        expl_lines = [line for line in body_lines[idx:] if not line.lower().startswith("частное:")]
        if expl_lines:
            lines.append("Пояснение по шагам:")
            lines.extend(_detailed_number_lines(expl_lines))
    elif _detailed_is_column_like(body_lines) or any("столбик" in line.lower() for line in body_lines):
        lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))
    else:
        order_block = _detailed_build_order_block(source)
        if order_block:
            lines.extend(order_block)
            lines.append("Решение по действиям:")
        else:
            lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))

    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def try_oai_20260411d_price_difference_first(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    return None



# --- FINAL USER PATCH 2026-04-11ZZ: fuller counted answers + mixed-unit same-time motion + cleaner fraction-whole wording ---

QUESTION_NOUN_FORMS.update({
    "детей": ("ребёнок", "ребёнка", "детей"),
    "ребенок": ("ребёнок", "ребёнка", "детей"),
    "ребёнок": ("ребёнок", "ребёнка", "детей"),
    "человек": ("человек", "человека", "человек"),
    "червячок": ("червячок", "червячка", "червячков"),
    "червячка": ("червячок", "червячка", "червячков"),
    "червячков": ("червячок", "червячка", "червячков"),
    "ручка": ("ручка", "ручки", "ручек"),
    "ручки": ("ручка", "ручки", "ручек"),
    "ручек": ("ручка", "ручки", "ручек"),
    "тетрадь": ("тетрадь", "тетради", "тетрадей"),
    "тетради": ("тетрадь", "тетради", "тетрадей"),
    "тетрадей": ("тетрадь", "тетради", "тетрадей"),
    "булочка": ("булочка", "булочки", "булочек"),
    "булочки": ("булочка", "булочки", "булочек"),
    "булочек": ("булочка", "булочки", "булочек"),
    "птица": ("птица", "птицы", "птиц"),
    "птицы": ("птица", "птицы", "птиц"),
    "птиц": ("птица", "птицы", "птиц"),
    "корзина": ("корзина", "корзины", "корзин"),
    "корзины": ("корзина", "корзины", "корзин"),
    "корзин": ("корзина", "корзины", "корзин"),
    "клетка": ("клетка", "клетки", "клеток"),
    "клетки": ("клетка", "клетки", "клеток"),
    "клеток": ("клетка", "клетки", "клеток"),
    "ягода": ("ягода", "ягоды", "ягод"),
    "ягоды": ("ягода", "ягоды", "ягод"),
    "ягод": ("ягода", "ягоды", "ягод"),
    "гриб": ("гриб", "гриба", "грибов"),
    "гриба": ("гриб", "гриба", "грибов"),
    "грибов": ("гриб", "гриба", "грибов"),
    "орешек": ("орешек", "орешка", "орешков"),
    "орешка": ("орешек", "орешка", "орешков"),
    "орешков": ("орешек", "орешка", "орешков"),
    "марка": ("марка", "марки", "марок"),
    "марки": ("марка", "марки", "марок"),
    "марок": ("марка", "марки", "марок"),
    "ложка": ("ложка", "ложки", "ложек"),
    "ложки": ("ложка", "ложки", "ложек"),
    "ложек": ("ложка", "ложки", "ложек"),
    "ириска": ("ириска", "ириски", "ирисок"),
    "ириски": ("ириска", "ириски", "ирисок"),
    "ирисок": ("ириска", "ириски", "ирисок"),
    "карамелька": ("карамелька", "карамельки", "карамелек"),
    "карамельки": ("карамелька", "карамельки", "карамелек"),
    "карамелек": ("карамелька", "карамельки", "карамелек"),
    "лимон": ("лимон", "лимона", "лимонов"),
    "лимона": ("лимон", "лимона", "лимонов"),
    "лимонов": ("лимон", "лимона", "лимонов"),
    "сетка": ("сетка", "сетки", "сеток"),
    "сетки": ("сетка", "сетки", "сеток"),
    "сеток": ("сетка", "сетки", "сеток"),
    "ведро": ("ведро", "ведра", "ведер"),
    "ведра": ("ведро", "ведра", "ведер"),
    "вёдер": ("ведро", "ведра", "ведер"),
    "ведер": ("ведро", "ведра", "ведер"),
    "пассажир": ("пассажир", "пассажира", "пассажиров"),
    "пассажира": ("пассажир", "пассажира", "пассажиров"),
    "пассажиров": ("пассажир", "пассажира", "пассажиров"),
})



_FINAL_PATCH_DISTANCE_TO_BASE_ZZ = {
    "мм": 1,
    "см": 10,
    "дм": 100,
    "м": 1000,
    "км": 1000000,
}

def _final_patch_normalize_time_unit_zz(unit: str) -> str:
    value = str(unit or "").strip().lower().replace("ё", "е")
    if value in {"ч", "час", "часа", "часов"}:
        return "ч"
    if value in {"мин", "минута", "минуты", "минут"}:
        return "мин"
    if value in {"с", "сек", "секунда", "секунды", "секунд"}:
        return "с"
    return value

def _final_patch_split_speed_unit_zz(speed_unit: str) -> Optional[Tuple[str, str]]:
    value = str(speed_unit or "").strip().lower()
    if "/" not in value:
        return None
    dist_unit, time_unit = value.split("/", 1)
    dist_unit = dist_unit.strip()
    time_unit = _final_patch_normalize_time_unit_zz(time_unit)
    if dist_unit not in _FINAL_PATCH_DISTANCE_TO_BASE_ZZ or time_unit not in {"ч", "мин", "с"}:
        return None
    return dist_unit, time_unit

def _final_patch_parse_same_time_motion_zz(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")

    if not ("за это же время" in lower or "за то же время" in lower):
        return None
    if not contains_any_fragment(lower, ("с какой скоростью", "какова скорость")):
        return None

    unit_group = r"(?:км|м|дм|см|мм)"
    speed_group = r"(?:км|м|дм|см|мм)/(?:ч|мин|с)"

    first_match = re.search(
        rf"(\d+)\s*({unit_group})\b[^.?!]{{0,100}}?со\s+скорост(?:ью|и)\s*(\d+)\s*({speed_group})",
        lower,
    )
    if not first_match:
        first_match = re.search(
            rf"со\s+скорост(?:ью|и)\s*(\d+)\s*({speed_group})[^.?!]{{0,100}}?(\d+)\s*({unit_group})\b",
            lower,
        )
        if first_match:
            speed_value = int(first_match.group(1))
            speed_unit = first_match.group(2)
            first_distance_value = int(first_match.group(3))
            first_distance_unit = first_match.group(4)
        else:
            return None
    else:
        first_distance_value = int(first_match.group(1))
        first_distance_unit = first_match.group(2)
        speed_value = int(first_match.group(3))
        speed_unit = first_match.group(4)

    second_match = re.search(
        rf"(?:за это же время|за то же время)[^.?!]{{0,120}}?(\d+)\s*({unit_group})\b",
        lower,
    )
    if not second_match:
        return None

    second_distance_value = int(second_match.group(1))
    second_distance_unit = second_match.group(2)

    split_speed = _final_patch_split_speed_unit_zz(speed_unit)
    if not split_speed:
        return None
    speed_distance_unit, time_unit = split_speed

    first_distance_base = first_distance_value * _FINAL_PATCH_DISTANCE_TO_BASE_ZZ[first_distance_unit]
    speed_distance_base = _FINAL_PATCH_DISTANCE_TO_BASE_ZZ[speed_distance_unit]
    if first_distance_base % speed_distance_base != 0:
        return None

    first_distance_in_speed_units = first_distance_base // speed_distance_base
    if speed_value == 0 or first_distance_in_speed_units % speed_value != 0:
        return None

    same_time = first_distance_in_speed_units // speed_value
    if same_time == 0 or second_distance_value % same_time != 0:
        return None

    second_speed = second_distance_value // same_time
    answer_unit = f"{second_distance_unit}/{time_unit}"

    return join_explanation_lines(
        f"1) Если первый участник прошёл {first_distance_in_speed_units} {speed_distance_unit} со скоростью {speed_value} {speed_unit}, то он был в пути {first_distance_in_speed_units} : {speed_value} = {same_time} {time_unit}",
        f"2) Если второй участник прошёл {second_distance_value} {second_distance_unit} за {same_time} {time_unit}, то его скорость равна {second_distance_value} : {same_time} = {second_speed} {answer_unit}",
        f"Ответ: скорость второго участника равна {second_speed} {answer_unit}",
        "Совет: если время у двух участников одинаковое, сначала найди это время, потом скорость второго участника",
    )




# --- FINAL USER PATCH 2026-04-11ZX: cleaner special case for fraction of money left after spending ---

def _final_patch_fraction_money_whole_zz(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace("ё", "е")

    if not contains_any_fragment(lower, ("израсходовал", "израсходовала", "израсходовали")):
        return None
    if "остал" not in lower or "руб" not in lower:
        return None

    frac_match = re.search(r"(\d+)\s*/\s*(\d+)", lower)
    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)\s*руб", lower)
    if not frac_match or not remain_match:
        return None

    spent_numerator = int(frac_match.group(1))
    denominator = int(frac_match.group(2))
    remaining_value = int(remain_match.group(1))
    remaining_numerator = denominator - spent_numerator
    if denominator == 0 or remaining_numerator <= 0:
        return None

    if remaining_numerator == 1:
        whole = remaining_value * denominator
        return join_explanation_lines(
            f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось 1/{denominator} всех денег",
            f"2) Если 1/{denominator} всех денег равна {remaining_value} руб., то все деньги равны {remaining_value} × {denominator} = {whole} руб.",
            f"Ответ: всего было {whole} руб.",
            "Совет: если известна одна доля, всё число находят умножением значения доли на число долей",
        )

    if remaining_value % remaining_numerator != 0:
        return None

    one_share = remaining_value // remaining_numerator
    whole = one_share * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value} руб., то 1/{denominator} всех денег равна {remaining_value} : {remaining_numerator} = {one_share} руб.",
        f"3) Если 1/{denominator} всех денег равна {one_share} руб., то все деньги равны {one_share} × {denominator} = {whole} руб.",
        f"Ответ: всего было {whole} руб.",
        "Совет: если известна оставшаяся часть, сначала находят одну долю, потом всё число",
    )



# --- OPENAI FINAL CONSOLIDATION PATCH 2026-04-11B: textbook priority, named purchase tasks, stable final prompt ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...
6. Если пример удобнее решать в столбик, сохрани запись столбиком и подробное пояснение по шагам.
7. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом перепиши само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. Для школьного стиля по возможности используй форму:
Если ..., то ...
6. После каждого действия коротко говори, что нашли.
7. Если в задаче несколько вопросов, отвечай на все вопросы по порядку.
8. В конце обязательно пиши:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если это именованные величины, сначала переведи их в одинаковые единицы.

Важные требования:
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Для многодейственных задач не перескакивай сразу к ответу.
Сначала действие, потом пояснение, потом следующее действие.
""".strip()

def _openai_final_20260411b_named_sum_of_two_products_money_explanation(raw_text: str) -> Optional[str]:
    try:
        direct = try_patch_named_sum_of_two_products_money_explanation(raw_text)
        if direct:
            return direct
    except Exception:
        pass

    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in lower:
        return None
    if not (contains_any_fragment(lower, ("заплат", "стоим", "стоил", "стоит")) or contains_any_fragment(question, ("сколько денег", "сколько заплат", "сколько стоила", "сколько стоит"))):
        return None

    products = _po_product_matches(raw_text)
    if len(products) < 2:
        return None
    if contains_any_fragment(question, ("сколько стоит 1", "сколько стоила 1", "сколько стоила одна", "сколько стоит одна")):
        return None

    first = products[0]
    second = products[1]
    first_total = first["count"] * first["value"]
    second_total = second["count"] * second["value"]
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если купили {first['count']} {first['name']} по {first['value']} руб., то за {first['name']} заплатили {first['count']} × {first['value']} = {first_total} руб",
        f"2) Если купили {second['count']} {second['name']} по {second['value']} руб., то за {second['name']} заплатили {second['count']} × {second['value']} = {second_total} руб",
        f"3) Если за {first['name']} заплатили {first_total} руб., а за {second['name']} {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: за всю покупку заплатили {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
    )

def _openai_final_20260411b_unknown_price_with_names_explanation(raw_text: str) -> Optional[str]:
    try:
        direct = try_high_priority_unknown_price_word_problem_explanation(raw_text)
        if direct:
            return direct
    except Exception:
        return None
    return None




# --- USER FINAL PATCH 2026-04-11ZZ: preserve architecture, stabilize final output ---

_USER_FINAL_PATCH_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION = _detailed_format_expression_solution

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом, сохраняя скобки и исходную запись.
2. Если действий несколько, обязательно пиши строку «Порядок действий:» и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши «Решение по действиям:» и ниже все вычисления по действиям: 1), 2), 3)...
4. Если пример удобнее решать в столбик, сохраняй запись столбиком и подробное пояснение по шагам.
5. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.
6. В конце пиши строку «Ответ: ...».

Для текстовых задач:
1. Сначала пиши «Задача.» и переписывай условие без изменения чисел.
2. Потом пиши «Решение.»
3. Затем обязательно пиши «Что известно: ...» и «Что нужно найти: ...».
4. Если сразу нельзя ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера: 1), 2), 3)...
7. Для школьного стиля по возможности используй форму «Если..., то ...».
8. После каждого действия коротко говори, что нашли.
9. Если в задаче несколько вопросов, ответь на все вопросы по порядку.
10. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку «Уравнение: ...».
2. Потом «Решение.»
3. Решай по шагам.
4. Обязательно пиши «Проверка: ...».
5. Потом «Ответ: ...».

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи дроби к общему знаменателю.
4. Если задача дана с величинами, сначала переведи величины в удобные одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.
5. В ответе обязательно пиши единицы измерения.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Сохраняй вычисления в столбик и подробные пояснения.
Для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

def _user_final_patch_pretty_expression_from_source(source: str) -> str:
    text = str(source or "")
    text = text.replace("*", "×").replace("/", ":")
    text = re.sub(r"([()+\-×:])", r" \1 ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = text.replace("( ", "(").replace(" )", ")")
    return text

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    source = to_expression_source(raw_text)
    if not source:
        return _USER_FINAL_PATCH_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

    formatted = _USER_FINAL_PATCH_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)
    lines = [line for line in str(formatted or "").split("\n")]
    if not lines:
        return formatted

    answer = ""
    match = re.match(r"^Пример:\s*.*?=\s*(.+)$", lines[0].strip())
    if match:
        answer = match.group(1).strip().rstrip(".")
    if not answer:
        answer = _detailed_expression_answer(source) or "проверь запись"

    lines[0] = f"Пример: {_user_final_patch_pretty_expression_from_source(source)} = {answer}"
    return _detailed_finalize_text(lines)

def explain_long_division(dividend: int, divisor: int) -> str:
    if divisor == 0:
        return join_explanation_lines(
            "На ноль делить нельзя",
            "Ответ: деление на ноль невозможно",
            "Совет: сначала смотри на делитель",
        )

    quotient, remainder = divmod(dividend, divisor)
    digits = list(str(dividend))
    lines: List[str] = [
        "Пишем деление столбиком",
        "Находим первое неполное делимое",
    ]

    current = 0
    started = False

    for index, digit_char in enumerate(digits):
        current = current * 10 + int(digit_char)

        if not started and current < divisor:
            continue

        if not started:
            started = True
            lines.append(f"Первое неполное делимое — {current}")

        if current < divisor:
            if index < len(digits) - 1:
                lines.append(f"Число {current} меньше {divisor}, поэтому в частном пишем 0 и сносим следующую цифру")
            else:
                lines.append(f"Число {current} меньше {divisor}, поэтому в частном пишем 0. Деление закончено")
            continue

        q_digit = current // divisor
        product = q_digit * divisor
        remainder_here = current - product
        next_try = (q_digit + 1) * divisor

        if index < len(digits) - 1:
            next_number = remainder_here * 10 + int(digits[index + 1])
            lines.append(
                f"Подбираем {q_digit}, потому что {q_digit} × {divisor} = {product}, а {q_digit + 1} × {divisor} = {next_try}, это уже больше. Вычитаем: {current} - {product} = {remainder_here}. Сносим следующую цифру и получаем {next_number}"
            )
        else:
            if remainder_here == 0:
                lines.append(
                    f"Подбираем {q_digit}, потому что {q_digit} × {divisor} = {product}, а {q_digit + 1} × {divisor} = {next_try}, это уже больше. Вычитаем: {current} - {product} = 0. Деление закончено"
                )
            else:
                lines.append(
                    f"Подбираем {q_digit}, потому что {q_digit} × {divisor} = {product}, а {q_digit + 1} × {divisor} = {next_try}, это уже больше. Вычитаем: {current} - {product} = {remainder_here}. Это остаток"
                )

        current = remainder_here

    if not started:
        lines.append(f"{dividend} меньше {divisor}, значит в частном будет 0")
        if remainder:
            lines.append(f"Остаток равен {remainder}")
            return join_explanation_lines(*lines, f"Ответ: 0, остаток {remainder}", "Совет: остаток всегда должен быть меньше делителя")
        return join_explanation_lines(*lines, "Ответ: 0", "Совет: если делимое меньше делителя, частное равно нулю")

    if remainder == 0:
        lines.append(f"Читаем ответ: частное равно {quotient}")
        return join_explanation_lines(*lines, f"Ответ: {quotient}", "Совет: в столбике повторяй шаги: взял, подобрал, умножил, вычел, снес цифру")

    lines.append(f"Читаем ответ: частное равно {quotient}, остаток {remainder}")
    return join_explanation_lines(*lines, f"Ответ: {quotient}, остаток {remainder}", "Совет: остаток всегда должен быть меньше делителя")
