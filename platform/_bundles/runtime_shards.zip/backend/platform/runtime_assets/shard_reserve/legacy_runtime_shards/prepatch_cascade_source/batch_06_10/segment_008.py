"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 6106-6977."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
# --- OPENAI CONSOLIDATION PATCH 2026-04-11Z: restore textbook cases lost in late patch chain ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. По возможности используй школьную форму:
Если ..., то ...
8. После каждого действия коротко говори, что нашли.
9. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Если задача дана с именованными величинами, сначала переведи их в удобные одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Сохраняй вычисления в столбик и пояснения.
Если в вычислении больше двух двузначных чисел или есть хотя бы одно трёхзначное число, можно показывать вычисление в столбик.
Для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

_CONSOLIDATION_PREV_BUILD_EXPLANATION_LOCAL_FIRST_Z = build_explanation_local_first

_CONSOLIDATION_EXTRA_QUESTION_NOUN_FORMS_Z = {
    "тюльпанов": ("тюльпан", "тюльпана", "тюльпанов"),
    "километров": ("километр", "километра", "километров"),
    "метров": ("метр", "метра", "метров"),
    "сантиметров": ("сантиметр", "сантиметра", "сантиметров"),
    "дециметров": ("дециметр", "дециметра", "дециметров"),
    "миллиметров": ("миллиметр", "миллиметра", "миллиметров"),
    "килограммов": ("килограмм", "килограмма", "килограммов"),
    "граммов": ("грамм", "грамма", "граммов"),
    "литров": ("литр", "литра", "литров"),
    "рублей": ("рубль", "рубля", "рублей"),
    "руб": ("рубль", "рубля", "рублей"),
    "часов": ("час", "часа", "часов"),
    "минут": ("минута", "минуты", "минут"),
    "тетрадей": ("тетрадь", "тетради", "тетрадей"),
    "ручек": ("ручка", "ручки", "ручек"),
    "машин": ("машина", "машины", "машин"),
    "страниц": ("страница", "страницы", "страниц"),
    "цветов": ("цветок", "цветка", "цветов"),
    "яблок": ("яблоко", "яблока", "яблок"),
    "груш": ("груша", "груши", "груш"),
    "булочек": ("булочка", "булочки", "булочек"),
    "кг": ("килограмм", "килограмма", "килограммов"),
    "л": ("литр", "литра", "литров"),
}

def _consolidation_normalize_noun_key_z(noun: str) -> str:
    return str(noun or "").strip().lower().replace("ё", "е")

def _consolidation_lookup_forms_z(noun: str) -> Optional[Tuple[str, str, str]]:
    key = _consolidation_normalize_noun_key_z(noun)
    if not key:
        return None
    forms = None
    try:
        forms = _lookup_question_noun_forms(key)
    except Exception:
        forms = None
    if forms:
        return forms
    return _CONSOLIDATION_EXTRA_QUESTION_NOUN_FORMS_Z.get(key)

def _consolidation_phrase_with_noun_z(count_value: int, noun: str) -> str:
    forms = _consolidation_lookup_forms_z(noun)
    if forms:
        return f"{count_value} {_select_plural_by_count(int(count_value), forms)}"
    return str(count_value)

def _consolidation_capitalize_z(text: str) -> str:
    value = str(text or "").strip()
    if not value:
        return value
    return value[:1].upper() + value[1:]

def _consolidation_split_question_parts_z(raw_text: str) -> List[str]:
    try:
        _, question = extract_condition_and_question(raw_text)
    except Exception:
        question = str(raw_text or "")
    return [part.strip() for part in re.split(r"\?", question) if part.strip()]

def _consolidation_answer_from_first_question_z(question_text: str, value: int, noun_hint: str = "") -> str:
    q = str(question_text or "").strip().rstrip("?.!").lower().replace("ё", "е")

    match = re.match(
        r"сколько\s+([а-яё]+)\s+(было|стало|будет|осталось|останется|получилось|оказалось|росло|лежало|ехало|шло|стоит|стоило|нужно|надо)\s+(.+)$",
        q,
    )
    if match:
        noun, verb, tail = match.groups()
        return f"{_consolidation_capitalize_z(tail)} {verb} {_consolidation_phrase_with_noun_z(value, noun)}"

    match = re.match(r"сколько\s+([а-яё]+)\s+(.+)$", q)
    if match:
        noun, tail = match.groups()
        first_word = tail.split()[0] if tail.split() else ""
        if first_word in {"в", "во", "на", "у", "из", "до", "после", "под", "над", "около"}:
            return f"{_consolidation_capitalize_z(tail)} было {_consolidation_phrase_with_noun_z(value, noun)}"
        return f"{_consolidation_capitalize_z(tail)} — {_consolidation_phrase_with_noun_z(value, noun)}"

    return _consolidation_phrase_with_noun_z(value, noun_hint)

def _consolidation_answer_from_compare_question_z(question_text: str, value: int, noun_hint: str = "") -> str:
    q = str(question_text or "").strip().rstrip("?.!").lower().replace("ё", "е")

    match = re.match(r"на\s+сколько\s+([а-яё]+)\s+(.+?)\s+(больше|меньше)(?:,?\s+чем\s+.+)?$", q)
    if match:
        noun, tail, mode = match.groups()
        return f"{_consolidation_capitalize_z(tail)} на {_consolidation_phrase_with_noun_z(value, noun)} {mode}"

    match = re.match(r"во\s+сколько\s+раз\s+([а-яё]+)\s+(.+?)\s+(больше|меньше)(?:,?\s+чем\s+.+)?$", q)
    if match:
        _, tail, mode = match.groups()
        return f"{_consolidation_capitalize_z(tail)} в {value} {plural_form(int(value), 'раз', 'раза', 'раз')} {mode}"

    if q.startswith("на сколько"):
        return f"Разность равна {_consolidation_phrase_with_noun_z(value, noun_hint)}"
    if q.startswith("во сколько"):
        return f"Отношение равно {value} {plural_form(int(value), 'раз', 'раза', 'раз')}"

    return _consolidation_phrase_with_noun_z(value, noun_hint)

def try_consolidation_direct_relation_multianswer_explanation_z(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if not has_multiple_questions(raw_text):
        return None
    if "на сколько" not in question and "во сколько" not in question:
        return None

    if re.search(r"\b(?:это|что|он|она)\b[^?.!]{0,40}(?:на\s+\d+|в\s+\d+\s+раз(?:а)?)", lower):
        return None

    numbers = extract_ordered_numbers(lower)
    if len(numbers) != 2:
        return None

    question_parts = _consolidation_split_question_parts_z(raw_text)
    first_question = question_parts[0] if question_parts else ""
    second_question = question_parts[1] if len(question_parts) > 1 else ""
    noun_hint = ""
    try:
        noun_hint = _extract_count_question_noun(raw_text) or _extract_question_noun(raw_text)
    except Exception:
        noun_hint = ""

    relation_pairs = extract_relation_pairs(lower)
    if len(relation_pairs) == 1:
        base = numbers[0]
        delta, mode = relation_pairs[0]
        if numbers[1] != delta:
            return None
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None

        first_answer = _consolidation_answer_from_first_question_z(first_question, related, noun_hint)

        if "на сколько" in question:
            diff = abs(base - related)
            second_answer = _consolidation_answer_from_compare_question_z(second_question, diff, noun_hint)
            return join_explanation_lines(
                f"1) Если первое количество равно {base}, а второе на {delta} {mode}, то второе количество равно {base} {'+' if mode == 'больше' else '-'} {delta} = {related}",
                f"2) Если первое количество равно {base}, а второе равно {related}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
                f"Ответ: {first_answer}; {second_answer}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )

        smaller = min(base, related)
        bigger = max(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        second_answer = _consolidation_answer_from_compare_question_z(second_question, ratio, noun_hint)
        return join_explanation_lines(
            f"1) Если первое количество равно {base}, а второе на {delta} {mode}, то второе количество равно {base} {'+' if mode == 'больше' else '-'} {delta} = {related}",
            f"2) Если первое количество равно {base}, а второе равно {related}, то большее число делим на меньшее: {bigger} : {smaller} = {ratio}",
            f"Ответ: {first_answer}; {second_answer}",
            "Совет: если нужно сначала найти второе число, а потом узнать во сколько раз одно больше другого, выполняй действия по порядку",
        )

    scale_pairs = extract_scale_pairs(lower)
    if len(scale_pairs) == 1:
        base = numbers[0]
        factor, mode = scale_pairs[0]
        if numbers[1] != factor:
            return None
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None

        first_answer = _consolidation_answer_from_first_question_z(first_question, related, noun_hint)

        if "на сколько" in question:
            diff = abs(base - related)
            second_answer = _consolidation_answer_from_compare_question_z(second_question, diff, noun_hint)
            return join_explanation_lines(
                f"1) Если первое количество равно {base}, а второе в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} {mode}, то второе количество равно {base} {'×' if mode == 'больше' else ':'} {factor} = {related}",
                f"2) Если первое количество равно {base}, а второе равно {related}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
                f"Ответ: {first_answer}; {second_answer}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )

        smaller = min(base, related)
        bigger = max(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        ratio = bigger // smaller
        second_answer = _consolidation_answer_from_compare_question_z(second_question, ratio, noun_hint)
        return join_explanation_lines(
            f"1) Если первое количество равно {base}, а второе в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} {mode}, то второе количество равно {base} {'×' if mode == 'больше' else ':'} {factor} = {related}",
            f"2) Если первое количество равно {base}, а второе равно {related}, то большее число делим на меньшее: {bigger} : {smaller} = {ratio}",
            f"Ответ: {first_answer}; {second_answer}",
            "Совет: если сначала нужно найти второе число, а потом узнать во сколько раз одно больше другого, выполняй действия по порядку",
        )

    return None

def try_consolidation_fraction_named_unit_explanation_z(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    fractions = extract_all_fraction_pairs(lower)
    if len(fractions) != 1 or "сколько" not in question:
        return None

    numerator, denominator = fractions[0]
    if denominator == 0:
        return None

    total_value = None
    answer_unit = ""
    lines: List[str] = []
    step_no = 1

    ton_match = re.search(r"\b(\d+)\s*т\b", lower)
    if ton_match:
        tons = int(ton_match.group(1))
        total_value = tons * 1000
        answer_unit = "кг"
        lines.append(f"1) Сначала переводим тонны в килограммы: {tons} т = {total_value} кг")
        step_no = 2
    else:
        for unit in ("кг", "г", "л", "м", "см", "дм", "км"):
            unit_match = re.search(rf"\b(\d+)\s*{re.escape(unit)}\b", lower)
            if unit_match:
                total_value = int(unit_match.group(1))
                answer_unit = unit
                break

    if total_value is None:
        values = extract_non_fraction_numbers(lower)
        if not values:
            return None
        total_value = max(values)

    if total_value % denominator != 0:
        return None

    one_part = total_value // denominator
    part_value = one_part * numerator

    unit_suffix = f" {answer_unit}" if answer_unit else ""
    lines.append(f"{step_no}) Если всё число равно {total_value}{unit_suffix}, то одна доля равна {total_value} : {denominator} = {one_part}{unit_suffix}")
    step_no += 1

    if numerator == 1:
        lines.append(f"{step_no}) Если нужно найти 1/{denominator} числа, то ответ равен {one_part}{unit_suffix}")
    else:
        lines.append(f"{step_no}) Если нужно найти {numerator}/{denominator} числа, то берём {numerator} такие доли: {one_part} × {numerator} = {part_value}{unit_suffix}")

    lines.append(f"Ответ: {part_value}{unit_suffix}")
    lines.append("Совет: если задача с дробью дана в тоннах, метрах или других единицах, сначала переводи величину в удобные одинаковые единицы")
    return join_explanation_lines(*lines)

def try_consolidation_return_trip_faster_explanation_z(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "обратно" not in lower or "быстр" not in lower or "сколько" not in question:
        return None

    factor_match = re.search(r"в\s+(\d+)\s+раз(?:а)?\s+быстр", lower)
    if not factor_match:
        return None
    factor = int(factor_match.group(1))
    if factor <= 0:
        return None

    distance_match = re.search(r"\b(\d+)\s*(км|м)\b", lower)
    speed_match = re.search(r"скорост[ьяию][^\d]{0,20}(\d+)\s*(км/ч|м/с|м/мин)?", lower)
    if not distance_match or not speed_match:
        return None

    distance_value = int(distance_match.group(1))
    distance_unit = distance_match.group(2)
    speed_value = int(speed_match.group(1))
    speed_unit = speed_match.group(2) or ("км/ч" if distance_unit == "км" else "")
    if speed_value <= 0 or distance_value % speed_value != 0:
        return None

    one_way_time = distance_value // speed_value
    time_unit = "ч" if "/ч" in speed_unit or "час" in question else "мин" if "/мин" in speed_unit or "мин" in question else ""

    if one_way_time % factor == 0:
        return_time = one_way_time // factor
        return join_explanation_lines(
            f"1) Если путь до пункта равен {distance_value} {distance_unit}, а скорость была {speed_value} {speed_unit}, то время в одну сторону равно {distance_value} : {speed_value} = {one_way_time}{(' ' + time_unit) if time_unit else ''}",
            f"2) Если обратно ехали в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} быстрее, то время в обратную сторону в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} меньше: {one_way_time} : {factor} = {return_time}{(' ' + time_unit) if time_unit else ''}",
            f"Ответ: {return_time}{(' ' + time_unit) if time_unit else ''}",
            "Совет: если скорость на том же пути увеличилась в несколько раз, то время уменьшается во столько же раз",
        )

    faster_speed = speed_value * factor
    if distance_value % faster_speed != 0:
        return None
    return_time = distance_value // faster_speed

    return join_explanation_lines(
        f"1) Если скорость на обратном пути в {factor} {plural_form(int(factor), 'раз', 'раза', 'раз')} больше, то новая скорость равна {speed_value} × {factor} = {faster_speed}{(' ' + speed_unit) if speed_unit else ''}",
        f"2) Если расстояние равно {distance_value} {distance_unit}, а новая скорость равна {faster_speed}{(' ' + speed_unit) if speed_unit else ''}, то время обратно равно {distance_value} : {faster_speed} = {return_time}{(' ' + time_unit) if time_unit else ''}",
        f"Ответ: {return_time}{(' ' + time_unit) if time_unit else ''}",
        "Совет: для одного и того же пути время находят делением расстояния на скорость",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_consolidation_direct_relation_multianswer_explanation_z(user_text)
        or try_consolidation_fraction_named_unit_explanation_z(user_text)
        or try_consolidation_return_trip_faster_explanation_z(user_text)
        or _CONSOLIDATION_PREV_BUILD_EXPLANATION_LOCAL_FIRST_Z(user_text, kind)
    )

# --- OPENAI HOTFIX 2026-04-11ZA: narrow named-unit fraction patch to real conversion cases ---

def try_consolidation_fraction_named_unit_explanation_z(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    fractions = extract_all_fraction_pairs(lower)
    if len(fractions) != 1 or "сколько" not in question:
        return None

    # Этот локальный обработчик нужен именно для задач, где требуется перевод единиц,
    # в первую очередь для тонн -> килограммы. Остальные дробные текстовые задачи
    # лучше оставлять более ранним специализированным объяснителям.
    ton_match = re.search(r"\b(\d+)\s*т\b", lower)
    if not ton_match:
        return None

    numerator, denominator = fractions[0]
    if denominator == 0:
        return None

    tons = int(ton_match.group(1))
    total_value = tons * 1000
    if total_value % denominator != 0:
        return None

    one_part = total_value // denominator
    part_value = one_part * numerator

    return join_explanation_lines(
        f"1) Сначала переводим тонны в килограммы: {tons} т = {total_value} кг",
        f"2) Если всё число равно {total_value} кг, то одна доля равна {total_value} : {denominator} = {one_part} кг",
        f"3) Если нужно найти {numerator}/{denominator} числа, то берём {numerator} такие доли: {one_part} × {numerator} = {part_value} кг",
        f"Ответ: {part_value} кг",
        "Совет: если задача с дробью дана в тоннах, сначала переведи тонны в килограммы",
    )

# --- CONSOLIDATION PATCH 2026-04-11AA: named measurement expressions from textbook ---

_PREV_20260411AA_INFER_TASK_KIND = infer_task_kind
_PREV_20260411AA_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first
_PREV_20260411AA_DETAILED_FORMAT_SOLUTION = _detailed_format_solution

_MEASURE_BASE_UNITS_20260411AA = {
    "length": [("км", 1_000_000), ("м", 1_000), ("дм", 100), ("см", 10), ("мм", 1)],
    "mass": [("т", 1_000_000), ("ц", 100_000), ("кг", 1_000), ("г", 1)],
    "time": [("ч", 3_600), ("мин", 60), ("с", 1)],
    "volume": [("л", 1_000), ("мл", 1)],
}

_MEASURE_UNIT_ALIASES_20260411AA = {
    "км": "км",
    "м": "м",
    "дм": "дм",
    "см": "см",
    "мм": "мм",
    "т": "т",
    "ц": "ц",
    "кг": "кг",
    "г": "г",
    "ч": "ч",
    "час": "ч",
    "часа": "ч",
    "часов": "ч",
    "мин": "мин",
    "минута": "мин",
    "минуты": "мин",
    "минут": "мин",
    "с": "с",
    "сек": "с",
    "секунда": "с",
    "секунды": "с",
    "секунд": "с",
    "л": "л",
    "мл": "мл",
}

_MEASURE_UNIT_PATTERN_20260411AA = "|".join(
    sorted((re.escape(unit) for unit in _MEASURE_UNIT_ALIASES_20260411AA), key=len, reverse=True)
)
_MEASURE_TOKEN_RE_20260411AA = re.compile(rf"(\d+)\s*({_MEASURE_UNIT_PATTERN_20260411AA})\b", re.IGNORECASE)

def _measure_canon_20260411AA(unit_text: str) -> str:
    return _MEASURE_UNIT_ALIASES_20260411AA.get(str(unit_text or "").strip().lower().replace("ё", "е"), "")

def _measure_family_20260411AA(unit_text: str) -> str:
    unit = _measure_canon_20260411AA(unit_text)
    for family, items in _MEASURE_BASE_UNITS_20260411AA.items():
        if any(name == unit for name, _ in items):
            return family
    return ""

def _measure_factor_20260411AA(family: str, unit_text: str) -> int:
    unit = _measure_canon_20260411AA(unit_text)
    for name, factor in _MEASURE_BASE_UNITS_20260411AA.get(family, []):
        if name == unit:
            return factor
    raise KeyError(unit)

def _measure_parse_value_20260411AA(text: str) -> Optional[dict]:
    raw = re.sub(r"\s+", " ", str(text or "").strip().lower().replace("ё", "е"))
    if not raw:
        return None
    matches = list(_MEASURE_TOKEN_RE_20260411AA.finditer(raw))
    if not matches:
        return None

    rebuilt_parts = []
    family = ""
    total = 0
    units_used = []
    normalized_tokens = []
    for match in matches:
        value = int(match.group(1))
        unit = _measure_canon_20260411AA(match.group(2))
        token_family = _measure_family_20260411AA(unit)
        if not token_family:
            return None
        if family and family != token_family:
            return None
        family = token_family
        rebuilt_parts.append(f"{value} {unit}")
        factor = _measure_factor_20260411AA(family, unit)
        total += value * factor
        if unit not in units_used:
            units_used.append(unit)
        normalized_tokens.append((value, unit))

    normalized = " ".join(rebuilt_parts)
    if re.sub(r"\s+", " ", normalized) != raw:
        return None

    preferred_units = sorted(units_used, key=lambda u: _measure_factor_20260411AA(family, u), reverse=True)
    return {
        "text": normalized,
        "family": family,
        "total": total,
        "units": preferred_units,
        "tokens": normalized_tokens,
    }

def _measure_format_from_base_20260411AA(total: int, family: str, preferred_units: List[str]) -> str:
    units = [u for u in preferred_units if _measure_family_20260411AA(u) == family]
    if not units:
        units = [name for name, _ in _MEASURE_BASE_UNITS_20260411AA[family]]
    units = sorted(units, key=lambda u: _measure_factor_20260411AA(family, u), reverse=True)

    if len(units) >= 2:
        first, second = units[0], units[1]
        first_factor = _measure_factor_20260411AA(family, first)
        second_factor = _measure_factor_20260411AA(family, second)
        first_value = total // first_factor
        remainder = total % first_factor
        second_value = remainder // second_factor
        parts = []
        if first_value:
            parts.append(f"{first_value} {first}")
        if second_value or not parts:
            parts.append(f"{second_value} {second}")
        return " ".join(parts)

    unit = units[0]
    factor = _measure_factor_20260411AA(family, unit)
    value = total // factor
    return f"{value} {unit}"

def _measure_base_unit_name_20260411AA(family: str) -> str:
    return _MEASURE_BASE_UNITS_20260411AA[family][-1][0]

def _parse_named_measurement_expression_20260411AA(raw_text: str) -> Optional[dict]:
    text = normalize_dashes(str(raw_text or "")).replace("×", " * ").replace(":", " / ").replace("÷", " / ")
    text = re.sub(r"\s+", " ", text).strip().lower().replace("ё", "е")
    if not text:
        return None

    measure_pattern = rf"(?:\d+\s*(?:{_MEASURE_UNIT_PATTERN_20260411AA})(?:\s+\d+\s*(?:{_MEASURE_UNIT_PATTERN_20260411AA}))*)"

    patterns = [
        (re.compile(rf"^({measure_pattern})\s*([+\-])\s*({measure_pattern})$", re.IGNORECASE), "measure_measure"),
        (re.compile(rf"^({measure_pattern})\s*([*/])\s*(\d+)$", re.IGNORECASE), "measure_number"),
        (re.compile(rf"^(\d+)\s*([*])\s*({measure_pattern})$", re.IGNORECASE), "number_measure"),
    ]

    for pattern, mode in patterns:
        match = pattern.fullmatch(text)
        if not match:
            continue
        if mode == "measure_measure":
            left = _measure_parse_value_20260411AA(match.group(1))
            right = _measure_parse_value_20260411AA(match.group(3))
            operator = "+" if match.group(2) == "+" else "-"
            if not left or not right or left["family"] != right["family"]:
                return None
            preferred = sorted(list(dict.fromkeys(left["units"] + right["units"])), key=lambda u: _measure_factor_20260411AA(left["family"], u), reverse=True)
            return {"mode": mode, "left": left, "right": right, "operator": operator, "family": left["family"], "preferred_units": preferred}
        if mode == "measure_number":
            left = _measure_parse_value_20260411AA(match.group(1))
            operator = "×" if match.group(2) == "*" else ":"
            number = int(match.group(3))
            if not left:
                return None
            return {"mode": mode, "left": left, "number": number, "operator": operator, "family": left["family"], "preferred_units": left["units"]}
        if mode == "number_measure":
            number = int(match.group(1))
            right = _measure_parse_value_20260411AA(match.group(3))
            if not right:
                return None
            return {"mode": mode, "left_number": number, "right": right, "number": number, "operator": "×", "family": right["family"], "preferred_units": right["units"]}
    return None

def _pretty_named_measurement_expression_20260411AA(parsed: dict) -> str:
    if parsed["mode"] == "measure_measure":
        return f"{parsed['left']['text']} {parsed['operator']} {parsed['right']['text']}"
    if parsed["mode"] == "measure_number":
        return f"{parsed['left']['text']} {parsed['operator']} {parsed['number']}"
    return f"{parsed['left_number']} × {parsed['right']['text']}"

def _build_named_measurement_expression_explanation_20260411AA(raw_text: str) -> Optional[str]:
    parsed = _parse_named_measurement_expression_20260411AA(raw_text)
    if not parsed:
        return None

    family = parsed["family"]
    base_unit = _measure_base_unit_name_20260411AA(family)
    pretty = _pretty_named_measurement_expression_20260411AA(parsed)

    if parsed["mode"] == "measure_measure":
        left = parsed["left"]
        right = parsed["right"]
        if parsed["operator"] == "-" and left["total"] < right["total"]:
            return None
        result_total = left["total"] + right["total"] if parsed["operator"] == "+" else left["total"] - right["total"]
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        verb = "Складываем" if parsed["operator"] == "+" else "Вычитаем"
        return join_explanation_lines(
            f"Пример: {pretty} = {answer}",
            "Решение.",
            f"1) Переводим первое именованное число в {base_unit}: {left['text']} = {left['total']} {base_unit}",
            f"2) Переводим второе именованное число в {base_unit}: {right['text']} = {right['total']} {base_unit}",
            f"3) {verb}: {left['total']} {'+' if parsed['operator'] == '+' else '-'} {right['total']} = {result_total} {base_unit}",
            f"4) Переводим ответ обратно: {result_total} {base_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при сложении и вычитании именованных чисел сначала переводи их в одинаковые единицы",
        )

    if parsed["mode"] == "measure_number":
        left = parsed["left"]
        number = parsed["number"]
        if parsed["operator"] == ":":
            if number == 0 or left["total"] % number != 0:
                return None
            result_total = left["total"] // number
            action_line = f"2) Делим: {left['total']} : {number} = {result_total} {base_unit}"
        else:
            result_total = left["total"] * number
            action_line = f"2) Умножаем: {left['total']} × {number} = {result_total} {base_unit}"
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        return join_explanation_lines(
            f"Пример: {pretty} = {answer}",
            "Решение.",
            f"1) Переводим составное именованное число в {base_unit}: {left['text']} = {left['total']} {base_unit}",
            action_line,
            f"3) Переводим ответ обратно: {result_total} {base_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при умножении и делении составные именованные числа сначала заменяют простыми, а потом выполняют вычисление",
        )

    right = parsed["right"]
    number = parsed["left_number"]
    result_total = right["total"] * number
    answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
    return join_explanation_lines(
        f"Пример: {pretty} = {answer}",
        "Решение.",
        f"1) Переводим составное именованное число в {base_unit}: {right['text']} = {right['total']} {base_unit}",
        f"2) Умножаем: {number} × {right['total']} = {result_total} {base_unit}",
        f"3) Переводим ответ обратно: {result_total} {base_unit} = {answer}",
        f"Ответ: {answer}",
        "Совет: при умножении составного именованного числа сначала переводи его в простое именованное число",
    )

def infer_task_kind(text: str) -> str:
    if _parse_named_measurement_expression_20260411AA(text):
        return "expression"
    return _PREV_20260411AA_INFER_TASK_KIND(text)

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return _build_named_measurement_expression_explanation_20260411AA(user_text) or _PREV_20260411AA_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)

def _format_named_measurement_expression_solution_20260411AA(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    parsed = _parse_named_measurement_expression_20260411AA(raw_text)
    pretty = _pretty_named_measurement_expression_20260411AA(parsed) if parsed else strip_known_prefix(raw_text)
    answer = parts["answer"] or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("пример:", "решение"))]
    lines: List[str] = [f"Пример: {pretty} = {answer}", "Решение."]
    lines.extend(_detailed_number_lines(body_lines))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or "сначала переводи составное именованное число в простое, потом выполняй вычисление"
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if _parse_named_measurement_expression_20260411AA(raw_text):
        return _format_named_measurement_expression_solution_20260411AA(raw_text, text)
    return _PREV_20260411AA_DETAILED_FORMAT_SOLUTION(raw_text, text, kind)

# --- HOTFIX 2026-04-11AB: use the smallest unit from the expression, not always family base ---

def _measure_conversion_unit_20260411AB(units: List[str], family: str) -> str:
    relevant = [u for u in units if _measure_family_20260411AA(u) == family]
    if not relevant:
        return _measure_base_unit_name_20260411AA(family)
    return min(relevant, key=lambda u: _measure_factor_20260411AA(family, u))

def _build_named_measurement_expression_explanation_20260411AA(raw_text: str) -> Optional[str]:
    parsed = _parse_named_measurement_expression_20260411AA(raw_text)
    if not parsed:
        return None

    family = parsed["family"]
    if parsed["mode"] == "measure_measure":
        left = parsed["left"]
        right = parsed["right"]
        conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
        if parsed["operator"] == "-" and left["total"] < right["total"]:
            return None
        result_total = left["total"] + right["total"] if parsed["operator"] == "+" else left["total"] - right["total"]
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        left_simple = left["total"] // _measure_factor_20260411AA(family, conversion_unit)
        right_simple = right["total"] // _measure_factor_20260411AA(family, conversion_unit)
        result_simple = result_total // _measure_factor_20260411AA(family, conversion_unit)
        verb = "Складываем" if parsed["operator"] == "+" else "Вычитаем"
        return join_explanation_lines(
            f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
            "Решение.",
            f"1) Переводим первое именованное число в {conversion_unit}: {left['text']} = {left_simple} {conversion_unit}",
            f"2) Переводим второе именованное число в {conversion_unit}: {right['text']} = {right_simple} {conversion_unit}",
            f"3) {verb}: {left_simple} {'+' if parsed['operator'] == '+' else '-'} {right_simple} = {result_simple} {conversion_unit}",
            f"4) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при сложении и вычитании именованных чисел сначала переводи их в одинаковые единицы",
        )

    if parsed["mode"] == "measure_number":
        left = parsed["left"]
        number = parsed["number"]
        conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
        left_simple = left["total"] // _measure_factor_20260411AA(family, conversion_unit)
        if parsed["operator"] == ":":
            if number == 0 or left_simple % number != 0:
                return None
            result_simple = left_simple // number
            action_line = f"2) Делим: {left_simple} : {number} = {result_simple} {conversion_unit}"
        else:
            result_simple = left_simple * number
            action_line = f"2) Умножаем: {left_simple} × {number} = {result_simple} {conversion_unit}"
        result_total = result_simple * _measure_factor_20260411AA(family, conversion_unit)
        answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
        return join_explanation_lines(
            f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
            "Решение.",
            f"1) Переводим составное именованное число в {conversion_unit}: {left['text']} = {left_simple} {conversion_unit}",
            action_line,
            f"3) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
            f"Ответ: {answer}",
            "Совет: при умножении и делении составные именованные числа сначала заменяют простыми, а потом выполняют вычисление",
        )

    right = parsed["right"]
    number = parsed["left_number"]
    conversion_unit = _measure_conversion_unit_20260411AB(parsed["preferred_units"], family)
    right_simple = right["total"] // _measure_factor_20260411AA(family, conversion_unit)
    result_simple = right_simple * number
    result_total = result_simple * _measure_factor_20260411AA(family, conversion_unit)
    answer = _measure_format_from_base_20260411AA(result_total, family, parsed["preferred_units"])
    return join_explanation_lines(
        f"Пример: {_pretty_named_measurement_expression_20260411AA(parsed)} = {answer}",
        "Решение.",
        f"1) Переводим составное именованное число в {conversion_unit}: {right['text']} = {right_simple} {conversion_unit}",
        f"2) Умножаем: {number} × {right_simple} = {result_simple} {conversion_unit}",
        f"3) Переводим ответ обратно: {result_simple} {conversion_unit} = {answer}",
        f"Ответ: {answer}",
        "Совет: при умножении составного именованного числа сначала переводи его в простое именованное число",
    )

# --- USER FINAL CONSOLIDATION PATCH 2026-04-11: generic equations + clearer textbook answers ---

_PATCH_USER_FINAL_PREV_INFER_TASK_KIND = infer_task_kind
_PATCH_USER_FINAL_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def _user_final_equation_variable_name(source: str) -> str:
    match = re.search(r"[A-Za-zА-Яа-я]", str(source or ""))
    return match.group(0) if match else "x"

def to_equation_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(text)
    text = normalize_cyrillic_x(text)
    text = text.replace("X", "x").replace("×", "*").replace("·", "*").replace("÷", "/").replace(":", "/")
    text = re.sub(r"\s+", "", text)
    if text.count("=") != 1:
        return None
    if not re.fullmatch(r"[\dA-Za-zА-Яа-я=+\-*/]+", text):
        return None
    letters = re.findall(r"[A-Za-zА-Яа-я]", text)
    if not letters:
        return None
    unique_letters = {letter.lower() for letter in letters}
    if len(unique_letters) != 1:
        return None
    variable = letters[0]
    if text.count(variable) + text.lower().count(variable.lower()) < 1:
        return None
    return text

def infer_task_kind(text: str) -> str:
    if to_equation_source(text):
        return "equation"
    return _PATCH_USER_FINAL_PREV_INFER_TASK_KIND(text)

def _user_final_format_equation_check(template: str, variable_name: str, value_text: str, expected_text: str) -> str:
    expression = template.replace(variable_name, value_text)
    return f"Проверка: {expression} = {expected_text}"
