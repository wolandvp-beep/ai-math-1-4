"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 2568-3461."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать очень подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой содержательной строке пиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, пиши строку:
Порядок действий:
Потом сам пример и над знаками действий цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши строку:
Решение по действиям:
4. Ниже обязательно пиши:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. По возможности используй школьную форму:
Если ..., то ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Важные требования:
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Если в задаче два вопроса, ответь на оба по порядку.
Для многодейственных задач не перескакивай сразу к ответу.
Сначала действие, потом пояснение, потом следующее действие.
""".strip()

BODY_LIMITS = {
    "expression": 40,
    "equation": 20,
    "fraction": 24,
    "geometry": 30,
    "word": 40,
    "other": 20,
}

_ORIGINAL_try_local_expression_explanation = try_local_expression_explanation
_ORIGINAL_try_local_equation_explanation = try_local_equation_explanation
_ORIGINAL_try_local_fraction_explanation = try_local_fraction_explanation
_ORIGINAL_try_local_geometry_explanation = try_local_geometry_explanation
_ORIGINAL_try_local_fraction_word_problem_explanation = try_local_fraction_word_problem_explanation
_ORIGINAL_try_local_motion_word_problem_explanation = try_local_motion_word_problem_explanation
_ORIGINAL_try_local_price_word_problem_explanation = try_local_price_word_problem_explanation
_ORIGINAL_try_local_unit_rate_word_problem_explanation = try_local_unit_rate_word_problem_explanation
_ORIGINAL_try_local_sum_and_divide_word_problem_explanation = try_local_sum_and_divide_word_problem_explanation
_ORIGINAL_try_local_proportional_division_word_problem = try_local_proportional_division_word_problem
_ORIGINAL_try_local_difference_unknown_word_problem = try_local_difference_unknown_word_problem
_ORIGINAL_try_local_indirect_word_problem_explanation = try_local_indirect_word_problem_explanation
_ORIGINAL_try_local_compound_word_problem_explanation = try_local_compound_word_problem_explanation
_ORIGINAL_try_local_word_problem_explanation = try_local_word_problem_explanation



def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")
    node = parse_expression_ast(source)
    pretty_expression = render_node(node) if node is not None else _detailed_compact_expression(source)
    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("что известно:", "что нужно найти:"))]
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]
    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block and not _detailed_is_column_like(body_lines):
        lines.extend(order_block)
        lines.append("Решение по действиям:")
    else:
        lines.append("Решение.")
    lines.extend(_detailed_number_lines(body_lines))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)



def _detailed_format_fraction_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_fraction_source(raw_text) or strip_known_prefix(raw_text)
    pretty = _detailed_pretty_fraction_expression(source)
    answer = parts["answer"] or "проверь запись"
    lines: List[str] = [f"Пример: {pretty} = {answer}", "Решение"]
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("fraction")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)




def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if kind == "expression" and to_expression_source(raw_text):
        return _detailed_format_expression_solution(raw_text, text)
    if kind == "equation" and to_equation_source(raw_text):
        return _detailed_format_equation_solution(raw_text, text)
    if kind == "fraction" and to_fraction_source(raw_text) and not re.search(r"[А-Яа-я]", raw_text):
        return _detailed_format_fraction_solution(raw_text, text)
    if kind in {"word", "geometry"} or re.search(r"[А-Яа-я]", raw_text):
        return _detailed_format_word_like_solution(raw_text, text, kind)
    return _detailed_format_generic_solution(raw_text, text, kind)

def shape_explanation(text: str, kind: str, forced_answer: Optional[str] = None, forced_advice: Optional[str] = None) -> str:
    parts = _detailed_split_sections(text)
    answer = forced_answer or parts["answer"] or "проверь запись"
    advice = forced_advice or parts["advice"] or default_advice(kind)
    lines = list(parts["body"])
    if kind == "equation" and parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)



def try_local_sum_then_subtract_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3:
        return None
    asks_left = bool(re.search(r"сколько[^.?!]*\b(осталось|останется)\b", lower))
    loss_markers = WORD_LOSS_HINTS + ("уехал", "уехала", "уехали", "уехало", "ушел", "ушла", "ушли", "ушло", "забрали")
    has_loss = contains_any_fragment(lower, loss_markers)
    if asks_left and has_loss:
        return explain_sum_then_subtract_word_problem(nums[0], nums[1], nums[2])
    return None

def try_local_named_sum_of_two_products_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower or ("заплат" not in lower and "стоил" not in lower and "стоят" not in lower and "стоимость" not in lower):
        return None

    matches = list(re.finditer(r"(\d+)\s+([^?.!,]{1,30}?)\s+по\s+(\d+)", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_name = matches[0].group(2).strip()
    first_price = int(matches[0].group(3))
    second_count = int(matches[1].group(1))
    second_name = matches[1].group(2).strip()
    second_price = int(matches[1].group(3))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"Если купили {first_count} {first_name} по {first_price} руб., то стоимость первой покупки равна {first_count} × {first_price} = {first_total} руб",
        f"Если купили {second_count} {second_name} по {second_price} руб., то стоимость второй покупки равна {second_count} × {second_price} = {second_total} руб",
        f"Если стоимость первой покупки {first_total} руб., а стоимость второй покупки {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала найди стоимость каждой покупки отдельно",
    )

def try_local_expression_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_expression_explanation(raw_text)

def try_local_equation_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_equation_explanation(raw_text)

def try_local_fraction_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_fraction_explanation(raw_text)

def try_local_geometry_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_geometry_explanation(raw_text)

def try_local_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_fraction_word_problem_explanation(raw_text)

def try_local_motion_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_motion_word_problem_explanation(raw_text)

def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_price_word_problem_explanation(raw_text)

def try_local_unit_rate_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_unit_rate_word_problem_explanation(raw_text)

def try_local_sum_and_divide_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_sum_and_divide_word_problem_explanation(raw_text)

def try_local_proportional_division_word_problem(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_proportional_division_word_problem(raw_text)

def try_local_difference_unknown_word_problem(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_difference_unknown_word_problem(raw_text)

def try_local_indirect_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_indirect_word_problem_explanation(raw_text)

def try_local_compound_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_compound_word_problem_explanation(raw_text)

def try_local_word_problem_explanation(raw_text: str) -> Optional[str]:
    return _ORIGINAL_try_local_word_problem_explanation(raw_text)



async def call_deepseek(payload: dict, timeout_seconds: float = 45.0):
    if not DEEPSEEK_API_KEY:
        return {"error": "DeepSeek API key is not configured"}
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        response = await client.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
                "Content-Type": "application/json",
            },
            json=payload,
        )
    if response.status_code != 200:
        return {"error": f"DeepSeek API error {response.status_code}", "details": response.text[:1500]}
    try:
        result = response.json()
    except Exception:
        return {"error": "DeepSeek вернул не JSON", "details": response.text[:1500]}
    if "choices" not in result or not result["choices"]:
        return {"error": "DeepSeek вернул неожиданный формат ответа", "details": str(result)[:1500]}
    message = result["choices"][0].get("message", {})
    answer = (message.get("content") or "").strip()
    if not answer:
        return {"error": "DeepSeek вернул пустой ответ", "details": str(result)[:1500]}
    return {"result": answer}



# --- FINAL SCHOOL PATCH: textbook-style word problems, clearer order marks, bug fixes ---


def _has_total_like_question(raw_text: str) -> bool:
    return asks_total_like(normalize_word_problem_text(raw_text).lower()) or "сколько всего" in normalize_word_problem_text(raw_text).lower()

def _has_group_count_question(text_lower: str) -> bool:
    return contains_any_fragment(
        text_lower,
        ("сколько короб", "сколько пакетов", "сколько корзин", "сколько клеток", "сколько сеток", "сколько потребуется", "сколько потребовалось", "сколько ведер", "сколько вёдер"),
    )

def _first_po_pair(text_lower: str) -> Optional[Tuple[int, int]]:
    match = re.search(r"(\d+)\s+[^\d?.!]{0,40}?\bпо\s+(\d+)\b", text_lower)
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))

def _fraction_numbers_and_text(raw_text: str):
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower()
    fracs = extract_all_fraction_pairs(lower)
    values = extract_non_fraction_numbers(lower)
    return text, lower, fracs, values

































def try_high_priority_unknown_addend_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None

    if re.search(r"(?:на двух|на обеих|на обоих|за два дня|всего|из них|на всем теле|на всём теле)", lower) and not _has_total_like_question(raw_text):
        total, known = nums[0], nums[1]
        if total < known:
            return None
        result = total - known
        return join_explanation_lines(
            f"1) Если всего было {total}, а одна часть равна {known}, то другая часть равна {total} - {known} = {result}",
            f"Ответ: {result}",
            "Совет: чтобы найти неизвестную часть, из целого вычитают известную часть",
        )
    return None

def try_high_priority_added_removed_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None

    if re.search(r"\b(стало|их стало|теперь стало|получилось)\b", lower) and contains_any_fragment(lower, WORD_GAIN_HINTS + ("постав", "добав", "приех", "вошло", "прибав")):
        before, after = nums[0], nums[1]
        if after < before:
            return None
        added = after - before
        return join_explanation_lines(
            f"1) Если сначала было {before}, а потом стало {after}, то добавили {after} - {before} = {added}",
            f"Ответ: {added}",
            "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
        )

    if re.search(r"\b(осталось|осталось прочитать|пришло|осталось расфасовать)\b", lower) and contains_any_fragment(lower, WORD_LOSS_HINTS + ("забрали", "сняли", "вышло", "заболело", "заболели", "заболел")):
        before, after = nums[0], nums[1]
        if before < after:
            return None
        removed = before - after
        return join_explanation_lines(
            f"1) Если сначала было {before}, а потом осталось {after}, то убрали {before} - {after} = {removed}",
            f"Ответ: {removed}",
            "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
        )

    if ("сколько было" in lower or "сколько было сначала" in lower) and re.search(r"\b(осталось|осталось на|осталось в)\b", lower):
        removed, left = nums[0], nums[1]
        result = removed + left
        return join_explanation_lines(
            f"1) Если убрали {removed}, а осталось {left}, то сначала было {removed} + {left} = {result}",
            f"Ответ: {result}",
            "Совет: неизвестное уменьшаемое находят сложением",
        )
    return None




def try_high_priority_unknown_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) >= 4 and "за всю покупку заплатили" in lower and "по" in lower and contains_any_fragment(lower, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        return explain_unknown_red_price(nums[0], nums[1], nums[2], nums[3])
    return None

def try_high_priority_total_cost_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоит 1", "сколько стоит одна", "сколько стоит один", "сколько стоит 1 ")):
        return explain_simple_price_per_item(nums[0], nums[1])
    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоят", "сколько стоила вся покупка", "сколько стоит вся покупка")):
        return explain_simple_total_cost(nums[0], nums[1])
    return None




# --- FINAL SCHOOL PATCH 2: units, group totals, cleaner purchase wording ---


def _append_unit_to_number_text(value: int, raw_text: str) -> str:
    unit = _detect_question_unit(raw_text)
    if not unit:
        return str(value)
    return f"{value} {unit}"








# --- FINAL SCHOOL PATCH 3: safer unit detection ---


# --- FINAL SCHOOL PATCH 4: reliable fraction routing for total-known vs remaining-known cases ---


# --- FINAL SCHOOL PATCH 5: only attach units when the question itself asks for that unit ---


# --- FINAL SCHOOL PATCH 6: fix "килограммов" vs "граммов" distinction ---


# --- OPENAI FINAL PATCH 2026-04-10: routing fixes, textbook-style compound tasks, safer answer units, ASCII columns ---

_PATCH8_PREVIOUS_explain_column_addition = explain_column_addition
_PATCH8_PREVIOUS_explain_column_subtraction = explain_column_subtraction
_PATCH8_PREVIOUS_explain_long_multiplication = explain_long_multiplication
_PATCH8_PREVIOUS_explain_long_division = explain_long_division

_PREFIX_NUMBER_MAP = {
    "одн": 1,
    "одно": 1,
    "двух": 2,
    "трех": 3,
    "трёх": 3,
    "четырех": 4,
    "четырёх": 4,
    "пяти": 5,
    "шести": 6,
    "семи": 7,
    "восьми": 8,
    "девяти": 9,
    "десяти": 10,
}

def _remove_one_value(seq: List[int], value: int) -> List[int]:
    data = list(seq)
    try:
        data.remove(value)
    except ValueError:
        pass
    return data

def _word_multiplier_value(word: str) -> Optional[int]:
    token = str(word or "").lower().replace("ё", "е")
    for prefix, value in _PREFIX_NUMBER_MAP.items():
        if token.startswith(prefix):
            return value
    return None

def _ascii_rule(width: int) -> str:
    return "-" * max(3, width)

def _render_column_addition_ascii(numbers: List[int]) -> List[str]:
    ordered = sorted(numbers, key=lambda x: (len(str(abs(x))), abs(x)), reverse=True)
    width = max(len(str(abs(n))) for n in ordered) + 1
    lines = ["Запись столбиком:"]
    for index, number in enumerate(ordered):
        sign = "+" if index > 0 else " "
        lines.append(f"{sign}{str(number).rjust(width - 1)}")
    lines.append(_ascii_rule(width))
    lines.append(f" {str(sum(ordered)).rjust(width - 1)}")
    return lines



def _render_long_multiplication_ascii(left: int, right: int) -> List[str]:
    a, b = left, right
    if len(str(abs(a))) < len(str(abs(b))):
        a, b = b, a
    width = max(len(str(abs(a))), len(str(abs(b))) + 1, len(str(abs(a * b)))) + 1
    lines = ["Запись столбиком:", f" {str(a).rjust(width - 1)}", f"×{str(b).rjust(width - 1)}", _ascii_rule(width)]
    digits_b = list(reversed(str(abs(b))))
    partials = []
    for index, digit in enumerate(digits_b):
        if digit == "0":
            continue
        partials.append(a * int(digit) * (10 ** index))
    if len(partials) <= 1:
        lines.append(f" {str(a * b).rjust(width - 1)}")
        return lines
    for partial in partials:
        lines.append(f" {str(partial).rjust(width - 1)}")
    lines.append(_ascii_rule(width))
    lines.append(f" {str(a * b).rjust(width - 1)}")
    return lines



def explain_column_addition(numbers: List[int]) -> str:
    base = _PATCH8_PREVIOUS_explain_column_addition(numbers)
    parts = _detailed_split_sections(base)
    lines = _render_column_addition_ascii(numbers) + parts["body"] + [
        f"Ответ: {parts['answer'] or sum(numbers)}",
        f"Совет: {parts['advice'] or 'в столбике всегда начинай с младшего разряда'}",
    ]
    return _detailed_finalize_text(lines)

def explain_column_subtraction(minuend: int, subtrahend: int) -> str:
    base = _PATCH8_PREVIOUS_explain_column_subtraction(minuend, subtrahend)
    parts = _detailed_split_sections(base)
    lines = _render_column_subtraction_ascii(minuend, subtrahend) + parts["body"] + [
        f"Ответ: {parts['answer'] or (minuend - subtrahend)}",
        f"Совет: {parts['advice'] or 'если разряда не хватает, занимаем 1 из соседнего старшего разряда'}",
    ]
    return _detailed_finalize_text(lines)

def explain_long_multiplication(left: int, right: int) -> str:
    base = _PATCH8_PREVIOUS_explain_long_multiplication(left, right)
    parts = _detailed_split_sections(base)
    lines = _render_long_multiplication_ascii(left, right) + parts["body"] + [
        f"Ответ: {parts['answer'] or (left * right)}",
        f"Совет: {parts['advice'] or 'в умножении столбиком сначала находят неполные произведения, потом их складывают'}",
    ]
    return _detailed_finalize_text(lines)

def explain_long_division(dividend: int, divisor: int) -> str:
    base = _PATCH8_PREVIOUS_explain_long_division(dividend, divisor)
    parts = _detailed_split_sections(base)
    answer_value = parts["answer"] or (f"{dividend // divisor}, остаток {dividend % divisor}" if divisor else "деление невозможно")
    lines = _render_long_division_ascii(dividend, divisor) + parts["body"] + [
        f"Ответ: {answer_value}",
        f"Совет: {parts['advice'] or 'в столбике повторяй шаги: взял, подобрал, умножил, вычел, снес цифру'}",
    ]
    return _detailed_finalize_text(lines)



def _split_ascii_layout_block(body_lines: List[str]) -> Tuple[List[str], List[str]]:
    lines = [str(line or "") for line in body_lines]
    if not lines or not lines[0].lower().startswith("запись столбиком"):
        return [], lines
    block = [lines[0]]
    index = 1
    while index < len(lines) and _is_ascii_math_layout_line(lines[index]):
        block.append(lines[index])
        index += 1
    return block, lines[index:]

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")
    node = parse_expression_ast(source)
    pretty_expression = render_node(node) if node is not None else _detailed_compact_expression(source)
    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("что известно:", "что нужно найти:"))]
    column_block, remaining_body = _split_ascii_layout_block(body_lines)
    if not remaining_body and not column_block:
        remaining_body = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]
    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block and not column_block:
        lines.extend(order_block)
        lines.append("Решение по действиям:")
    else:
        lines.append("Решение.")
    if column_block:
        lines.extend(column_block)
        if remaining_body:
            lines.append("Пояснение:")
    lines.extend(_detailed_number_lines(remaining_body))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)







def try_priority_fraction_by_given_part_explanation(raw_text: str) -> Optional[str]:
    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if len(fracs) != 1 or not values:
        return None
    numerator, denominator = fracs[0]
    if denominator == 0:
        return None
    if "составляет" in lower or re.search(rf"это\s+{numerator}\s*/\s*{denominator}\s+(?:всего\s+)?", lower):
        value_match = re.search(r"(?:составляет|равна|равен)[^\d]{0,20}(\d+)", lower)
        part_value = int(value_match.group(1)) if value_match else max(values)
        return explain_number_by_fraction_word_problem(part_value, numerator, denominator)
    return None

def try_high_priority_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    explicit = try_priority_fraction_by_given_part_explanation(raw_text)
    if explicit:
        return explicit

    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if not fracs:
        return None

    unit = _detect_question_unit(raw_text)

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower) and values:
        total = max(values)
        solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
        if solved:
            return solved

    if len(fracs) != 1:
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None

    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
    explicit_total_match = re.search(r"(?:\bбыло\b|\bвсего\b|\bмасса\b|\bдлина\b|\bпуть\b|\bпрошли\b|\bпрошел\b|\bпрошла\b|\bлистов\b|\bруды\b)[^\d]{0,40}(\d+)", lower)

    if remain_match and (not explicit_total_match or explicit_total_match.start() > remain_match.start()):
        remaining_value = int(remain_match.group(1))
        remaining_numerator = denominator - numerator
        if remaining_numerator <= 0 or remaining_value % remaining_numerator != 0:
            return None
        one_part = remaining_value // remaining_numerator
        whole = one_part * denominator
        remaining_text = f"{remaining_value} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        whole_text = f"{whole} {unit}".strip()
        return join_explanation_lines(
            f"1) Если израсходовали {numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
            f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_text}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part_text}",
            f"3) Если одна доля равна {one_part_text}, то все деньги равны {one_part} × {denominator} = {whole_text}",
            f"Ответ: всего было {whole_text}",
            "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
        )

    if values:
        total = max(values)
        if total % denominator != 0:
            return None
        one_part = total // denominator
        part = one_part * numerator
        remaining = total - part
        total_text = f"{total} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        part_text = f"{part} {unit}".strip()
        remaining_text = f"{remaining} {unit}".strip()

        if "во 2 день" in lower or "во второй день" in lower:
            return join_explanation_lines(
                f"1) Если весь путь равен {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если в первый день прошли {numerator}/{denominator} пути, то в первый день прошли {one_part} × {numerator} = {part_text}",
                f"3) Если весь путь {total_text}, а в первый день прошли {part_text}, то во второй день прошли {total} - {part} = {remaining_text}",
                f"Ответ: во второй день прошли {remaining_text}",
                "Совет: чтобы найти другую часть пути, сначала найди известную часть, потом вычти её из всего пути",
            )

        if "остал" in lower:
            return join_explanation_lines(
                f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если требуется найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
                f"3) Если всего было {total_text}, а израсходовали {part_text}, то осталось {total} - {part} = {remaining_text}",
                f"Ответ: осталось {remaining_text}",
                "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
            )

        return join_explanation_lines(
            f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
            f"Ответ: {part_text}",
            "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
        )
    return None







# --- OPENAI FINAL PATCH 2026-04-10B: remaining/added routing order, unit tolerance, heading colons ---



def try_priority_group_change_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    question = _question_text_only(raw_text).lower().replace("ё", "е") or lower

    if len(re.findall(r"\bпо\s+\d+", lower)) > 1:
        return None

    pair = _find_group_pair_any(lower)
    if not pair:
        return None
    groups = pair["groups"]
    per_group = pair["per_group"]
    pair_total = groups * per_group
    before_number, after_number = _numbers_before_after(lower, pair["start"], pair["end"])

    # 1. Если известен общий объём и одна часть вида n × k, находим другую часть.
    if ("осталось" in question or "осталось расфасовать" in question or "осталось проехать" in question or re.search(r"сколько[^.?!]*(?:отремонтировали|продали|расфасовали)\b", question)) and before_number is not None and before_number >= pair_total:
        result = before_number - pair_total
        return join_explanation_lines(
            f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
            f"2) Если всего было {before_number}, а эта часть равна {pair_total}, то другая часть равна {before_number} - {pair_total} = {result}",
            f"Ответ: {result}",
            "Совет: если известно всё число и одна часть, другую часть находят вычитанием",
        )

    # 2. Если сначала есть группы, а потом часть убрали, находим остаток.
    if ("осталось" in question or "осталось в магазине" in question) and after_number is not None and pair_total >= after_number:
        result = pair_total - after_number
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {pair_total}",
            f"2) Если было {pair_total}, а убрали {after_number}, то осталось {pair_total} - {after_number} = {result}",
            f"Ответ: {result}",
            "Совет: если сначала находят одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    # 3. Если известны израсходованная часть и остаток, находим всё число.
    if re.search(r"сколько[^.?!]*(?:привезли|было)\b", question):
        remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
        remain = int(remain_match.group(1)) if remain_match else after_number
        if remain is not None:
            result = pair_total + remain
            return join_explanation_lines(
                f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
                f"2) Если одна часть равна {pair_total}, а другая часть равна {remain}, то всего было {pair_total} + {remain} = {result}",
                f"Ответ: {result}",
                "Совет: если известны израсходованная часть и остаток, то всё число находят сложением",
            )

    # 4. Если сначала есть группы, а потом что-то добавили, находим итог.
    if ("стало" in question or "всего" in question) and contains_any_fragment(lower, WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")):
        extra = after_number
        if extra is not None:
            result = pair_total + extra
            return join_explanation_lines(
                f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {per_group} × {groups} = {pair_total}",
                f"2) Если было {pair_total}, а потом добавили ещё {extra}, то стало {pair_total} + {extra} = {result}",
                f"Ответ: {result}",
                "Совет: если сначала находят одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
            )

    return None

# --- OPENAI FINAL PATCH 2026-04-10C: protect subtraction/division layout lines from sanitizer ---

def _render_column_subtraction_ascii(minuend: int, subtrahend: int) -> List[str]:
    width = max(len(str(abs(minuend))), len(str(abs(subtrahend)))) + 1
    result = minuend - subtrahend
    return [
        "Запись столбиком:",
        f" {str(minuend).rjust(width - 1)}",
        f"–{str(subtrahend).rjust(width - 1)}",
        _ascii_rule(width),
        f" {str(result).rjust(width - 1)}",
    ]
