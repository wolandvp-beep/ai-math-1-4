"""Auto-generated runtime shard for prepatch_build_source.py, lines 20234-21052."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _stress20260416ad_try_extra_text_tasks(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е').replace('–', '-').replace('—', '-').replace('−', '-')
    lower = re.sub(r'\s+', ' ', lower).strip()

    # --- Nonstandard counting tasks ---
    m = re.search(r'во дворе .*?стоят (\d+) мальчик', lower)
    if m and 'между каждым мальчиком' in lower and 'по одной девочке' in lower:
        boys = int(m.group(1))
        girls = max(boys - 1, 0)
        total = boys + girls
        return _stress20260416ad_task(
            raw_text,
            f'в ряд стоят {boys} мальчика, между каждым соседними мальчиками стоит по одной девочке',
            'сколько девочек и сколько всего детей',
            [
                f'1) Между четырьмя мальчиками получается на одно место меньше, чем мальчиков: {boys} - 1 = {girls}.',
                f'2) Теперь находим, сколько всего детей: {boys} + {girls} = {total}.',
            ],
            f'девочек {girls}, всего детей {total}',
            'если дети стоят в ряд, то промежутков между ними всегда на один меньше, чем самих детей',
        )

    m = re.search(r'юля сидит .*? (\w+) спереди .*? (\w+) сзади', lower)
    if m and 'за каждой партой по два человека' in lower:
        front = _stress20260416ad_num_from_token(m.group(1))
        back = _stress20260416ad_num_from_token(m.group(2))
        if front and back:
            desks = front + back - 1
            children = desks * 2
            return _stress20260416ad_task(
                raw_text,
                f'Юля сидит на {front}-й парте спереди и на {back}-й парте сзади, за каждой партой сидят по 2 человека',
                'сколько парт в ряду и сколько детей в ряду',
                [
                    f'1) Юлина парта считается и спереди, и сзади, поэтому один раз её не добавляем: {front} + {back} - 1 = {desks}.',
                    f'2) На каждой парте сидят по 2 человека, значит детей в ряду: {desks} × 2 = {children}.',
                ],
                f'парт {desks}, детей {children}',
                'если одно и то же место считают с двух сторон, один раз его нужно вычесть',
            )

    m = re.search(r'насчитал (\w+) пар.*?насчитал (\w+) пар', lower)
    if m and 'шел парами' in lower:
        front_pairs = _stress20260416ad_num_from_token(m.group(1))
        back_pairs = _stress20260416ad_num_from_token(m.group(2))
        if front_pairs is not None and back_pairs is not None:
            total_pairs = front_pairs + back_pairs + 1
            total_students = total_pairs * 2
            return _stress20260416ad_task(
                raw_text,
                f'впереди у ученика {front_pairs} пар, сзади {back_pairs} пар, сам он тоже идёт в паре',
                'сколько учеников шло в колонне',
                [
                    f'1) Всего пар: {front_pairs} + {back_pairs} + 1 = {total_pairs}.',
                    f'2) В каждой паре по 2 ученика, значит учеников было: {total_pairs} × 2 = {total_students}.',
                ],
                f'{total_students} учеников',
                'если считают пары впереди и сзади, не забудь прибавить свою пару',
            )

    m = re.search(r'высотой (\d+) метр.*?вверх на (\d+) метр.*?спускается на (\d+) метр', lower)
    if m and 'улитка' in lower:
        height, up, down = map(int, m.groups())
        if up > down:
            if up >= height:
                day = 1
            else:
                remain_before_last = height - up
                net = up - down
                full_days = (remain_before_last + net - 1) // net
                day = full_days + 1
            return _stress20260416ad_task(
                raw_text,
                f'высота дерева {height} м, днём улитка поднимается на {up} м, ночью спускается на {down} м',
                'на какой день улитка доберётся до макушки',
                [
                    f'1) За один полный день и ночь улитка поднимается на {up} - {down} = {up - down} м.',
                    f'2) В последний день ей не нужно ждать ночи: как только она поднимется до {height} м, задача решена.',
                    f'3) Через 5 полных дней улитка будет на высоте 5 м, а на 6-й день поднимется ещё на {up} м и доберётся до {height} м.',
                ],
                f'на {day}-й день',
                'в задачах про улитку последний подъём считают отдельно: после него улитка уже не спускается',
            )

    # --- Sum / difference / grouping tasks ---
    m = re.search(r'сделали из бумаги (\d+) фонариков и (\d+) звездоч.*?(\d+) елочн.*гирлянд', lower)
    if m:
        a, b, groups = map(int, m.groups())
        total = a + b
        per = total // groups
        return _stress20260416ad_task(
            raw_text,
            f'сделали {a} фонариков и {b} звёздочек, все игрушки разделили на {groups} гирлянд',
            'сколько игрушек было в каждой гирлянде',
            [
                f'1) Находим, сколько всего игрушек сделали: {a} + {b} = {total}.',
                f'2) Делим все игрушки поровну на {groups} гирлянд: {total} : {groups} = {per}.',
            ],
            f'в каждой гирлянде по {per} игрушек',
            'если все предметы разделили поровну, сначала находят общее количество, а потом делят',
        )

    m = re.search(r'с одной грядки (\d+) кг .*? с другой -? ?(\d+) кг.*?(\d+) корзин', lower)
    if m and 'свекл' in lower:
        a, b, groups = map(int, m.groups())
        total = a + b
        per = total // groups
        return _stress20260416ad_task(
            raw_text,
            f'с одной грядки собрали {a} кг, с другой {b} кг, всё уложили в {groups} корзин',
            'сколько килограммов было в каждой корзине',
            [
                f'1) Сначала находим всю свёклу: {a} + {b} = {total} кг.',
                f'2) Теперь делим всё поровну на {groups} корзин: {total} : {groups} = {per} кг.',
            ],
            f'в каждой корзине было по {per} кг свёклы',
            'если всё разложили поровну, сначала находят всё количество, а потом делят его на число групп',
        )

    m = re.search(r'красной ткани было (\d+) м, белой -? ?(\d+) м.*?на каждое по (\d+) м', lower)
    if m and 'плать' in lower:
        red, white, per_item = map(int, m.groups())
        total = red + white
        count = total // per_item
        return _stress20260416ad_task(
            raw_text,
            f'красной ткани {red} м, белой {white} м, на одно платье идёт {per_item} м ткани',
            'сколько платьев получилось',
            [
                f'1) Находим, сколько было всей ткани: {red} + {white} = {total} м.',
                f'2) Узнаём, сколько платьев можно сшить: {total} : {per_item} = {count}.',
            ],
            f'получилось {count} платьев',
            'когда известен расход на один предмет, общее количество материала делят на этот расход',
        )

    m = re.search(r'в первом бидоне было (\d+) л .*? во втором (\d+) л.*?поровну в (\d+) бан', lower)
    if m:
        first, second, groups = map(int, m.groups())
        total = first + second
        per = total // groups
        return _stress20260416ad_task(
            raw_text,
            f'в первом бидоне {first} л, во втором {second} л, всё разлили поровну в {groups} банок',
            'сколько литров молока в каждой банке',
            [
                f'1) Сначала находим всё молоко: {first} + {second} = {total} л.',
                f'2) Делим всё молоко поровну на {groups} банок: {total} : {groups} = {per} л.',
            ],
            f'в каждой банке по {per} л',
            'если всё разлили поровну, складывают весь объём и делят на число одинаковых ёмкостей',
        )

    m = re.search(r'в 4 бидона разлили (\d+) кг меда.*?в трех бидонах оказалось по (\d+) кг', lower)
    if m:
        total, same = map(int, m.groups())
        known = 3 * same
        fourth = total - known
        return _stress20260416ad_task(
            raw_text,
            f'всего {total} кг мёда, в трёх бидонах по {same} кг',
            'сколько килограммов мёда в четвёртом бидоне',
            [
                f'1) Находим, сколько мёда в трёх бидонах: {same} × 3 = {known} кг.',
                f'2) Находим, сколько осталось для четвёртого бидона: {total} - {known} = {fourth} кг.',
            ],
            f'в четвёртом бидоне {fourth} кг мёда',
            'если известно всё количество и несколько одинаковых частей, сначала находят сумму известных частей, потом остаток',
        )

    m = re.search(r'привезли (\d+) кг яблок и груш.*?(\d+) ящика по (\d+) кг', lower)
    if m and 'сколько килограммов груш' in lower:
        total, boxes, per_box = map(int, m.groups())
        apples = boxes * per_box
        pears = total - apples
        return _stress20260416ad_task(
            raw_text,
            f'всего привезли {total} кг яблок и груш, яблок было {boxes} ящика по {per_box} кг',
            'сколько килограммов груш привезли',
            [
                f'1) Находим массу яблок: {boxes} × {per_box} = {apples} кг.',
                f'2) Находим массу груш: {total} - {apples} = {pears} кг.',
            ],
            f'груш привезли {pears} кг',
            'если общее количество состоит из двух частей, неизвестную часть находят вычитанием',
        )

    m = re.search(r'в большой оленьей упряжке (\d+) оленей.*?в маленькой упряжке по (\d+) оленя.*?всего (\d+) оленей', lower)
    if m:
        big, small_each, total = map(int, m.groups())
        rest = total - big
        count = rest // small_each
        return _stress20260416ad_task(
            raw_text,
            f'в большой упряжке {big} оленей, в маленькой по {small_each} оленя, всего {total} оленей',
            'сколько маленьких упряжек',
            [
                f'1) Находим, сколько оленей осталось для маленьких упряжек: {total} - {big} = {rest}.',
                f'2) Узнаём, сколько маленьких упряжек получилось: {rest} : {small_each} = {count}.',
            ],
            f'{count} маленьких упряжек',
            'если известны общее количество и одна большая часть, сначала находят остаток, а потом делят его на размер одной группы',
        )

    m = re.search(r'в ящике (\d+) кг винограда.*?в четыр[её]х одинаковых коробках (\d+) кг', lower)
    if m and 'в одной коробке' in lower:
        crate, boxes_total = map(int, m.groups())
        one_box = boxes_total // 4
        ratio = max(one_box, crate) // min(one_box, crate)
        return _stress20260416ad_task(
            raw_text,
            f'в ящике {crate} кг винограда, в четырёх одинаковых коробках {boxes_total} кг',
            'во сколько раз больше винограда в одной коробке, чем в ящике',
            [
                f'1) Сначала находим, сколько винограда в одной коробке: {boxes_total} : 4 = {one_box} кг.',
                f'2) Теперь сравниваем одну коробку и ящик: {one_box} : {crate} = {ratio}.',
            ],
            f'в одной коробке винограда в {ratio} раза больше',
            'при кратном сравнении сначала нужно узнать величину одной части, если дана сумма нескольких одинаковых частей',
        )

    # --- Relative comparison / ratio tasks ---
    m = re.search(r'пиявка весом (\d+) г .*? высосать (\d+) г крови', lower)
    if m and 'во сколько раз больше' in lower:
        own, blood = map(int, m.groups())
        after = own + blood
        ratio = after // own
        return _stress20260416ad_task(
            raw_text,
            f'пиявка весит {own} г и после обеда станет тяжелее на {blood} г',
            'во сколько раз её масса после обеда больше прежней',
            [
                f'1) Находим массу после обеда: {own} + {blood} = {after} г.',
                f'2) Сравниваем новую массу с прежней: {after} : {own} = {ratio}.',
            ],
            f'в {ratio} раз',
            'чтобы узнать, во сколько раз одно число больше другого, большее число делят на меньшее',
        )

    m = re.search(r'посадили (\d+) кг картофеля, а собрали (\d+) кг', lower)
    if m and 'во сколько раз больше собрали' in lower:
        planted, gathered = map(int, m.groups())
        ratio = gathered // planted
        return _stress20260416ad_task(
            raw_text,
            f'посадили {planted} кг, собрали {gathered} кг',
            'во сколько раз собрали больше, чем посадили',
            [f'1) Делим большее количество на меньшее: {gathered} : {planted} = {ratio}.'],
            f'в {ratio} раз',
            'при кратном сравнении большее число делят на меньшее',
        )

    m = re.search(r'отцу (\d+) год[а-я]*, сыну (\d+) лет', lower)
    if m and 'во сколько раз сын моложе' in lower:
        father, son = map(int, m.groups())
        ratio = father // son
        return _stress20260416ad_task(
            raw_text,
            f'отцу {father} года, сыну {son} лет',
            'во сколько раз сын моложе отца',
            [f'1) Сравниваем возраст отца и сына: {father} : {son} = {ratio}.'],
            f'в {ratio} раза',
            'слова «во сколько раз» означают действие деления',
        )

    m = re.search(r'сделали (\d+) больших игрушек, а маленьких - в (\d+) раз меньше', lower)
    if m and 'на сколько' in lower:
        big, factor = map(int, m.groups())
        small = big // factor
        diff = big - small
        return _stress20260416ad_task(
            raw_text,
            f'больших игрушек {big}, маленьких в {factor} раз меньше',
            'на сколько больших игрушек сделали больше, чем маленьких',
            [
                f'1) Находим количество маленьких игрушек: {big} : {factor} = {small}.',
                f'2) Находим, на сколько больших игрушек больше: {big} - {small} = {diff}.',
            ],
            f'на {diff}',
            'если сказано «в несколько раз меньше», сначала делят, а потом находят разность',
        )

    # --- Motion tasks ---
    m = re.search(r'проехал (\d+) км со скоростью (\d+) км/ч.*?скорость (\d+) км/ч', lower)
    if m and 'до встречи' in lower:
        first_path, first_speed, second_speed = map(int, m.groups())
        if first_path % first_speed == 0:
            time_value = first_path // first_speed
            second_path = second_speed * time_value
            return _stress20260416ad_task(
                raw_text,
                f'первый автобус проехал {first_path} км со скоростью {first_speed} км/ч, скорость второго автобуса {second_speed} км/ч',
                'сколько километров до встречи проехал второй автобус',
                [
                    f'1) Находим время движения до встречи: {first_path} : {first_speed} = {time_value} ч.',
                    f'2) За это время второй автобус проедет: {second_speed} × {time_value} = {second_path} км.',
                ],
                f'{second_path} км',
                'если участники встретились одновременно, время движения до встречи у них одинаковое',
            )

    m = re.search(r'расстояние между .*? (\d+) км.*?скорость первого (\d+) км/ч.*?второго (\d+) км/ч', lower)
    if m and 'навстречу друг другу' in lower:
        distance, v1, v2 = map(int, m.groups())
        total_speed = v1 + v2
        if distance % total_speed == 0:
            time_value = distance // total_speed
            return _stress20260416ad_task(
                raw_text,
                f'расстояние между пристанями {distance} км, скорости теплоходов {v1} км/ч и {v2} км/ч',
                'через сколько часов теплоходы встретятся',
                [
                    f'1) При движении навстречу складываем скорости: {v1} + {v2} = {total_speed} км/ч.',
                    f'2) Время до встречи равно расстоянию, делённому на скорость сближения: {distance} : {total_speed} = {time_value} ч.',
                ],
                f'{time_value} ч',
                'при движении навстречу друг другу скорость сближения равна сумме скоростей',
            )

    m = re.search(r'длиной (\d+) м .*?со скоростью (\d+) м/с.*?через (\d+) с', lower)
    if m and 'навстречу друг другу' in lower:
        distance, v1, time_value = map(int, m.groups())
        if distance % time_value == 0:
            total_speed = distance // time_value
            v2 = total_speed - v1
            return _stress20260416ad_task(
                raw_text,
                f'длина дорожки {distance} м, скорость первого мальчика {v1} м/с, встретились через {time_value} с',
                'какова скорость второго мальчика',
                [
                    f'1) Находим общую скорость сближения: {distance} : {time_value} = {total_speed} м/с.',
                    f'2) Вычитаем скорость первого мальчика: {total_speed} - {v1} = {v2} м/с.',
                ],
                f'{v2} м/с',
                'если известны расстояние и время до встречи, сначала находят общую скорость сближения',
            )

    # --- Geometry tasks ---
    m = re.search(r'длина (\d+) дм, а ширина на (\d+) дм меньше', lower)
    if m and 'площад' in lower and 'см²' in lower:
        length_dm, less_dm = map(int, m.groups())
        width_dm = length_dm - less_dm
        area_dm2 = length_dm * width_dm
        area_cm2 = area_dm2 * 100
        return _stress20260416ad_task(
            raw_text,
            f'длина ковра {length_dm} дм, ширина на {less_dm} дм меньше',
            'площадь ковра в квадратных сантиметрах',
            [
                f'1) Находим ширину ковра: {length_dm} - {less_dm} = {width_dm} дм.',
                f'2) Находим площадь в квадратных дециметрах: {length_dm} × {width_dm} = {area_dm2} дм².',
                f'3) Переводим в квадратные сантиметры: {area_dm2} дм² = {area_cm2} см².',
            ],
            f'{area_cm2} см²',
            'если нужно перевести дм² в см², умножают на 100',
        )

    m = re.search(r'длина равна (\d+) м, а ширина .*?в (\d+) раза меньше', lower)
    if m and 'периметр прямоугольника' in lower:
        length, factor = map(int, m.groups())
        width = length // factor
        per = 2 * (length + width)
        return _stress20260416ad_task(
            raw_text,
            f'длина прямоугольника {length} м, ширина в {factor} раза меньше',
            'периметр прямоугольника',
            [
                f'1) Находим ширину: {length} : {factor} = {width} м.',
                f'2) Находим периметр: ({length} + {width}) × 2 = {per} м.',
            ],
            f'{per} м',
            'если ширина в несколько раз меньше длины, длину делят на это число',
        )

    m = re.search(r'периметр прямоугольника равен (\d+) см, а его длина на (\d+) см больше ширины', lower)
    if m and 'площад' in lower:
        per, diff = map(int, m.groups())
        half = per // 2
        width = (half - diff) // 2
        length = width + diff
        area = width * length
        return _stress20260416ad_task(
            raw_text,
            f'периметр прямоугольника {per} см, длина на {diff} см больше ширины',
            'площадь прямоугольника',
            [
                f'1) Находим сумму длины и ширины: {per} : 2 = {half} см.',
                f'2) Если длина на {diff} см больше, то без этой разницы остаётся: {half} - {diff} = {half - diff} см.',
                f'3) Находим ширину: {half - diff} : 2 = {width} см.',
                f'4) Находим длину: {width} + {diff} = {length} см.',
                f'5) Находим площадь: {width} × {length} = {area} см².',
            ],
            f'{area} см²',
            'в задачах на периметр прямоугольника сначала часто находят полупериметр — сумму длины и ширины',
        )

    m = re.search(r'одна сторона равна (\d+) см.*?меньше второй стороны на (\d+) см .*?меньше третьей стороны на (\d+) см', lower)
    if m and 'треугольник' in lower and 'периметр' in lower:
        side1, less2, less3 = map(int, m.groups())
        side2 = side1 + less2
        side3 = side1 + less3
        per = side1 + side2 + side3
        return _stress20260416ad_task(
            raw_text,
            f'одна сторона {side1} см, вторая на {less2} см больше, третья на {less3} см больше',
            'периметр треугольника',
            [
                f'1) Находим вторую сторону: {side1} + {less2} = {side2} см.',
                f'2) Находим третью сторону: {side1} + {less3} = {side3} см.',
                f'3) Находим периметр: {side1} + {side2} + {side3} = {per} см.',
            ],
            f'{per} см',
            'периметр многоугольника равен сумме длин всех его сторон',
        )

    m = re.search(r'ширина прямоугольника (\d+) см, периметр (\d+) см', lower)
    if m and 'площад' in lower:
        width, per = map(int, m.groups())
        half = per // 2
        length = half - width
        area = length * width
        return _stress20260416ad_task(
            raw_text,
            f'ширина прямоугольника {width} см, периметр {per} см',
            'площадь прямоугольника',
            [
                f'1) Находим сумму длины и ширины: {per} : 2 = {half} см.',
                f'2) Находим длину: {half} - {width} = {length} см.',
                f'3) Находим площадь: {length} × {width} = {area} см².',
            ],
            f'{area} см²',
            'если известны периметр и одна сторона прямоугольника, сначала находят сумму длины и ширины',
        )

    m = re.search(r'за (\d+) минут .*?скоростью (\d+) м/мин.*?ширина огорода (\d+) м', lower)
    if m and 'обходит' in lower and 'площад' in lower:
        minutes, speed, width = map(int, m.groups())
        per = minutes * speed
        half = per // 2
        length = half - width
        area = length * width
        return _stress20260416ad_task(
            raw_text,
            f'за {minutes} минут человек обходит огород со скоростью {speed} м/мин, ширина огорода {width} м',
            'площадь огорода',
            [
                f'1) Находим периметр огорода: {speed} × {minutes} = {per} м.',
                f'2) Находим сумму длины и ширины: {per} : 2 = {half} м.',
                f'3) Находим длину: {half} - {width} = {length} м.',
                f'4) Находим площадь: {length} × {width} = {area} м².',
            ],
            f'{area} м²',
            'если известен путь по контуру фигуры, сначала находят периметр, а потом стороны',
        )

    # --- Fraction word problems ---
    m = re.search(r'за первый день машина проехала (\d+)/(\d+) .*? во второй день (\d+)/(\d+) .*? в третий день она проехала (\d+) км', lower)
    if m:
        n1, d1, n2, d2, third_distance = map(int, m.groups())
        if d1 == d2:
            first_frac = Fraction(n1, d1)
            second_frac = Fraction(n2, d2)
            third_frac = Fraction(1, 1) - first_frac - second_frac
            if third_frac > 0:
                total = Fraction(third_distance, 1) / third_frac
                if total.denominator == 1:
                    total = total.numerator
                    first = total * n1 // d1
                    second = total * n2 // d2
                    return _stress20260416ad_task(
                        raw_text,
                        f'в первый день машина прошла {n1}/{d1} пути, во второй {n2}/{d2} пути, в третий день {third_distance} км',
                        'каково всё расстояние и сколько машина прошла в каждый день',
                        [
                            f'1) Находим, какая часть пути пришлась на третий день: 1 - {n1}/{d1} - {n2}/{d2} = {third_frac.numerator}/{third_frac.denominator}.',
                            f'2) Если {third_frac.numerator}/{third_frac.denominator} пути равны {third_distance} км, то весь путь равен {third_distance} : {third_frac.numerator}/{third_frac.denominator} = {total} км.',
                            f'3) В первый день машина прошла: {total} × {n1}/{d1} = {first} км.',
                            f'4) Во второй день машина прошла: {total} × {n2}/{d2} = {second} км.',
                            f'5) В третий день машина прошла {third_distance} км.',
                        ],
                        f'весь путь {total} км; в первый день {first} км, во второй день {second} км, в третий день {third_distance} км',
                        'если известна часть пути, оставшуюся дробь сначала находят вычитанием из единицы',
                    )

    if 'на субботник вышли 90 учащихся' in lower and '1/2' in lower and '1/5' in lower and '1/10' in lower and '9 носилок' in lower:
        total = 90
        shovels = total // 2
        rakes = total // 5
        buckets = total // 10
        assigned = shovels + rakes + buckets
        rest = total - assigned
        people_for_stretchers = 9 * 2
        yes_no = 'да' if rest == people_for_stretchers else 'нет'
        return _stress20260416ad_task(
            raw_text,
            f'на субботник вышли {total} учащихся; 1/2 получили лопаты, 1/5 — грабли, 1/10 — вёдра; остальным выдали 9 носилок',
            'всем ли ребятам досталась работа',
            [
                f'1) Лопаты получили: {total} : 2 = {shovels} человек.',
                f'2) Грабли получили: {total} : 5 = {rakes} человек.',
                f'3) Вёдра получили: {total} : 10 = {buckets} человек.',
                f'4) Всего уже заняты работой: {shovels} + {rakes} + {buckets} = {assigned} человек.',
                f'5) Осталось ребят: {total} - {assigned} = {rest} человек.',
                f'6) На 9 носилок нужно по 2 человека: 9 × 2 = {people_for_stretchers} человек.',
            ],
            f'{yes_no}, всем ребятам досталась работа, потому что осталось {rest} человек, а на 9 носилок нужно {people_for_stretchers} человек',
            'в задачах с дробями от числа сначала находят каждую часть, потом складывают их и сравнивают с общим количеством',
        )

    return None

async def build_explanation(user_text: str) -> dict:
    local = _stress20260416ad_try_extra_text_tasks(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _STRESS20260416AD_PREV_BUILD_EXPLANATION(user_text)

# --- STRESS AUDIT PATCH 2026-04-16AE: explicit meeting-time pattern for two equal speeds ---

_STRESS20260416AE_PREV_BUILD_EXPLANATION = build_explanation

def _stress20260416ae_try_swallow_task(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е').replace('–', '-').replace('—', '-').replace('−', '-')
    lower = re.sub(r'\s+', ' ', lower).strip()
    m = re.search(r'скорость каждой .*? (\d+) м/с.*?расстояние между ними (\d+) м', lower)
    if m and 'ласточк' in lower and 'навстречу друг другу' in lower:
        speed_each, distance = map(int, m.groups())
        total_speed = speed_each * 2
        if distance % total_speed == 0:
            time_value = distance // total_speed
            return _stress20260416ad_task(
                raw_text,
                f'каждая ласточка летит со скоростью {speed_each} м/с, расстояние между ними {distance} м',
                'через сколько секунд ласточки встретятся',
                [
                    f'1) При движении навстречу складываем скорости: {speed_each} + {speed_each} = {total_speed} м/с.',
                    f'2) Время до встречи равно расстоянию, делённому на скорость сближения: {distance} : {total_speed} = {time_value} с.',
                ],
                f'{time_value} с',
                'при движении навстречу скорость сближения равна сумме скоростей',
            )
    return None

async def build_explanation(user_text: str) -> dict:
    local = _stress20260416ae_try_swallow_task(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _STRESS20260416AE_PREV_BUILD_EXPLANATION(user_text)

def _geo20260416ag_measure_family(unit: str) -> Optional[str]:
    u = unit.lower()
    if u in {'мм','см','дм','м','км'}:
        return 'length'
    if u in {'г','кг','ц','т'}:
        return 'mass'
    if u in {'с','сек','секунд','секунда','секунды','мин','ч','сутки','суток'}:
        return 'time'
    return None

def _geo20260416ag_measure_factor(unit: str) -> Optional[int]:
    u = unit.lower()
    factors = {
        'мм': 1, 'см': 10, 'дм': 100, 'м': 1000, 'км': 1000000,
        'г': 1, 'кг': 1000, 'ц': 100000, 'т': 1000000,
        'с': 1, 'сек': 1, 'секунд': 1, 'секунда': 1, 'секунды': 1,
        'мин': 60, 'ч': 3600, 'сутки': 86400, 'суток': 86400,
    }
    return factors.get(u)

def _geo20260416ag_pretty_measure_unit(unit: str) -> str:
    u = unit.lower()
    mapping = {
        'мм': 'мм', 'см': 'см', 'дм': 'дм', 'м': 'м', 'км': 'км',
        'г': 'г', 'кг': 'кг', 'ц': 'ц', 'т': 'т',
        'с': 'с', 'сек': 'с', 'секунд': 'с', 'секунда': 'с', 'секунды': 'с',
        'мин': 'мин', 'ч': 'ч', 'сутки': 'сутки', 'суток': 'суток',
    }
    return mapping.get(u, unit)

def _geo20260416ag_parse_measure_quantity(text: str) -> Optional[dict]:
    source = normalize_dashes(text).lower().replace('²', '').replace('³', '')
    source = re.sub(r'\s+', ' ', source).strip()
    matches = list(re.finditer(r'(\d+)\s*(мм|см|дм|км|м|кг|г|ц|т|сутки|суток|ч|мин|с|сек(?:унда|унды|унд)?)', source))
    if not matches:
        return None
    family = None
    total = 0
    parts = []
    for m in matches:
        value = int(m.group(1))
        unit = m.group(2)
        current_family = _geo20260416ag_measure_family(unit)
        factor = _geo20260416ag_measure_factor(unit)
        if current_family is None or factor is None:
            return None
        if family is None:
            family = current_family
        elif family != current_family:
            return None
        total += value * factor
        parts.append((value, _geo20260416ag_pretty_measure_unit(unit)))
    pretty = ' '.join(f'{value} {unit}' for value, unit in parts)
    return {'family': family, 'total': total, 'pretty': pretty}

def _geo20260416ag_format_measure_from_base(total: int, units: List[str]) -> str:
    if not units:
        return str(total)
    normalized = [_geo20260416ag_pretty_measure_unit(u) for u in units]
    factors = [_geo20260416ag_measure_factor(u) for u in normalized]
    if any(f is None for f in factors):
        return str(total)
    factors = [int(f) for f in factors]
    if len(normalized) == 1:
        value = total // factors[0]
        return f'{value} {normalized[0]}'
    remaining = total
    parts = []
    for idx, unit in enumerate(normalized):
        factor = factors[idx]
        if idx < len(normalized) - 1:
            value = remaining // factor
            remaining -= value * factor
        else:
            value = remaining // factor
        parts.append(f'{value} {unit}')
    return ' '.join(parts)

def _geo20260416ag_compare_sign(left_total: int, right_total: int) -> str:
    if left_total < right_total:
        return '<'
    if left_total > right_total:
        return '>'
    return '='

def _geo20260416ag_try_named_units_extended(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = normalize_dashes(text).lower().replace('…', '').replace('?', '').strip()

    m = re.fullmatch(r'(\d+\s*(?:мм|см|дм|км|м|кг|г|ц|т|сутки|суток|ч|мин|с)(?:\s*\d+\s*(?:мм|см|дм|км|м|кг|г|ц|т|сутки|суток|ч|мин|с))*)\s*=\s*((?:мм|см|дм|км|м|кг|г|ц|т|сутки|суток|ч|мин|с)(?:\s+(?:мм|см|дм|км|м|кг|г|ц|т|сутки|суток|ч|мин|с))*)\.?', lower)
    if m:
        left_text = m.group(1).strip()
        target_units = m.group(2).strip().rstrip('.').split()
        parsed = _geo20260416ag_parse_measure_quantity(left_text)
        if parsed:
            target_family = _geo20260416ag_measure_family(target_units[0])
            if target_family == parsed['family']:
                answer = _geo20260416ag_format_measure_from_base(parsed['total'], target_units)
                base_unit = {'length': 'мм', 'mass': 'г', 'time': 'с'}[parsed['family']]
                base_value = parsed['total'] // _geo20260416ag_measure_factor(base_unit)
                lines = [
                    f'Пример: {parsed["pretty"]} = {answer}.',
                    'Решение.',
                ]
                if len(target_units) == 1:
                    unit = _geo20260416ag_pretty_measure_unit(target_units[0])
                    factor = _geo20260416ag_measure_factor(unit)
                    base_from = parsed['pretty']
                    lines += [
                        f'1) Переводим {base_from} в более удобную единицу {unit}.',
                    ]
                    family = parsed['family']
                    if family == 'length':
                        if unit == 'дм':
                            lines.append('2) В 1 дм 10 см.')
                        elif unit == 'м':
                            lines.append('2) В 1 м 100 см.')
                        elif unit == 'см':
                            lines.append('2) Выполняем перевод в сантиметры.')
                    elif family == 'mass':
                        if unit == 'кг':
                            lines.append('2) В 1 кг 1000 г.')
                        elif unit == 'ц':
                            lines.append('2) В 1 ц 100 кг.')
                        elif unit == 'т':
                            lines.append('2) В 1 т 1000 кг.')
                    value = parsed['total'] // factor
                    lines.append(f'3) Получаем: {answer}.')
                else:
                    largest = _geo20260416ag_pretty_measure_unit(target_units[0])
                    lines += [
                        f'1) Переводим {parsed["pretty"]} в более крупную единицу и остаток.',
                        f'2) Получаем: {answer}.',
                    ]
                lines += [
                    f'Ответ: {answer}',
                    'Совет: при переводе величин сначала выбирают одну общую единицу измерения',
                ]
                return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'сравни\s*:\s*(.+?)\s+и\s+(.+?)\.?', lower)
    if m:
        left_raw = m.group(1).strip()
        right_raw = m.group(2).strip()
        left = _geo20260416ag_parse_measure_quantity(left_raw)
        right = _geo20260416ag_parse_measure_quantity(right_raw)
        if left and right and left['family'] == right['family']:
            family = left['family']
            common_unit = {'length': 'см', 'mass': 'г', 'time': 'с'}[family]
            common_factor = _geo20260416ag_measure_factor(common_unit)
            left_common = left['total'] // common_factor
            right_common = right['total'] // common_factor
            sign = _geo20260416ag_compare_sign(left['total'], right['total'])
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'1) Переводим обе величины в {common_unit}.',
                f'2) {left["pretty"]} = {left_common} {common_unit}.',
                f'3) {right["pretty"]} = {right_common} {common_unit}.',
                f'4) Сравниваем: {left_common} {common_unit} {sign} {right_common} {common_unit}.',
                f'Ответ: {left["pretty"]} {sign} {right["pretty"]}',
                'Совет: чтобы сравнить именованные величины, их переводят в одинаковые единицы',
            ]
            return _mass20260416x_finalize(lines)
    return None

def _geo20260416ag_try_geometry_extended(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = normalize_dashes(text).lower().replace('см2', 'см²').replace('см 2', 'см²')
    lower = re.sub(r'\s+', ' ', lower).strip()

    m = re.search(r'периметр прямоугольника равен (\d+) см\.?.*во сколько раз длина прямоугольника больше его ширины, если ширина равна (\d+) см', lower)
    if m:
        per = int(m.group(1)); width = int(m.group(2))
        half = per // 2
        length = half - width
        if width > 0 and length > 0 and per == 2 * (length + width) and length % width == 0:
            ratio = length // width
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: периметр прямоугольника {per} см, ширина {width} см.',
                'Что нужно найти: во сколько раз длина больше ширины.',
                f'1) У прямоугольника половина периметра равна сумме длины и ширины: {per} : 2 = {half} см.',
                f'2) Находим длину: {half} - {width} = {length} см.',
                f'3) Узнаём, во сколько раз длина больше ширины: {length} : {width} = {ratio}.',
                f'Ответ: в {ratio} раза',
                'Совет: если известен периметр прямоугольника, сначала удобно найти сумму длины и ширины',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'длина прямоугольника (\d+) см\.?.*ширина прямоугольника, если периметр (\d+) см', lower)
    if m:
        length = int(m.group(1)); per = int(m.group(2))
        half = per // 2
        width = half - length
        if width > 0 and per == 2 * (length + width):
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: длина прямоугольника {length} см, периметр {per} см.',
                'Что нужно найти: ширину прямоугольника.',
                f'1) Половина периметра равна сумме длины и ширины: {per} : 2 = {half} см.',
                f'2) Вычитаем длину: {half} - {length} = {width} см.',
                f'Ответ: {width} см',
                'Совет: у прямоугольника сумма длины и ширины равна половине периметра',
            ]
            return _mass20260416x_finalize(lines)

    m = re.search(r'длина прямоугольника (\d+) см,? а ширина в (\d+) раз[а-я]* короче.*найди (площадь|периметр) прямоугольника', lower)
    if m:
        length = int(m.group(1)); ratio = int(m.group(2)); ask = m.group(3)
        if ratio > 0 and length % ratio == 0:
            width = length // ratio
            lines = [
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: длина прямоугольника {length} см, ширина в {ratio} раза короче.',
                'Что нужно найти: ' + ('площадь прямоугольника.' if 'площад' in ask else 'периметр прямоугольника.'),
                f'1) Находим ширину: {length} : {ratio} = {width} см.',
            ]
            if 'площад' in ask:
                area = length * width
                lines += [
                    f'2) Площадь прямоугольника равна длине, умноженной на ширину: {length} × {width} = {area} см².',
                    f'Ответ: {area} см²',
                    'Совет: если одна сторона в несколько раз короче другой, меньшую сторону находят делением',
                ]
            else:
                per = 2 * (length + width)
                lines += [
                    f'2) Периметр прямоугольника: ({length} + {width}) × 2 = {per} см.',
                    f'Ответ: {per} см',
                    'Совет: если одна сторона в несколько раз короче другой, меньшую сторону находят делением',
                ]
            return _mass20260416x_finalize(lines)
    return None

_STRESS20260416AG_PREV_BUILD_EXPLANATION = build_explanation

async def build_explanation(user_text: str) -> dict:
    local = _geo20260416ag_try_named_units_extended(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    local = _geo20260416ag_try_geometry_extended(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _STRESS20260416AG_PREV_BUILD_EXPLANATION(user_text)
