"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 865-1703."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_local_equation_explanation(raw_text: str) -> Optional[str]:
    source = to_equation_source(raw_text)
    if not source:
        return None
    lhs, rhs = source.split("=", 1)
    lhs, rhs = swap_equation_sides_if_needed(lhs, rhs)
    try:
        rhs_value = Fraction(int(rhs), 1)
    except ValueError:
        return None

    patterns = [
        (r"^x\+(\d+)$", "x_plus"),
        (r"^x-(\d+)$", "x_minus"),
        (r"^x\*(\d+)$", "x_mul"),
        (r"^x/(\d+)$", "x_div"),
        (r"^(\d+)\+x$", "plus_x"),
        (r"^(\d+)-x$", "minus_x"),
        (r"^(\d+)\*x$", "mul_x"),
        (r"^(\d+)/x$", "div_x"),
    ]

    for pattern, kind in patterns:
        match = re.fullmatch(pattern, lhs)
        if not match:
            continue
        number = Fraction(int(match.group(1)), 1)
        number_text = format_fraction(number)
        rhs_text = format_fraction(rhs_value)

        if kind in {"x_plus", "plus_x"}:
            answer = rhs_value - number
            check_template = f"x + {number_text}" if kind == "x_plus" else f"{number_text} + x"
            return join_explanation_lines(
                "Ищем неизвестное слагаемое",
                f"Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: {rhs_text} - {number_text} = {format_fraction(answer)}",
                format_equation_check(check_template, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное слагаемое находим вычитанием",
            )

        if kind == "x_minus":
            answer = rhs_value + number
            return join_explanation_lines(
                "Ищем неизвестное уменьшаемое",
                f"Чтобы найти неизвестное уменьшаемое, к разности прибавляем вычитаемое: {rhs_text} + {number_text} = {format_fraction(answer)}",
                format_equation_check(f"x - {number_text}", format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное уменьшаемое находим сложением",
            )

        if kind == "minus_x":
            answer = number - rhs_value
            return join_explanation_lines(
                "Ищем неизвестное вычитаемое",
                f"Чтобы найти неизвестное вычитаемое, из уменьшаемого вычитаем разность: {number_text} - {rhs_text} = {format_fraction(answer)}",
                format_equation_check(f"{number_text} - x", format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное вычитаемое находим вычитанием",
            )

        if kind in {"x_mul", "mul_x"}:
            if number == 0:
                if rhs_value == 0:
                    return join_explanation_lines("При умножении на 0 всегда получается 0", "Значит, подходит любое число", "Ответ: подходит любое число", "Совет: 0 × любое число = 0")
                return join_explanation_lines("При умножении на 0 нельзя получить другое число", "Ответ: решения нет", "Совет: проверь уравнение ещё раз")
            answer = rhs_value / number
            check_template = f"x × {number_text}" if kind == "x_mul" else f"{number_text} × x"
            return join_explanation_lines(
                "Ищем неизвестный множитель",
                f"Чтобы найти неизвестный множитель, произведение делим на известный множитель: {rhs_text} : {number_text} = {format_fraction(answer)}",
                format_equation_check(check_template, format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестный множитель находим делением",
            )

        if kind == "x_div":
            if number == 0:
                return join_explanation_lines("На ноль делить нельзя", "Ответ: решения нет", "Совет: проверь делитель")
            answer = rhs_value * number
            return join_explanation_lines(
                "Ищем неизвестное делимое",
                f"Чтобы найти неизвестное делимое, делитель умножаем на частное: {rhs_text} × {number_text} = {format_fraction(answer)}",
                format_equation_check(f"x : {number_text}", format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестное делимое находим умножением",
            )

        if kind == "div_x":
            if rhs_value == 0:
                return join_explanation_lines("На ноль делить нельзя, а частное здесь равно 0", "Ответ: решения нет", "Совет: проверь уравнение ещё раз")
            answer = number / rhs_value
            return join_explanation_lines(
                "Ищем неизвестный делитель",
                f"Чтобы найти неизвестный делитель, делимое делим на частное: {number_text} : {rhs_text} = {format_fraction(answer)}",
                format_equation_check(f"{number_text} : x", format_fraction(answer), rhs_text),
                f"Ответ: {format_fraction(answer)}",
                "Совет: неизвестный делитель находим делением",
            )
    return None

def apply_more_less(base: int, delta: int, mode: str) -> Optional[int]:
    if mode == "больше":
        return base + delta
    result = base - delta
    return result if result >= 0 else None

def apply_times_relation(base: int, factor: int, mode: str) -> Optional[int]:
    if factor == 0:
        return None
    if mode == "больше":
        return base * factor
    if base % factor != 0:
        return None
    return base // factor

def explain_ratio_word_problem(first: int, second: int) -> Optional[str]:
    bigger = max(first, second)
    smaller = min(first, second)
    if smaller == 0:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: в задаче «во сколько раз» делим только на ненулевое число")
    if bigger % smaller != 0:
        return None
    result = bigger // smaller
    return join_explanation_lines(
        "Нужно узнать, во сколько раз одно число больше или меньше другого",
        f"Для этого большее число делим на меньшее: {bigger} : {smaller} = {result}",
        f"Ответ: {result} {plural_form(result, 'раз', 'раза', 'раз')}",
        "Совет: вопрос «во сколько раз» решаем делением",
    )




















def explain_related_quantity_and_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"Сначала находим второе количество: {base} {sign} {delta} = {related}",
        f"Потом находим всё вместе: {base} + {related} = {total}",
        f"Ответ: второе количество — {related}; всего — {total}",
        "Совет: сначала найди второе число, потом считай всё вместе",
    )

def explain_related_quantity_and_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"Сначала находим второе количество: {base} {op} {factor} = {related}",
        f"Потом находим всё вместе: {base} + {related} = {total}",
        f"Ответ: второе количество — {related}; всего — {total}",
        "Совет: сначала найди второе число, потом считай всё вместе",
    )

def explain_indirect_plus_minus_total_problem(base: int, delta: int, relation: str) -> Optional[str]:
    if relation in {"старше", "больше"}:
        other = base - delta
        if other < 0:
            return None
        sign = "-"
        relation_text = "другое число на столько же меньше"
    else:
        other = base + delta
        sign = "+"
        relation_text = "другое число на столько же больше"
    total = base + other
    return join_explanation_lines(
        f"Это косвенная форма: если здесь на {delta} {relation}, то {relation_text}",
        f"Сначала находим второе число: {base} {sign} {delta} = {other}",
        f"Потом находим всё вместе: {base} + {other} = {total}",
        f"Ответ: второе количество — {other}; всего — {total}",
        "Совет: в косвенной задаче сначала переведи её в прямую",
    )

def explain_indirect_times_total_problem(base: int, factor: int, relation: str) -> Optional[str]:
    if relation == "больше":
        if factor == 0 or base % factor != 0:
            return None
        other = base // factor
        op = ":"
        relation_text = "другое число во столько же раз меньше"
    else:
        other = base * factor
        op = "×"
        relation_text = "другое число во столько же раз больше"
    total = base + other
    return join_explanation_lines(
        f"Это косвенная форма: если здесь в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то {relation_text}",
        f"Сначала находим второе число: {base} {op} {factor} = {other}",
        f"Потом находим всё вместе: {base} + {other} = {total}",
        f"Ответ: второе количество — {other}; всего — {total}",
        "Совет: в косвенной задаче сначала переведи её в прямую",
    )







def explain_other_from_total_and_part_word_problem(total: int, known_part: int) -> Optional[str]:
    other = total - known_part
    if other < 0:
        return None
    return join_explanation_lines(
        f"Из общего количества вычитаем известную часть: {total} - {known_part} = {other}",
        f"Ответ: {other}",
        "Совет: если известно всё число и одна часть, другую часть находят вычитанием",
    )




def explain_meeting_other_speed_word_problem(total_distance: int, first_speed: int, first_path: int, distance_unit: str = "", speed_unit: str = "") -> Optional[str]:
    if first_speed == 0 or first_path % first_speed != 0:
        return None
    time_value = first_path // first_speed
    second_path = total_distance - first_path
    if time_value <= 0 or second_path < 0 or second_path % time_value != 0:
        return None
    second_speed = second_path // time_value
    answer = f"{second_speed} {speed_unit}".strip() if speed_unit else str(second_speed)
    return join_explanation_lines(
        f"Сначала находим время до встречи: {first_path} : {first_speed} = {time_value}",
        f"Потом находим путь второго участника: {total_distance} - {first_path} = {second_path}",
        f"Теперь находим его скорость: {second_path} : {time_value} = {second_speed}",
        f"Ответ: {answer}",
        "Совет: если известны путь и время, скорость находят делением",
    )

def explain_opposite_other_speed_word_problem(distance_after: int, time_value: int, first_speed: int, speed_unit: str = "") -> Optional[str]:
    if time_value == 0:
        return None
    first_path = first_speed * time_value
    second_path = distance_after - first_path
    if second_path < 0 or second_path % time_value != 0:
        return None
    second_speed = second_path // time_value
    answer = f"{second_speed} {speed_unit}".strip() if speed_unit else str(second_speed)
    return join_explanation_lines(
        f"Сначала находим путь первого участника: {first_speed} × {time_value} = {first_path}",
        f"Потом находим путь второго участника: {distance_after} - {first_path} = {second_path}",
        f"Теперь находим его скорость: {second_path} : {time_value} = {second_speed}",
        f"Ответ: {answer}",
        "Совет: если известны путь и время, скорость находят делением",
    )

def explain_meeting_distance_with_related_speed_word_problem(time_value: int, first_speed: int, delta: int, mode: str, distance_unit: str = "") -> Optional[str]:
    second_speed = apply_more_less(first_speed, delta, mode)
    if second_speed is None:
        return None
    first_path = first_speed * time_value
    second_path = second_speed * time_value
    total_distance = first_path + second_path
    answer = f"{total_distance} {distance_unit}".strip() if distance_unit else str(total_distance)
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"Сначала находим скорость второго участника: {first_speed} {sign} {delta} = {second_speed}",
        f"Потом находим путь первого участника: {first_speed} × {time_value} = {first_path}",
        f"Находим путь второго участника: {second_speed} × {time_value} = {second_path}",
        f"Теперь складываем пути: {first_path} + {second_path} = {total_distance}",
        f"Ответ: {answer}",
        "Совет: при встречном движении расстояние складывается из двух путей",
    )









def explain_unit_rate_boxes_problem(groups: int, total_amount: int, wanted_amount: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    per_group = total_amount // groups
    if per_group == 0 or wanted_amount % per_group != 0:
        return None
    result = wanted_amount // per_group
    return join_explanation_lines(
        f"Сначала находим, сколько приходится на одну группу: {total_amount} : {groups} = {per_group}",
        f"Потом узнаём, сколько групп нужно: {wanted_amount} : {per_group} = {result}",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят значение одной группы",
    )











def explain_catch_up_motion(distance: int, speed_diff: int, unit: str = "ч") -> Optional[str]:
    if speed_diff == 0 or distance % speed_diff != 0:
        return None
    time_value = distance // speed_diff
    answer = f"{time_value} {unit}".strip() if unit else str(time_value)
    return join_explanation_lines(
        "Нужно узнать, через сколько времени расстояние исчезнет",
        f"Для этого делим расстояние между объектами на скорость сближения: {distance} : {speed_diff} = {time_value}",
        f"Ответ: {answer}",
        "Совет: в задаче на догонку делят расстояние на разность скоростей",
    )

def has_word_stem(text: str, stems) -> bool:
    fragment = str(text or "").lower().replace("ё", "е")
    return any(re.search(rf"\b{re.escape(stem)}", fragment) for stem in stems)

def classify_change_fragment(fragment: str) -> Optional[str]:
    part = str(fragment or "").lower().replace("ё", "е")
    gain = has_word_stem(part, WORD_GAIN_HINTS)
    loss = has_word_stem(part, WORD_LOSS_HINTS)
    if gain and not loss:
        return "gain"
    if loss and not gain:
        return "loss"
    return None



def extract_scale_pairs(text: str):
    return [(int(match.group(1)), match.group(2)) for match in re.finditer(r"в\s+(\d+)\s+раз(?:а)?\s+(больше|меньше)", str(text or ""))]

def split_between_change_fragment(fragment: str):
    part = str(fragment or "")
    pieces = re.split(r"(?:,\s*)?(?:а\s+потом|потом|а\s+затем|затем)\b", part, maxsplit=1)
    if len(pieces) == 2:
        return pieces[0], pieces[1]
    return part, part

def try_local_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    frac = extract_fraction_pair(lower)
    numbers = extract_ordered_numbers(lower)
    if not frac or len(numbers) < 3:
        return None
    numerator, denominator = frac
    candidates = [n for n in numbers if n not in {numerator, denominator}]
    if not candidates:
        return None
    first_number = candidates[0]
    if re.search(r"это\s+\d+\s*/\s*\d+\s+(?:всего\s+)?пути|это\s+\d+\s*/\s*\d+\s+всего", lower):
        return explain_number_by_fraction_word_problem(first_number, numerator, denominator)
    if "остал" in lower:
        return explain_fraction_of_number_word_problem(first_number, numerator, denominator, ask_remaining=True)
    if contains_any_fragment(lower, ("сколько потрат", "сколько выпил", "сколько израсход", "сколько взяли", "сколько состав")):
        return explain_fraction_of_number_word_problem(first_number, numerator, denominator, ask_remaining=False)
    if "сколько" in lower:
        if "всего" in lower or "какое расстояние" in lower or "какова длина" in lower or "какое число" in lower:
            return explain_number_by_fraction_word_problem(first_number, numerator, denominator)
        return explain_fraction_of_number_word_problem(first_number, numerator, denominator, ask_remaining=False)
    return None

def try_local_motion_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None

    distance_unit = "км" if "км" in lower else "м" if re.search(r"\bм\b", lower) else ""
    time_unit = "ч" if re.search(r"\bч\b|час", lower) else "мин" if "мин" in lower else ""
    speed_unit = "км/ч" if "км/ч" in lower else "м/с" if "м/с" in lower else ("км/ч" if distance_unit == "км" and time_unit == "ч" else "")

    speed_values = [int(v) for v in re.findall(r"(\d+)\s*км/ч", lower)] or [int(v) for v in re.findall(r"скорост[ьяию][^\d]{0,20}(\d+)", lower)]
    through_match = re.search(r"через\s+(\d+)\s*(?:ч|час|мин)", lower)
    speed_delta_match = re.search(r"на\s+(\d+)\s*км/ч\s+(больше|меньше)", lower)

    if "навстречу" in lower and "расстояние между" in lower and "до встречи" in lower:
        total_match = re.search(r"расстояние между[^\d]{0,40}(\d+)", lower)
        path_match = re.search(r"прош[её]л[^\d]{0,20}(\d+)\s*(?:км|м)", lower)
        if total_match and path_match and speed_values:
            total_distance = int(total_match.group(1))
            first_path = int(path_match.group(1))
            solved = explain_meeting_other_speed_word_problem(total_distance, speed_values[0], first_path, distance_unit, speed_unit)
            if solved:
                return solved

    if "в противоположных направлениях" in lower and through_match and "расстояние между" in lower:
        distance_match = re.search(r"расстояние между[^\d]{0,40}(\d+)", lower)
        first_speed_match = re.search(r"скорост[ьяию] первого[^\d]{0,20}(\d+)", lower)
        first_speed = int(first_speed_match.group(1)) if first_speed_match else (speed_values[0] if speed_values else None)
        if distance_match and first_speed is not None:
            solved = explain_opposite_other_speed_word_problem(int(distance_match.group(1)), int(through_match.group(1)), first_speed, speed_unit)
            if solved:
                return solved

    if "навстречу" in lower and through_match and speed_delta_match and speed_values:
        delta = int(speed_delta_match.group(1))
        mode = speed_delta_match.group(2)
        solved = explain_meeting_distance_with_related_speed_word_problem(int(through_match.group(1)), speed_values[0], delta, mode, distance_unit)
        if solved:
            return solved

    if "навстречу" in lower and len(speed_values) >= 2 and through_match and not speed_delta_match:
        return explain_meeting_motion(speed_values[0], speed_values[1], int(through_match.group(1)), distance_unit)
    if "в противоположных направлениях" in lower and len(speed_values) >= 2 and through_match and not speed_delta_match:
        return explain_opposite_motion(speed_values[0], speed_values[1], int(through_match.group(1)), distance_unit)
    if contains_any_fragment(lower, ("догонит", "догонку")) and len(nums) >= 2:
        return explain_catch_up_motion(nums[0], nums[1], time_unit or "ч")

    asks_distance = contains_any_fragment(lower, ("какое расстояние", "сколько километров", "какое расстояние пройдет", "какое расстояние он пройдет"))
    asks_speed = contains_any_fragment(lower, ("с какой скоростью", "какова скорость"))
    asks_time = contains_any_fragment(lower, ("сколько часов", "сколько времени", "за какое время"))

    if asks_distance and len(nums) >= 2:
        return explain_simple_motion_distance(nums[0], nums[1], distance_unit)
    if asks_speed and len(nums) >= 2:
        return explain_simple_motion_speed(nums[1], nums[0], speed_unit)
    if asks_time and len(nums) >= 2:
        return explain_simple_motion_time(nums[1], nums[0], time_unit or "ч")
    return None

def try_local_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    if contains_any_fragment(lower, ("сколько таких коробок", "сколько можно купить", "сколько коробок можно купить")):
        return explain_price_quantity_cost_problem(nums[0], nums[1], nums[2])
    return None

def try_local_unit_rate_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None

    if contains_any_fragment(lower, ("таких же", "такие же")):
        return explain_bring_to_unit_total_word_problem(nums[0], nums[1], nums[2])

    if contains_any_fragment(lower, ("сколько потребуется коробок", "сколько коробок", "сколько пакетов", "сколько сеток")) and "руб" not in lower:
        return explain_unit_rate_boxes_problem(nums[0], nums[1], nums[2])
    return None

def try_local_proportional_division_word_problem(raw_text: str) -> Optional[str]:
    """Задачи на пропорциональное деление: купили 10 наборов голубых и 4 красных, всего 350 руб."""
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None
    match = re.search(r"(\d+)\s+(?:набор|пакет|коробк|ящик)[а-я]*\s+[а-я]+\s+и\s+(\d+)\s+(?:набор|пакет|коробк|ящик)[а-я]*\s+[а-я]+", lower)
    if not match:
        return None
    count1 = int(match.group(1))
    count2 = int(match.group(2))
    total_cost = None
    for n in nums:
        if n not in (count1, count2) and n > count1 and n > count2:
            total_cost = n
            break
    if total_cost is None:
        return None
    total_count = count1 + count2
    if total_cost % total_count != 0:
        return None
    price_per_unit = total_cost // total_count
    cost1 = price_per_unit * count1
    cost2 = price_per_unit * count2
    return join_explanation_lines(
        f"Сначала находим общее количество наборов: {count1} + {count2} = {total_count}",
        f"Потом находим цену одного набора: {total_cost} : {total_count} = {price_per_unit}",
        f"Теперь находим стоимость первых наборов: {price_per_unit} × {count1} = {cost1}",
        f"И стоимость вторых наборов: {price_per_unit} × {count2} = {cost2}",
        f"Ответ: за первые наборы заплатили {cost1}, за вторые — {cost2}",
        "Совет: в задачах на пропорциональное деление сначала находят общее количество частей",
    )

def try_local_difference_unknown_word_problem(raw_text: str) -> Optional[str]:
    """Задачи на нахождение неизвестного по двум разностям (2099-2128)."""
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None

    # Шаблон: Собрали A кг моркови и B кг картофеля. Картофеля получилось на C мешков больше.
    # Или: В первом куске A м, во втором B м, второй дороже на C руб.
    match = re.search(r"(\d+)\s+(?:кг|м|л|шт)[а-я]*\s+(?:и|,)\s+(\d+)\s+(?:кг|м|л|шт)[а-я]*", lower)
    if not match:
        return None
    val1 = int(match.group(1))
    val2 = int(match.group(2))
    diff_count = None
    # Ищем фразу "на X больше/меньше/дороже"
    diff_match = re.search(r"на\s+(\d+)\s+(?:мешков|коробок|ящиков|руб|коп|больше|меньше|дороже)", lower)
    if diff_match:
        diff_count = int(diff_match.group(1))
    if diff_count is None:
        return None
    # Определяем, что есть что: большее значение обычно картофель, но не всегда
    # Предположим, что val1 и val2 - количества, diff_count - разница в мешках/единицах
    # Тогда находим разность количеств: разность_значений = abs(val1 - val2)
    diff_value = abs(val1 - val2)
    if diff_value % diff_count != 0:
        return None
    per_unit = diff_value // diff_count
    # Теперь нужно понять, сколько единиц каждого вида
    # Обычно в задаче спрашивают "сколько было мешков картофеля и моркови"
    # val1 и val2 - общие веса, diff_count - разница в мешках
    # Тогда количество мешков = вес / per_unit
    count1 = val1 // per_unit
    count2 = val2 // per_unit
    # Но нужно угадать, где что
    if val1 > val2:
        bigger_count = count1
        smaller_count = count2
    else:
        bigger_count = count2
        smaller_count = count1

    # Формируем ответ
    if "картофел" in lower and "морков" in lower:
        name1 = "картофеля" if val1 > val2 else "моркови"
        name2 = "моркови" if val1 > val2 else "картофеля"
        return join_explanation_lines(
            f"Сначала находим, на сколько больше собрали {name1}: {max(val1, val2)} - {min(val1, val2)} = {diff_value}",
            f"Эта разница поместилась в {diff_count} мешков, значит в одном мешке {diff_value} : {diff_count} = {per_unit} кг",
            f"Теперь находим мешки {name1}: {max(val1, val2)} : {per_unit} = {max(count1, count2)}",
            f"И мешки {name2}: {min(val1, val2)} : {per_unit} = {min(count1, count2)}",
            f"Ответ: {name1} — {max(count1, count2)} мешков, {name2} — {min(count1, count2)} мешков",
            "Совет: в задачах на нахождение неизвестного по двум разностям сначала находят разность величин",
        )
    elif "кусок" in lower and "ткани" in lower or "стоит" in lower:
        return join_explanation_lines(
            f"Находим разность длин: {max(val1, val2)} - {min(val1, val2)} = {diff_value} м",
            f"Эта разница стоит {diff_count} руб., значит 1 м стоит {diff_count} : {diff_value} = {per_unit} руб.",
            f"Первый кусок: {val1} × {per_unit} = {val1 * per_unit} руб.",
            f"Второй кусок: {val2} × {per_unit} = {val2 * per_unit} руб.",
            f"Ответ: первый кусок стоит {val1 * per_unit} руб., второй — {val2 * per_unit} руб.",
            "Совет: сначала найди цену одного метра, разделив разницу в стоимости на разницу в длине",
        )
    # Общий случай
    return join_explanation_lines(
        f"Разность величин: {max(val1, val2)} - {min(val1, val2)} = {diff_value}",
        f"Эта разность соответствует {diff_count} единицам, значит на одну единицу приходится {diff_value // diff_count}",
        f"Первое количество: {val1} : {per_unit} = {count1}",
        f"Второе количество: {val2} : {per_unit} = {count2}",
        f"Ответ: {count1} и {count2}",
        "Совет: найди значение одной единицы через разность",
    )

def try_local_geometry_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    unit = geometry_unit(lower)
    nums = extract_ordered_numbers(lower)
    question_parts = [part.strip() for part in re.split(r"[?.!]", lower) if part.strip()]
    question = question_parts[-1] if question_parts else lower

    asks_perimeter = "периметр" in question or "найти периметр" in lower or "узнайте периметр" in lower
    asks_area = "площад" in question or "найти площадь" in lower or "узнайте площадь" in lower
    asks_side = any(fragment in question for fragment in ("найти сторону", "найти длину стороны", "какова сторона"))
    asks_width = any(fragment in question for fragment in ("найти ширину", "какова ширина"))
    asks_length = any(fragment in question for fragment in ("найти длину", "какова длина")) and not asks_width

    if "прямоугольник" in lower and asks_area and asks_perimeter and "со сторонами" in lower and len(nums) >= 2:
        length, width = nums[0], nums[1]
        area = length * width
        perimeter = 2 * (length + width)
        return join_explanation_lines(
            f"Сначала находим площадь: {length} × {width} = {area}",
            f"Потом находим периметр: ({length} + {width}) × 2 = {perimeter}",
            f"Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}",
            "Совет: для прямоугольника отдельно считают площадь и периметр",
        )

    perimeter_val = extract_keyword_number(lower, "периметр")
    area_val = extract_keyword_number(lower, "площад")
    length_val = extract_keyword_number(lower, "длина")
    width_val = extract_keyword_number(lower, "ширина")

    square_side_match = re.search(r"сторона квадрата[^\d]{0,80}(\d+)|квадрат[^.?!]*сторон[аы][^\d]{0,80}(\d+)", lower)
    square_side_val = int(next(group for group in square_side_match.groups() if group)) if square_side_match else None
    triangle_side_match = re.search(r"равносторонн[а-я ]*треугольник[а-я ]*сторон[аы][^\d]{0,80}(\d+)", lower)
    triangle_side_val = int(triangle_side_match.group(1)) if triangle_side_match else None

    explicit = re.search(r"периметр прямоугольника равен\s+(\d+).*?длина прямоугольника равна\s+(\d+).*?(?:найти|найдите) площадь", lower)
    if explicit:
        perimeter = int(explicit.group(1))
        length = int(explicit.group(2))
        if perimeter % 2 == 0:
            half = perimeter // 2
            width = half - length
            if width >= 0:
                area = length * width
                return join_explanation_lines(
                    "Сначала находим сумму длины и ширины",
                    f"Половина периметра равна сумме длины и ширины: {perimeter} : 2 = {half}",
                    f"Потом находим ширину: {half} - {length} = {width}",
                    f"Теперь находим площадь: {length} × {width} = {area}",
                    f"Ответ: {with_unit(area, unit, square=True)}",
                    "Совет: если известен периметр прямоугольника, сначала находят его половину",
                )

    explicit = re.search(r"площадь прямоугольника равна\s+(\d+).*?длина[^\d]{0,80}(\d+).*?(?:найти|найдите) периметр", lower)
    if explicit:
        area = int(explicit.group(1))
        length = int(explicit.group(2))
        if length != 0 and area % length == 0:
            width = area // length
            perimeter = 2 * (length + width)
            return join_explanation_lines(
                "Сначала находим ширину прямоугольника",
                f"Ширина равна площади, делённой на длину: {area} : {length} = {width}",
                f"Потом находим периметр: ({length} + {width}) × 2 = {perimeter}",
                f"Ответ: {with_unit(perimeter, unit)}",
                "Совет: если известны площадь и длина, сначала находят ширину",
            )

    explicit = re.search(r"сторона равностороннего треугольника равна\s+(\d+).*?стороны квадрата.*?периметр которого равен периметру треугольника", lower)
    if explicit:
        tri_side = int(explicit.group(1))
        tri_perimeter = tri_side * 3
        if tri_perimeter % 4 == 0:
            square_side = tri_perimeter // 4
            return join_explanation_lines(
                "Сначала находим периметр равностороннего треугольника",
                f"У треугольника три равные стороны: {tri_side} × 3 = {tri_perimeter}",
                f"Теперь находим сторону квадрата: {tri_perimeter} : 4 = {square_side}",
                f"Ответ: {with_unit(square_side, unit)}",
                "Совет: у равностороннего треугольника три равные стороны, а у квадрата четыре",
            )

    if "квадрат" in lower and asks_area and asks_perimeter and (square_side_val is not None or nums):
        side = square_side_val if square_side_val is not None else nums[0]
        area = side * side
        perimeter = side * 4
        return join_explanation_lines(
            f"Сначала находим площадь квадрата: {side} × {side} = {area}",
            f"Потом находим периметр квадрата: {side} × 4 = {perimeter}",
            f"Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}",
            "Совет: у квадрата площадь и периметр считают по стороне",
        )

    if "равносторон" in lower and "треугольник" in lower and "квадрат" in lower and "равен периметру" in lower and triangle_side_val is not None and asks_side:
        triangle_perimeter = triangle_side_val * 3
        if triangle_perimeter % 4 != 0:
            return None
        square_side = triangle_perimeter // 4
        return join_explanation_lines(
            "Сначала находим периметр равностороннего треугольника",
            f"У треугольника три равные стороны: {triangle_side_val} × 3 = {triangle_perimeter}",
            f"Теперь находим сторону квадрата: {triangle_perimeter} : 4 = {square_side}",
            f"Ответ: {with_unit(square_side, unit)}",
            "Совет: у равностороннего треугольника три равные стороны, а у квадрата четыре",
        )

    if "прямоугольник" in lower and area_val is not None and length_val is not None and asks_perimeter:
        if length_val == 0 or area_val % length_val != 0:
            return None
        width = area_val // length_val
        perimeter = 2 * (length_val + width)
        return join_explanation_lines(
            "Сначала находим ширину прямоугольника",
            f"Ширина равна площади, делённой на длину: {area_val} : {length_val} = {width}",
            f"Потом находим периметр: ({length_val} + {width}) × 2 = {perimeter}",
            f"Ответ: {with_unit(perimeter, unit)}",
            "Совет: если известны площадь и длина, сначала находят ширину",
        )

    if "прямоугольник" in lower and perimeter_val is not None and length_val is not None and asks_area:
        if perimeter_val % 2 != 0:
            return None
        half = perimeter_val // 2
        width = half - length_val
        if width < 0:
            return None
        area = length_val * width
        return join_explanation_lines(
            "Сначала находим сумму длины и ширины",
            f"Половина периметра равна сумме длины и ширины: {perimeter_val} : 2 = {half}",
            f"Потом находим ширину: {half} - {length_val} = {width}",
            f"Теперь находим площадь: {length_val} × {width} = {area}",
            f"Ответ: {with_unit(area, unit, square=True)}",
            "Совет: если известен периметр прямоугольника, сначала находят его половину",
        )

    if "квадрат" in lower and perimeter_val is not None and asks_side:
        if perimeter_val % 4 != 0:
            return None
        side = perimeter_val // 4
        return join_explanation_lines(
            "У квадрата все стороны равны",
            f"Чтобы найти сторону, делим периметр на 4: {perimeter_val} : 4 = {side}",
            f"Ответ: {with_unit(side, unit)}",
            "Совет: сторона квадрата равна периметру, делённому на 4",
        )

    if "квадрат" in lower and area_val is not None and asks_side:
        side = int(math.isqrt(area_val))
        if side * side != area_val:
            return None
        return join_explanation_lines(
            "Площадь квадрата равна стороне, умноженной на сторону",
            f"Нужно найти число, которое в квадрате даёт {area_val}",
            f"Это {side}, потому что {side} × {side} = {area_val}",
            f"Ответ: {with_unit(side, unit)}",
            "Совет: если знаешь площадь квадрата, ищи такую сторону, которая в квадрате даёт эту площадь",
        )

    if "прямоугольник" in lower and area_val is not None and length_val is not None and asks_width:
        if length_val == 0 or area_val % length_val != 0:
            return None
        width = area_val // length_val
        return join_explanation_lines(
            "Площадь прямоугольника равна длине, умноженной на ширину",
            f"Чтобы найти ширину, делим площадь на длину: {area_val} : {length_val} = {width}",
            f"Ответ: {with_unit(width, unit)}",
            "Совет: ширину находим делением площади на длину",
        )

    if "прямоугольник" in lower and area_val is not None and width_val is not None and asks_length:
        if width_val == 0 or area_val % width_val != 0:
            return None
        length = area_val // width_val
        return join_explanation_lines(
            "Площадь прямоугольника равна длине, умноженной на ширину",
            f"Чтобы найти длину, делим площадь на ширину: {area_val} : {width_val} = {length}",
            f"Ответ: {with_unit(length, unit)}",
            "Совет: длину находим делением площади на ширину",
        )

    if "квадрат" in lower and square_side_val is not None and asks_perimeter:
        result = square_side_val * 4
        return join_explanation_lines(
            "Периметр квадрата — это сумма четырёх равных сторон",
            f"Считаем: {square_side_val} × 4 = {result}",
            f"Ответ: {with_unit(result, unit)}",
            "Совет: у квадрата все четыре стороны равны",
        )

    if "прямоугольник" in lower and length_val is not None and width_val is not None and asks_perimeter:
        result = 2 * (length_val + width_val)
        return join_explanation_lines(
            "Периметр прямоугольника равен сумме длины и ширины, умноженной на 2",
            f"Сначала складываем длину и ширину: {length_val} + {width_val} = {length_val + width_val}",
            f"Потом умножаем на 2: ({length_val} + {width_val}) × 2 = {result}",
            f"Ответ: {with_unit(result, unit)}",
            "Совет: для периметра прямоугольника сначала сложи длину и ширину",
        )

    if "квадрат" in lower and square_side_val is not None and asks_area:
        result = square_side_val * square_side_val
        return join_explanation_lines(
            "Площадь квадрата равна стороне, умноженной на сторону",
            f"Считаем: {square_side_val} × {square_side_val} = {result}",
            f"Ответ: {with_unit(result, unit, square=True)}",
            "Совет: площадь квадрата — это сторона на сторону",
        )

    if "прямоугольник" in lower and length_val is not None and width_val is not None and asks_area:
        result = length_val * width_val
        return join_explanation_lines(
            "Площадь прямоугольника равна длине, умноженной на ширину",
            f"Считаем: {length_val} × {width_val} = {result}",
            f"Ответ: {with_unit(result, unit, square=True)}",
            "Совет: для площади прямоугольника умножай длину на ширину",
        )
    return None
