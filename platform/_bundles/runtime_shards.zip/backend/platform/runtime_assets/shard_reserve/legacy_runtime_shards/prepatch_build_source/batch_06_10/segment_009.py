"""Auto-generated runtime shard for prepatch_build_source.py, lines 7083-7981."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _detailed_format_equation_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_equation_source(raw_text) or normalize_cyrillic_x(strip_known_prefix(raw_text))
    variable_name = _user_final_equation_variable_name(source)
    pretty = _detailed_pretty_equation(source)
    answer = parts["answer"] or "проверь запись"
    if re.fullmatch(r"-?\d+(?:/\d+)?", answer):
        answer = f"{variable_name} = {answer}"
    lines: List[str] = [f"Уравнение: {pretty}", "Решение."]
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("equation")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _user_final_question_text(raw_text: str) -> str:
    try:
        _, question = extract_condition_and_question(raw_text)
    except Exception:
        question = ""
    return str(question or "").lower().replace("ё", "е")

def try_patch_textbook_two_products_money_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _user_final_question_text(raw_text)
    if "сколько" not in lower:
        return None
    if not contains_any_fragment(question, ("сколько денег", "сколько заплат", "сколько стоила вся покупка", "сколько стоит вся покупка", "сколько стоила покупка", "сколько стоит покупка")):
        return None

    matches = list(re.finditer(r"(\d+)\s+[^?.!,]{1,40}?\s+по\s+(\d+)\s*(?:руб|руб\.|рубля|рублей)?", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_price = int(matches[0].group(2))
    second_count = int(matches[1].group(1))
    second_price = int(matches[1].group(2))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если первая покупка состоит из {first_count} предметов по {first_price} руб., то её стоимость равна {first_count} × {first_price} = {first_total} руб.",
        f"2) Если вторая покупка состоит из {second_count} предметов по {second_price} руб., то её стоимость равна {second_count} × {second_price} = {second_total} руб.",
        f"3) Если первая покупка стоит {first_total} руб., а вторая {second_total} руб., то вся покупка стоит {first_total} + {second_total} = {total} руб.",
        f"Ответ: за всю покупку заплатили {total} руб.",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно.",
    )

def explain_piece_lengths_from_total_and_costs(total_length: int, first_cost: int, second_cost: int) -> Optional[str]:
    if total_length == 0:
        return None
    total_cost = first_cost + second_cost
    if total_cost % total_length != 0:
        return None
    unit_price = total_cost // total_length
    if unit_price == 0 or first_cost % unit_price != 0 or second_cost % unit_price != 0:
        return None
    first_length = first_cost // unit_price
    second_length = second_cost // unit_price
    return join_explanation_lines(
        f"1) Если один кусок стоит {first_cost}, а другой {second_cost}, то общая стоимость равна {first_cost} + {second_cost} = {total_cost}.",
        f"2) Если за {total_length} м заплатили {total_cost}, то один метр стоит {total_cost} : {total_length} = {unit_price}.",
        f"3) Если первый кусок стоит {first_cost}, а один метр стоит {unit_price}, то длина первого куска равна {first_cost} : {unit_price} = {first_length} м.",
        f"4) Если второй кусок стоит {second_cost}, а один метр стоит {unit_price}, то длина второго куска равна {second_cost} : {unit_price} = {second_length} м.",
        f"Ответ: в первом куске {first_length} м, во втором — {second_length} м.",
        "Совет: если у одинакового товара одна и та же цена за единицу, сначала находят цену одной единицы.",
    )

def explain_costs_from_length_difference(first_length: int, second_length: int, diff_cost: int) -> Optional[str]:
    diff_length = abs(second_length - first_length)
    if diff_length == 0 or diff_cost % diff_length != 0:
        return None
    price_per_meter = diff_cost // diff_length
    first_cost = first_length * price_per_meter
    second_cost = second_length * price_per_meter
    return join_explanation_lines(
        f"1) Если во втором куске {second_length} м ткани, а в первом {first_length} м ткани, то разность длин равна {second_length} - {first_length} = {diff_length} м.",
        f"2) Если второй кусок дороже на {diff_cost} руб. и длиннее на {diff_length} м, то один метр ткани стоит {diff_cost} : {diff_length} = {price_per_meter} руб.",
        f"3) Если в первом куске {first_length} м, а один метр стоит {price_per_meter} руб., то первый кусок стоит {first_length} × {price_per_meter} = {first_cost} руб.",
        f"4) Если во втором куске {second_length} м, а один метр стоит {price_per_meter} руб., то второй кусок стоит {second_length} × {price_per_meter} = {second_cost} руб.",
        f"Ответ: первый кусок стоит {first_cost} руб., второй — {second_cost} руб.",
        "Совет: если цена зависит от длины одинаково, сначала найди цену одной единицы длины.",
    )

def explain_masses_from_bag_difference(first_bags: int, second_bags: int, diff_mass: int) -> Optional[str]:
    diff_bags = abs(first_bags - second_bags)
    if diff_bags == 0 or diff_mass % diff_bags != 0:
        return None
    per_bag = diff_mass // diff_bags
    first_mass = first_bags * per_bag
    second_mass = second_bags * per_bag
    return join_explanation_lines(
        f"1) Если с одного участка собрали {first_bags} мешков, а с другого {second_bags} мешков, то разность мешков равна {first_bags} - {second_bags} = {diff_bags}.",
        f"2) Если {diff_bags} мешков составляют {diff_mass} кг, то в одном мешке {diff_mass} : {diff_bags} = {per_bag} кг.",
        f"3) Если на первом участке {first_bags} мешков по {per_bag} кг, то всего собрали {first_bags} × {per_bag} = {first_mass} кг.",
        f"4) Если на втором участке {second_bags} мешков по {per_bag} кг, то всего собрали {second_bags} × {per_bag} = {second_mass} кг.",
        f"Ответ: с первого участка собрали {first_mass} кг, со второго — {second_mass} кг.",
        "Совет: если известна разность по мешкам и по килограммам, сначала найди массу одного мешка.",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_patch_textbook_two_products_money_explanation(user_text)
        or _PATCH_USER_FINAL_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- USER CONSOLIDATION PATCH 2026-04-11: textbook wording, safer precedence, preserved architecture ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку «Порядок действий:».
3. Ниже пиши тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
4. Потом пиши строку «Решение по действиям:».
5. Ниже пиши действия по порядку: 1) ... 2) ... 3) ...
6. В конце пиши строку «Ответ: ...».

Для текстовых задач:
1. Сначала пиши «Задача.» и само условие без изменения чисел.
2. Потом пиши «Решение.»
3. Затем обязательно пиши «Что известно: ...» и «Что нужно найти: ...».
4. Дальше решай по действиям.
5. После каждого действия коротко говори, что нашли.
6. По возможности используй школьную форму «Если ..., то ...».
7. В конце пиши «Ответ: ...».

Для уравнений:
1. Пиши строку «Уравнение: ...».
2. Потом «Решение.»
3. Решай по шагам.
4. Обязательно пиши «Проверка: ...».
5. Потом «Ответ: ...».

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии и величин:
1. Сначала назови правило или формулу.
2. Если нужно, сначала переведи величины в одинаковые единицы.
3. Потом решай по действиям.
4. В ответе обязательно пиши единицы измерения.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Сохраняй вычисления в столбик и подробные пояснения.
Сложение или вычитание в столбик особенно уместно, если в вычислениях больше двух двузначных чисел или есть хотя бы одно трёхзначное число.
""".strip()

def explain_addition_word_problem(first: int, second: int) -> str:
    result = first + second
    return join_explanation_lines(
        "Нужно узнать, сколько всего или сколько стало.",
        f"Если первое количество равно {first}, а второе равно {second}, то всего {first} + {second} = {result}.",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько всего или сколько стало, обычно нужно сложение",
    )

def explain_subtraction_word_problem(first: int, second: int) -> str:
    result = first - second
    if result < 0:
        return ""
    return join_explanation_lines(
        "Нужно узнать, сколько осталось или сколько стало меньше.",
        f"Если сначала было {first}, а потом убрали {second}, то осталось {first} - {second} = {result}.",
        f"Ответ: {result}",
        "Совет: если что-то убрали, отдали или потратили, обычно нужно вычитание",
    )

def explain_comparison_word_problem(first: int, second: int) -> str:
    bigger = max(first, second)
    smaller = min(first, second)
    result = bigger - smaller
    return join_explanation_lines(
        "Нужно узнать, на сколько одно число больше или меньше другого.",
        f"Для этого из большего числа вычитаем меньшее: {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: вопрос «на сколько» решают вычитанием",
    )

def explain_find_initial_after_loss_problem(remaining: int, removed: int) -> str:
    result = remaining + removed
    return join_explanation_lines(
        "Нужно узнать, сколько было сначала.",
        f"Если осталось {remaining}, а убрали {removed}, то сначала было {remaining} + {removed} = {result}.",
        f"Ответ: {result}",
        "Совет: неизвестное уменьшаемое находят сложением",
    )

def explain_find_initial_after_gain_problem(final_total: int, added: int) -> str:
    result = final_total - added
    if result < 0:
        return ""
    return join_explanation_lines(
        "Нужно узнать, сколько было сначала.",
        f"Если стало {final_total} после того, как прибавили {added}, то сначала было {final_total} - {added} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы найти число до прибавления, из нового числа вычитают то, что прибавили",
    )

def explain_find_added_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        "Нужно узнать, сколько добавили.",
        f"Сравниваем, сколько было и сколько стало: {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
    )

def explain_find_removed_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        "Нужно узнать, сколько убрали.",
        f"Из того, что было, вычитаем то, что осталось: {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
    )

def explain_multiplication_word_problem(groups: int, per_group: int) -> str:
    result = groups * per_group
    return join_explanation_lines(
        "Нужно узнать, сколько всего предметов в одинаковых группах.",
        f"Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {result}.",
        f"Ответ: {result}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def explain_sharing_word_problem(total: int, groups: int) -> Optional[str]:
    if groups == 0:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: проверь, на сколько частей делят")
    quotient, remainder = divmod(total, groups)
    if remainder == 0:
        return join_explanation_lines(
            "Нужно узнать, сколько получит каждый.",
            f"Если {total} предметов разделили на {groups} равные части, то {total} : {groups} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: слова «поровну» и «каждый» подсказывают деление",
        )
    return join_explanation_lines(
        "Нужно разделить поровну.",
        f"Делим: {total} : {groups} = {quotient}, остаток {remainder}.",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: остаток всегда должен быть меньше делителя",
    )

def explain_group_count_word_problem(total: int, per_group: int, needs_extra_group: bool = False, explicit_remainder: bool = False) -> Optional[str]:
    if per_group == 0:
        return join_explanation_lines("В одной группе не может быть 0 предметов", "Ответ: запись задачи неверная", "Совет: проверь размер одной группы")
    quotient, remainder = divmod(total, per_group)
    if remainder == 0:
        return join_explanation_lines(
            "Нужно узнать, сколько групп получится.",
            f"Если всего {total} предметов, а в одной группе по {per_group}, то групп будет {total} : {per_group} = {quotient}.",
            f"Ответ: {quotient}",
            "Совет: число групп находят делением",
        )
    if needs_extra_group:
        return join_explanation_lines(
            f"Сначала находим, сколько полных групп получится: {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"Так как предметы ещё остались, нужна ещё одна группа, всего {quotient + 1}.",
            f"Ответ: {quotient + 1}",
            "Совет: если после деления ещё есть остаток, иногда нужна ещё одна коробка или место",
        )
    if explicit_remainder:
        return join_explanation_lines(
            "Нужно узнать, сколько полных групп получится.",
            f"Делим: {total} : {per_group} = {quotient}, остаток {remainder}.",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше размера одной группы",
        )
    return None

def explain_related_quantity_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    result = apply_more_less(base, delta, mode)
    if result is None:
        return None
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        "Сначала нужно найти второе количество.",
        f"Если второе количество на {delta} {mode}, то считаем так: {base} {sign} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: если число на несколько единиц больше, прибавляют; если меньше, вычитают",
    )

def explain_related_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"Сначала находим второе количество: {base} {sign} {delta} = {related}.",
        f"Потом находим всё вместе: {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: в составной задаче сначала находят неизвестное количество, потом сумму",
    )

def explain_related_quantity_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    result = apply_times_relation(base, factor, mode)
    if result is None:
        return None
    op = "×" if mode == "больше" else ":"
    return join_explanation_lines(
        "Сначала нужно найти второе количество.",
        f"Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то считаем так: {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: если число в несколько раз больше, умножают; если в несколько раз меньше, делят",
    )

def explain_related_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"Сначала находим второе количество: {base} {op} {factor} = {related}.",
        f"Потом находим всё вместе: {base} + {related} = {total}.",
        f"Ответ: {total}",
        "Совет: сначала найди число, которое дано через отношение, потом считай общее количество",
    )

def explain_indirect_plus_minus_problem(base: int, delta: int, relation: str) -> Optional[str]:
    if relation in {"старше", "больше"}:
        result = base - delta
        if result < 0:
            return None
        relation_text = "другое число на столько же меньше"
        op = "-"
    else:
        result = base + delta
        relation_text = "другое число на столько же больше"
        op = "+"
    return join_explanation_lines(
        f"Это задача в косвенной форме: если здесь на {delta} {relation}, то {relation_text}.",
        f"Значит, искомое число равно {base} {op} {delta} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переведи условие в прямую форму",
    )

def explain_indirect_times_problem(base: int, factor: int, relation: str) -> Optional[str]:
    if relation == "больше":
        if factor == 0 or base % factor != 0:
            return None
        result = base // factor
        op = ":"
        relation_text = "другое число во столько же раз меньше"
    else:
        result = base * factor
        op = "×"
        relation_text = "другое число во столько же раз больше"
    return join_explanation_lines(
        f"Это задача в косвенной форме: если здесь в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то {relation_text}.",
        f"Значит, искомое число равно {base} {op} {factor} = {result}.",
        f"Ответ: {result}",
        "Совет: в косвенной задаче сначала переведи условие в прямую форму",
    )

def explain_bring_to_unit_total_word_problem(groups: int, total_amount: int, target_groups: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    one_group = total_amount // groups
    result = one_group * target_groups
    return join_explanation_lines(
        f"1) Если в {groups} группах {total_amount}, то в одной группе {total_amount} : {groups} = {one_group}.",
        f"2) Если в одной группе {one_group}, то в {target_groups} таких же группах {one_group} × {target_groups} = {result}.",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну группу",
    )

def explain_simple_motion_distance(speed: int, time_value: int, unit: str = "") -> str:
    result = speed * time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "Нужно найти расстояние.",
        "Пользуемся правилом: расстояние равно скорости, умноженной на время.",
        f"Считаем: {speed} × {time_value} = {result}.",
        f"Ответ: {answer}",
        "Совет: чтобы найти расстояние, скорость умножают на время",
    )

def explain_simple_motion_speed(distance: int, time_value: int, unit: str = "") -> Optional[str]:
    if time_value == 0 or distance % time_value != 0:
        return None
    result = distance // time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "Нужно найти скорость.",
        "Пользуемся правилом: скорость равна расстоянию, делённому на время.",
        f"Считаем: {distance} : {time_value} = {result}.",
        f"Ответ: {answer}",
        "Совет: чтобы найти скорость, расстояние делят на время",
    )

def explain_simple_motion_time(distance: int, speed: int, unit: str = "") -> Optional[str]:
    if speed == 0 or distance % speed != 0:
        return None
    result = distance // speed
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "Нужно найти время.",
        "Пользуемся правилом: время равно расстоянию, делённому на скорость.",
        f"Считаем: {distance} : {speed} = {result}.",
        f"Ответ: {answer}",
        "Совет: чтобы найти время, расстояние делят на скорость",
    )

def try_local_expression_explanation(raw_text: str) -> Optional[str]:
    source = to_expression_source(raw_text)
    if not source:
        return None
    node = parse_expression_ast(source)
    if node is None:
        return None

    # Важно: цепочку сложения упрощаем только без скобок, чтобы не ломать школьный порядок действий.
    if "(" not in source and ")" not in source:
        add_chain = flatten_add_chain(node)
        if add_chain and all(n >= 0 for n in add_chain):
            if should_use_column_for_sum(add_chain):
                return explain_column_addition(add_chain)
            if len(add_chain) == 2:
                return explain_simple_addition(add_chain[0], add_chain[1])
            current = add_chain[0]
            lines = ["Нужно найти сумму нескольких чисел."]
            for idx, n in enumerate(add_chain[1:], start=1):
                new_total = current + n
                if idx == 1:
                    lines.append(f"Сначала складываем: {current} + {n} = {new_total}.")
                elif idx == 2:
                    lines.append(f"Потом складываем: {current} + {n} = {new_total}.")
                else:
                    lines.append(f"Дальше складываем: {current} + {n} = {new_total}.")
                current = new_total
            lines.extend([f"Ответ: {current}", "Совет: при нескольких действиях считай по порядку"])
            return join_explanation_lines(*lines)

    simple = try_simple_binary_int_expression(node)
    if simple:
        operator = simple["operator"]
        left = simple["left"]
        right = simple["right"]
        if operator is ast.Add:
            return explain_simple_addition(left, right)
        if operator is ast.Sub:
            return explain_simple_subtraction(left, right)
        if operator is ast.Mult:
            return explain_simple_multiplication(left, right)
        if operator is ast.Div:
            return explain_simple_division(left, right)

    try:
        value, steps = build_eval_steps(node, source)
    except ZeroDivisionError:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: сначала смотри на делитель")
    except Exception:
        return None

    if not steps:
        return None

    body_lines = []
    has_brackets = "(" in source or ")" in source
    for index, step in enumerate(steps, start=1):
        text = f"{step['left']} {step['operator']} {step['right']} = {step['result']}"
        if index == 1 and has_brackets and len(steps) > 1:
            body_lines.append(f"{index}) Сначала выполняем действие в скобках: {text}")
        elif index == 1:
            body_lines.append(f"{index}) Сначала {step['verb']}: {text}")
        elif index == 2:
            body_lines.append(f"{index}) Потом {step['verb']}: {text}")
        else:
            body_lines.append(f"{index}) Дальше {step['verb']}: {text}")

    answer = format_fraction(value)
    advice = "сначала выполняй умножение и деление, потом сложение и вычитание" if re.search(r"[+\-].*[*/]|[*/].*[+\-]", source) else default_advice("expression")
    return join_explanation_lines(*body_lines, f"Ответ: {answer}", f"Совет: {advice}")

# --- USER TEXTBOOK PATCH 2026-04-11B: shelf/book templates from the uploaded methodology ---

def _user_patch_lower_text_20260411b(raw_text: str) -> str:
    return normalize_word_problem_text(raw_text).lower().replace("ё", "е")

def _user_patch_books_word_20260411b(count: int) -> str:
    return plural_form(count, "книга", "книги", "книг")

def try_user_patch_shelf_total_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*(обеих|двух) полк", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,40}на второй(?: полке)?(?: было)?\s*(\d+)\b", lower)
    if not match:
        return None
    first = int(match.group(1))
    second = int(match.group(2))
    total = first + second
    return join_explanation_lines(
        f"1) Если на первой полке было {first} {_user_patch_books_word_20260411b(first)}, а на второй {second} {_user_patch_books_word_20260411b(second)}, то на обеих полках было {first} + {second} = {total} книг.",
        f"Ответ: на двух полках было {total} книг.",
        "Совет: если спрашивают, сколько на обеих полках, складывают количества на первой и второй полке.",
    )

def try_user_patch_shelf_more_less_total_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*(обеих|двух) полк", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,40}на второй(?: полке)?\s*на\s*(\d+)\s*(больше|меньше)", lower)
    if not match:
        return None
    first = int(match.group(1))
    delta = int(match.group(2))
    mode = match.group(3)
    second = first + delta if mode == "больше" else first - delta
    if second < 0:
        return None
    total = first + second
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если на первой полке {first} {_user_patch_books_word_20260411b(first)}, а на второй на {delta} {mode}, то на второй полке было {first} {sign} {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
        f"2) Если на первой полке {first} {_user_patch_books_word_20260411b(first)}, а на второй {second} {_user_patch_books_word_20260411b(second)}, то на двух полках было {first} + {second} = {total} книг.",
        f"Ответ: на двух полках было {total} книг.",
        "Совет: в составной задаче сначала находят неизвестное количество, потом сумму.",
    )

def try_user_patch_shelf_unknown_second_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*второй полке", lower):
        return None
    match = re.search(r"на двух полках(?: было)?\s*(\d+)\s*книг[^\d]{0,80}на первой полке(?: было)?\s*(\d+)\s*книг", lower)
    if not match:
        return None
    total = int(match.group(1))
    first = int(match.group(2))
    second = total - first
    if second < 0:
        return None
    return join_explanation_lines(
        f"1) Если на двух полках было {total} книг, а на первой полке было {first} {_user_patch_books_word_20260411b(first)}, то на второй полке было {total} - {first} = {second} {_user_patch_books_word_20260411b(second)}.",
        f"Ответ: на второй полке было {second} {_user_patch_books_word_20260411b(second)}.",
        "Совет: чтобы найти, сколько было на второй полке, из общего количества вычитают количество на первой полке.",
    )

def try_user_patch_shelf_indirect_explanation_20260411b(raw_text: str) -> Optional[str]:
    lower = _user_patch_lower_text_20260411b(raw_text)
    if not ("полке" in lower and "книг" in lower):
        return None
    if not re.search(r"сколько[^.?!]*второй полке", lower):
        return None
    match = re.search(r"на первой полке(?: было)?\s*(\d+)\s*книг[^\d]{0,30}это\s+на\s*(\d+)\s*книг[^\d]{0,20}(больше|меньше),?\s+чем\s+на\s+второй", lower)
    if match:
        first = int(match.group(1))
        delta = int(match.group(2))
        relation = match.group(3)
        if relation == "больше":
            second = first - delta
            if second < 0:
                return None
            return join_explanation_lines(
                f"1) Если на первой полке книг на {delta} больше, чем на второй, то на второй полке книг на {delta} меньше, чем на первой.",
                f"2) Если на первой полке {first} книг, а на второй на {delta} меньше, то на второй полке было {first} - {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
                f"Ответ: на второй полке было {second} {_user_patch_books_word_20260411b(second)}.",
                "Совет: в косвенной задаче сначала переведи условие в прямую форму.",
            )
        second = first + delta
        return join_explanation_lines(
            f"1) Если на первой полке книг на {delta} меньше, чем на второй, то на второй полке книг на {delta} больше, чем на первой.",
            f"2) Если на первой полке {first} книг, а на второй на {delta} больше, то на второй полке было {first} + {delta} = {second} {_user_patch_books_word_20260411b(second)}.",
            f"Ответ: на второй полке было {second} книг.",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму.",
        )

    match = re.search(r"на второй полке(?: было)?\s*(\d+)\s*книг[^\d]{0,30}это\s+в\s*(\d+)\s*раз(?:а)?\s*больше,?\s+чем\s+на\s+первой", lower)
    if match:
        second = int(match.group(1))
        factor = int(match.group(2))
        if factor == 0 or second % factor != 0:
            return None
        first = second // factor
        return join_explanation_lines(
            f"1) Если на второй полке книг в {factor} раза больше, чем на первой, то на первой полке книг в {factor} раза меньше, чем на второй.",
            f"2) Если на второй полке {second} книг, а на первой в {factor} раза меньше, то на первой полке было {second} : {factor} = {first} {_user_patch_books_word_20260411b(first)}.",
            f"Ответ: на первой полке было {first} {_user_patch_books_word_20260411b(first)}.",
            "Совет: если сказано «в несколько раз больше» в косвенной форме, сначала переведи это в «в несколько раз меньше».",
        )
    return None

__OAI_20260411_USER_PREV_BUILD_LOCAL_SAFE = build_explanation_local_first

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_user_patch_shelf_total_explanation_20260411b(user_text)
        or try_user_patch_shelf_more_less_total_explanation_20260411b(user_text)
        or try_user_patch_shelf_unknown_second_explanation_20260411b(user_text)
        or try_user_patch_shelf_indirect_explanation_20260411b(user_text)
        or __OAI_20260411_USER_PREV_BUILD_LOCAL_SAFE(user_text, kind)
    )

# --- OAI FINAL CLEAN PATCH 2026-04-11C: formatting cleanup, stable compare answers, textbook polish ---

_OAI_20260411C_PREV_EXPLAIN_PRICE_DIFFERENCE = explain_price_difference_problem
_OAI_20260411C_PREV_DETAILED_FORMAT_EXPRESSION = _detailed_format_expression_solution
_OAI_20260411C_PREV_DETAILED_FORMAT_SOLUTION = _detailed_format_solution

def explain_price_difference_problem(quantity: int, total_a: int, total_b: int) -> Optional[str]:
    if quantity == 0 or total_a % quantity != 0 or total_b % quantity != 0:
        return None
    price_a = total_a // quantity
    price_b = total_b // quantity
    diff = abs(price_a - price_b)
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых товаров заплатили {total_a} руб., то цена одного товара равна {total_a} : {quantity} = {price_a} руб",
        f"2) Если за {quantity} таких же товаров заплатили {total_b} руб., то цена одного товара равна {total_b} : {quantity} = {price_b} руб",
        f"3) Сравниваем цены: {max(price_a, price_b)} - {min(price_a, price_b)} = {diff} руб",
        f"Ответ: цены отличаются на {diff} руб",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

def _oai_20260411c_expression_body_lines(body_lines: List[str]) -> List[str]:
    cleaned: List[str] = []
    seen = set()
    for raw in body_lines:
        line = str(raw or "").strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("частное:"):
            continue
        if lower.startswith("пример:"):
            continue
        key = lower.rstrip(". ")
        if key in seen:
            continue
        seen.add(key)
        cleaned.append(line)
    return cleaned

def _oai_20260411c_pretty_expr_with_map(source: str) -> Tuple[str, dict]:
    pretty_parts: List[str] = []
    op_map = {}
    current_len = 0
    for index, ch in enumerate(source):
        if ch in "+-*/":
            symbol = "×" if ch == "*" else ":" if ch == "/" else ch
            token = f" {symbol} "
            pretty_parts.append(token)
            op_map[index] = current_len + 1
            current_len += len(token)
        else:
            pretty_parts.append(ch)
            current_len += 1
    return "".join(pretty_parts), op_map

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")

    node = parse_expression_ast(source)
    if node is not None:
        pretty_expression = render_node(node)
    else:
        pretty_expression, _ = _oai_20260411c_pretty_expr_with_map(source)

    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = _oai_20260411c_expression_body_lines(parts["body"])
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]

    if _detailed_is_column_like(body_lines) or any("столбик" in line.lower() for line in body_lines):
        lines.append("Решение.")
        before_expl: List[str] = []
        expl: List[str] = []
        in_expl = False
        for line in body_lines:
            low = line.lower()
            if low.startswith("пояснение"):
                in_expl = True
                continue
            if not in_expl:
                before_expl.append(line)
            else:
                expl.append(line)
        if before_expl:
            lines.extend(before_expl)
        if expl:
            lines.append("Пояснение по шагам:")
            lines.extend(_detailed_number_lines(expl))
        else:
            remaining = [line for line in body_lines if not line.lower().startswith("запись столбиком")]
            lines.extend(_detailed_number_lines(remaining))
    else:
        order_block = _detailed_build_order_block(source)
        if order_block:
            lines.extend(order_block)
            lines.append("Решение по действиям:")
        else:
            lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))

    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_solution(raw_text: str, text: str, kind: str) -> str:
    if kind == "expression" and to_expression_source(raw_text):
        return _detailed_format_expression_solution(raw_text, text)
    return _OAI_20260411C_PREV_DETAILED_FORMAT_SOLUTION(raw_text, text, kind)

# --- OAI FINAL CLEAN PATCH 2026-04-11D: preferred routing for price tasks and cleaner column formatting ---

_OAI_20260411D_PREV_BUILD_LOCAL = build_explanation_local_first

def _oai_20260411d_is_visual_column_line(line: str) -> bool:
    value = str(line or "").strip()
    if not value:
        return False
    if re.search(r"[А-Яа-яЁё]", value):
        return False
    return True

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")

    node = parse_expression_ast(source)
    if node is not None:
        pretty_expression = render_node(node)
    else:
        pretty_expression, _ = _oai_20260411c_pretty_expr_with_map(source)

    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = _oai_20260411c_expression_body_lines(parts["body"])
    if not body_lines:
        body_lines = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]

    if body_lines and body_lines[0].lower().startswith("запись столбиком"):
        lines.append("Решение.")
        lines.append("Запись столбиком:")
        visual_lines: List[str] = []
        idx = 1
        while idx < len(body_lines):
            current = body_lines[idx]
            lower = current.lower()
            if lower.startswith("частное:"):
                idx += 1
                continue
            if _oai_20260411d_is_visual_column_line(current):
                visual_lines.append(current)
                idx += 1
                continue
            break
        lines.extend(visual_lines)
        expl_lines = [line for line in body_lines[idx:] if not line.lower().startswith("частное:")]
        if expl_lines:
            lines.append("Пояснение по шагам:")
            lines.extend(_detailed_number_lines(expl_lines))
    elif _detailed_is_column_like(body_lines) or any("столбик" in line.lower() for line in body_lines):
        lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))
    else:
        order_block = _detailed_build_order_block(source)
        if order_block:
            lines.extend(order_block)
            lines.append("Решение по действиям:")
        else:
            lines.append("Решение.")
        lines.extend(_detailed_number_lines(body_lines))

    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def try_oai_20260411d_price_difference_first(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3:
        return None
    if contains_any_fragment(lower, ("за столько же", "на сколько пакет", "на сколько дороже", "на сколько дешевле")):
        return explain_price_difference_problem(nums[0], nums[1], nums[2])
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_user_patch_shelf_total_explanation_20260411b(user_text)
        or try_user_patch_shelf_more_less_total_explanation_20260411b(user_text)
        or try_user_patch_shelf_unknown_second_explanation_20260411b(user_text)
        or try_user_patch_shelf_indirect_explanation_20260411b(user_text)
        or try_oai_20260411d_price_difference_first(user_text)
        or try_local_price_word_problem_explanation(user_text)
        or _OAI_20260411D_PREV_BUILD_LOCAL(user_text, kind)
    )

# --- FINAL USER PATCH 2026-04-11ZZ: fuller counted answers + mixed-unit same-time motion + cleaner fraction-whole wording ---

_FINAL_USER_PATCH_PREV_BUILD_EXPLANATION_LOCAL_FIRST_ZZ = build_explanation_local_first
_FINAL_USER_PATCH_PREV_DETAILED_MAYBE_ENRICH_ANSWER_ZZ = _detailed_maybe_enrich_answer
