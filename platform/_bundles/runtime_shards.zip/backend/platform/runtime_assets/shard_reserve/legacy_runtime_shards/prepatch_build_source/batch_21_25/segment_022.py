"""Auto-generated runtime shard for prepatch_build_source.py, lines 18503-19363."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _mass20260416x_try_basic_geometry(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.fullmatch(r'начерти отрезок длиной (\d+) см\.?', lower)
    if m:
        length = int(m.group(1))
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: нужно начертить отрезок длиной {length} см.',
            'Что нужно сделать: построить отрезок нужной длины.',
            '1) Поставь первую точку.',
            f'2) По линейке отложи {length} см и поставь вторую точку.',
            '3) Соедини точки линейкой.',
            f'Ответ: получится отрезок длиной {length} см',
            'Совет: длину отрезка удобно откладывать по линейке от нулевой отметки',
        ]
        return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'начерти отрезок на (\d+) см длиннее, чем (\d+) см\.?', lower)
    if m:
        delta = int(m.group(1)); base = int(m.group(2)); length = base + delta
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: нужно начертить отрезок на {delta} см длиннее, чем {base} см.',
            'Что нужно найти: длину нового отрезка.',
            f'1) Находим длину нового отрезка: {base} + {delta} = {length} см.',
            f'2) Теперь по линейке чертим отрезок длиной {length} см.',
            f'Ответ: нужно начертить отрезок длиной {length} см',
            'Совет: если отрезок длиннее на несколько сантиметров, эти сантиметры прибавляют',
        ]
        return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'(?:построй|начерти) отрезок, который короче (\d+) см на (\d+) см\.?', lower)
    if m:
        base = int(m.group(1)); delta = int(m.group(2)); length = base - delta
        lines = [
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: новый отрезок короче {base} см на {delta} см.',
            'Что нужно найти: длину нового отрезка.',
            f'1) Находим длину нового отрезка: {base} - {delta} = {length} см.',
            f'2) Теперь по линейке строим отрезок длиной {length} см.',
            f'Ответ: нужно начертить отрезок длиной {length} см',
            'Совет: если отрезок короче на несколько сантиметров, эти сантиметры вычитают',
        ]
        return _mass20260416x_finalize(lines)

    if 'сколько углов у квадрата' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'У квадрата четыре стороны и четыре угла.',
            'Ответ: 4 угла',
            'Совет: у квадрата все углы прямые, и их всегда четыре',
        ])

    if '3 стороны' in lower and '3 угла' in lower and 'назови фигуру' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'Фигура с тремя сторонами и тремя углами называется треугольником.',
            'Ответ: треугольник',
            'Совет: количество сторон и углов у многоугольника одинаковое',
        ])

    m = re.fullmatch(r'начерти прямоугольник со сторонами (\d+) см и (\d+) см\.?', lower)
    if m:
        a = int(m.group(1)); b = int(m.group(2))
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: стороны прямоугольника равны {a} см и {b} см.',
            'Что нужно сделать: начертить такой прямоугольник.',
            f'1) Построй одну сторону длиной {a} см.',
            f'2) От её концов построй стороны по {b} см.',
            f'3) Соедини концы и получи прямоугольник {a} см на {b} см.',
            f'Ответ: прямоугольник со сторонами {a} см и {b} см',
            'Совет: у прямоугольника противоположные стороны равны, а все углы прямые',
        ])

    if 'чем отличается круг от овала' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'Круг одинаково широкий во все стороны от центра.',
            'Овал вытянут: в одном направлении он длиннее, чем в другом.',
            'Ответ: круг круглый во все стороны одинаково, а овал вытянут',
            'Совет: если фигура вытянута, это овал, а не круг',
        ])

    if 'ломаную из 3 звеньев' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'Ломаная из 3 звеньев состоит из трёх отрезков.',
            '1) Начерти первый отрезок.',
            '2) От его конца начерти второй отрезок в другом направлении.',
            '3) От конца второго начерти третий отрезок.',
            'Ответ: получится ломаная из 3 звеньев',
            'Совет: звено ломаной — это один её отрезок',
        ])

    if 'сколько вершин у куба' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'У куба восемь вершин.',
            'Ответ: 8 вершин',
            'Совет: вершина — это угол фигуры, где встречаются рёбра',
        ])

    if 'похожий на шар' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            'На шар похож, например, мяч.',
            'Ответ: мяч',
            'Совет: шар — это объёмная круглая фигура',
        ])

    m = re.fullmatch(r'начерти прямоугольник с периметром (\d+) см\.?', lower)
    if m:
        per = int(m.group(1))
        if per < 6 or per % 2:
            return None
        a = per // 4 + 1
        b = per // 2 - a
        if b <= 0:
            a, b = per // 4, per // 4
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: периметр прямоугольника равен {per} см.',
            'Что нужно сделать: выбрать такие длину и ширину, чтобы сумма длин всех сторон была равна этому числу.',
            f'1) Например, возьмём стороны {a} см и {b} см.',
            f'2) Проверяем: ({a} + {b}) × 2 = {per} см.',
            f'Ответ: можно начертить прямоугольник со сторонами {a} см и {b} см',
            'Совет: у прямоугольника периметр равен сумме длины и ширины, умноженной на 2',
        ])

    m = re.fullmatch(r'начерти квадрат площадью (\d+) см²\.?', lower)
    if m:
        area = int(m.group(1))
        side = int(math.isqrt(area))
        if side * side != area:
            return None
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: площадь квадрата равна {area} см².',
            'Что нужно найти: длину стороны квадрата.',
            f'1) У квадрата площадь равна стороне, умноженной на такую же сторону.',
            f'2) Ищем число, которое при умножении само на себя даёт {area}. Это {side}.',
            f'3) Значит, нужно начертить квадрат со стороной {side} см.',
            f'Ответ: квадрат со стороной {side} см',
            'Совет: площадь квадрата равна a × a',
        ])
    return None

def _mass20260416x_try_named_units(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text).lower().replace('−', '-').replace('–', '-')
    clean = text.replace('…', '').replace('?', '').strip()

    m = re.fullmatch(r'(\d+)\s*дм\s*(\d+)\s*см\s*=\s*см\.?', clean)
    if m:
        dm, cm = map(int, m.groups()); total = dm * 10 + cm
        return _mass20260416x_finalize([
            f'Пример: {dm} дм {cm} см = {total} см.',
            'Решение.',
            f'1) В 1 дм 10 см.',
            f'2) {dm} дм = {dm * 10} см.',
            f'3) {dm * 10} см + {cm} см = {total} см.',
            f'Ответ: {total} см',
            'Совет: крупную единицу удобно сначала перевести в меньшую',
        ])

    m = re.fullmatch(r'(\d+)\s*см\s*=\s*дм\.?', clean)
    if m:
        cm = int(m.group(1)); dm = cm // 10
        return _mass20260416x_finalize([
            f'Пример: {cm} см = {dm} дм.',
            'Решение.',
            '1) В 1 дм 10 см.',
            f'2) {cm} : 10 = {dm}.',
            f'Ответ: {dm} дм',
            'Совет: чтобы перевести сантиметры в дециметры, делят на 10',
        ])

    m = re.fullmatch(r'(\d+)\s*ч\s*(\d+)\s*мин\s*=\s*мин\.?', clean)
    if m:
        h, minute = map(int, m.groups()); total = h * 60 + minute
        return _mass20260416x_finalize([
            f'Пример: {h} ч {minute} мин = {total} мин.',
            'Решение.',
            '1) В 1 часе 60 минут.',
            f'2) {h} ч = {h * 60} мин.',
            f'3) {h * 60} мин + {minute} мин = {total} мин.',
            f'Ответ: {total} мин',
            'Совет: часы в минуты переводят умножением на 60',
        ])

    m = re.fullmatch(r'(\d+)\s*мин\s*([+\-])\s*(\d+)\s*мин\s*=\s*ч\s*мин\.?', clean)
    if m:
        a, op, b = m.groups(); a = int(a); b = int(b); total = a + b if op == '+' else a - b
        h, minute = divmod(total, 60)
        return _mass20260416x_finalize([
            f'Пример: {a} мин {op} {b} мин = {h} ч {minute} мин.',
            'Решение.',
            f'1) Выполняем действие в минутах: {a} {op} {b} = {total} мин.',
            f'2) Переводим {total} мин в часы и минуты: {h} ч {minute} мин.',
            f'Ответ: {h} ч {minute} мин',
            'Совет: если минут больше 60, выделяют полные часы',
        ])

    m = re.fullmatch(r'(\d+)\s*кг\s*-\s*(\d+)\s*г\s*=\s*г\.?', clean)
    if m:
        kg, g = map(int, m.groups()); total = kg * 1000 - g
        return _mass20260416x_finalize([
            f'Пример: {kg} кг - {g} г = {total} г.',
            'Решение.',
            '1) В 1 кг 1000 г.',
            f'2) {kg} кг = {kg * 1000} г.',
            f'3) {kg * 1000} г - {g} г = {total} г.',
            f'Ответ: {total} г',
            'Совет: килограммы в граммы переводят умножением на 1000',
        ])

    m = re.fullmatch(r'(\d+)\s*дм\s*(\d+)\s*см\s*\+\s*(\d+)\s*дм\s*(\d+)\s*см\s*=\s*дм\s*см\.?', clean)
    if m:
        d1, c1, d2, c2 = map(int, m.groups()); total = d1 * 10 + c1 + d2 * 10 + c2; d, c = divmod(total, 10)
        return _mass20260416x_finalize([
            f'Пример: {d1} дм {c1} см + {d2} дм {c2} см = {d} дм {c} см.',
            'Решение.',
            f'1) Переводим первое число в сантиметры: {d1} дм {c1} см = {d1 * 10 + c1} см.',
            f'2) Переводим второе число в сантиметры: {d2} дм {c2} см = {d2 * 10 + c2} см.',
            f'3) Складываем: {d1 * 10 + c1} + {d2 * 10 + c2} = {total} см.',
            f'4) Переводим обратно: {total} см = {d} дм {c} см.',
            f'Ответ: {d} дм {c} см',
            'Совет: именованные числа удобно сначала переводить в меньшую единицу',
        ])

    m = re.fullmatch(r'(\d+)\s*мин\s*=\s*ч\s*мин\.?', clean)
    if m:
        total = int(m.group(1)); h, minute = divmod(total, 60)
        return _mass20260416x_finalize([
            f'Пример: {total} мин = {h} ч {minute} мин.',
            'Решение.',
            f'1) Делим {total} на 60: {total} : 60 = {h} ч и {minute} мин в остатке.',
            f'Ответ: {h} ч {minute} мин',
            'Совет: чтобы минуты перевести в часы и минуты, делят на 60',
        ])

    m = re.fullmatch(r'(\d+)\s*м\s*-\s*(\d+)\s*дм\s*=\s*дм\.?', clean)
    if m:
        mtr, dm = map(int, m.groups()); total = mtr * 10 - dm
        return _mass20260416x_finalize([
            f'Пример: {mtr} м - {dm} дм = {total} дм.',
            'Решение.',
            '1) В 1 м 10 дм.',
            f'2) {mtr} м = {mtr * 10} дм.',
            f'3) {mtr * 10} дм - {dm} дм = {total} дм.',
            f'Ответ: {total} дм',
            'Совет: метры в дециметры переводят умножением на 10',
        ])

    m = re.fullmatch(r'(\d+)\s*кг\s*(\d+)\s*г\s*-\s*(\d+)\s*кг\s*(\d+)\s*г\s*=\s*г\.?', clean)
    if m:
        k1, g1, k2, g2 = map(int, m.groups()); total = (k1 * 1000 + g1) - (k2 * 1000 + g2)
        return _mass20260416x_finalize([
            f'Пример: {k1} кг {g1} г - {k2} кг {g2} г = {total} г.',
            'Решение.',
            f'1) Переводим первое число в граммы: {k1} кг {g1} г = {k1 * 1000 + g1} г.',
            f'2) Переводим второе число в граммы: {k2} кг {g2} г = {k2 * 1000 + g2} г.',
            f'3) Вычитаем: {k1 * 1000 + g1} - {k2 * 1000 + g2} = {total} г.',
            f'Ответ: {total} г',
            'Совет: при вычислениях с килограммами и граммами удобно всё переводить в граммы',
        ])

    m = re.fullmatch(r'(\d+)\s*сутки\s*-\s*(\d+)\s*ч\s*=\s*ч\.?', clean)
    if m:
        day, hour = map(int, m.groups()); total = day * 24 - hour
        return _mass20260416x_finalize([
            f'Пример: {day} сутки - {hour} ч = {total} ч.',
            'Решение.',
            '1) В 1 сутках 24 часа.',
            f'2) {day} сутки = {day * 24} ч.',
            f'3) {day * 24} ч - {hour} ч = {total} ч.',
            f'Ответ: {total} ч',
            'Совет: сутки в часы переводят умножением на 24',
        ])

    m = re.fullmatch(r'вырази в метрах\s*:\s*(\d+)\s*см\.?', clean)
    if m:
        cm = int(m.group(1)); meters = Decimal(cm) / Decimal(100)
        return _mass20260416x_finalize([
            f'Пример: {cm} см = {_mass20260416x_fmt_decimal(meters)} м.',
            'Решение.',
            '1) В 1 м 100 см.',
            f'2) {cm} : 100 = {_mass20260416x_fmt_decimal(meters)}.',
            f'Ответ: {_mass20260416x_fmt_decimal(meters)} м',
            'Совет: сантиметры в метры переводят делением на 100',
        ])

    m = re.fullmatch(r'вырази в рублях\s*:\s*(\d+)\s*коп\.?', clean)
    if m:
        kop = int(m.group(1)); rub = Decimal(kop) / Decimal(100)
        return _mass20260416x_finalize([
            f'Пример: {kop} коп = {_mass20260416x_fmt_decimal(rub)} руб.',
            'Решение.',
            '1) В 1 рубле 100 копеек.',
            f'2) {kop} : 100 = {_mass20260416x_fmt_decimal(rub)}.',
            f'Ответ: {_mass20260416x_fmt_decimal(rub)} руб',
            'Совет: копейки в рубли переводят делением на 100',
        ])
    return None

def _mass20260416x_try_generic_unit_rate(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'на\s+(\d+)\s+одинаков[а-я]+\s+[а-яё]+\s+пошло\s+(\d+)\s+([а-яё]+)', lower)
    m2 = re.search(r'сколько\s+[а-яё]+\s+нужно\s+на\s+(\d+)\s+таких', lower)
    if m and m2:
        count = int(m.group(1)); total = int(m.group(2)); unit = m.group(3); target = int(m2.group(1))
        if count == 0 or total % count != 0:
            return None
        one = total // count; result = one * target
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: на {count} одинаковых предметов пошло {total} {unit}.',
            f'Что нужно найти: сколько {unit} нужно на {target} таких предметов.',
            f'1) Сначала находим, сколько {unit} идёт на один предмет: {total} : {count} = {one}.',
            f'2) Теперь находим, сколько {unit} нужно на {target} предметов: {one} × {target} = {result}.',
            f'Ответ: {result} {unit}',
            'Совет: в задачах на приведение к единице сначала находят одну группу, потом нужное число групп',
        ])

    m = re.search(r'за\s+(\d+)\s+одинаков[а-я]+\s+[а-яё]+\s+заплатили\s+(\d+)\s+руб', lower)
    m2 = re.search(r'сколько\s+стоят\s+(\d+)\s+таких', lower)
    if m and m2:
        count = int(m.group(1)); total = int(m.group(2)); target = int(m2.group(1))
        if count == 0 or total % count != 0:
            return None
        one = total // count; result = one * target
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: за {count} одинаковых предметов заплатили {total} руб.',
            f'Что нужно найти: сколько стоят {target} таких предметов.',
            f'1) Находим цену одного предмета: {total} : {count} = {one} руб.',
            f'2) Находим стоимость {target} предметов: {one} × {target} = {result} руб.',
            f'Ответ: {result} руб.',
            'Совет: если известна общая стоимость одинаковых предметов, сначала находят цену одного предмета',
        ])
    return None

def _mass20260416x_try_simple_fraction_meta(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'разделили на (\d+) равных част', lower)
    if m and 'какая доля' in lower:
        den = int(m.group(1))
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Если целое разделили на {den} равных частей, то одна часть — это одна из {den} частей.',
            f'Ответ: 1/{den}',
            'Совет: одна часть из нескольких равных частей записывается дробью 1/знаменатель',
        ])

    m = re.fullmatch(r'приведи к знаменателю\s+(\d+)\s*:\s*(\d+)\s*/\s*(\d+)\s+и\s+(\d+)\s*/\s*(\d+)\.?', lower)
    if m:
        target = int(m.group(1)); a1, b1, a2, b2 = map(int, m.groups()[1:])
        if target % b1 != 0 or target % b2 != 0:
            return None
        k1 = target // b1; k2 = target // b2
        n1 = a1 * k1; n2 = a2 * k2
        return _mass20260416x_finalize([
            f'Пример: привести к знаменателю {target}: {a1}/{b1} и {a2}/{b2}.',
            'Решение.',
            f'1) Для дроби {a1}/{b1}: {b1} × {k1} = {target}, значит, умножаем числитель и знаменатель на {k1}.',
            f'2) Получаем: {a1}/{b1} = {n1}/{target}.',
            f'3) Для дроби {a2}/{b2}: {b2} × {k2} = {target}, значит, умножаем числитель и знаменатель на {k2}.',
            f'4) Получаем: {a2}/{b2} = {n2}/{target}.',
            f'Ответ: {a1}/{b1} = {n1}/{target}; {a2}/{b2} = {n2}/{target}',
            'Совет: чтобы привести дробь к новому знаменателю, числитель и знаменатель умножают на одно и то же число',
        ])

    m = re.fullmatch(r'реши уравнение\s*:\s*x\s*\+\s*(\d+)\s*/\s*(\d+)\s*=\s*(\d+)\s*/\s*(\d+)\.?', lower)
    if m:
        a, b, c, d = map(int, m.groups())
        left = Fraction(a, b); right = Fraction(c, d); x = right - left
        return _mass20260416x_finalize([
            'Уравнение:',
            f'x + {a}/{b} = {c}/{d}',
            'Решение.',
            f'1) Чтобы найти неизвестное слагаемое, из суммы вычитаем известное слагаемое: x = {c}/{d} - {a}/{b}.',
            f'2) Считаем: x = {x.numerator}/{x.denominator}.',
            f'Проверка: {x.numerator}/{x.denominator} + {a}/{b} = {c}/{d}.',
            f'Ответ: {x.numerator}/{x.denominator}',
            'Совет: неизвестное слагаемое находят вычитанием',
        ])
    return None

def _mass20260416x_try_decimals(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(text).replace(' ', '')
    m = re.fullmatch(r'(\d+,\d+)\+(\d+,\d+)', clean)
    if m:
        a, b = m.groups(); da, db = _mass20260416x_dec(a), _mass20260416x_dec(b); res = da + db
        return _mass20260416x_finalize([
            f'Пример: {a} + {b} = {_mass20260416x_fmt_decimal(res)}.',
            'Решение.',
            '1) Складываем десятичные дроби по разрядам.',
            f'2) {a} + {b} = {_mass20260416x_fmt_decimal(res)}.',
            f'Ответ: {_mass20260416x_fmt_decimal(res)}',
            'Совет: при сложении десятичных дробей единицы пишут под единицами, десятые под десятыми',
        ])
    m = re.fullmatch(r'(\d+,\d+)-(\d+,\d+)', clean)
    if m:
        a, b = m.groups(); da, db = _mass20260416x_dec(a), _mass20260416x_dec(b); res = da - db
        return _mass20260416x_finalize([
            f'Пример: {a} - {b} = {_mass20260416x_fmt_decimal(res)}.',
            'Решение.',
            '1) Вычитаем десятичные дроби по разрядам.',
            f'2) {a} - {b} = {_mass20260416x_fmt_decimal(res)}.',
            f'Ответ: {_mass20260416x_fmt_decimal(res)}',
            'Совет: при вычитании десятичных дробей запятые ставят друг под другом',
        ])

    m = re.fullmatch(r'запиши в виде десятичной дроби\s*:\s*([0-9/;\s]+)\.?', text.lower())
    if m:
        parts = [p.strip() for p in m.group(1).split(';') if p.strip()]
        if not parts:
            return None
        out = []
        lines = ['Задача.', _audit_task_line(raw_text), 'Решение.']
        for idx, part in enumerate(parts, 1):
            if not re.fullmatch(r'(\d+)/(\d+)', part):
                return None
            a, b = map(int, part.split('/'))
            dec = Decimal(a) / Decimal(b)
            out.append(_mass20260416x_fmt_decimal(dec))
            lines.append(f'{idx}) {part} = {_mass20260416x_fmt_decimal(dec)}.')
        lines += [f'Ответ: {"; ".join(out)}', 'Совет: дроби со знаменателем 10 или 100 легко записывать десятичной дробью']
        return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'запиши обыкновенной дробью\s*:\s*([0-9,;\s]+)\.?', text.lower())
    if m:
        parts = [p.strip() for p in m.group(1).split(';') if p.strip()]
        if not parts:
            return None
        out = []
        lines = ['Задача.', _audit_task_line(raw_text), 'Решение.']
        for idx, part in enumerate(parts, 1):
            if ',' not in part:
                return None
            frac_digits = len(part.split(',')[1])
            num = int(part.replace(',', ''))
            den = 10 ** frac_digits
            out.append(f'{num}/{den}')
            lines.append(f'{idx}) {part} = {num}/{den}.')
        lines += [f'Ответ: {"; ".join(out)}', 'Совет: количество цифр после запятой показывает знаменатель: 10, 100, 1000']
        return _mass20260416x_finalize(lines)
    return None

def _mass20260416x_try_percent(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'найди\s+(\d+)%\s+от\s+(\d+)', lower)
    if m:
        p = int(m.group(1)); total = int(m.group(2)); result = total * p // 100 if (total * p) % 100 == 0 else total * p / 100
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) {p}% — это {p}/100 от числа.',
            f'2) Находим {p}% от {total}: {total} × {p} : 100 = {result}.',
            f'Ответ: {result}',
            'Совет: чтобы найти проценты от числа, число умножают на количество процентов и делят на 100',
        ])

    m = re.search(r'в классе (\d+) ученик[а-я]*,\s*(\d+)% из них', lower) or re.search(r'в саду (\d+) дерев[а-я]*,\s*из них (\d+)%', lower) or re.search(r'в библиотеке (\d+) книг,\s*(\d+)%', lower)
    if m:
        total = int(m.group(1)); p = int(m.group(2)); result = total * p // 100
        unit = 'учеников' if 'ученик' in lower else 'деревьев' if 'дерев' in lower else 'книг'
        if 'отличник' in lower:
            unit = 'отличников'
        elif 'яблон' in lower:
            unit = 'яблонь'
        elif 'словар' in lower:
            unit = 'словарей'
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим {p}% от {total}: {total} × {p} : 100 = {result}.',
            f'Ответ: {result} {unit}',
            'Совет: процент — это одна сотая часть числа',
        ])

    m = re.search(r'товар стоил (\d+) руб\.? цена снизилась на (\d+)%', lower)
    if m:
        price = int(m.group(1)); p = int(m.group(2)); disc = price * p // 100; new = price - disc
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько рублей составляет скидка: {price} × {p} : 100 = {disc} руб.',
            f'2) Вычитаем скидку из старой цены: {price} - {disc} = {new} руб.',
            f'Ответ: {new} руб.',
            'Совет: чтобы уменьшить число на несколько процентов, сначала находят эти проценты',
        ])

    m = re.search(r'скидка (\d+)%[\s\S]*вещь стоит (\d+) руб', lower)
    if m:
        p = int(m.group(1)); price = int(m.group(2)); save = price * p // 100
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим {p}% от {price}: {price} × {p} : 100 = {save} руб.',
            f'Ответ: {save} руб.',
            'Совет: размер скидки находят как процент от цены',
        ])

    m = re.search(r'цена выросла с (\d+) руб\.? до (\d+) руб\.?', lower)
    if m and 'на сколько процентов' in lower:
        old = int(m.group(1)); new = int(m.group(2)); diff = new - old; p = diff * 100 // old if (diff * 100) % old == 0 else diff * 100 / old
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, на сколько рублей выросла цена: {new} - {old} = {diff} руб.',
            f'2) Теперь узнаём, какую часть это составляет от старой цены: {diff} × 100 : {old} = {p}%.',
            f'Ответ: {p}%',
            'Совет: процент увеличения считают от старого значения',
        ])

    m = re.search(r'под (\d+)% годовых', lower)
    if m and 'сколько процентов' in lower:
        p = int(m.group(1))
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'По условию вклад открыт под {p}% годовых.',
            f'Ответ: {p}%',
            'Совет: если процентная ставка дана в условии, её и называют в ответе',
        ])
    return None

def _mass20260416x_try_average(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    m = re.search(r'найди среднее арифметическое чисел ([0-9,\s]+)', lower)
    if m:
        nums = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
        if not nums:
            return None
        total = sum(nums); n = len(nums); avg = total / n
        avg_text = int(avg) if avg == int(avg) else avg
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Складываем числа: {" + ".join(map(str, nums))} = {total}.',
            f'2) Делим сумму на количество чисел: {total} : {n} = {avg_text}.',
            f'Ответ: {avg_text}',
            'Совет: среднее арифметическое находят делением суммы чисел на их количество',
        ])

    m = re.search(r'среднее арифметическое трех чисел равно (\d+)[\s\S]*сумма двух из них (\d+)', lower)
    if m:
        avg = int(m.group(1)); sum_two = int(m.group(2)); total = avg * 3; third = total - sum_two
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим сумму трех чисел: {avg} × 3 = {total}.',
            f'2) Находим третье число: {total} - {sum_two} = {third}.',
            f'Ответ: {third}',
            'Совет: если известно среднее арифметическое, сначала можно найти общую сумму',
        ])

    m = re.search(r'средний рост пяти игроков (\d+) см[\s\S]*сумма роста четырех игроков (\d+) см', lower)
    if m:
        avg = int(m.group(1)); sum_four = int(m.group(2)); total = avg * 5; fifth = total - sum_four
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим общий рост пяти игроков: {avg} × 5 = {total} см.',
            f'2) Находим рост пятого игрока: {total} - {sum_four} = {fifth} см.',
            f'Ответ: {fifth} см',
            'Совет: средний рост умножают на количество игроков, чтобы получить общий рост',
        ])

    m = re.search(r'среднее арифметическое двух чисел (\d+), одно из них (\d+)', lower)
    if m:
        avg = int(m.group(1)); one = int(m.group(2)); total = avg * 2; two = total - one
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим сумму двух чисел: {avg} × 2 = {total}.',
            f'2) Находим второе число: {total} - {one} = {two}.',
            f'Ответ: {two}',
            'Совет: если известно среднее двух чисел, сумма равна среднему, умноженному на 2',
        ])

    m = re.search(r'машина проехала (\d+) км за (\d+) ч, затем (\d+) км за (\d+) ч', lower)
    if m and 'среднюю скорость' in lower:
        s1, t1, s2, t2 = map(int, m.groups()); total_s = s1 + s2; total_t = t1 + t2; v = total_s / total_t
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим весь путь: {s1} + {s2} = {total_s} км.',
            f'2) Находим всё время: {t1} + {t2} = {total_t} ч.',
            f'3) Средняя скорость равна всему пути, деленному на всё время: {total_s} : {total_t} = {int(v) if v == int(v) else v} км/ч.',
            f'Ответ: {int(v) if v == int(v) else v} км/ч',
            'Совет: среднюю скорость на всём пути находят делением всего пути на всё время',
        ])

    # generic average with a list and a unit
    m = re.search(r':\s*([0-9,\s]+)\.?\s*найди средн', lower)
    if m:
        nums = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
        if nums:
            total = sum(nums); n = len(nums); avg = total / n
            unit = '°' if 'температур' in lower else ''
            avg_text = int(avg) if avg == int(avg) else avg
            return _mass20260416x_finalize([
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'1) Складываем все значения: {" + ".join(map(str, nums))} = {total}.',
                f'2) Делим сумму на количество значений: {total} : {n} = {avg_text}.',
                f'Ответ: {avg_text}{unit}',
                'Совет: среднее арифметическое показывает, сколько пришлось бы на каждый случай поровну',
            ])

    m = re.search(r'в первый день собрали (\d+) кг [а-я]+, во второй (\d+) кг, в третий (\d+) кг', lower)
    if m and 'в среднем' in lower:
        a, b, c = map(int, m.groups()); total = a + b + c; avg = total // 3
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Складываем весь урожай: {a} + {b} + {c} = {total} кг.',
            f'2) Делим на 3 дня: {total} : 3 = {avg} кг.',
            f'Ответ: {avg} кг',
            'Совет: чтобы найти среднее за несколько дней, нужно общий результат разделить на число дней',
        ])

    m = re.search(r'в трех коробках лежат карандаши:\s*(\d+),\s*(\d+)\s*и\s*(\d+)', lower)
    if m and 'в среднем' in lower:
        a, b, c = map(int, m.groups()); total = a + b + c; avg = total // 3
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим общее число карандашей: {a} + {b} + {c} = {total}.',
            f'2) Делим на 3 коробки: {total} : 3 = {avg}.',
            f'Ответ: {avg}',
            'Совет: среднее число в коробке находят делением общего количества на число коробок',
        ])

    m = re.search(r'оценки:\s*([0-9,\s]+)\.?\s*найди средний балл', lower)
    if m:
        nums = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
        if nums:
            total = sum(nums); n = len(nums); avg = total / n
            avg_text = int(avg) if avg == int(avg) else _mass20260416x_fmt_decimal(Decimal(str(avg)))
            return _mass20260416x_finalize([
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'1) Складываем оценки: {" + ".join(map(str, nums))} = {total}.',
                f'2) Делим на число оценок: {total} : {n} = {avg_text}.',
                f'Ответ: {avg_text}',
                'Совет: средний балл — это среднее арифметическое всех оценок',
            ])
    return None

def _mass20260416x_try_system_word_problems(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'сумма двух чисел (\d+), разность (\d+)', lower)
    if m:
        s = int(m.group(1)); d = int(m.group(2)); big = (s + d) // 2; small = (s - d) // 2
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если к сумме прибавить разность, получится удвоенное большее число: {s} + {d} = {s + d}.',
            f'2) Большее число: {s + d} : 2 = {big}.',
            f'3) Меньшее число: {s} - {big} = {small}.',
            f'Ответ: {big} и {small}',
            'Совет: в задачах на сумму и разность удобно сначала находить большее число',
        ])

    m = re.search(r'одно число больше другого на (\d+), а сумма их (\d+)', lower)
    if m:
        d = int(m.group(1)); s = int(m.group(2)); small = (s - d) // 2; big = small + d
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если одно число больше на {d}, то без этой добавки два числа были бы равны.',
            f'2) Убираем добавку: {s} - {d} = {s - d}.',
            f'3) Находим меньшее число: {s - d} : 2 = {small}.',
            f'4) Находим большее число: {small} + {d} = {big}.',
            f'Ответ: {small} и {big}',
            'Совет: если одно число больше другого на несколько единиц, можно сначала убрать эту разницу',
        ])

    m = re.search(r'в двух корзинах (\d+) яблок.*в первой на (\d+) меньше', lower)
    if m:
        s = int(m.group(1)); d = int(m.group(2)); second = (s + d) // 2; first = s - second
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если в первой корзине на {d} яблок меньше, то во второй на {d} яблок больше.',
            f'2) Прибавим эту разницу к общему числу: {s} + {d} = {s + d}.',
            f'3) Во второй корзине: {s + d} : 2 = {second}.',
            f'4) В первой корзине: {s} - {second} = {first}.',
            f'Ответ: в первой {first}, во второй {second}',
            'Совет: в задачах с суммой и разницей сначала удобно найти большее количество',
        ])

    m = re.search(r'у кати и лены вместе (\d+) руб[а-я]*, у кати на (\d+) руб[а-я]* больше', lower)
    if m:
        s = int(m.group(1)); d = int(m.group(2)); lena = (s - d) // 2; katya = lena + d
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если у Кати на {d} рубля больше, то без этой добавки у девочек было бы поровну.',
            f'2) Убираем добавку: {s} - {d} = {s - d}.',
            f'3) Находим деньги Лены: {s - d} : 2 = {lena} руб.',
            f'4) Находим деньги Кати: {lena} + {d} = {katya} руб.',
            f'Ответ: у Кати {katya} руб., у Лены {lena} руб.',
            'Совет: если один имеет на несколько единиц больше, сначала убирают эту разницу',
        ])

    m = re.search(r'сумма двух чисел (\d+), одно в (\d+) раза больше другого', lower)
    if m:
        s = int(m.group(1)); k = int(m.group(2)); small = s // (k + 1); big = small * k
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Всего равных частей: 1 + {k} = {k + 1}.',
            f'2) Одна часть: {s} : {k + 1} = {small}.',
            f'3) Большее число: {small} × {k} = {big}.',
            f'Ответ: {big} и {small}',
            'Совет: если одно число в несколько раз больше другого, удобно делить сумму на число частей',
        ])

    m = re.search(r'разность двух чисел (\d+), одно в (\d+) раза больше другого', lower)
    if m:
        d = int(m.group(1)); k = int(m.group(2))
        if k <= 1 or d % (k - 1) != 0:
            return None
        small = d // (k - 1); big = small * k
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Разность между {k} частями и 1 частью равна {k - 1} частям.',
            f'2) Одна часть: {d} : {k - 1} = {small}.',
            f'3) Большее число: {small} × {k} = {big}.',
            f'Ответ: {big} и {small}',
            'Совет: при кратном сравнении разность помогает найти одну часть',
        ])

    m = re.search(r'в классе (\d+) учеников, девочек на (\d+) больше, чем мальчиков', lower)
    if m:
        s = int(m.group(1)); d = int(m.group(2)); boys = (s - d) // 2; girls = boys + d
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если убрать лишние {d} девочки, мальчиков и девочек было бы поровну.',
            f'2) {s} - {d} = {s - d}.',
            f'3) Мальчиков: {s - d} : 2 = {boys}.',
            f'4) Девочек: {boys} + {d} = {girls}.',
            f'Ответ: мальчиков {boys}, девочек {girls}',
            'Совет: если одной группы больше на несколько человек, сначала убирают разницу',
        ])

    m = re.search(r'два числа в сумме дают (\d+), а одно составляет (\d+)/(\d+) другого', lower)
    if m:
        s = int(m.group(1)); num = int(m.group(2)); den = int(m.group(3))
        # smaller = num/den larger
        whole_parts = num + den
        if s * den % whole_parts != 0:
            return None
        larger = s * den // whole_parts
        smaller = s - larger
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) По условию одно число составляет {num}/{den} другого.',
            f'2) Значит, вся сумма — это {num} части и {den} частей, всего {whole_parts} частей.',
            f'3) Одна часть: {s} : {whole_parts} = {s // whole_parts}.',
            f'4) Числа равны {smaller} и {larger}.',
            f'Ответ: {smaller} и {larger}',
            'Совет: дробное отношение удобно переводить в равные части',
        ])

    m = re.search(r'в двух ящиках (\d+) кг апельсинов. в первом в (\d+) раза больше', lower)
    if m:
        s = int(m.group(1)); k = int(m.group(2)); second = s // (k + 1); first = second * k
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Всего частей: {k} + 1 = {k + 1}.',
            f'2) Во втором ящике: {s} : {k + 1} = {second} кг.',
            f'3) В первом ящике: {second} × {k} = {first} кг.',
            f'Ответ: в первом {first} кг, во втором {second} кг',
            'Совет: если одно количество в несколько раз больше другого, удобнее делить сумму на число частей',
        ])
    return None
