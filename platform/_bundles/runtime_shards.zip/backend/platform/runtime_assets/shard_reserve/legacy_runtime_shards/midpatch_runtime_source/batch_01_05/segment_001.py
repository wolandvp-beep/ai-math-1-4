"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 1-864."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def normalize_word_problem_text(text: str) -> str:
    cleaned = strip_known_prefix(text)
    cleaned = normalize_dashes(cleaned)
    cleaned = cleaned.replace("ё", "е").replace("Ё", "Е")
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip()



def join_explanation_lines(*lines: str) -> str:
    parts = [normalize_sentence(line) for line in lines if str(line or "").strip()]
    return "\n".join(parts)

def sanitize_model_text(text: str) -> str:
    cleaned = str(text or "").replace("\r", "")
    while True:
        updated = LEADING_FILLER_SENTENCE.sub("", cleaned, count=1)
        if updated == cleaned:
            break
        cleaned = updated
    cleaned = cleaned.replace("**", "").replace("__", "").replace("`", "")
    cleaned = re.sub(r"^\s*#{1,6}\s*", "", cleaned, flags=re.MULTILINE)
    cleaned = cleaned.replace("\\(", "").replace("\\)", "").replace("\\[", "").replace("\\]", "")
    cleaned = cleaned.replace("\\", "")
    cleaned = re.sub(r"^\s*[-*•]\s*", "", cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    raw_lines = [line.strip() for line in cleaned.split("\n")]
    lines = []
    seen = set()
    for raw in raw_lines:
        if not raw:
            continue
        if BANNED_OPENERS.match(raw):
            continue
        raw = SECTION_PREFIX_RE.sub(lambda m: f"{m.group(1).capitalize()}: ", raw)
        key = raw.lower()
        if key in seen:
            continue
        seen.add(key)
        lines.append(raw)
    return "\n".join(lines).strip()

def is_low_value_body_line(text: str) -> bool:
    line = str(text or "").strip()
    return any(p.fullmatch(line) for p in LOW_VALUE_BODY_PATTERNS)

def extract_answer_value(answer_line: str) -> str:
    if not answer_line:
        return ""
    return re.sub(r"^Ответ:\s*", "", answer_line, flags=re.IGNORECASE).strip().rstrip(".!?").strip()



def contains_any_fragment(text: str, fragments) -> bool:
    base = str(text or "")
    return any(fragment in base for fragment in fragments)

def extract_ordered_numbers(text: str) -> List[int]:
    return [int(value) for value in re.findall(r"\d+", str(text or ""))]

def extract_fraction_pair(text: str) -> Optional[Tuple[int, int]]:
    match = FRACTION_IN_TEXT_RE.search(str(text or ""))
    if not match:
        return None
    return int(match.group(1)), int(match.group(2))

def geometry_unit(text: str) -> str:
    match = GEOMETRY_UNIT_RE.search(str(text or ""))
    return match.group(1).lower() if match else ""

def with_unit(value: int, unit: str, square: bool = False) -> str:
    if not unit:
        return str(value)
    suffix = f" {unit}²" if square else f" {unit}"
    return f"{value}{suffix}"

def plural_form(count: int, one: str, few: str, many: str) -> str:
    value = abs(int(count)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return many
    if tail == 1:
        return one
    if 2 <= tail <= 4:
        return few
    return many

def has_multiple_questions(text: str) -> bool:
    return len(re.findall(r"\?", str(text or ""))) >= 2

def asks_total_like(text: str) -> bool:
    lower = str(text or "").lower().replace("ё", "е")
    if re.search(r"сколько[^.?!]*\b(всего|вместе)\b", lower):
        return True
    if re.search(r"сколько[^.?!]*\b(на|в)\s+(?:двух|трех|трёх|четырех|четырёх|обеих|обоих|всех)\b", lower):
        return True
    if re.search(r"сколько[^.?!]*\b(обеих|обоих|всех)\b", lower):
        return True
    if re.search(r"сколько[^.?!]*\bполках\b", lower) and re.search(r"\b(двух|трех|трёх|обеих|обоих|четырех|четырёх)\b", lower):
        return True
    if re.search(r"сколько[^.?!]*\bкружках\b", lower) and re.search(r"\b(двух|трех|трёх|обеих|обоих)\b", lower):
        return True
    return False

def extract_keyword_number(text: str, keyword: str) -> Optional[int]:
    base = str(text or "").lower()
    patterns = [
        rf"{keyword}[^\d]{{0,80}}(\d+)",
        rf"{keyword}\s*=\s*(\d+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, base)
        if match:
            return int(match.group(1))
    return None

def extract_pairs_after_po(text: str) -> List[Tuple[int, int]]:
    pairs: List[Tuple[int, int]] = []
    for match in re.finditer(r"(\d+)\s+[^\d?.!]{0,40}?по\s+(\d+)", str(text or "").lower()):
        pairs.append((int(match.group(1)), int(match.group(2))))
    return pairs

def format_fraction(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"

def infer_task_kind(text: str) -> str:
    base = strip_known_prefix(text)
    lowered = normalize_cyrillic_x(base).lower()
    if re.search(r"\d+\s*/\s*\d+\s*[+\-]\s*\d+\s*/\s*\d+", lowered):
        return "fraction"
    if "x" in lowered and "=" in lowered:
        return "equation"
    if re.search(r"периметр|площадь|прямоугольник|квадрат|треугольник|сторон|длина|ширина", lowered):
        return "geometry"
    if re.search(r"[а-я]", lowered):
        return "word"
    if re.search(r"[+\-*/()×÷:]", lowered):
        return "expression"
    return "other"




def to_fraction_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(text)
    text = re.sub(r"[=?]+$", "", text).strip()
    if not re.fullmatch(r"\s*\d+\s*/\s*\d+\s*[+\-]\s*\d+\s*/\s*\d+\s*", text):
        return None
    return text

def is_int_literal_node(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and type(node.value) is int

def int_from_literal_node(node: ast.AST) -> int:
    if not is_int_literal_node(node):
        raise ValueError("Expected integer literal node")
    return int(node.value)

def validate_expression_ast(node: ast.AST) -> bool:
    if isinstance(node, ast.Expression):
        return validate_expression_ast(node.body)
    if isinstance(node, ast.BinOp):
        return isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)) and validate_expression_ast(node.left) and validate_expression_ast(node.right)
    if isinstance(node, ast.UnaryOp):
        return isinstance(node.op, ast.USub) and validate_expression_ast(node.operand)
    return is_int_literal_node(node)

def parse_expression_ast(source: str) -> Optional[ast.AST]:
    try:
        parsed = ast.parse(source, mode="eval")
    except SyntaxError:
        return None
    if not validate_expression_ast(parsed):
        return None
    return parsed.body

def eval_fraction_node(node: ast.AST) -> Fraction:
    if is_int_literal_node(node):
        return Fraction(int_from_literal_node(node), 1)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -eval_fraction_node(node.operand)
    if isinstance(node, ast.BinOp):
        left = eval_fraction_node(node.left)
        right = eval_fraction_node(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise ZeroDivisionError("division by zero")
            return left / right
    raise ValueError("Unsupported expression")

def render_node(node: ast.AST, parent_precedence: int = 0, is_right_child: bool = False) -> str:
    if is_int_literal_node(node):
        return str(int_from_literal_node(node))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        inner = render_node(node.operand, 3)
        return f"-{inner}"
    if isinstance(node, ast.BinOp):
        current_precedence = PRECEDENCE[type(node.op)]
        left_text = render_node(node.left, current_precedence, False)
        right_text = render_node(node.right, current_precedence, True)
        text = f"{left_text} {OPERATOR_SYMBOLS[type(node.op)]} {right_text}"
        needs_brackets = current_precedence < parent_precedence or (
            is_right_child and isinstance(node.op, (ast.Add, ast.Sub)) and parent_precedence == current_precedence
        )
        return f"({text})" if needs_brackets else text
    raise ValueError("Unsupported node")




def flatten_add_chain(node: ast.AST) -> Optional[List[int]]:
    if is_int_literal_node(node):
        value = int_from_literal_node(node)
        return [value] if value >= 0 else None
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = flatten_add_chain(node.left)
        right = flatten_add_chain(node.right)
        if left is None or right is None:
            return None
        return left + right
    return None

def count_two_digit_numbers(nums: List[int]) -> int:
    return sum(1 for n in nums if 10 <= abs(n) <= 99)

def should_use_column_for_sum(nums: List[int]) -> bool:
    if any(abs(n) >= 100 for n in nums):
        return True
    return count_two_digit_numbers(nums) > 2

def get_digits(n: int) -> List[int]:
    return [int(ch) for ch in str(abs(n))]

def digits_by_place(n: int, width: int) -> List[int]:
    s = str(abs(n)).rjust(width, "0")
    return [int(ch) for ch in s]

def split_tens_units(n: int) -> Tuple[int, int]:
    return n - n % 10, n % 10

def explain_addition_via_ten(left: int, right: int) -> str:
    to_ten = 10 - left
    rest = right - to_ten
    total = left + right
    return join_explanation_lines(
        "Ищем сумму",
        f"Чтобы получить 10, к {left} нужно прибавить {to_ten}",
        f"Разложим {right} на {to_ten} и {rest}",
        f"{left} + {to_ten} = 10, потом 10 + {rest} = {total}",
        f"Ответ: {total}",
        "Совет: если удобно, сначала доводи число до 10",
    )

def explain_subtraction_via_ten(left: int, right: int) -> str:
    first_part = left % 10
    second_part = right - first_part
    result = left - right
    return join_explanation_lines(
        "Ищем разность",
        f"Разложим {right} на {first_part} и {second_part}",
        f"Сначала {left} - {first_part} = 10",
        f"Потом 10 - {second_part} = {result}",
        f"Ответ: {result}",
        "Совет: при вычитании через десяток удобно сначала дойти до 10",
    )

def explain_subtraction_two_digit_with_borrow(minuend: int, subtrahend: int) -> Optional[str]:
    """Объяснение вычитания двузначных чисел с переходом через десяток (устный приём)."""
    if minuend < 20 or subtrahend < 10:
        return None
    if minuend % 10 >= subtrahend % 10:
        return None  # нет перехода
    tens = (minuend // 10 - 1) * 10
    units = 10 + (minuend % 10)
    subtrahend_tens = (subtrahend // 10) * 10
    subtrahend_units = subtrahend % 10
    result = minuend - subtrahend
    return join_explanation_lines(
        "Ищем разность",
        f"Представим {minuend} как {tens} + {units}",
        f"Представим {subtrahend} как {subtrahend_tens} + {subtrahend_units}",
        f"Вычитаем десятки: {tens} - {subtrahend_tens} = {tens - subtrahend_tens}",
        f"Вычитаем единицы: {units} - {subtrahend_units} = {units - subtrahend_units}",
        f"Складываем полученные разности: {tens - subtrahend_tens} + {units - subtrahend_units} = {result}",
        f"Ответ: {result}",
        "Совет: при вычитании с переходом через десяток удобно разложить уменьшаемое",
    )

def explain_column_addition(numbers: List[int]) -> str:
    ordered = sorted(numbers, key=lambda x: (len(str(abs(x))), abs(x)), reverse=True)
    width = max(len(str(abs(n))) for n in ordered)
    columns = [digits_by_place(n, width) for n in ordered]
    carry = 0
    lines = [
        "Пишем числа в столбик: единицы под единицами, десятки под десятками и так далее",
        "Начинаем сложение с единиц",
    ]
    for pos_from_right in range(width):
        idx = width - 1 - pos_from_right
        digits = [col[idx] for col in columns]
        total = sum(digits) + carry
        digit = total % 10
        new_carry = total // 10
        place_name = PLACE_NAMES[pos_from_right] if pos_from_right < len(PLACE_NAMES) else "разряд"
        expr = " + ".join(str(d) for d in digits)
        if carry:
            if new_carry:
                next_place = NEXT_PLACE_NAMES[pos_from_right] if pos_from_right < len(NEXT_PLACE_NAMES) else "следующий разряд"
                lines.append(f"{place_name.capitalize()}: {expr} и ещё {carry} = {total}. Пишем {digit}, {new_carry} {next_place} запоминаем")
            else:
                lines.append(f"{place_name.capitalize()}: {expr} и ещё {carry} = {total}. Пишем {digit}")
        else:
            if new_carry:
                next_place = NEXT_PLACE_NAMES[pos_from_right] if pos_from_right < len(NEXT_PLACE_NAMES) else "следующий разряд"
                lines.append(f"{place_name.capitalize()}: {expr} = {total}. Пишем {digit}, {new_carry} {next_place} запоминаем")
            else:
                lines.append(f"{place_name.capitalize()}: {expr} = {total}. Пишем {digit}")
        carry = new_carry
    if carry:
        lines.append(f"В следующем разряде записываем {carry}")
    total = sum(ordered)
    lines.append(f"Читаем ответ: сумма равна {total}")
    return join_explanation_lines(*lines, f"Ответ: {total}", "Совет: в столбике всегда начинай с младшего разряда")

def explain_column_subtraction(minuend: int, subtrahend: int) -> str:
    if subtrahend > minuend:
        return join_explanation_lines(
            "Первое число меньше второго",
            f"Считаем: {minuend} - {subtrahend} = {minuend - subtrahend}",
            f"Ответ: {minuend - subtrahend}",
            "Совет: перед вычитанием сравни числа",
        )
    work = get_digits(minuend)
    sub = get_digits(subtrahend)
    width = max(len(work), len(sub))
    work = [0] * (width - len(work)) + work
    sub = [0] * (width - len(sub)) + sub
    lines = [
        "Пишем числа в столбик: единицы под единицами, десятки под десятками и так далее",
        "Начинаем вычитание с единиц",
    ]
    result = [0] * width

    for pos_from_right in range(width):
        idx = width - 1 - pos_from_right
        top = work[idx]
        bottom = sub[idx]
        place_name = PLACE_NAMES[pos_from_right] if pos_from_right < len(PLACE_NAMES) else "разряд"
        if top >= bottom:
            result[idx] = top - bottom
            lines.append(f"{place_name.capitalize()}: {top} - {bottom} = {result[idx]}")
            continue

        j = idx - 1
        while j >= 0 and work[j] == 0:
            j -= 1
        if j < 0:
            return join_explanation_lines(
                "В этом примере не получается выполнить вычитание обычным способом",
                "Ответ: проверь запись примера",
                "Совет: уменьшаемое должно быть не меньше вычитаемого",
            )

        work[j] -= 1
        for k in range(j + 1, idx):
            work[k] = 9
        work[idx] += 10
        borrowed_value = work[idx]
        if idx - j == 1:
            higher_place = NEXT_PLACE_NAMES[pos_from_right] if pos_from_right < len(NEXT_PLACE_NAMES) else "следующий разряд"
            lines.append(
                f"Из {top} нельзя вычесть {bottom}. Занимаем 1 {higher_place}. Получаем {borrowed_value}. {borrowed_value} - {bottom} = {borrowed_value - bottom}"
            )
        else:
            lines.append(
                f"Из {top} нельзя вычесть {bottom}. Слева есть нули, поэтому занимаем в более старшем разряде. Получаем {borrowed_value}. {borrowed_value} - {bottom} = {borrowed_value - bottom}"
            )
        result[idx] = borrowed_value - bottom
        work[idx] = result[idx]

    answer = int("".join(str(d) for d in result))
    lines.append(f"Читаем ответ: разность равна {answer}")
    return join_explanation_lines(*lines, f"Ответ: {answer}", "Совет: если разряда не хватает, занимаем 1 из соседнего старшего разряда")

def explain_long_multiplication(left: int, right: int) -> str:
    a, b = left, right
    if len(str(abs(a))) < len(str(abs(b))):
        a, b = b, a
    result = a * b
    lines = ["Пишем множители столбиком: единицы под единицами, десятки под десятками и так далее"]
    if abs(b) < 10:
        carry = 0
        digits = get_digits(a)
        for pos_from_right, digit in enumerate(reversed(digits)):
            place_name = PLACE_NAMES[pos_from_right] if pos_from_right < len(PLACE_NAMES) else "разряд"
            total = digit * b + carry
            write_digit = total % 10
            new_carry = total // 10
            if carry:
                if new_carry:
                    lines.append(f"{place_name.capitalize()}: {digit} × {b} и ещё {carry} = {total}. Пишем {write_digit}, {new_carry} запоминаем")
                else:
                    lines.append(f"{place_name.capitalize()}: {digit} × {b} и ещё {carry} = {total}. Пишем {write_digit}")
            else:
                if new_carry:
                    lines.append(f"{place_name.capitalize()}: {digit} × {b} = {total}. Пишем {write_digit}, {new_carry} запоминаем")
                else:
                    lines.append(f"{place_name.capitalize()}: {digit} × {b} = {total}. Пишем {write_digit}")
            carry = new_carry
        if carry:
            lines.append(f"В старшем разряде записываем {carry}")
        lines.append(f"Читаем ответ: произведение равно {result}")
        return join_explanation_lines(*lines, f"Ответ: {result}", "Совет: в столбике умножай по разрядам справа налево")

    digits_b = list(reversed(get_digits(b)))
    partials = []
    for idx, digit in enumerate(digits_b):
        place_value = digit * (10 ** idx)
        if digit == 0:
            lines.append(f"В разряде {PLACE_NAMES[idx] if idx < len(PLACE_NAMES) else 'разряда'} второго множителя стоит 0, это неполное произведение пропускаем")
            continue
        partial = a * place_value
        partials.append(partial)
        lines.append(f"Находим неполное произведение: {a} × {place_value} = {partial}")
    if len(partials) > 1:
        lines.append(f"Складываем неполные произведения: {' + '.join(str(p) for p in partials)} = {result}")
    lines.append(f"Читаем ответ: произведение равно {result}")
    return join_explanation_lines(*lines, f"Ответ: {result}", "Совет: в умножении столбиком сначала находят неполные произведения, потом их складывают")

def build_long_division_steps(dividend: int, divisor: int):
    digits = list(str(dividend))
    steps = []
    current = ""
    quotient_digits = []
    started = False
    for index, digit in enumerate(digits):
        current += digit
        current_number = int(current)
        if current_number < divisor:
            if started:
                quotient_digits.append(("zero", current_number, index))
            continue
        started = True
        q_digit = current_number // divisor
        product = q_digit * divisor
        remainder = current_number - product
        next_digit = int(digits[index + 1]) if index + 1 < len(digits) else None
        steps.append({"current": current_number, "q_digit": q_digit, "product": product, "remainder": remainder, "next_digit": next_digit, "index": index})
        quotient_digits.append(("digit", q_digit, index))
        current = str(remainder)
    if not started:
        quotient_digits = [("digit", 0, 0)]
    remainder = int(current or "0")
    return {"steps": steps, "quotient": dividend // divisor if divisor != 0 else None, "remainder": remainder, "quotient_digits": quotient_digits}

def explain_long_division(dividend: int, divisor: int) -> str:
    if divisor == 0:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: сначала смотри на делитель")
    quotient, remainder = divmod(dividend, divisor)
    model = build_long_division_steps(dividend, divisor)
    steps = model["steps"]
    lines = ["Пишем деление столбиком", "Сначала находим первое неполное делимое"]
    if not steps:
        lines.append(f"{dividend} меньше {divisor}, значит в частном будет 0")
        if remainder:
            lines.append(f"Остаток равен {remainder}")
        answer_text = "0" if remainder == 0 else f"0, остаток {remainder}"
        return join_explanation_lines(*lines, f"Ответ: {answer_text}", "Совет: если делимое меньше делителя, частное начинается с нуля")

    lines.append(f"Первое неполное делимое — {steps[0]['current']}")
    step_idx = 0
    quotient_started = False
    current = ""
    digits = list(str(dividend))
    for digit_char in digits:
        current += digit_char
        current_number = int(current)
        if current_number < divisor and quotient_started:
            lines.append(f"Число {current_number} меньше {divisor}, поэтому в частном пишем 0 и сносим следующую цифру")
            continue
        if current_number < divisor:
            continue
        quotient_started = True
        step = steps[step_idx]
        q_digit = step["q_digit"]
        product = step["product"]
        remainder_here = step["remainder"]
        next_try = (q_digit + 1) * divisor
        if next_try > current_number:
            choose_line = f"Подбираем {q_digit}, потому что {q_digit} × {divisor} = {product}, а {q_digit + 1} × {divisor} = {next_try}, это уже больше"
        else:
            choose_line = f"Подбираем {q_digit}, потому что {q_digit} × {divisor} = {product}"
        if step["next_digit"] is not None:
            next_number = int(str(remainder_here) + str(step["next_digit"]))
            lines.append(f"{choose_line}. Вычитаем: {step['current']} - {product} = {remainder_here}. Сносим следующую цифру и получаем {next_number}")
        elif remainder_here == 0:
            lines.append(f"{choose_line}. Вычитаем: {step['current']} - {product} = 0. Деление закончено")
        else:
            lines.append(f"{choose_line}. Вычитаем: {step['current']} - {product} = {remainder_here}. Это остаток")
        current = str(remainder_here)
        step_idx += 1

    if remainder == 0:
        lines.append(f"Читаем ответ: частное равно {quotient}")
        return join_explanation_lines(*lines, f"Ответ: {quotient}", "Совет: в столбике повторяй шаги: взял, подобрал, умножил, вычел, снес цифру")
    lines.append(f"Читаем ответ: частное равно {quotient}, остаток {remainder}")
    return join_explanation_lines(*lines, f"Ответ: {quotient}, остаток {remainder}", "Совет: остаток всегда должен быть меньше делителя")

def explain_simple_addition(left: int, right: int) -> str:
    total = left + right
    if 0 <= left < 10 and 0 <= right < 10 and total > 10:
        return explain_addition_via_ten(left, right)
    if 10 <= left <= 99 and 10 <= right <= 99:
        lt, lu = split_tens_units(left)
        rt, ru = split_tens_units(right)
        return join_explanation_lines(
            "Ищем сумму",
            f"Разложим числа на десятки и единицы: {left} = {lt} + {lu}, {right} = {rt} + {ru}",
            f"Складываем десятки: {lt} + {rt} = {lt + rt}",
            f"Складываем единицы: {lu} + {ru} = {lu + ru}",
            f"Теперь складываем результаты: {lt + rt} + {lu + ru} = {total}",
            f"Ответ: {total}",
            "Совет: двузначные числа удобно раскладывать на десятки и единицы",
        )
    if left >= 100 or right >= 100:
        return explain_column_addition([left, right])
    return join_explanation_lines("Ищем сумму", f"Считаем: {left} + {right} = {total}", f"Ответ: {total}", "Совет: называй числа по порядку")

def explain_simple_subtraction(left: int, right: int) -> str:
    result = left - right
    if 10 < left < 20 and 0 < right < 10 and left % 10 < right:
        return explain_subtraction_via_ten(left, right)
    if 10 <= left <= 99 and 10 <= right <= 99 and result >= 0 and left < 100:
        # попробуем устный приём с переходом через десяток
        if left % 10 < right % 10:
            explanation = explain_subtraction_two_digit_with_borrow(left, right)
            if explanation:
                return explanation
        lt, lu = split_tens_units(left)
        rt, ru = split_tens_units(right)
        if lu >= ru:
            return join_explanation_lines(
                "Ищем разность",
                f"Разложим числа на десятки и единицы: {left} = {lt} + {lu}, {right} = {rt} + {ru}",
                f"Вычитаем десятки: {lt} - {rt} = {lt - rt}",
                f"Вычитаем единицы: {lu} - {ru} = {lu - ru}",
                f"Теперь складываем результаты: {lt - rt} + {lu - ru} = {result}",
                f"Ответ: {result}",
                "Совет: двузначные числа удобно раскладывать на десятки и единицы",
            )
    if left >= 100 and right >= 0 and result >= 0:
        return explain_column_subtraction(left, right)
    if result < 0:
        return join_explanation_lines(
            "Сначала сравниваем числа",
            f"{left} меньше {right}, поэтому ответ будет отрицательным",
            f"Считаем: {left} - {right} = {result}",
            f"Ответ: {result}",
            "Совет: перед вычитанием полезно сравнить числа",
        )
    return join_explanation_lines("Ищем разность", f"Считаем: {left} - {right} = {result}", f"Ответ: {result}", "Совет: вычитай спокойно и следи за знаком минус")

def explain_two_digit_by_two_digit_multiplication(left: int, right: int) -> str:
    big = max(left, right)
    small = min(left, right)
    tens, units = split_tens_units(small)
    first = big * tens
    second = big * units
    result = left * right
    return join_explanation_lines(
        "Ищем произведение",
        f"Разложим {small} на {tens} и {units}",
        f"{big} × {tens} = {first}",
        f"{big} × {units} = {second}",
        f"Складываем частичные результаты: {first} + {second} = {result}",
        f"Ответ: {result}",
        "Совет: при умножении удобно разложить одно число на десятки и единицы",
    )

def explain_multiply_divide_by_power_of_10(left: int, right: int, op) -> Optional[str]:
    """Объяснение умножения/деления на 10, 100, 1000."""
    if op is ast.Mult:
        if right in (10, 100, 1000):
            result = left * right
            zeros = len(str(right)) - 1
            return join_explanation_lines(
                f"Умножение на {right}",
                f"При умножении на {right} к числу справа дописываем {zeros} нул{'ь' if zeros == 1 else 'я' if 2 <= zeros <= 4 else 'ей'}",
                f"{left} × {right} = {result}",
                f"Ответ: {result}",
                "Совет: запомни правило умножения на 10, 100, 1000",
            )
        if left in (10, 100, 1000):
            return explain_multiply_divide_by_power_of_10(right, left, op)
    elif op is ast.Div:
        if right in (10, 100, 1000):
            if left % right != 0:
                return None
            result = left // right
            zeros = len(str(right)) - 1
            return join_explanation_lines(
                f"Деление на {right}",
                f"При делении на {right} у числа справа отбрасываем {zeros} нул{'ь' if zeros == 1 else 'я' if 2 <= zeros <= 4 else 'ей'}",
                f"{left} : {right} = {result}",
                f"Ответ: {result}",
                "Совет: запомни правило деления на 10, 100, 1000",
            )
    return None

def explain_two_digit_division(dividend: int, divisor: int) -> Optional[str]:
    """Объяснение деления двузначного на двузначное с однозначным частным методом подбора."""
    if divisor < 10 or dividend < 10 or dividend >= 100 or divisor >= 100:
        return None
    if dividend % divisor != 0:
        return None
    quotient = dividend // divisor
    if quotient >= 10:
        return None
    return join_explanation_lines(
        f"Нужно разделить {dividend} на {divisor}",
        f"Подбираем число, которое при умножении на {divisor} даст {dividend}",
        f"Пробуем: {divisor} × {quotient} = {dividend}",
        f"Значит, {dividend} : {divisor} = {quotient}",
        f"Ответ: {quotient}",
        "Совет: при делении двузначного на двузначное подбирай частное умножением",
    )

def explain_simple_multiplication(left: int, right: int) -> str:
    # сначала проверяем умножение на 10,100,1000
    power10 = explain_multiply_divide_by_power_of_10(left, right, ast.Mult)
    if power10:
        return power10
    result = left * right
    big = max(left, right)
    small = min(left, right)
    if big >= 100:
        return explain_long_multiplication(left, right)
    if 10 <= left <= 99 and 10 <= right <= 99:
        return explain_two_digit_by_two_digit_multiplication(left, right)
    if big >= 10 and small <= 10:
        tens = big - big % 10
        units = big % 10
        return join_explanation_lines(
            "Ищем произведение",
            f"Разбиваем {big} на {tens} и {units}",
            f"{tens} × {small} = {tens * small}",
            f"{units} × {small} = {units * small}",
            f"Теперь складываем части: {tens * small} + {units * small} = {result}",
            f"Ответ: {result}",
            "Совет: умножение удобно разбирать на части",
        )
    return join_explanation_lines("Ищем произведение", f"Считаем: {left} × {right} = {result}", f"Ответ: {result}", "Совет: умножение показывает одинаковые группы")

def explain_simple_division(left: int, right: int) -> str:
    if right == 0:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: сначала смотри на делитель")
    # проверка деления на 10,100,1000
    power10 = explain_multiply_divide_by_power_of_10(left, right, ast.Div)
    if power10:
        return power10
    quotient, remainder = divmod(left, right)
    if left < 100 and right < 100 and 10 <= right <= 99 and remainder == 0 and quotient < 10:
        two_digit_div = explain_two_digit_division(left, right)
        if two_digit_div:
            return two_digit_div
    if left < 100 and right < 10:
        if remainder == 0:
            return join_explanation_lines(
                "Ищем, на какое число нужно умножить делитель, чтобы получить делимое",
                f"{quotient} × {right} = {left}, значит {left} : {right} = {quotient}",
                f"Ответ: {quotient}",
                "Совет: в простом делении полезно проверять умножением",
            )
        return join_explanation_lines(
            "Ищем, сколько полных раз делитель помещается в делимом",
            f"{quotient} × {right} = {quotient * right}",
            f"Остаток: {left} - {quotient * right} = {remainder}",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше делителя",
        )
    if left < 100 and right < 100 and remainder == 0:
        return join_explanation_lines(
            "Ищем, на какое число нужно умножить делитель, чтобы получить делимое",
            f"{right} × {quotient} = {left}",
            f"Значит, {left} : {right} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: при делении двузначных чисел помогает подбор и проверка умножением",
        )
    return explain_long_division(left, right)

def try_simple_binary_int_expression(node: ast.AST) -> Optional[dict]:
    if not isinstance(node, ast.BinOp):
        return None
    if not is_int_literal_node(node.left) or not is_int_literal_node(node.right):
        return None
    left = int_from_literal_node(node.left)
    right = int_from_literal_node(node.right)
    if left < 0 or right < 0:
        return None
    return {"operator": type(node.op), "left": left, "right": right}

def try_local_expression_explanation(raw_text: str) -> Optional[str]:
    source = to_expression_source(raw_text)
    if not source:
        return None
    node = parse_expression_ast(source)
    if node is None:
        return None

    add_chain = flatten_add_chain(node)
    if add_chain and all(n >= 0 for n in add_chain):
        if should_use_column_for_sum(add_chain):
            return explain_column_addition(add_chain)
        if len(add_chain) == 2:
            return explain_simple_addition(add_chain[0], add_chain[1])
        current = add_chain[0]
        lines = ["Ищем сумму нескольких чисел"]
        for idx, n in enumerate(add_chain[1:], start=1):
            new_total = current + n
            prefix = "Сначала" if idx == 1 else "Потом" if idx == 2 else "Дальше"
            lines.append(f"{prefix} складываем: {current} + {n} = {new_total}")
            current = new_total
        lines.extend([f"Ответ: {current}", "Совет: при нескольких действиях считай по порядку"])
        return join_explanation_lines(*lines)

    simple = try_simple_binary_int_expression(node)
    if simple:
        operator = simple["operator"]
        left = simple["left"]
        right = simple["right"]
        if operator is ast.Add:
            return explain_simple_addition(left, right)
        if operator is ast.Sub:
            return explain_simple_subtraction(left, right)
        if operator is ast.Mult:
            return explain_simple_multiplication(left, right)
        if operator is ast.Div:
            return explain_simple_division(left, right)

    try:
        value, steps = build_eval_steps(node, source)
    except ZeroDivisionError:
        return join_explanation_lines("На ноль делить нельзя", "Ответ: деление на ноль невозможно", "Совет: сначала смотри на делитель")
    except Exception:
        return None

    if not steps:
        return None

    body_lines = format_step_lines(steps, source)
    answer = format_fraction(value)
    advice = "сначала выполняй умножение и деление, потом сложение и вычитание" if re.search(r"[+\-].*[*/]|[*/].*[+\-]", source) else default_advice("expression")
    return join_explanation_lines(*body_lines, f"Ответ: {answer}", f"Совет: {advice}")

def try_local_fraction_explanation(raw_text: str) -> Optional[str]:
    source = to_fraction_source(raw_text)
    if not source:
        return None
    match = re.fullmatch(r"\s*(\d+)\s*/\s*(\d+)\s*([+\-])\s*(\d+)\s*/\s*(\d+)\s*", source)
    if not match:
        return None
    a, b, operator, c, d = match.groups()
    a, b, c, d = int(a), int(b), int(c), int(d)
    if b == 0 or d == 0:
        return join_explanation_lines("У дроби знаменатель не может быть равен нулю", "Ответ: запись дроби неверная", "Совет: сначала проверь знаменатели")
    action_symbol = "+" if operator == "+" else "-"
    result = Fraction(a, b) + Fraction(c, d) if operator == "+" else Fraction(a, b) - Fraction(c, d)
    if b == d:
        top_result = a + c if operator == "+" else a - c
        lines = [
            "Сначала смотрим на знаменатели. Они одинаковые",
            f"Значит, работаем только с числителями: {a} {action_symbol} {c} = {top_result}",
            f"Получаем дробь {top_result}/{b}",
        ]
        if format_fraction(result) != f"{top_result}/{b}":
            lines.append(f"Сокращаем: {top_result}/{b} = {format_fraction(result)}")
        lines.extend([f"Ответ: {format_fraction(result)}", "Совет: при одинаковых знаменателях меняется только числитель"])
        return join_explanation_lines(*lines)

    common = math.lcm(b, d)
    a_scaled = a * (common // b)
    c_scaled = c * (common // d)
    top_result = a_scaled + c_scaled if operator == "+" else a_scaled - c_scaled
    simplified = Fraction(top_result, common)
    lines = [
        f"Сначала делаем одинаковые знаменатели: {common}",
        f"{a}/{b} = {a_scaled}/{common}, а {c}/{d} = {c_scaled}/{common}",
        f"Теперь считаем: {a_scaled}/{common} {action_symbol} {c_scaled}/{common} = {top_result}/{common}",
    ]
    if format_fraction(simplified) != f"{top_result}/{common}":
        lines.append(f"Сокращаем: {top_result}/{common} = {format_fraction(simplified)}")
    lines.extend([f"Ответ: {format_fraction(result)}", "Совет: сначала приводи дроби к общему знаменателю"])
    return join_explanation_lines(*lines)

def swap_equation_sides_if_needed(lhs: str, rhs: str):
    if "x" not in lhs and "x" in rhs:
        return rhs, lhs
    return lhs, rhs

def format_equation_check(template: str, value_text: str, expected_text: str) -> str:
    expression = template.replace("x", value_text)
    return f"Проверка: {expression} = {expected_text}"
