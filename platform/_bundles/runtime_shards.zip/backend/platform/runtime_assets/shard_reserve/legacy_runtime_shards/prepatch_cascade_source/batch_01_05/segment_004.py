"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 2630-3482."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
# --- OPENAI HOTFIX 2026-04-11C: correct answer noun for "в скольких ..." tasks ---

def try_priority_bring_to_unit_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or not ("сколько" in lower or "скольких" in lower):
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} ":
        return None

    first_groups = nums[0]
    total_amount = nums[1]
    target_value = nums[2]

    if "таких же" in lower or re.search(r"(?:сколько[^.?!]*\bв\s+\d+\s+[а-яё]+\b)", question):
        solved = explain_bring_to_unit_total_word_problem(first_groups, total_amount, target_value)
        if solved:
            return solved

    if "в скольких" in question or "скольких" in question or _has_group_count_question(question):
        if first_groups == 0 or total_amount % first_groups != 0:
            return None
        per_group = total_amount // first_groups
        if per_group == 0 or target_value % per_group != 0:
            return None
        result = target_value // per_group
        noun_match = re.search(r"в\s+скольких\s+([а-яё]+)", question)
        noun = noun_match.group(1) if noun_match else ""
        noun = noun.strip().rstrip("?.!,")
        answer_tail = f" {noun}" if noun else ""
        return join_explanation_lines(
            f"1) Если в {first_groups} группах {total_amount}, то в одной группе {total_amount} : {first_groups} = {per_group}",
            f"2) Если в одной группе {per_group}, то {target_value} : {per_group} = {result}",
            f"Ответ: {result}{answer_tail}",
            "Совет: в задачах на приведение к единице сначала находят значение одной группы",
        )
    return None

# --- OPENAI HOTFIX 2026-04-11D: no metric unit for "в скольких" questions ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_lower_text(raw_text)
    lower_full = _statement_lower_text(raw_text)

    if "в скольких" in question:
        return ""

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if "мм" in question or "миллиметр" in question:
        return "мм"
    if "см²" in question or "кв. см" in question or ("площад" in question and ("см" in question or "сантиметр" in question)):
        return "см²"
    if "дм²" in question or "кв. дм" in question or ("площад" in question and ("дм" in question or "дециметр" in question)):
        return "дм²"
    if "м²" in question or "кв. м" in question or ("площад" in question and ("м " in question or question.endswith(" м") or "метр" in question)):
        return "м²"
    if re.search(r"(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:килограмм|кг)", question):
        return "кг"
    if re.search(r"(?:(?<!кило)грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:километр|км)", question):
        return "км"
    if re.search(r"(?:сантиметр|см)", question):
        return "см"
    if re.search(r"(?:дециметр|дм)", question):
        return "дм"
    if re.search(r"(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"
    return ""

def try_priority_bring_to_unit_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or not ("сколько" in lower or "скольких" in lower):
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} ":
        return None

    first_groups = nums[0]
    total_amount = nums[1]
    target_value = nums[2]

    if "таких же" in lower or re.search(r"(?:сколько[^.?!]*\bв\s+\d+\s+[а-яё]+\b)", question):
        solved = explain_bring_to_unit_total_word_problem(first_groups, total_amount, target_value)
        if solved:
            return solved

    if "в скольких" in question or "скольких" in question or _has_group_count_question(question):
        if first_groups == 0 or total_amount % first_groups != 0:
            return None
        per_group = total_amount // first_groups
        if per_group == 0 or target_value % per_group != 0:
            return None
        result = target_value // per_group
        return join_explanation_lines(
            f"1) Если в {first_groups} группах {total_amount}, то в одной группе {total_amount} : {first_groups} = {per_group}",
            f"2) Если в одной группе {per_group}, то {target_value} : {per_group} = {result}",
            f"Ответ: {result}",
            "Совет: в задачах на приведение к единице сначала находят значение одной группы",
        )
    return None

# --- OPENAI FINAL PATCH 2026-04-11E: cleaner expression formatting, fuller answers, stronger oral methods ---

_PREV_FINAL_PATCH_explain_simple_addition = explain_simple_addition
_PREV_FINAL_PATCH_explain_simple_subtraction = explain_simple_subtraction
_PREV_FINAL_PATCH_explain_simple_multiplication = explain_simple_multiplication

def _schoolify_expression_source(source: str) -> str:
    text = str(source or "").strip()
    if not text:
        return ""
    out = []
    for i, ch in enumerate(text):
        prev = text[i - 1] if i > 0 else ""
        if ch in "*/+":
            symbol = "×" if ch == "*" else ":" if ch == "/" else ch
            out.append(f" {symbol} ")
        elif ch == "-":
            if i == 0 or prev in "(+-*/":
                out.append("-")
            else:
                out.append(" - ")
        else:
            out.append(ch)
    pretty = re.sub(r"\s+", " ", "".join(out)).strip()
    pretty = pretty.replace("( ", "(").replace(" )", ")")
    return pretty

def _build_pretty_expression_and_operator_map(source: str) -> Tuple[str, dict]:
    raw = str(source or "")
    pretty_parts: List[str] = []
    raw_to_pretty: dict = {}
    current_len = 0
    for i, ch in enumerate(raw):
        prev = raw[i - 1] if i > 0 else ""
        if ch in "*/+":
            token = f" {'×' if ch == '*' else ':' if ch == '/' else ch} "
            raw_to_pretty[i] = current_len + 1
            pretty_parts.append(token)
            current_len += len(token)
        elif ch == "-" and not (i == 0 or prev in "(+-*/"):
            token = " - "
            raw_to_pretty[i] = current_len + 1
            pretty_parts.append(token)
            current_len += len(token)
        else:
            pretty_parts.append(ch)
            current_len += 1
    pretty = re.sub(r"\s+", " ", "".join(pretty_parts)).strip()
    pretty = pretty.replace("( ", "(").replace(" )", ")")
    # after whitespace normalization, rebuild exact operator positions in pretty string
    rebuilt_map: dict = {}
    pi = 0
    ri = 0
    raw_no_space = raw
    while ri < len(raw_no_space) and pi < len(pretty):
        rc = raw_no_space[ri]
        pc = pretty[pi]
        if rc in "*/+" or (rc == "-" and not (ri == 0 or raw_no_space[ri - 1] in "(+-*/")):
            symbol = '×' if rc == '*' else ':' if rc == '/' else rc
            # move to symbol in pretty
            while pi < len(pretty) and pretty[pi] != symbol:
                pi += 1
            if pi < len(pretty):
                rebuilt_map[ri] = pi
                pi += 1
            ri += 1
            continue
        if rc == pc:
            ri += 1
            pi += 1
        else:
            pi += 1
    return pretty, rebuilt_map

# override: preserve parentheses in the first line of expressions and in the order block

# override: fuller numeric answers for text tasks

def _detect_question_unit(raw_text: str) -> str:
    try:
        question = _question_lower_text(raw_text)
    except Exception:
        question = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    if "в скольких" in question:
        return ""
    if "во сколько раз" in question:
        return "раз"

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if "мм" in question or "миллиметр" in question:
        return "мм"
    if "см²" in question or "кв. см" in question or ("площад" in question and ("см" in question or "сантиметр" in question)):
        return "см²"
    if "дм²" in question or "кв. дм" in question or ("площад" in question and ("дм" in question or "дециметр" in question)):
        return "дм²"
    if "м²" in question or "кв. м" in question or ("площад" in question and ("метр" in question or re.search(r"\bм\b", question))):
        return "м²"
    if re.search(r"(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:килограмм|кг)", question):
        return "кг"
    if re.search(r"(?:(?<!кило)грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:километр|км)", question):
        return "км"
    if re.search(r"(?:сантиметр|см)", question):
        return "см"
    if re.search(r"(?:дециметр|дм)", question):
        return "дм"
    if re.search(r"(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"
    return ""

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    if re.fullmatch(r"-?\d+(?:/\d+)?", value):
        unit = _detect_question_unit(raw_text)
        if unit:
            return f"{value} {unit}".strip()
        noun = _extract_question_noun(raw_text)
        if noun:
            return f"{value} {noun}".strip()
    return value

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")

    pretty_expression = _schoolify_expression_source(source)
    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("что известно:", "что нужно найти:"))]
    column_block, remaining_body = _split_ascii_layout_block(body_lines)
    if not remaining_body and not column_block:
        remaining_body = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block and not column_block:
        lines.extend(order_block)
        lines.append("Решение по действиям:")
    else:
        lines.append("Решение.")

    if column_block:
        lines.extend(column_block)
        if remaining_body:
            lines.append("Пояснение:")
    lines.extend(_detailed_number_lines(remaining_body))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

# stronger mental methods for crossing a ten

def explain_simple_addition(left: int, right: int) -> str:
    total = left + right

    if 0 <= left < 10 and 0 <= right < 10 and total > 10:
        return explain_addition_via_ten(left, right)

    big = max(left, right)
    small = min(left, right)
    if 10 <= big <= 99 and 1 <= small <= 9 and (big % 10) + small >= 10 and big % 10 != 0:
        to_next_ten = 10 - (big % 10)
        rest = small - to_next_ten
        next_ten_value = big + to_next_ten
        return join_explanation_lines(
            "Ищем сумму",
            f"Чтобы получить следующий десяток, к {big} нужно прибавить {to_next_ten}",
            f"Разложим {small} на {to_next_ten} и {rest}",
            f"{big} + {to_next_ten} = {next_ten_value}",
            f"{next_ten_value} + {rest} = {total}",
            f"Ответ: {total}",
            "Совет: при сложении через десяток удобно сначала дойти до круглого десятка",
        )

    return _PREV_FINAL_PATCH_explain_simple_addition(left, right)

def explain_simple_subtraction(left: int, right: int) -> str:
    if left >= 20 and left % 10 == 0 and 0 < right < 10:
        first_part = left - 10
        second_part = 10 - right
        result = left - right
        return join_explanation_lines(
            "Ищем разность",
            f"Представим {left} как {first_part} + 10",
            f"Сначала вычтем {right} из 10: 10 - {right} = {second_part}",
            f"Потом прибавим оставшиеся десятки: {first_part} + {second_part} = {result}",
            f"Ответ: {result}",
            "Совет: из круглого десятка удобно вычитать через 10",
        )
    return _PREV_FINAL_PATCH_explain_simple_subtraction(left, right)

def explain_simple_multiplication(left: int, right: int) -> str:
    big = max(left, right)
    small = min(left, right)
    if 10 <= big <= 99 and big % 10 == 0 and 1 <= small <= 9:
        tens = big // 10
        result = big * small
        return join_explanation_lines(
            "Ищем произведение",
            f"Число {big} — это {tens} десятков",
            f"Умножаем десятки: {tens} × {small} = {tens * small} десятков",
            f"{tens * small} десятков = {result}",
            f"Ответ: {result}",
            "Совет: круглое число удобно воспринимать как десятки",
        )
    return _PREV_FINAL_PATCH_explain_simple_multiplication(left, right)

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи",
            "Запишите пример или задачу полнее и без сокращений",
            "Ответ: пока нужен более понятный ввод",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 1800,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- OPENAI FINAL PATCH 2026-04-11F: safer noun enrichment and better tens wording ---

def _can_use_raw_plural_noun_with_count(count_value: int) -> bool:
    value = abs(int(count_value)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return True
    return tail == 0 or tail >= 5

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    if re.fullmatch(r"-?\d+(?:/\d+)?", value):
        unit = _detect_question_unit(raw_text)
        if unit:
            return f"{value} {unit}".strip()
        noun = _extract_question_noun(raw_text)
        if noun:
            try:
                count_value = int(value.split("/", 1)[0])
            except Exception:
                count_value = None
            if noun == "раз":
                return f"{value} раз"
            if count_value is not None and _can_use_raw_plural_noun_with_count(count_value):
                return f"{value} {noun}".strip()
    return value

def explain_simple_multiplication(left: int, right: int) -> str:
    big = max(left, right)
    small = min(left, right)
    if 10 <= big <= 99 and big % 10 == 0 and 1 <= small <= 9:
        tens = big // 10
        tens_word = plural_form(tens, 'десяток', 'десятка', 'десятков')
        product_tens = tens * small
        product_tens_word = plural_form(product_tens, 'десяток', 'десятка', 'десятков')
        result = big * small
        return join_explanation_lines(
            "Ищем произведение",
            f"Число {big} — это {tens} {tens_word}",
            f"Умножаем десятки: {tens} × {small} = {product_tens} {product_tens_word}",
            f"{product_tens} {product_tens_word} = {result}",
            f"Ответ: {result}",
            "Совет: круглое число удобно воспринимать как десятки",
        )
    return _PREV_FINAL_PATCH_explain_simple_multiplication(left, right)

# --- FINAL PATCH 2026-04-11G: textbook fixes, fuller answers, better compound tasks ---

_PATCH20260411G_PREVIOUS_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже обязательно:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. По возможности используй школьную форму:
Если ..., то ...
6. Если сразу нельзя ответить на главный вопрос, сначала найди то, что нужно для ответа.
7. После каждого действия коротко говори, что нашли.
8. В конце:
Ответ: ...
Ответ лучше писать полной фразой, а не только числом.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если это выражение, сначала назови порядок действий.
Если это уравнение, оставляй x отдельно и объясняй обратное действие.
Если это дроби, сначала смотри на знаменатели.
Если это геометрия, сначала назови формулу, потом подставь числа.
Если это именованные величины, сначала переведи их в одинаковые единицы.

Используй школьные приёмы:
сложение через десяток — разложи число так, чтобы сначала получить 10;
вычитание через десяток — вычитай по частям через 10;
двузначные числа раскладывай на десятки и единицы;
если числа большие, объясняй по разрядам;
для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

def _patch_answer_with_question_noun(value: int, raw_text: str) -> str:
    unit = _detect_question_unit(raw_text) or ""
    if unit:
        return f"{value} {unit}".strip()
    noun = _extract_question_noun(raw_text)
    if noun:
        try:
            count = int(value)
        except Exception:
            count = None
        if noun == "раз":
            return f"{value} раз"
        if count is not None and _can_use_raw_plural_noun_with_count(count):
            return f"{value} {noun}".strip()
    return str(value)

def try_patch_unknown_minuend_simple_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in question:
        return None
    if not ("было" in question or "сначала" in question):
        return None
    if "остал" not in lower:
        return None
    if not contains_any_fragment(lower, WORD_LOSS_HINTS + ("сняли", "взяли", "убрали", "забрали", "отдали", "продали")):
        return None

    removed, remaining = nums[0], nums[1]
    total = removed + remaining
    removed_phrase = _patch_number_phrase(raw_text, removed, 0)
    remaining_phrase = _patch_number_phrase(raw_text, remaining, 0)
    answer = _patch_answer_with_question_noun(total, raw_text)
    return join_explanation_lines(
        f"1) Если сняли {removed_phrase} и осталось {remaining_phrase}, то сначала было {removed} + {remaining} = {answer}",
        f"Ответ: {answer}",
        "Совет: чтобы найти, сколько было сначала, к оставшемуся прибавляют то, что убрали",
    )

def try_patch_implicit_total_with_relation_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in question:
        return None
    if not (("в первый день" in lower and "во второй" in lower) or ("в первый" in lower and "во второй" in lower)):
        return None
    if "во второй" in question or "в первый" in question:
        return None

    base = nums[0]
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    noun_matches = re.findall(rf"{base}\s+([а-яё]+)", lower)
    noun = noun_matches[0] if noun_matches else ""

    if len(relation_pairs) == 1:
        delta, mode = relation_pairs[0]
        if delta != nums[1]:
            return None
        second = apply_more_less(base, delta, mode)
        if second is None:
            return None
        op = "+" if mode == "больше" else "-"
        total = base + second
        answer = _patch_answer_with_question_noun(total, raw_text)
        second_text = f"{second} {noun}".strip()
        return join_explanation_lines(
            f"1) Если в первый день было {base} {noun}, а во второй на {delta} {mode}, то во второй день было {base} {op} {delta} = {second_text}",
            f"2) Если в первый день было {base} {noun}, а во второй день {second_text}, то всего {base} + {second} = {answer}",
            f"Ответ: {answer}",
            "Совет: если сразу нельзя ответить на главный вопрос, сначала найди неизвестное количество, потом сумму",
        )

    if len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        if factor != nums[1]:
            return None
        second = apply_times_relation(base, factor, mode)
        if second is None:
            return None
        op = "×" if mode == "больше" else ":"
        total = base + second
        answer = _patch_answer_with_question_noun(total, raw_text)
        second_text = f"{second} {noun}".strip()
        return join_explanation_lines(
            f"1) Если во второй день в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то во второй день было {base} {op} {factor} = {second_text}",
            f"2) Если в первый день было {base} {noun}, а во второй день {second_text}, то всего {base} + {second} = {answer}",
            f"Ответ: {answer}",
            "Совет: сначала найди число, которое дано через отношение, потом считай всё вместе",
        )
    return None

def try_patch_part_then_compare_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "из них" not in lower or "осталь" not in lower:
        return None
    if not ("на сколько" in question or "во сколько" in question):
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None

    total, known = nums[0], nums[1]
    if known > total:
        return None
    other = total - known

    pattern = re.search(r"из\s+них\s+(\d+)\s+([а-яё]+).*?остальн[а-яё]*\s*[—-]?\s*([а-яё]+)", lower)
    known_name = pattern.group(2) if pattern else "известной части"
    other_name = pattern.group(3) if pattern else "другой части"
    q_left, q_right = _patch_pick_compare_names_from_question(raw_text)
    if q_left:
        known_name = q_left if q_left in lower else known_name
        other_name = q_right if q_right in lower else other_name

    if "во сколько" in question:
        bigger = max(known, other)
        smaller = min(known, other)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        return join_explanation_lines(
            f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
        )

    bigger = max(known, other)
    smaller = min(known, other)
    diff = bigger - smaller
    if known >= other:
        answer_line = f"Ответ: {known_name} на {diff} больше, чем {other_name}"
    else:
        answer_line = f"Ответ: {other_name} на {diff} больше, чем {known_name}"
    return join_explanation_lines(
        f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
        f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
        answer_line,
        "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
    )

def try_patch_same_quantity_price_compare_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "за столько же" not in lower or not ("дороже" in question or "дешевле" in question):
        return None

    first = re.search(r"за\s+(\d+)\s+([а-яё]+)\s+([а-яё]+)\s+заплатил\w*\s+(\d+)\s*руб", lower)
    second = re.search(r"за\s+столько\s+же\s+([а-яё]+)\s+([а-яё]+)\s+\w+\s+заплатил\w*\s+(\d+)\s*руб", lower)
    if not first or not second:
        return None

    count = int(first.group(1))
    unit_plural = first.group(2)
    item1 = first.group(3)
    cost1 = int(first.group(4))
    item2 = second.group(2)
    cost2 = int(second.group(3))
    if count == 0 or cost1 % count != 0 or cost2 % count != 0:
        return None

    price1 = cost1 // count
    price2 = cost2 // count
    diff = abs(price1 - price2)
    unit_singular = _patch_singular_unit(unit_plural)

    asked = re.search(rf"{unit_singular}\s+([а-яё]+).*?чем\s+{unit_singular}\s+([а-яё]+)", question)
    left_item = asked.group(1) if asked else item2
    right_item = asked.group(2) if asked else item1
    price_by_item = {item1: price1, item2: price2}
    if left_item not in price_by_item or right_item not in price_by_item:
        return None

    left_price = price_by_item[left_item]
    right_price = price_by_item[right_item]
    if left_price > right_price:
        answer_line = f"Ответ: один {unit_singular} {left_item} на {diff} руб. дороже, чем один {unit_singular} {right_item}"
    elif left_price < right_price:
        answer_line = f"Ответ: один {unit_singular} {left_item} на {diff} руб. дешевле, чем один {unit_singular} {right_item}"
    else:
        answer_line = f"Ответ: один {unit_singular} {left_item} стоит столько же, сколько и один {unit_singular} {right_item}"

    return join_explanation_lines(
        f"1) Если за {count} {unit_plural} {item1} заплатили {cost1} руб., то один {unit_singular} {item1} стоит {cost1} : {count} = {price1} руб",
        f"2) Если за {count} {unit_plural} {item2} заплатили {cost2} руб., то один {unit_singular} {item2} стоит {cost2} : {count} = {price2} руб",
        f"3) Сравниваем цены: {max(price1, price2)} - {min(price1, price2)} = {diff} руб",
        answer_line,
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

def try_patch_named_sum_of_two_products_money_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in lower:
        return None
    if not (contains_any_fragment(lower, ("заплат", "стоим")) or contains_any_fragment(question, ("сколько денег", "сколько заплат", "сколько стоила", "сколько стоит"))):
        return None

    products = _po_product_matches(raw_text)
    if len(products) < 2:
        return None
    if contains_any_fragment(question, ("сколько стоит 1", "сколько стоила 1", "сколько стоила одна", "сколько стоит одна")):
        return None

    first = products[0]
    second = products[1]
    first_total = first["count"] * first["value"]
    second_total = second["count"] * second["value"]
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если купили {first['count']} {first['name']} по {first['value']} руб., то за {first['name']} заплатили {first['count']} × {first['value']} = {first_total} руб",
        f"2) Если купили {second['count']} {second['name']} по {second['value']} руб., то за {second['name']} заплатили {second['count']} × {second['value']} = {second_total} руб",
        f"3) Если за {first['name']} заплатили {first_total} руб., а за {second['name']} {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: за всю покупку заплатили {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
    )

def try_patch_labeled_proportional_division_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if not contains_any_fragment(lower, ("цена наборов одинаковая", "цена одинаковая", "если цена наборов одинаковая", "если цена одинаковая")):
        return None
    if not ("сколько" in question and contains_any_fragment(question, ("каждого", "каждая", "каждой"))):
        return None

    match = re.search(r"(\d+)\s+([^.,;]+?)\s+и\s+(\d+)\s+([^.,;]+?)\.\s*за\s+всю\s+покупку\s+заплатил[аи]?\s+(\d+)\s*руб", lower)
    if not match:
        return None

    count1 = int(match.group(1))
    label1 = match.group(2).strip()
    count2 = int(match.group(3))
    label2 = match.group(4).strip()
    total_cost = int(match.group(5))

    total_count = count1 + count2
    if total_count == 0 or total_cost % total_count != 0:
        return None
    one_price = total_cost // total_count
    first_cost = one_price * count1
    second_cost = one_price * count2

    return join_explanation_lines(
        f"1) Если купили {count1} {label1} и {count2} {label2}, то всего купили {count1} + {count2} = {total_count} наборов",
        f"2) Если за {total_count} наборов заплатили {total_cost} руб., то один набор стоит {total_cost} : {total_count} = {one_price} руб",
        f"3) Если один набор стоит {one_price} руб., то за {count1} {label1} заплатили {one_price} × {count1} = {first_cost} руб",
        f"4) Если один набор стоит {one_price} руб., то за {count2} {label2} заплатили {one_price} × {count2} = {second_cost} руб",
        f"Ответ: за {count1} {label1} заплатили {first_cost} руб.; за {count2} {label2} — {second_cost} руб",
        "Совет: в задачах на пропорциональное деление сначала находят одну равную часть",
    )

def try_patch_labeled_two_differences_bag_counts_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or "мешк" not in question:
        return None
    if not ("морков" in lower and "картоф" in lower):
        return None

    carrot_mass, potato_mass, diff_bags = nums
    diff_mass = potato_mass - carrot_mass
    if diff_bags == 0 or diff_mass <= 0 or diff_mass % diff_bags != 0:
        return None
    per_bag = diff_mass // diff_bags
    if carrot_mass % per_bag != 0 or potato_mass % per_bag != 0:
        return None
    carrot_bags = carrot_mass // per_bag
    potato_bags = potato_mass // per_bag

    return join_explanation_lines(
        f"1) Если картофеля собрали {potato_mass} кг, а моркови {carrot_mass} кг, то разность масс равна {potato_mass} - {carrot_mass} = {diff_mass} кг",
        f"2) Если эти {diff_mass} кг составляют {diff_bags} мешков, то в одном мешке {diff_mass} : {diff_bags} = {per_bag} кг",
        f"3) Если моркови {carrot_mass} кг, а в одном мешке {per_bag} кг, то мешков моркови {carrot_mass} : {per_bag} = {carrot_bags}",
        f"4) Если картофеля {potato_mass} кг, а в одном мешке {per_bag} кг, то мешков картофеля {potato_mass} : {per_bag} = {potato_bags}",
        f"Ответ: моркови было {carrot_bags} мешков, картофеля — {potato_bags} мешков",
        "Совет: в задачах по двум разностям сначала находят, чему соответствует одна равная часть",
    )
