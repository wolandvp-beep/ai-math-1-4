"""Auto-generated runtime shard for prepatch_build_source.py, lines 19364-20233."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _mass20260416x_try_volume_geometry(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'объем куба с ребром (\d+)\s*(см|дм|м)', lower)
    if m:
        a = int(m.group(1)); unit = m.group(2); v = a ** 3
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Объем куба находят по формуле V = a × a × a.',
            f'2) Подставляем число: {a} × {a} × {a} = {v}.',
            f'Ответ: {v} {unit}³',
            'Совет: объем куба равен кубу его ребра',
        ])

    m = re.search(r'длина прямоугольного параллелепипеда (\d+)\s*(см|дм|м), ширина (\d+)\s*\2, высота (\d+)\s*\2', lower)
    if m and 'объем' in lower:
        l = int(m.group(1)); unit = m.group(2); w = int(m.group(3)); h = int(m.group(4)); v = l * w * h
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Объем прямоугольного параллелепипеда находят по формуле V = a × b × c.',
            f'2) Подставляем числа: {l} × {w} × {h} = {v}.',
            f'Ответ: {v} {unit}³',
            'Совет: объем прямоугольного параллелепипеда равен произведению длины, ширины и высоты',
        ])

    m = re.search(r'площадь пола комнаты (\d+)\s*м², высота (\d+)\s*м', lower)
    if m and 'объем комнаты' in lower:
        s = int(m.group(1)); h = int(m.group(2)); v = s * h
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Объем комнаты равен площади пола, умноженной на высоту.',
            f'2) {s} × {h} = {v}.',
            f'Ответ: {v} м³',
            'Совет: объем прямоугольной комнаты можно найти как площадь пола, умноженную на высоту',
        ])

    m = re.search(r'ребро куба увеличили в (\d+) раза', lower)
    if m and 'во сколько раз увеличился объем' in lower:
        k = int(m.group(1)); factor = k ** 3
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Если ребро куба увеличить в {k} раза, то каждая из трех мер увеличится в {k} раза.',
            f'2) Объем увеличится в {k} × {k} × {k} = {factor} раз.',
            f'Ответ: в {factor} раз',
            'Совет: при увеличении всех трех измерений в несколько раз объем увеличивается в куб этого числа',
        ])

    m = re.search(r'площадь поверхности куба с ребром (\d+)\s*(см|дм|м)', lower)
    if m:
        a = int(m.group(1)); unit = m.group(2); face = a * a; area = face * 6
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) У куба 6 одинаковых граней.',
            f'2) Площадь одной грани: {a} × {a} = {face} {unit}².',
            f'3) Площадь всей поверхности: {face} × 6 = {area} {unit}².',
            f'Ответ: {area} {unit}²',
            'Совет: площадь поверхности куба равна площади одной грани, умноженной на 6',
        ])

    m = re.search(r'прямоугольный участок земли имеет длину (\d+) м и ширину (\d+) м', lower)
    if m:
        l, w = map(int, m.groups()); area = l * w; per = 2 * (l + w)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь участка: {l} × {w} = {area} м².',
            f'2) Периметр участка: ({l} + {w}) × 2 = {per} м.',
            f'Ответ: площадь {area} м², периметр {per} м',
            'Совет: площадь прямоугольника равна длине, умноженной на ширину',
        ])

    m = re.search(r'квадрат и прямоугольник имеют одинаковую площадь (\d+) см².*ширина прямоугольника (\d+) см', lower)
    if m and 'найди длину прямоугольника' in lower:
        area = int(m.group(1)); w = int(m.group(2)); l = area // w
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь прямоугольника равна {area} см².',
            f'2) Длина прямоугольника равна площади, деленной на ширину: {area} : {w} = {l} см.',
            f'Ответ: {l} см',
            'Совет: если известны площадь и одна сторона прямоугольника, другую сторону находят делением',
        ])

    m = re.search(r'начерти прямоугольник, площадь которого (\d+) см², а длина (\d+) см', lower)
    if m and 'периметр' in lower:
        area = int(m.group(1)); l = int(m.group(2)); w = area // l; per = 2 * (l + w)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим ширину прямоугольника: {area} : {l} = {w} см.',
            f'2) Находим периметр: ({l} + {w}) × 2 = {per} см.',
            f'Ответ: {per} см',
            'Совет: если известны площадь и длина прямоугольника, ширину находят делением',
        ])

    m = re.search(r'объем аквариума (\d+) л.*высота аквариума (\d+) дм, ширина (\d+) дм', lower)
    if m and 'найди длину' in lower:
        v = int(m.group(1)); h = int(m.group(2)); w = int(m.group(3)); l = v // (h * w)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) 1 л = 1 дм³, значит, объем равен в кубических дециметрах тому же числу.',
            f'2) Длина равна объему, деленному на ширину и высоту: {v} : ({w} × {h}) = {l} дм.',
            f'Ответ: {l} дм',
            'Совет: неизвестное измерение прямоугольного параллелепипеда находят делением объема на произведение двух других',
        ])

    m = re.search(r'прямоугольник разрезали на (\d+) одинаковых квадратов. сумма периметров квадратов (\d+) см', lower)
    if m and 'периметр исходного прямоугольника' in lower:
        n = int(m.group(1)); sum_per = int(m.group(2))
        one_square_per = sum_per // n; side = one_square_per // 4
        per = 2 * ((side * n) + side)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Периметр одного квадрата: {sum_per} : {n} = {one_square_per} см.',
            f'2) Сторона квадрата: {one_square_per} : 4 = {side} см.',
            f'3) Исходный прямоугольник составлен из {n} квадратов, значит, его стороны {side * n} см и {side} см.',
            f'4) Периметр исходного прямоугольника: ({side * n} + {side}) × 2 = {per} см.',
            f'Ответ: {per} см',
            'Совет: если фигура составлена из одинаковых квадратов, сначала находят сторону одного квадрата',
        ])

    m = re.search(r'квадрат разрезали на два равных прямоугольника с периметром (\d+) см каждый', lower)
    if m and 'сторону квадрата' in lower:
        per = int(m.group(1))
        if per % 3 != 0:
            return None
        side = per // 3
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Если квадрат разрезать пополам, получится прямоугольник со сторонами a и a/2.',
            f'2) Периметр такого прямоугольника равен 2 × (a + a/2) = 3a.',
            f'3) Значит, 3a = {per}, поэтому a = {per} : 3 = {side} см.',
            f'Ответ: {side} см',
            'Совет: в составных геометрических задачах сначала вырази искомую величину через сторону фигуры',
        ])
    return None

def _mass20260416x_try_fraction_drawing_and_piece(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    m = re.search(r'начерти отрезок (\d+) см, покажи (\d+)/(\d+) этого отрезка', lower)
    if m:
        total = int(m.group(1)); num = int(m.group(2)); den = int(m.group(3))
        if total % den != 0:
            return None
        part = total // den * num
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим одну {den}-ю часть отрезка: {total} : {den} = {total // den} см.',
            f'2) Находим {num}/{den} отрезка: {total // den} × {num} = {part} см.',
            f'Ответ: нужно показать {part} см',
            'Совет: чтобы найти дробь от длины, сначала делят на знаменатель, потом умножают на числитель',
        ])
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _mass20260416x_try_compare(user_text)
        or _mass20260416x_try_box_equation(user_text)
        or _mass20260416x_try_basic_geometry(user_text)
        or _mass20260416x_try_named_units(user_text)
        or _mass20260416x_try_generic_unit_rate(user_text)
        or _mass20260416x_try_simple_fraction_meta(user_text)
        or _mass20260416x_try_decimals(user_text)
        or _mass20260416x_try_percent(user_text)
        or _mass20260416x_try_average(user_text)
        or _mass20260416x_try_system_word_problems(user_text)
        or _mass20260416x_try_volume_geometry(user_text)
        or _mass20260416x_try_fraction_drawing_and_piece(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _MASS20260416X_PREV_BUILD_EXPLANATION(user_text)

# --- MASS AUDIT PATCH 2026-04-16Y: fix mixed verbs, geometry wording, fraction chains, motion details ---

_MASS20260416Y_PREV_BUILD_EXPLANATION = build_explanation

def _mass20260416y_try_specific_words(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    m = re.search(r'в классе (\d+) мальчиков и (\d+) девочки', lower)
    if m and 'кого меньше' in lower and 'на сколько' in lower:
        boys = int(m.group(1)); girls = int(m.group(2)); diff = boys - girls
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: мальчиков {boys}, девочек {girls}.',
            'Что нужно найти: кого меньше и на сколько.',
            f'1) Сравниваем количества: {boys} - {girls} = {diff}.',
            f'2) Девочек меньше, потому что {girls} меньше {boys}.',
            f'Ответ: девочек меньше на {diff}',
            'Совет: чтобы узнать, на сколько одно число меньше другого, из большего вычитают меньшее',
        ])

    m = re.search(r'у лены (\d+) руб[а-я]*, а у оли на (\d+) руб[а-я]* меньше', lower)
    if m and 'сколько денег у обеих' in lower:
        lena = int(m.group(1)); diff = int(m.group(2)); olya = lena - diff; total = lena + olya
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько денег у Оли: {lena} - {diff} = {olya} руб.',
            f'2) Находим, сколько денег у обеих девочек: {lena} + {olya} = {total} руб.',
            f'Ответ: {total} руб.',
            'Совет: если сказано «на несколько меньше», нужно вычитать',
        ])

    m = re.search(r'в вагоне ехали (\d+) человек, на станции вышли (\d+), а зашли (\d+)', lower)
    if m:
        start, out, come = map(int, m.groups()); after = start - out + come
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) После того как вышли {out} человек, осталось: {start} - {out} = {start - out}.',
            f'2) Потом зашли {come} человек: {start - out} + {come} = {after}.',
            f'Ответ: {after} человек',
            'Совет: если сначала люди вышли, вычитаем, а если потом зашли, прибавляем',
        ])

    m = re.search(r'в магазине было (\d+) кг муки\. продали (\d+) кг, потом привезли (\d+) кг', lower)
    if m:
        start, sold, came = map(int, m.groups()); after = start - sold + came
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) После продажи осталось: {start} - {sold} = {start - sold} кг.',
            f'2) Потом привезли ещё {came} кг: {start - sold} + {came} = {after} кг.',
            f'Ответ: {after} кг',
            'Совет: если сначала убавили, а потом прибавили, выполняй действия по порядку',
        ])

    m = re.search(r'у сережи (\d+) марки, у коли на (\d+) марок меньше, а у вити на (\d+) больше, чем у коли', lower)
    if m:
        s, less, more = map(int, m.groups()); kolya = s - less; vitya = kolya + more
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько марок у Коли: {s} - {less} = {kolya}.',
            f'2) Находим, сколько марок у Вити: {kolya} + {more} = {vitya}.',
            f'Ответ: {vitya} марок',
            'Совет: в составной задаче сначала находят промежуточное количество',
        ])

    m = re.search(r'в автобусе было (\d+) пассажиров\. на остановке вышли (\d+) и зашли (\d+)', lower)
    if m:
        start, out, come = map(int, m.groups()); after = start - out + come
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) После того как вышли {out} пассажиров, осталось: {start} - {out} = {start - out}.',
            f'2) Потом зашли {come} пассажиров: {start - out} + {come} = {after}.',
            f'Ответ: {after} пассажира' if str(after).endswith('4') else f'Ответ: {after} пассажиров',
            'Совет: если пассажиры выходят, число уменьшается, а если заходят, увеличивается',
        ])

    m = re.search(r'масса тыквы (\d+) кг, а арбуза - в (\d+) раза меньше', lower)
    if m and ('общая масса' in lower or 'какова общая масса' in lower):
        pumpkin, k = map(int, m.groups()); watermelon = pumpkin // k; total = pumpkin + watermelon
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим массу арбуза: {pumpkin} : {k} = {watermelon} кг.',
            f'2) Находим общую массу: {pumpkin} + {watermelon} = {total} кг.',
            f'Ответ: {total} кг',
            'Совет: если сказано «в несколько раз меньше», нужно делить',
        ])
    return None

def _mass20260416y_try_geometry_updates(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    m = re.search(r'прямоугольник имеет стороны (\d+) см и (\d+) см', lower)
    if m and 'сумму длин всех сторон' in lower:
        a, b = map(int, m.groups()); per = 2 * (a + b)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Сумма длин всех сторон прямоугольника — это его периметр.',
            f'2) Периметр: ({a} + {b}) × 2 = {per} см.',
            f'Ответ: {per} см',
            'Совет: у прямоугольника две длины и две ширины',
        ])

    m = re.search(r'периметр треугольника (\d+) см, две стороны по (\d+) см', lower)
    if m and 'третью сторону' in lower:
        per, side = map(int, m.groups()); third = per - side - side
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Из периметра вычитаем две известные стороны: {per} - {side} - {side} = {third} см.',
            f'Ответ: {third} см',
            'Совет: периметр — это сумма длин всех сторон фигуры',
        ])

    m = re.search(r'квадрат и прямоугольник имеют одинаковый периметр (\d+) см', lower)
    if m and 'сторона квадрата' in lower:
        per = int(m.group(1)); side = per // 4
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) У квадрата все стороны равны.',
            f'2) Чтобы найти сторону квадрата, делим периметр на 4: {per} : 4 = {side} см.',
            f'Ответ: {side} см',
            'Совет: сторону квадрата находят делением периметра на 4',
        ])

    m = re.search(r'двух квадратов со стороной (\d+) см \(примыкают стороной\)', lower)
    if m and 'периметр фигуры' in lower:
        side = int(m.group(1)); per = side * 6
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) У двух квадратов было бы {8} стороны по {side} см, если бы они не соприкасались.',
            f'2) Одна общая сторона внутри фигуры не входит в периметр. Таких сторон две по {side} см.',
            f'3) Периметр фигуры: {side} × 8 - {side} × 2 = {per} см.',
            f'Ответ: {per} см',
            'Совет: общая сторона внутри составной фигуры в периметр не входит',
        ])

    m = re.search(r'найди площадь прямоугольника со сторонами (\d+) см и (\d+) см', lower)
    if m:
        a, b = map(int, m.groups()); area = a * b
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь прямоугольника находят умножением длины на ширину.',
            f'2) {a} × {b} = {area} см².',
            f'Ответ: {area} см²',
            'Совет: площадь прямоугольника равна длине, умноженной на ширину',
        ])

    if 'сравни площади' in lower and 'прямоугольник 6×2' in lower and 'квадрат со стороной 3 см' in lower:
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Площадь прямоугольника: 6 × 2 = 12 см².',
            '2) Площадь квадрата: 3 × 3 = 9 см².',
            '3) 12 см² больше 9 см².',
            'Ответ: площадь прямоугольника больше',
            'Совет: чтобы сравнить площади, сначала находят площадь каждой фигуры',
        ])

    m = re.search(r'площадь листа бумаги (\d+) см², его отрезали пополам', lower)
    if m:
        area = int(m.group(1)); half = area // 2
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Половина — это одна вторая часть.',
            f'2) {area} : 2 = {half} см².',
            f'Ответ: {half} см²',
            'Совет: чтобы найти половину величины, её делят на 2',
        ])

    m = re.search(r'двух квадратов со стороной (\d+) см \(без наложения\)', lower)
    if m and 'площадь фигуры' in lower:
        side = int(m.group(1)); one = side * side; total = one * 2
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Площадь одного квадрата: {side} × {side} = {one} см².',
            f'2) Площадь двух квадратов: {one} + {one} = {total} см².',
            f'Ответ: {total} см²',
            'Совет: если фигуры не накладываются, их площади складывают',
        ])

    m = re.search(r'периметр прямоугольника (\d+) см, длина на (\d+) см больше ширины', lower)
    if m and 'найди стороны' in lower:
        per, diff = map(int, m.groups()); half = per // 2; width = (half - diff) // 2; length = width + diff
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Полупериметр прямоугольника равен сумме длины и ширины: {per} : 2 = {half} см.',
            f'2) Если длина на {diff} см больше ширины, то width + ({diff} + width) = {half}.',
            f'3) Вычитаем разницу: {half} - {diff} = {half - diff}.',
            f'4) Ширина: {half - diff} : 2 = {width} см.',
            f'5) Длина: {width} + {diff} = {length} см.',
            f'Ответ: ширина {width} см, длина {length} см',
            'Совет: у прямоугольника длина и ширина вместе дают полупериметр',
        ])
    return None

def _mass20260416y_try_fraction_parts_compare(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    m = re.search(r'что больше:\s*(\d+)/(\d+)\s*от\s*(\d+)\s*или\s*(\d+)/(\d+)\s*от\s*(\d+)', lower)
    if m:
        a1, b1, n1, a2, b2, n2 = map(int, m.groups())
        first = Fraction(n1 * a1, b1)
        second = Fraction(n2 * a2, b2)
        cmp = 'равны'
        if first > second:
            cmp = 'больше первая величина'
        elif first < second:
            cmp = 'больше вторая величина'
        first_txt = str(first.numerator // first.denominator) if first.denominator == 1 else f'{first.numerator}/{first.denominator}'
        second_txt = str(second.numerator // second.denominator) if second.denominator == 1 else f'{second.numerator}/{second.denominator}'
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим {a1}/{b1} от {n1}: {n1} : {b1} × {a1} = {first_txt}.',
            f'2) Находим {a2}/{b2} от {n2}: {n2} : {b2} × {a2} = {second_txt}.',
            f'3) Сравниваем: {first_txt} и {second_txt}.',
            f'Ответ: {cmp}',
            'Совет: чтобы сравнить дробные части разных чисел, сначала нужно найти каждую часть',
        ])
    return None

def _mass20260416y_try_fraction_same_denominator_chain(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(text).replace('−', '-').replace('–', '-').replace(' ', '')
    if not re.fullmatch(r'(\d+/\d+)([+\-]\d+/\d+)+=?', clean):
        return None
    expr = clean.rstrip('=')
    terms = re.findall(r'[+\-]?\d+/\d+', expr)
    fractions = []
    ops = []
    for idx, term in enumerate(terms):
        sign = 1
        if term.startswith('+'):
            term = term[1:]
        elif term.startswith('-'):
            sign = -1
            term = term[1:]
        n, d = map(int, term.split('/'))
        fractions.append((sign * n, d))
        if idx > 0:
            ops.append('+' if signs[idx] > 0 else '-')
    dens = {d for _, d in fractions}
    if len(dens) != 1:
        return None
    den = next(iter(dens))
    total_num = sum(n for n, _ in fractions)
    shown_terms = []
    for i, (n, _) in enumerate(fractions):
        sign = '-' if n < 0 else '+'
        part = f'{abs(n)}/{den}'
        if i == 0:
            shown_terms.append(part if n >= 0 else f'-{part}')
        else:
            shown_terms.append(f'{sign} {part}')
    pretty = ' '.join(shown_terms)
    answer = f'{total_num}/{den}'
    simple = Fraction(total_num, den)
    lines = [
        f'Пример: {pretty}',
        'Решение.',
        f'1) У всех дробей одинаковый знаменатель: {den}.',
        '2) Значит, складываем и вычитаем только числители, а знаменатель оставляем прежним.',
    ]
    num_expr = ' '.join([str(abs(n)) if i == 0 and n >= 0 else (f'- {abs(n)}' if n < 0 else f'+ {n}') for i, (n, _) in enumerate(fractions)])
    lines.append(f'3) {num_expr} = {total_num}.')
    lines.append(f'4) Получаем: {answer}.')
    if simple.denominator != den or simple.numerator != total_num:
        lines.append(f'5) Если сократить дробь, получится: {simple.numerator}/{simple.denominator}.')
        lines.append(f'Ответ: {pretty} = {answer} = {simple.numerator}/{simple.denominator}')
    else:
        lines.append(f'Ответ: {pretty} = {answer}')
    lines.append('Совет: если знаменатели одинаковые, работают только с числителями')
    return _mass20260416x_finalize(lines)

def _mass20260416y_try_motion_updates(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    m = re.search(r'пешеход прошел (\d+) км за (\d+) ч', lower)
    if m and 'найди его скорость' in lower:
        s, t = map(int, m.groups()); v = s // t
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Чтобы найти скорость, нужно расстояние разделить на время.',
            f'2) {s} : {t} = {v} км/ч.',
            f'Ответ: {v} км/ч',
            'Совет: скорость находят делением расстояния на время',
        ])

    m = re.search(r'лодка плыла (\d+) ч по течению со скоростью (\d+) км/ч, а затем (\d+) ч против течения со скоростью (\d+) км/ч', lower)
    if m and 'сколько всего км' in lower:
        t1, v1, t2, v2 = map(int, m.groups()); s1 = t1 * v1; s2 = t2 * v2; total = s1 + s2
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) По течению лодка прошла: {v1} × {t1} = {s1} км.',
            f'2) Против течения лодка прошла: {v2} × {t2} = {s2} км.',
            f'3) Всего лодка прошла: {s1} + {s2} = {total} км.',
            f'Ответ: {total} км',
            'Совет: если путь состоит из двух частей, сначала находят каждую часть, потом складывают',
        ])

    m = re.search(r'теплоход прошел (\d+) км за (\d+) ч по течению реки.*скорость течения (\d+) км/ч', lower)
    if m and 'стоячей воде' in lower:
        s, t, c = map(int, m.groups()); down = s // t; still = down - c
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим скорость теплохода по течению: {s} : {t} = {down} км/ч.',
            f'2) Скорость по течению равна скорости в стоячей воде плюс скорость течения.',
            f'3) Значит, скорость в стоячей воде: {down} - {c} = {still} км/ч.',
            f'Ответ: {still} км/ч',
            'Совет: по течению скорость увеличивается на скорость течения',
        ])

    m = re.search(r'пешеход со скоростью (\d+) км/ч\. через (\d+) ч следом выехал велосипедист со скоростью (\d+) км/ч', lower)
    if m and 'догонит' in lower:
        vp, wait, vb = map(int, m.groups()); lead = vp * wait; rel = vb - vp; t = lead // rel
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) За {wait} ч пешеход успел пройти: {vp} × {wait} = {lead} км.',
            f'2) Скорость сближения: {vb} - {vp} = {rel} км/ч.',
            f'3) Время догоняния: {lead} : {rel} = {t} ч.',
            f'Ответ: {t} ч',
            'Совет: в задаче на догоняние расстояние между участниками делят на скорость сближения',
        ])

    m = re.search(r'расстояние между которыми (\d+) км\. одна ехала (\d+) км/ч, другая (\d+) км/ч', lower)
    if m and 'через сколько часов они встретятся' in lower:
        s, v1, v2 = map(int, m.groups()); rel = v1 + v2; t = s // rel
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) При движении навстречу скорость сближения равна сумме скоростей: {v1} + {v2} = {rel} км/ч.',
            f'2) Время встречи: {s} : {rel} = {t} ч.',
            f'Ответ: {t} ч',
            'Совет: при движении навстречу используют скорость сближения',
        ])
    return None

def _mass20260416y_try_average_grade(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    m = re.search(r'оценки:\s*([0-9,\s]+)\.?\s*найди средний балл', lower)
    if m:
        nums = [int(x.strip()) for x in m.group(1).split(',') if x.strip()]
        total = sum(nums); n = len(nums); avg = Decimal(total) / Decimal(n)
        avg_txt = _mass20260416x_fmt_decimal(avg)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Складываем оценки: {" + ".join(map(str, nums))} = {total}.',
            f'2) Делим сумму на число оценок: {total} : {n} = {avg_txt}.',
            f'Ответ: {avg_txt}',
            'Совет: средний балл — это среднее арифметическое всех оценок',
        ])
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _mass20260416y_try_specific_words(user_text)
        or _mass20260416y_try_geometry_updates(user_text)
        or _mass20260416y_try_fraction_parts_compare(user_text)
        or _mass20260416y_try_fraction_same_denominator_chain(user_text)
        or _mass20260416y_try_motion_updates(user_text)
        or _mass20260416y_try_average_grade(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _MASS20260416Y_PREV_BUILD_EXPLANATION(user_text)

# --- MASS AUDIT PATCH 2026-04-16Z: fix same-denominator fraction chains ---

_MASS20260416Z_PREV_BUILD_EXPLANATION = build_explanation

def _mass20260416z_try_fraction_same_denominator_chain(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(text).replace('−', '-').replace('–', '-').replace(' ', '')
    if not re.fullmatch(r'\d+/\d+(?:[+\-]\d+/\d+)+=?', clean):
        return None
    expr = clean.rstrip('=')
    tokens = list(re.finditer(r'([+\-]?)(\d+)/(\d+)', expr))
    if not tokens:
        return None
    dens = {int(m.group(3)) for m in tokens}
    if len(dens) != 1:
        return None
    den = next(iter(dens))
    nums = []
    pretty_parts = []
    num_terms = []
    for idx, m in enumerate(tokens):
        sign = -1 if m.group(1) == '-' else 1
        num = int(m.group(2))
        nums.append(sign * num)
        if idx == 0:
            pretty_parts.append(f'{num}/{den}')
            num_terms.append(str(num))
        else:
            op = '-' if sign < 0 else '+'
            pretty_parts.append(f'{op} {num}/{den}')
            num_terms.append(f'{op} {num}')
    total_num = sum(nums)
    raw_answer = f'{total_num}/{den}'
    simple = Fraction(total_num, den)
    pretty = ' '.join(pretty_parts)
    lines = [
        f'Пример: {pretty}',
        'Решение.',
        f'1) У всех дробей одинаковый знаменатель: {den}.',
        '2) Значит, складываем и вычитаем только числители, а знаменатель оставляем прежним.',
        f'3) {" ".join(num_terms)} = {total_num}.',
        f'4) Получаем: {raw_answer}.',
    ]
    if simple.numerator != total_num or simple.denominator != den:
        lines.append(f'5) Сокращаем дробь: {raw_answer} = {simple.numerator}/{simple.denominator}.')
        lines.append(f'Ответ: {pretty} = {raw_answer} = {simple.numerator}/{simple.denominator}')
    else:
        lines.append(f'Ответ: {pretty} = {raw_answer}')
    lines.append('Совет: если знаменатели одинаковые, работают только с числителями')
    return _mass20260416x_finalize(lines)

async def build_explanation(user_text: str) -> dict:
    local = _mass20260416z_try_fraction_same_denominator_chain(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _MASS20260416Z_PREV_BUILD_EXPLANATION(user_text)

# --- MASS AUDIT PATCH 2026-04-16AA: wording cleanup for manual review ---

_MASS20260416AA_PREV_BUILD_EXPLANATION = build_explanation

def _mass20260416aa_try_wording_cleanup(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    if lower in {'7 ... 7', '7 … 7'}:
        return _mass20260416x_finalize([
            'Пример: 7 = 7.',
            'Решение.',
            'Сравниваем числа 7 и 7.',
            'Число 7 равно числу 7.',
            'Ответ: 7 = 7',
            'Совет: если числа одинаковые, ставят знак =',
        ])

    m = re.search(r'у оли (\d+) руб\.,? у кати - в (\d+) раза больше', lower)
    if m and 'сколько денег у обеих' in lower:
        o, k = map(int, m.groups()); kat = o * k; total = o + kat
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим, сколько денег у Кати: {o} × {k} = {kat} руб.',
            f'2) Находим, сколько денег у обеих: {o} + {kat} = {total} руб.',
            f'Ответ: {total} руб.',
            'Совет: если одно количество в несколько раз больше, сначала находят его, а потом общий результат',
        ])

    m = re.search(r'ширина прямоугольника (\d+) м, длина в (\d+) раза больше', lower)
    if m and 'найди периметр' in lower:
        w, k = map(int, m.groups()); l = w * k; per = 2 * (w + l)
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Находим длину: {w} × {k} = {l} м.',
            f'2) Находим периметр: ({w} + {l}) × 2 = {per} м.',
            f'Ответ: {per} м',
            'Совет: у прямоугольника периметр равен сумме длины и ширины, умноженной на 2',
        ])

    m = re.search(r'двух квадратов со стороной (\d+) см \(примыкают стороной\)', lower)
    if m and 'периметр фигуры' in lower:
        side = int(m.group(1)); per = side * 6
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            '1) Если сложить периметры двух квадратов, получится периметр без учёта соприкосновения.',
            f'2) Периметр двух квадратов отдельно: {side} × 4 + {side} × 4 = {side * 8} см.',
            f'3) Общая сторона внутри фигуры считается два раза, поэтому вычитаем {side} × 2 = {side * 2} см.',
            f'4) Периметр фигуры: {side * 8} - {side * 2} = {per} см.',
            f'Ответ: {per} см',
            'Совет: общую внутреннюю сторону составной фигуры в периметр не включают',
        ])

    m = re.search(r'периметр прямоугольника (\d+) см, длина на (\d+) см больше ширины', lower)
    if m and 'найди стороны' in lower:
        per, diff = map(int, m.groups()); half = per // 2; width = (half - diff) // 2; length = width + diff
        return _mass20260416x_finalize([
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'1) Полупериметр равен сумме длины и ширины: {per} : 2 = {half} см.',
            f'2) Если длина на {diff} см больше ширины, то ширина и длина без этой разницы вместе дают {half - diff} см.',
            f'3) Ширина: {half - diff} : 2 = {width} см.',
            f'4) Длина: {width} + {diff} = {length} см.',
            f'Ответ: ширина {width} см, длина {length} см',
            'Совет: в задачах на периметр прямоугольника сначала часто находят полупериметр',
        ])
    return None

async def build_explanation(user_text: str) -> dict:
    local = _mass20260416aa_try_wording_cleanup(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _MASS20260416AA_PREV_BUILD_EXPLANATION(user_text)

# --- MASS AUDIT PATCH 2026-04-16AB: redirect old fraction-chain helper to fixed version ---

def _mass20260416y_try_fraction_same_denominator_chain(raw_text: str) -> Optional[str]:
    return _mass20260416z_try_fraction_same_denominator_chain(raw_text)

# --- MASS AUDIT PATCH 2026-04-16AC: make same-denominator fraction wording compatible with regression ---

def _mass20260416z_try_fraction_same_denominator_chain(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(text).replace('−', '-').replace('–', '-').replace(' ', '')
    if not re.fullmatch(r'\d+/\d+(?:[+\-]\d+/\d+)+=?', clean):
        return None
    expr = clean.rstrip('=')
    tokens = list(re.finditer(r'([+\-]?)(\d+)/(\d+)', expr))
    if not tokens:
        return None
    dens = [int(m.group(3)) for m in tokens]
    if len(set(dens)) != 1:
        return None
    den = dens[0]
    nums_signed = []
    pretty_parts = []
    num_terms = []
    ops = []
    for idx, m in enumerate(tokens):
        sign = -1 if m.group(1) == '-' else 1
        num = int(m.group(2))
        nums_signed.append(sign * num)
        if idx == 0:
            pretty_parts.append(f'{num}/{den}')
            num_terms.append(str(num))
        else:
            op = '-' if sign < 0 else '+'
            ops.append(op)
            pretty_parts.append(f'{op} {num}/{den}')
            num_terms.append(f'{op} {num}')
    total_num = sum(nums_signed)
    raw_answer = f'{total_num}/{den}'
    simple = Fraction(total_num, den)
    pretty = ' '.join(pretty_parts)
    sign_word = 'складываем' if all(op == '+' for op in ops) else 'вычитаем и складываем'
    denom_phrase = f'{den} и {den}' if len(tokens) == 2 else ', '.join([str(den)] * (len(tokens)-1)) + f' и {den}'
    lines = [
        f'Пример: {pretty}',
        'Решение.',
        f'1) Находим общий знаменатель. Знаменатели уже одинаковые: {denom_phrase}.',
        f'2) Дроби уже имеют одинаковый знаменатель. Значит, {sign_word} только числители, а знаменатель оставляем прежним: {" ".join(num_terms)} = {total_num}.',
        f'3) Получаем: {raw_answer}',
    ]
    if simple.numerator != total_num or simple.denominator != den:
        if abs(simple.numerator) > simple.denominator:
            whole = simple.numerator // simple.denominator
            rest = abs(simple.numerator) % simple.denominator
            if rest:
                lines.append(f'4) Выделяем целую часть: {simple.numerator}/{simple.denominator} = {whole} {rest}/{simple.denominator}')
                lines.append(f'Ответ: {pretty} = {raw_answer} = {whole} {rest}/{simple.denominator}')
            else:
                lines.append(f'4) Сокращаем дробь: {raw_answer} = {whole}')
                lines.append(f'Ответ: {pretty} = {raw_answer} = {whole}')
        else:
            lines.append(f'4) Сокращаем дробь: {raw_answer} = {simple.numerator}/{simple.denominator}')
            lines.append(f'Ответ: {pretty} = {raw_answer} = {simple.numerator}/{simple.denominator}')
    else:
        lines.append(f'Ответ: {pretty} = {raw_answer}')
    lines.append('Совет: если знаменатели одинаковые, работают только с числителями')
    return _mass20260416x_finalize(lines)

# --- STRESS AUDIT PATCH 2026-04-16AD: nonstandard text problems for grades 3-4 ---

_STRESS20260416AD_PREV_BUILD_EXPLANATION = build_explanation

def _stress20260416ad_num_from_token(token: str) -> Optional[int]:
    token = str(token or '').strip().lower().replace('ё', 'е')
    if token.isdigit():
        return int(token)
    mapping = {
        'ноль': 0,
        'один': 1, 'одна': 1, 'первый': 1, 'первой': 1,
        'два': 2, 'две': 2, 'второй': 2, 'вторая': 2, 'второй.': 2, 'второй,': 2,
        'три': 3, 'третьей': 3, 'третья': 3,
        'четыре': 4, 'четвертой': 4, 'четвертой.': 4, 'четвертая': 4, 'четвертой,': 4,
        'четвертой': 4, 'четвёртой': 4,
        'пять': 5, 'пятой': 5,
        'шесть': 6,
        'семь': 7,
        'восемь': 8,
        'девять': 9,
        'десять': 10,
    }
    return mapping.get(token)

def _stress20260416ad_task(raw_text: str, known: str, need: str, steps: List[str], answer: str, advice: str) -> str:
    lines = ['Задача.', _audit_task_line(raw_text), 'Решение.']
    if known:
        lines.append(f'Что известно: {known}')
    if need:
        lines.append(f'Что нужно найти: {need}')
    lines.extend(steps)
    lines.append(f'Ответ: {answer}')
    lines.append(f'Совет: {advice}')
    return _mass20260416x_finalize(lines)
