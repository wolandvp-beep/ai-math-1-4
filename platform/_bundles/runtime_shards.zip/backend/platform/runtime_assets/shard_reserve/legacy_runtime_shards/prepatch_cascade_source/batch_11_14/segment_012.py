"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 9618-10507."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _patch_20260412c_step_header(index: int, operator: str, left: str, right: str, use_column: bool) -> str:
    ordinal = _PATCH_20260412C_ORDINAL_WORDS.get(index, f"{index}-е")
    action_name = {
        "+": "сложение",
        "-": "вычитание",
        "×": "умножение",
        ":": "деление",
    }.get(operator, "действие")
    if use_column:
        return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right}. Выполним это действие в столбик"
    return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right} = {step_result_placeholder}"

def _patch_20260412c_render_mixed_expression_solution(source: str) -> Optional[str]:
    node = parse_expression_ast(source)
    if node is None:
        return None

    steps = _detailed_collect_expression_steps(node, source)
    if len(steps) <= 1:
        return None

    pretty_expression = _user_final_patch_pretty_expression_from_source(source)
    answer = _detailed_expression_answer(source) or "проверь запись"
    advice = (
        "сначала выполняй действия по порядку: в скобках, потом умножение и деление, потом сложение и вычитание"
        if "(" in source or ")" in source or re.search(r"[+\-].*[*/]|[*/].*[+\-]", source)
        else default_advice("expression")
    )

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block:
        lines.extend(order_block)
    lines.append("Решение по действиям:")

    for index, step in enumerate(steps, start=1):
        left = str(step.get("left", "")).strip()
        right = str(step.get("right", "")).strip()
        operator = str(step.get("operator", "")).strip()
        result = str(step.get("result", "")).strip()

        use_column = _patch_20260412c_should_use_column_for_step(step, source)
        if not use_column:
            ordinal = _PATCH_20260412C_ORDINAL_WORDS.get(index, f"{index}-е")
            action_name = {
                "+": "сложение",
                "-": "вычитание",
                "×": "умножение",
                ":": "деление",
            }.get(operator, "действие")
            lines.append(f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right} = {result}")
            continue

        lines.append(
            f"{index}) {_PATCH_20260412C_ORDINAL_WORDS.get(index, f'{index}-е')} действие: {left} {operator} {right}"
        )
        detailed = _patch_20260412c_step_explanation_text(step)
        if not detailed:
            lines.append(f"{left} {operator} {right} = {result}")
            continue

        parts = _detailed_split_sections(detailed)
        column_block, remaining_body = _split_ascii_layout_block(parts.get("body", []))
        cleaned_body = _patch_20260412c_clean_body_lines(remaining_body)

        if column_block:
            lines.extend(column_block)
        if cleaned_body:
            lines.append("Пояснение к действию:")
            lines.extend(cleaned_body)
        lines.append(f"Значит, {left} {operator} {right} = {result}")

    lines.append(f"Ответ: {answer}")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    source = to_expression_source(raw_text)
    if not source:
        return _PATCH_20260412C_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

    rendered = _patch_20260412c_render_mixed_expression_solution(source)
    if rendered:
        return rendered

    return _PATCH_20260412C_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

# --- FINAL PATCH 2026-04-12C.1: safe helper text ---

def _patch_20260412c_step_header(index: int, operator: str, left: str, right: str, result: str, use_column: bool) -> str:
    ordinal = _PATCH_20260412C_ORDINAL_WORDS.get(index, f"{index}-е")
    action_name = {
        "+": "сложение",
        "-": "вычитание",
        "×": "умножение",
        ":": "деление",
    }.get(operator, "действие")
    if use_column:
        return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right}. Выполним это действие в столбик"
    return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right} = {result}"

# --- USER CONSOLIDATION PATCH 2026-04-12: fuller school-style wording without changing architecture ---

def explain_sum_then_subtract_word_problem(first: int, second: int, removed: int) -> Optional[str]:
    total = first + second
    remaining = total - removed
    if remaining < 0:
        return None
    return join_explanation_lines(
        f"1) Если сначала было {first} и ещё {second}, то всего было {first} + {second} = {total}",
        f"2) Если всего было {total}, а потом убрали {removed}, то осталось {total} - {removed} = {remaining}",
        f"Ответ: {remaining}",
        "Совет: если сначала объединяют две части, а потом часть убирают, сначала находят сумму",
    )

def explain_initial_from_taken_and_left_word_problem(first_taken: int, second_taken: int, left: int) -> Optional[str]:
    taken = first_taken + second_taken
    total = taken + left
    return join_explanation_lines(
        f"1) Если взяли {first_taken} и ещё {second_taken}, то всего взяли {first_taken} + {second_taken} = {taken}",
        f"2) Если взяли {taken}, а осталось {left}, то сначала было {taken} + {left} = {total}",
        f"Ответ: {total}",
        "Совет: если известны взяли и осталось, начальное число находят сложением",
    )

def explain_relation_chain_total_word_problem(base: int, delta1: int, mode1: str, delta2: int, mode2: str) -> Optional[str]:
    second = apply_more_less(base, delta1, mode1)
    if second is None:
        return None
    third = apply_more_less(second, delta2, mode2)
    if third is None:
        return None
    total = base + second + third
    sign1 = "+" if mode1 == "больше" else "-"
    sign2 = "+" if mode2 == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta1} {mode1}, чем первое, то второе количество равно {base} {sign1} {delta1} = {second}",
        f"2) Если третье количество на {delta2} {mode2}, чем второе, то третье количество равно {second} {sign2} {delta2} = {third}",
        f"3) Если первое количество {base}, второе {second}, а третье {third}, то всего {base} + {second} + {third} = {total}",
        f"Ответ: {total}",
        "Совет: в составной задаче сначала находят все неизвестные количества, потом общее число",
    )

def explain_relation_chain_times_total_word_problem(base: int, factor1: int, mode1: str, factor2: int, mode2: str) -> Optional[str]:
    second = apply_times_relation(base, factor1, mode1)
    if second is None:
        return None
    third = apply_times_relation(second, factor2, mode2)
    if third is None:
        return None
    total = base + second + third
    op1 = "×" if mode1 == "больше" else ":"
    op2 = "×" if mode2 == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor1} {plural_form(factor1, 'раз', 'раза', 'раз')} {mode1}, чем первое, то второе количество равно {base} {op1} {factor1} = {second}",
        f"2) Если третье количество в {factor2} {plural_form(factor2, 'раз', 'раза', 'раз')} {mode2}, чем второе, то третье количество равно {second} {op2} {factor2} = {third}",
        f"3) Если первое количество {base}, второе {second}, а третье {third}, то всего {base} + {second} + {third} = {total}",
        f"Ответ: {total}",
        "Совет: если числа связаны словами «в несколько раз», сначала находят каждое зависимое число отдельно",
    )

def explain_simple_motion_distance(speed: int, time_value: int, unit: str = "") -> str:
    result = speed * time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти расстояние, нужно скорость умножить на время",
        f"2) Если скорость равна {speed}, а время равно {time_value}, то расстояние равно {speed} × {time_value} = {result}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом S = v × t",
    )

def explain_simple_motion_speed(distance: int, time_value: int, unit: str = "") -> Optional[str]:
    if time_value == 0 or distance % time_value != 0:
        return None
    result = distance // time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти скорость, нужно расстояние разделить на время",
        f"2) Если расстояние равно {distance}, а время равно {time_value}, то скорость равна {distance} : {time_value} = {result}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом v = S : t",
    )

def explain_simple_motion_time(distance: int, speed: int, unit: str = "") -> Optional[str]:
    if speed == 0 or distance % speed != 0:
        return None
    result = distance // speed
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти время, нужно расстояние разделить на скорость",
        f"2) Если расстояние равно {distance}, а скорость равна {speed}, то время равно {distance} : {speed} = {result}",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом t = S : v",
    )

def explain_meeting_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    closing_speed = v1 + v2
    distance = closing_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2}, то скорость сближения равна {v1} + {v2} = {closing_speed}",
        f"2) Если скорость сближения равна {closing_speed}, а время равно {time_value}, то расстояние между пунктами равно {closing_speed} × {time_value} = {distance}",
        f"Ответ: {answer}",
        "Совет: при движении навстречу сначала находят скорость сближения",
    )

def explain_opposite_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    removal_speed = v1 + v2
    distance = removal_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2} в противоположных направлениях, то скорость удаления равна {v1} + {v2} = {removal_speed}",
        f"2) Если скорость удаления равна {removal_speed}, а время равно {time_value}, то расстояние между ними равно {removal_speed} × {time_value} = {distance}",
        f"Ответ: {answer}",
        "Совет: при движении в противоположных направлениях сначала находят скорость удаления",
    )

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        "1) Чтобы найти цену одного предмета, нужно стоимость разделить на количество",
        f"2) Если {count} одинаковых предметов стоят {total_cost} руб., то один предмет стоит {total_cost} : {count} = {price} руб.",
        f"Ответ: {price} руб.",
        "Совет: пользуйся правилом Ц = С : К",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        "1) Чтобы найти стоимость, нужно цену умножить на количество",
        f"2) Если один предмет стоит {price} руб., а купили {count} предметов, то вся покупка стоит {price} × {count} = {total} руб.",
        f"Ответ: {total} руб.",
        "Совет: пользуйся правилом С = Ц × К",
    )

def explain_unknown_red_price(known_count: int, known_price: int, unknown_count: int, total_cost: int) -> Optional[str]:
    known_total = known_count * known_price
    other_total = total_cost - known_total
    if unknown_count == 0 or other_total < 0 or other_total % unknown_count != 0:
        return None
    unit_price = other_total // unknown_count
    return join_explanation_lines(
        f"1) Если купили {known_count} цветка по {known_price} руб., то за них заплатили {known_count} × {known_price} = {known_total} руб.",
        f"2) Если за всю покупку заплатили {total_cost} руб., а за известные цветы заплатили {known_total} руб., то за остальные цветы заплатили {total_cost} - {known_total} = {other_total} руб.",
        f"3) Если за {unknown_count} остальных цветов заплатили {other_total} руб., то одна штука стоит {other_total} : {unknown_count} = {unit_price} руб.",
        f"Ответ: одна красная гвоздика стоила {unit_price} руб.",
        "Совет: если известна общая стоимость покупки, сначала вычти известную часть, а потом раздели на количество",
    )

def explain_price_quantity_cost_problem(quantity: int, total_cost: int, wanted_cost: int) -> Optional[str]:
    if quantity == 0 or total_cost % quantity != 0:
        return None
    price = total_cost // quantity
    if price == 0 or wanted_cost % price != 0:
        return None
    result = wanted_cost // price
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых товаров заплатили {total_cost} руб., то один товар стоит {total_cost} : {quantity} = {price} руб.",
        f"2) Если один товар стоит {price} руб., то на {wanted_cost} руб. можно купить {wanted_cost} : {price} = {result}",
        f"Ответ: {result}",
        "Совет: в задачах на цену, количество и стоимость сначала находят цену одной штуки",
    )

def explain_price_difference_problem(quantity: int, total_a: int, total_b: int) -> Optional[str]:
    if quantity == 0 or total_a % quantity != 0 or total_b % quantity != 0:
        return None
    price_a = total_a // quantity
    price_b = total_b // quantity
    diff = abs(price_a - price_b)
    relation = "дороже" if price_a > price_b else "дешевле"
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых товаров заплатили {total_a} руб., то цена одного товара равна {total_a} : {quantity} = {price_a} руб.",
        f"2) Если за {quantity} таких же товаров заплатили {total_b} руб., то цена одного товара равна {total_b} : {quantity} = {price_b} руб.",
        f"3) Если одна цена {price_a} руб., а другая {price_b} руб., то разность цен равна {max(price_a, price_b)} - {min(price_a, price_b)} = {diff} руб.",
        f"Ответ: на {diff} руб. {relation}.",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

# --- FINAL CONSOLIDATED PATCH: textbook-style priorities and multi-question fixes ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень понятный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно и по-школьному.
Не используй markdown, таблицы, смайлики, лишние вступления и похвалу.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна полезная мысль.

Главные правила объяснения:
1. Объясняй подробно, по действиям и по шагам.
2. Не пропускай промежуточные вычисления.
3. Для текстовых задач по возможности используй форму:
Если ..., то ...
4. Сначала находи то, что нужно для главного вопроса, потом отвечай на главный вопрос.
5. Если вопросов два, ответь на оба по порядку.
6. Если запись непонятная, попроси записать задачу понятнее.

Для выражений:
1. Сначала напиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, напиши:
Порядок действий:
и ниже тот же пример с цифрами 1, 2, 3 над знаками действий.
3. Потом напиши:
Решение по действиям:
4. Ниже:
1) ...
2) ...
3) ...
5. В конце:
Ответ: ...
6. Если пример удобно считать в столбик, сохрани столбик и подробное пояснение.

Для текстовых задач:
1. Сначала:
Задача.
2. Потом без изменения чисел запиши условие.
3. Потом:
Решение.
4. Затем обязательно:
Что известно: ...
Что нужно найти: ...
5. Дальше решай по действиям:
1) ...
2) ...
3) ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Сначала:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом считай по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если единицы разные, сначала переведи их в одинаковые единицы.
4. Потом решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При встречном движении называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
""".strip()

_FINAL_CONSOLIDATED_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def _final_consolidated_questions(raw_text: str) -> List[str]:
    text = normalize_word_problem_text(raw_text)
    parts = [part.strip() for part in re.split(r"[?]", text) if part.strip()]
    return parts

def _final_consolidated_try_second_quantity_and_difference_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if lower.count("?") < 2:
        return None
    if "на сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None:
        return None

    diff = abs(base - second)
    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если первое количество равно {base}, а второе равно {second}, то разность равна {max(base, second)} - {min(base, second)} = {diff}",
        f"Ответ: второе количество — {second}{tail}; разность — {diff}{tail}",
        "Совет: если в задаче два вопроса, сначала находят второе число, потом сравнивают числа",
    )

def _final_consolidated_try_second_quantity_and_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if lower.count("?") < 2:
        return None
    if "во сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None or min(base, second) == 0:
        return None

    bigger = max(base, second)
    smaller = min(base, second)
    if bigger % smaller != 0:
        return None
    ratio = bigger // smaller

    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если большее количество равно {bigger}, а меньшее равно {smaller}, то кратное сравнение равно {bigger} : {smaller} = {ratio}",
        f"Ответ: второе количество — {second}{tail}; в {ratio} {plural_form(ratio, 'раз', 'раза', 'раз')}",
        "Совет: если нужно сначала найти второе число, а потом узнать, во сколько раз одно число больше другого, выполняй действия по порядку",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_consolidated_try_second_quantity_and_difference_explanation(user_text)
        or _final_consolidated_try_second_quantity_and_ratio_explanation(user_text)
        or _FINAL_CONSOLIDATED_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL CONSOLIDATED PATCH 2: detect second question even without second "?" ---

def _final_consolidated_has_two_question_clauses(raw_text: str) -> bool:
    text = normalize_word_problem_text(raw_text).strip()
    clauses = [part.strip() for part in re.split(r"[?.!]", text) if part.strip()]
    question_like = 0
    for clause in clauses:
        lower = clause.lower().replace("ё", "е")
        if re.match(r"^(сколько|на сколько|во сколько|какова|какой|какое|чему|найдите|узнайте)\b", lower):
            question_like += 1
    return question_like >= 2 or text.count("?") >= 2

def _final_consolidated_try_second_quantity_and_difference_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if not _final_consolidated_has_two_question_clauses(raw_text):
        return None
    if "на сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None:
        return None

    diff = abs(base - second)
    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если первое количество равно {base}, а второе равно {second}, то разность равна {max(base, second)} - {min(base, second)} = {diff}",
        f"Ответ: второе количество — {second}{tail}; разность — {diff}{tail}",
        "Совет: если в задаче два вопроса, сначала находят второе число, потом сравнивают числа",
    )

def _final_consolidated_try_second_quantity_and_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if not _final_consolidated_has_two_question_clauses(raw_text):
        return None
    if "во сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None or min(base, second) == 0:
        return None

    bigger = max(base, second)
    smaller = min(base, second)
    if bigger % smaller != 0:
        return None
    ratio = bigger // smaller

    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если большее количество равно {bigger}, а меньшее равно {smaller}, то кратное сравнение равно {bigger} : {smaller} = {ratio}",
        f"Ответ: второе количество — {second}{tail}; в {ratio} {plural_form(ratio, 'раз', 'раза', 'раз')}",
        "Совет: если нужно сначала найти второе число, а потом узнать, во сколько раз одно число больше другого, выполняй действия по порядку",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_consolidated_try_second_quantity_and_difference_explanation(user_text)
        or _final_consolidated_try_second_quantity_and_ratio_explanation(user_text)
        or _FINAL_CONSOLIDATED_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- CONSOLIDATED FINAL PATCH 2026-04-12: textbook wording, stable final prompt, user-requested detail ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. Если пример удобно считать в столбик, сохрани запись столбиком и подробные пояснения.
6. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие задачи без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. По возможности используй школьную форму:
Если ..., то ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если решение записывается по действиям, в каждом действии, кроме последнего, полезно писать пояснение, что именно нашли.
""".strip()

def explain_addition_word_problem(first: int, second: int) -> str:
    result = first + second
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе количество равно {second}, то всего будет {first} + {second} = {result}",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько всего или сколько стало, обычно нужно сложение",
    )

def explain_subtraction_word_problem(first: int, second: int) -> str:
    result = first - second
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если сначала было {first}, а потом стало {second}, то разность равна {first} - {second} = {result}",
        f"Ответ: {result}",
        "Совет: если нужно узнать, сколько осталось или на сколько уменьшилось, используют вычитание",
    )

def explain_comparison_word_problem(first: int, second: int) -> str:
    bigger = max(first, second)
    smaller = min(first, second)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если одно количество равно {bigger}, а другое равно {smaller}, то чтобы узнать, на сколько одно больше другого, нужно вычислить {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: вопрос «на сколько» решают вычитанием: из большего числа вычитают меньшее",
    )

def explain_find_initial_after_loss_problem(remaining: int, removed: int) -> str:
    result = remaining + removed
    return join_explanation_lines(
        f"1) Если после того как убрали {removed}, осталось {remaining}, то сначала было {remaining} + {removed} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы найти, сколько было сначала, к остатку прибавляют то, что убрали",
    )

def explain_find_initial_after_gain_problem(final_total: int, added: int) -> str:
    result = final_total - added
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если стало {final_total}, а прибавили {added}, то сначала было {final_total} - {added} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы найти число до прибавления, из нового числа вычитают прибавленную часть",
    )

def explain_find_added_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {smaller}, а потом стало {bigger}, то добавили {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
    )

def explain_find_removed_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {bigger}, а потом осталось {smaller}, то убрали {bigger} - {smaller} = {result}",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
    )

def explain_multiplication_word_problem(groups: int, per_group: int) -> str:
    result = groups * per_group
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего будет {groups} × {per_group} = {result}",
        f"Ответ: {result}",
        "Совет: если одинаковое количество повторяется несколько раз, используют умножение",
    )

def explain_sharing_word_problem(total: int, groups: int) -> Optional[str]:
    if groups == 0:
        return join_explanation_lines(
            "На ноль делить нельзя",
            "Ответ: деление на ноль невозможно",
            "Совет: сначала проверь, на сколько частей делят",
        )
    quotient, remainder = divmod(total, groups)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если {total} предметов разделили на {groups} равные части, то каждая часть равна {total} : {groups} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: слова «поровну» и «каждый» подсказывают деление",
        )
    return join_explanation_lines(
        f"1) Если {total} разделить на {groups}, то получится {quotient}, остаток {remainder}",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: остаток всегда должен быть меньше делителя",
    )

def explain_group_count_word_problem(total: int, per_group: int, needs_extra_group: bool = False, explicit_remainder: bool = False) -> Optional[str]:
    if per_group == 0:
        return join_explanation_lines(
            "В одной группе не может быть 0 предметов",
            "Ответ: запись задачи неверная",
            "Совет: проверь, сколько предметов должно быть в одной группе",
        )
    quotient, remainder = divmod(total, per_group)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если всего {total} предметов, а в одной группе по {per_group}, то групп будет {total} : {per_group} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: число групп находят делением",
        )
    if needs_extra_group:
        return join_explanation_lines(
            f"1) Полных групп получится {quotient}, потому что {total} : {per_group} = {quotient}, остаток {remainder}",
            f"2) Так как предметы ещё остались, нужна ещё одна группа, всего {quotient + 1}",
            f"Ответ: {quotient + 1}",
            "Совет: если после деления что-то осталось, иногда нужна ещё одна коробка или ещё одно место",
        )
    if explicit_remainder:
        return join_explanation_lines(
            f"1) Если {total} разделить на группы по {per_group}, то получится {quotient}, остаток {remainder}",
            f"Ответ: {quotient}, остаток {remainder}",
            "Совет: остаток всегда должен быть меньше размера одной группы",
        )
    return None

def explain_related_quantity_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    result = apply_more_less(base, delta, mode)
    if result is None:
        return None
    sign = "+" if mode == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, чем первое, то второе количество равно {base} {sign} {delta} = {result}",
        f"Ответ: {result}",
        "Совет: если число на несколько единиц больше, прибавляют; если меньше, вычитают",
    )

def explain_related_total_word_problem(base: int, delta: int, mode: str) -> Optional[str]:
    related = apply_more_less(base, delta, mode)
    if related is None:
        return None
    sign = "+" if mode == "больше" else "-"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, чем первое, то сначала найдём его: {base} {sign} {delta} = {related}",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего {base} + {related} = {total}",
        f"Ответ: {total}",
        "Совет: в составной задаче сначала находят неизвестное количество, потом сумму",
    )

def explain_related_quantity_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    result = apply_times_relation(base, factor, mode)
    if result is None:
        return None
    op = "×" if mode == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, чем первое, то оно равно {base} {op} {factor} = {result}",
        f"Ответ: {result}",
        "Совет: если число в несколько раз больше, умножают; если в несколько раз меньше, делят",
    )

def explain_related_total_times_word_problem(base: int, factor: int, mode: str) -> Optional[str]:
    related = apply_times_relation(base, factor, mode)
    if related is None:
        return None
    op = "×" if mode == "больше" else ":"
    total = base + related
    return join_explanation_lines(
        f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, чем первое, то сначала найдём его: {base} {op} {factor} = {related}",
        f"2) Если первое количество равно {base}, а второе равно {related}, то всего {base} + {related} = {total}",
        f"Ответ: {total}",
        "Совет: сначала находят число, которое дано через кратное отношение, а потом сумму",
    )

def explain_bring_to_unit_total_word_problem(groups: int, total_amount: int, target_groups: int) -> Optional[str]:
    if groups == 0 or total_amount % groups != 0:
        return None
    one_group = total_amount // groups
    result = one_group * target_groups
    return join_explanation_lines(
        f"1) Если в {groups} группах {total_amount}, то в одной группе {total_amount} : {groups} = {one_group}",
        f"2) Если в одной группе {one_group}, то в {target_groups} таких же группах {one_group} × {target_groups} = {result}",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну группу",
    )
