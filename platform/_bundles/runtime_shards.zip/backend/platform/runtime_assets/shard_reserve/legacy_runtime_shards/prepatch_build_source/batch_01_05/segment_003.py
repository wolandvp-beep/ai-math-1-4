"""Auto-generated runtime shard for prepatch_build_source.py, lines 1781-2651."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _detailed_format_word_like_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    statement = _detailed_statement_text(raw_text)
    info_lines: List[str] = []
    body_lines: List[str] = []
    for line in parts["body"]:
        lower = line.lower()
        if lower.startswith("что известно:") or lower.startswith("что нужно найти:"):
            info_lines.append(line)
        else:
            body_lines.append(line)
    if not info_lines:
        condition, question = extract_condition_and_question(raw_text)
        if condition:
            info_lines.append(f"Что известно: {condition}")
        if question:
            info_lines.append(f"Что нужно найти: {question}")
    column_block, remaining_body = _split_ascii_layout_block(body_lines)
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    lines: List[str] = []
    if statement:
        lines.append("Задача.")
        lines.append(statement)
    lines.append("Решение.")
    lines.extend(info_lines)
    if column_block:
        lines.extend(column_block)
        if remaining_body:
            lines.append("Пояснение:")
    lines.extend(_detailed_number_lines(remaining_body))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind if kind in DEFAULT_ADVICE else "other")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_generic_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    statement = _detailed_statement_text(raw_text)
    column_block, remaining_body = _split_ascii_layout_block(parts["body"])
    lines: List[str] = []
    if statement and kind in {"word", "geometry"}:
        lines.append("Задача.")
        lines.append(statement)
        lines.append("Решение.")
    else:
        lines.append("Решение.")
    if column_block:
        lines.extend(column_block)
        if remaining_body:
            lines.append("Пояснение:")
    lines.extend(_detailed_number_lines(remaining_body))
    if parts["check"]:
        lines.append(parts["check"])
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind)
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:килограмм|кг)", question):
        return "кг"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:(?<!кило)грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:сколько|какова|какое расстояние|какой путь|чему равно расстояние)[^?.!]{0,25}(?:километр|км)", question):
        return "км"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:сантиметр|см)", question):
        return "см"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:дециметр|дм)", question):
        return "дм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:миллиметр|мм)", question):
        return "мм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"
    return ""

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    if re.fullmatch(r"-?\d+(?:/\d+)?", value):
        unit = _detect_question_unit(raw_text)
        if unit:
            return f"{value} {unit}"
    return value

def try_priority_fraction_by_given_part_explanation(raw_text: str) -> Optional[str]:
    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if len(fracs) != 1 or not values:
        return None
    numerator, denominator = fracs[0]
    if denominator == 0:
        return None
    if "составляет" in lower or re.search(rf"это\s+{numerator}\s*/\s*{denominator}\s+(?:всего\s+)?", lower):
        value_match = re.search(r"(?:составляет|равна|равен)[^\d]{0,20}(\d+)", lower)
        part_value = int(value_match.group(1)) if value_match else max(values)
        return explain_number_by_fraction_word_problem(part_value, numerator, denominator)
    return None

def try_high_priority_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    explicit = try_priority_fraction_by_given_part_explanation(raw_text)
    if explicit:
        return explicit

    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if not fracs:
        return None

    unit = _detect_question_unit(raw_text)

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower) and values:
        total = max(values)
        solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
        if solved:
            return solved

    if len(fracs) != 1:
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None

    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
    explicit_total_match = re.search(r"(?:\bбыло\b|\bвсего\b|\bмасса\b|\bдлина\b|\bпуть\b|\bпрошли\b|\bпрошел\b|\bпрошла\b|\bлистов\b|\bруды\b)[^\d]{0,40}(\d+)", lower)

    if remain_match and (not explicit_total_match or explicit_total_match.start() > remain_match.start()):
        remaining_value = int(remain_match.group(1))
        remaining_numerator = denominator - numerator
        if remaining_numerator <= 0 or remaining_value % remaining_numerator != 0:
            return None
        one_part = remaining_value // remaining_numerator
        whole = one_part * denominator
        remaining_text = f"{remaining_value} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        whole_text = f"{whole} {unit}".strip()
        return join_explanation_lines(
            f"1) Если израсходовали {numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
            f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_text}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part_text}",
            f"3) Если одна доля равна {one_part_text}, то все деньги равны {one_part} × {denominator} = {whole_text}",
            f"Ответ: всего было {whole_text}",
            "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
        )

    if values:
        total = max(values)
        if total % denominator != 0:
            return None
        one_part = total // denominator
        part = one_part * numerator
        remaining = total - part
        total_text = f"{total} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        part_text = f"{part} {unit}".strip()
        remaining_text = f"{remaining} {unit}".strip()

        if "во 2 день" in lower or "во второй день" in lower:
            return join_explanation_lines(
                f"1) Если весь путь равен {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если в первый день прошли {numerator}/{denominator} пути, то в первый день прошли {one_part} × {numerator} = {part_text}",
                f"3) Если весь путь {total_text}, а в первый день прошли {part_text}, то во второй день прошли {total} - {part} = {remaining_text}",
                f"Ответ: во второй день прошли {remaining_text}",
                "Совет: чтобы найти другую часть пути, сначала найди известную часть, потом вычти её из всего пути",
            )

        if "остал" in lower:
            return join_explanation_lines(
                f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если требуется найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
                f"3) Если всего было {total_text}, а израсходовали {part_text}, то осталось {total} - {part} = {remaining_text}",
                f"Ответ: осталось {remaining_text}",
                "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
            )

        return join_explanation_lines(
            f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
            f"Ответ: {part_text}",
            "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
        )
    return None

def try_priority_relation_then_compare_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    question = _question_text_only(raw_text).lower().replace("ё", "е") or lower
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None

    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)

    if len(relation_pairs) == 1 and ("во сколько" in question or "на сколько" in question):
        base = nums[0]
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        if "во сколько" in question:
            bigger, smaller = max(base, related), min(base, related)
            if smaller == 0 or bigger % smaller != 0:
                return None
            result = bigger // smaller
            op = "+" if mode == "больше" else "-"
            return join_explanation_lines(
                f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {op} {delta} = {related}",
                f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
                f"Ответ: {result} {plural_form(result, 'раз', 'раза', 'раз')}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )
        diff = abs(related - base)
        op = "+" if mode == "больше" else "-"
        return join_explanation_lines(
            f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {max(base, related)}, а другое равно {min(base, related)}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
            f"Ответ: {diff}",
            "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
        )

    if len(scale_pairs) == 1 and ("во сколько" in question or "на сколько" in question):
        base = nums[0]
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        if "во сколько" in question:
            bigger, smaller = max(base, related), min(base, related)
            if smaller == 0 or bigger % smaller != 0:
                return None
            result = bigger // smaller
            op = "×" if mode == "больше" else ":"
            return join_explanation_lines(
                f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}",
                f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
                f"Ответ: {result} {plural_form(result, 'раз', 'раза', 'раз')}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )
        diff = abs(related - base)
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {max(base, related)}, а другое равно {min(base, related)}, то разность равна {max(base, related)} - {min(base, related)} = {diff}",
            f"Ответ: {diff}",
            "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
        )
    return None

def try_priority_group_change_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    question = _question_text_only(raw_text).lower().replace("ё", "е") or lower

    if len(re.findall(r"\bпо\s+\d+", lower)) > 1:
        return None

    pair = _find_group_pair_any(lower)
    if not pair:
        return None
    groups = pair["groups"]
    per_group = pair["per_group"]
    pair_total = groups * per_group
    before_number, after_number = _numbers_before_after(lower, pair["start"], pair["end"])

    if ("стало" in question or asks_total_like(question)) and contains_any_fragment(lower, WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")):
        extra = after_number
        if extra is not None:
            result = pair_total + extra
            return join_explanation_lines(
                f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {per_group} × {groups} = {pair_total}",
                f"2) Если было {pair_total}, а потом добавили ещё {extra}, то стало {pair_total} + {extra} = {result}",
                f"Ответ: {result}",
                "Совет: если сначала находят одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
            )

    if "осталось" in question or "осталось расфасовать" in question or "осталось проехать" in question:
        if before_number is not None and before_number >= pair_total:
            result = before_number - pair_total
            return join_explanation_lines(
                f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
                f"2) Если всего было {before_number}, а одна часть равна {pair_total}, то другая часть равна {before_number} - {pair_total} = {result}",
                f"Ответ: {result}",
                "Совет: в составной задаче сначала найди часть, а потом вычти её из целого",
            )
        if after_number is not None and pair_total >= after_number:
            result = pair_total - after_number
            return join_explanation_lines(
                f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {pair_total}",
                f"2) Если было {pair_total}, а убрали {after_number}, то осталось {pair_total} - {after_number} = {result}",
                f"Ответ: {result}",
                "Совет: если сначала находят одинаковые группы, а потом часть убирают, сначала выполняют умножение",
            )

    if re.search(r"сколько[^.?!]*(?:привезли|было)\b", question):
        remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
        remain = int(remain_match.group(1)) if remain_match else after_number
        if remain is not None:
            result = pair_total + remain
            return join_explanation_lines(
                f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
                f"2) Если одна часть равна {pair_total}, а другая часть равна {remain}, то всего было {pair_total} + {remain} = {result}",
                f"Ответ: {result}",
                "Совет: если известны израсходованная часть и остаток, то всё число находят сложением",
            )

    if re.search(r"сколько[^.?!]*(?:отремонтировали|продали|расфасовали)\b", question) and before_number is not None and before_number >= pair_total:
        result = before_number - pair_total
        return join_explanation_lines(
            f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
            f"2) Если всего было {before_number}, а эта часть равна {pair_total}, то другая часть равна {before_number} - {pair_total} = {result}",
            f"Ответ: {result}",
            "Совет: если известно всё число и одна часть, другую часть находят вычитанием",
        )

    return None

def try_high_priority_simple_group_total_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if "сколько" not in lower:
        return None
    if contains_any_fragment(lower, WORD_GAIN_HINTS + WORD_LOSS_HINTS + ("остал", "расфас", "продал", "подарил", "добавил", "вошло", "приехало")):
        return None
    if _has_group_count_question(lower) or "поровну" in lower or "кажд" in lower:
        return None
    pair = _find_group_pair_any(lower)
    if not pair:
        return None
    if not (asks_total_like(lower) or contains_any_fragment(lower, ("сколько килограммов", "сколько книг", "сколько карандашей", "сколько литров", "сколько огурцов", "сколько конфет"))):
        return None
    groups = pair["groups"]
    per_group = pair["per_group"]
    total = groups * per_group
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {total}",
        f"Ответ: {total}",
        "Совет: слова «по ... в каждой» или составные слова вроде «двухлитровых» подсказывают умножение",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_priority_fraction_by_given_part_explanation(user_text)
        or try_priority_relation_then_compare_explanation(user_text)
        or try_priority_group_change_word_problem_explanation(user_text)
        or try_high_priority_named_sum_of_two_products_word_problem_explanation(user_text)
        or try_high_priority_unknown_price_word_problem_explanation(user_text)
        or try_high_priority_total_cost_word_problem_explanation(user_text)
        or try_high_priority_fraction_word_problem_explanation(user_text)
        or try_high_priority_unknown_addend_word_problem_explanation(user_text)
        or try_high_priority_added_removed_word_problem_explanation(user_text)
        or try_high_priority_simple_group_total_word_problem_explanation(user_text)
        or _PATCH8_PREVIOUS_build_explanation_local_first(user_text, kind)
    )

# --- OPENAI FINAL PATCH 2026-04-10B: remaining/added routing order, unit tolerance, heading colons ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    # Сначала более длинные и более специфичные единицы.
    if "мм" in question or "миллиметр" in question:
        return "мм"
    if "см²" in question or "кв. см" in question or ("площад" in question and ("см" in question or "сантиметр" in question)):
        return "см²"
    if "дм²" in question or "кв. дм" in question or ("площад" in question and ("дм" in question or "дециметр" in question)):
        return "дм²"
    if "м²" in question or "кв. м" in question or ("площад" in question and ("м " in question or question.endswith(" м") or "метр" in question)):
        return "м²"
    if re.search(r"(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:килограмм|кг)", question):
        return "кг"
    if re.search(r"(?:(?<!кило)грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:километр|км)", question):
        return "км"
    if re.search(r"(?:сантиметр|см)", question):
        return "см"
    if re.search(r"(?:дециметр|дм)", question):
        return "дм"
    if re.search(r"(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"
    return ""

def try_priority_group_change_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    question = _question_text_only(raw_text).lower().replace("ё", "е") or lower

    if len(re.findall(r"\bпо\s+\d+", lower)) > 1:
        return None

    pair = _find_group_pair_any(lower)
    if not pair:
        return None
    groups = pair["groups"]
    per_group = pair["per_group"]
    pair_total = groups * per_group
    before_number, after_number = _numbers_before_after(lower, pair["start"], pair["end"])

    # 1. Если известен общий объём и одна часть вида n × k, находим другую часть.
    if ("осталось" in question or "осталось расфасовать" in question or "осталось проехать" in question or re.search(r"сколько[^.?!]*(?:отремонтировали|продали|расфасовали)\b", question)) and before_number is not None and before_number >= pair_total:
        result = before_number - pair_total
        return join_explanation_lines(
            f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
            f"2) Если всего было {before_number}, а эта часть равна {pair_total}, то другая часть равна {before_number} - {pair_total} = {result}",
            f"Ответ: {result}",
            "Совет: если известно всё число и одна часть, другую часть находят вычитанием",
        )

    # 2. Если сначала есть группы, а потом часть убрали, находим остаток.
    if ("осталось" in question or "осталось в магазине" in question) and after_number is not None and pair_total >= after_number:
        result = pair_total - after_number
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {pair_total}",
            f"2) Если было {pair_total}, а убрали {after_number}, то осталось {pair_total} - {after_number} = {result}",
            f"Ответ: {result}",
            "Совет: если сначала находят одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    # 3. Если известны израсходованная часть и остаток, находим всё число.
    if re.search(r"сколько[^.?!]*(?:привезли|было)\b", question):
        remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
        remain = int(remain_match.group(1)) if remain_match else after_number
        if remain is not None:
            result = pair_total + remain
            return join_explanation_lines(
                f"1) Если {groups} групп по {per_group} в каждой, то эта часть равна {groups} × {per_group} = {pair_total}",
                f"2) Если одна часть равна {pair_total}, а другая часть равна {remain}, то всего было {pair_total} + {remain} = {result}",
                f"Ответ: {result}",
                "Совет: если известны израсходованная часть и остаток, то всё число находят сложением",
            )

    # 4. Если сначала есть группы, а потом что-то добавили, находим итог.
    if ("стало" in question or "всего" in question) and contains_any_fragment(lower, WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")):
        extra = after_number
        if extra is not None:
            result = pair_total + extra
            return join_explanation_lines(
                f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {per_group} × {groups} = {pair_total}",
                f"2) Если было {pair_total}, а потом добавили ещё {extra}, то стало {pair_total} + {extra} = {result}",
                f"Ответ: {result}",
                "Совет: если сначала находят одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
            )

    return None

# --- OPENAI FINAL PATCH 2026-04-10C: protect subtraction/division layout lines from sanitizer ---

def _render_column_subtraction_ascii(minuend: int, subtrahend: int) -> List[str]:
    width = max(len(str(abs(minuend))), len(str(abs(subtrahend)))) + 1
    result = minuend - subtrahend
    return [
        "Запись столбиком:",
        f" {str(minuend).rjust(width - 1)}",
        f"–{str(subtrahend).rjust(width - 1)}",
        _ascii_rule(width),
        f" {str(result).rjust(width - 1)}",
    ]

def _render_long_division_ascii(dividend: int, divisor: int) -> List[str]:
    if divisor == 0:
        return ["Запись столбиком:", "Деление на ноль невозможно"]
    quotient, remainder = divmod(dividend, divisor)
    lines = ["Запись столбиком:", f"{divisor} | {dividend}", f"Частное: {quotient}"]
    if remainder:
        lines.append(f"Остаток: {remainder}")
    return lines

def _is_ascii_math_layout_line(line: str) -> bool:
    stripped = str(line or "").rstrip()
    if not stripped:
        return False
    return bool(re.fullmatch(r"[ 0-9+\-–×:=/|()]+", stripped))

# --- OPENAI CONSOLIDATION PATCH 2026-04-11: routing fixes, richer school templates, safer high-priority handlers ---

_PREV_20260411_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def _answer_number_with_unit(value: int, raw_text: str, fallback_unit: str = "") -> str:
    unit = ""
    try:
        unit = _detect_question_unit(raw_text) or ""
    except Exception:
        unit = ""
    if not unit:
        unit = (fallback_unit or "").strip().rstrip(".")
    return f"{value} {unit}".strip()

def try_priority_simple_two_part_total_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} " or "поровну" in lower or "кажд" in lower:
        return None
    if contains_any_fragment(lower, WORD_GAIN_HINTS + WORD_LOSS_HINTS + ("остал", "стало", "теперь", "отдали", "вышло", "вошло", "приехало")):
        return None
    if not (_has_total_like_question(raw_text) or contains_any_fragment(question, ("сколько всего", "сколько вместе", "на обеих", "на обоих", "на двух"))):
        return None

    first, second = nums
    total = first + second
    answer_text = _answer_number_with_unit(total, raw_text)
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе количество равно {second}, то всего {first} + {second} = {total}",
        f"Ответ: {answer_text}",
        "Совет: если спрашивают, сколько всего или сколько вместе, обычно нужно сложение",
    )

def try_priority_relation_then_compare_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2 or "сколько" not in lower:
        return None

    base = nums[0]
    relation_pairs = extract_relation_pairs(lower)
    if len(relation_pairs) == 1 and ("во сколько" in question or "на сколько" in question):
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if "во сколько" in question:
            if smaller == 0 or bigger % smaller != 0:
                return None
            result = bigger // smaller
            op = "+" if mode == "больше" else "-"
            return join_explanation_lines(
                f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {op} {delta} = {related}",
                f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
                f"Ответ: {result} {plural_form(result, 'раз', 'раза', 'раз')}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )
        diff = bigger - smaller
        op = "+" if mode == "больше" else "-"
        answer_text = _answer_number_with_unit(diff, raw_text)
        return join_explanation_lines(
            f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            f"Ответ: {answer_text}",
            "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
        )

    scale_pairs = extract_scale_pairs(lower)
    if len(scale_pairs) == 1 and ("во сколько" in question or "на сколько" in question):
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if "во сколько" in question:
            if smaller == 0 or bigger % smaller != 0:
                return None
            result = bigger // smaller
            op = "×" if mode == "больше" else ":"
            return join_explanation_lines(
                f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}",
                f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
                f"Ответ: {result} {plural_form(result, 'раз', 'раза', 'раз')}",
                "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
            )
        diff = bigger - smaller
        op = "×" if mode == "больше" else ":"
        answer_text = _answer_number_with_unit(diff, raw_text)
        return join_explanation_lines(
            f"1) Если второе количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то сначала находим его: {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            f"Ответ: {answer_text}",
            "Совет: если сначала нужно найти второе число, а потом сравнить, выполняй действия по порядку",
        )
    return None

def try_high_priority_named_sum_of_two_products_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in lower:
        return None

    products = _po_product_matches(raw_text)
    if len(products) < 2:
        return None

    # Не перехватываем случаи, где спрашивают цену одной штуки и общая стоимость уже дана.
    if contains_any_fragment(question, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        return None

    first = products[0]
    second = products[1]
    first_total = first["count"] * first["value"]
    second_total = second["count"] * second["value"]
    total = first_total + second_total

    money_question = contains_any_fragment(lower, ("заплат", "стоим")) or contains_any_fragment(question, ("сколько денег", "сколько заплатили", "сколько стоила"))
    answer_unit = ""
    if money_question:
        answer_unit = "руб"
        return join_explanation_lines(
            f"1) Если купили {first['count']} {first['name']} по {first['value']} руб., то первая часть равна {first['count']} × {first['value']} = {first_total} руб",
            f"2) Если купили {second['count']} {second['name']} по {second['value']} руб., то вторая часть равна {second['count']} × {second['value']} = {second_total} руб",
            f"3) Если первая часть равна {first_total} руб., а вторая часть равна {second_total} руб., то всего {first_total} + {second_total} = {total} руб",
            f"Ответ: за всю покупку заплатили {total} руб",
            "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
        )

    # Общий случай: сумма двух произведений по массе/количеству/литрам и т. п.
    unit = _detect_question_unit(raw_text) or first["unit"] or second["unit"]
    answer_text = _answer_number_with_unit(total, raw_text, unit)
    unit_tail = f" {unit}".rstrip() if unit else ""
    return join_explanation_lines(
        f"1) Если было {first['count']} {first['name']} по {first['value']}{unit_tail}, то первая часть равна {first['count']} × {first['value']} = {first_total}{unit_tail}",
        f"2) Если было {second['count']} {second['name']} по {second['value']}{unit_tail}, то вторая часть равна {second['count']} × {second['value']} = {second_total}{unit_tail}",
        f"3) Если первая часть равна {first_total}{unit_tail}, а вторая часть равна {second_total}{unit_tail}, то всего {first_total} + {second_total} = {total}{unit_tail}",
        f"Ответ: {answer_text}",
        "Совет: если в задаче есть две группы вида «по столько-то», сначала находят каждую группу отдельно, потом складывают",
    )

def try_high_priority_simple_group_total_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in lower:
        return None
    if contains_any_fragment(lower, WORD_GAIN_HINTS + WORD_LOSS_HINTS + ("остал", "расфас", "продал", "подарил", "добавил", "вошло", "приехало")):
        return None
    if _has_group_count_question(lower) or "поровну" in lower or "кажд" in lower:
        return None

    products = _po_product_matches(raw_text)
    if len(products) != 1:
        return None
    if not (_has_total_like_question(raw_text) or contains_any_fragment(question, ("сколько килограммов", "сколько книг", "сколько карандашей", "сколько литров", "сколько всего"))):
        return None

    product = products[0]
    total = product["count"] * product["value"]
    unit = _detect_question_unit(raw_text) or product["unit"]
    answer_text = _answer_number_with_unit(total, raw_text, unit)
    unit_tail = f" {unit}".rstrip() if unit else ""
    return join_explanation_lines(
        f"1) Если есть {product['count']} одинаковых групп по {product['value']}{unit_tail} в каждой, то всего {product['count']} × {product['value']} = {total}{unit_tail}",
        f"Ответ: {answer_text}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def try_priority_bring_to_unit_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or "сколько" not in lower:
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} ":
        return None

    first_groups = nums[0]
    total_amount = nums[1]
    target_value = nums[2]

    # Тип 1: "В 3 пачках 12 фломастеров. Сколько фломастеров в 2 пачках?"
    if "таких же" in lower or re.search(r"(?:сколько[^.?!]*\bв\s+\d+\s+[а-яё]+\b)", question):
        solved = explain_bring_to_unit_total_word_problem(first_groups, total_amount, target_value)
        if solved:
            return solved

    # Тип 2: "В 2 вёдрах 16 кг. В скольких вёдрах 24 кг?"
    if "в скольких" in question or _has_group_count_question(question):
        solved = explain_unit_rate_boxes_problem(first_groups, total_amount, target_value)
        if solved:
            return solved
    return None

def try_priority_unit_rate_compare_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None

    match = re.search(r"за\s+(\d+)\s+дн", lower)
    if match and "чем за один" in question and "на сколько" in question:
        days = int(match.group(1))
        total_amount = nums[1] if len(nums) >= 2 else None
        if total_amount is None or days == 0 or total_amount % days != 0:
            return None
        one_day = total_amount // days
        diff = total_amount - one_day
        answer_text = _answer_number_with_unit(diff, raw_text)
        total_text = _answer_number_with_unit(total_amount, raw_text)
        one_day_text = _answer_number_with_unit(one_day, raw_text)
        return join_explanation_lines(
            f"1) Если за {days} дней расходуется {total_text}, то за один день расходуется {total_amount} : {days} = {one_day_text}",
            f"2) Если за {days} дней расходуется {total_text}, а за один день {one_day_text}, то разность равна {total_amount} - {one_day} = {answer_text}",
            f"Ответ: {answer_text}",
            "Совет: в такой задаче сначала находят одну одинаковую часть, потом сравнивают",
        )
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_priority_relation_then_compare_explanation(user_text)
        or try_priority_simple_two_part_total_word_problem_explanation(user_text)
        or try_priority_bring_to_unit_word_problem_explanation(user_text)
        or try_priority_unit_rate_compare_word_problem_explanation(user_text)
        or try_high_priority_named_sum_of_two_products_word_problem_explanation(user_text)
        or try_high_priority_simple_group_total_word_problem_explanation(user_text)
        or _PREV_20260411_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- OPENAI HOTFIX 2026-04-11A: relation pairs with measurement words ---

def extract_relation_pairs(text: str):
    pairs = []
    pattern = re.compile(r"на\s+(\d+)(?:\s+[а-яёa-z]+)?\s+(больше|меньше)", re.IGNORECASE)
    for match in pattern.finditer(str(text or "").lower().replace("ё", "е")):
        pairs.append((int(match.group(1)), match.group(2)))
    return pairs

# --- OPENAI HOTFIX 2026-04-11B: "скольких" in bring-to-unit tasks ---

def try_priority_bring_to_unit_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or not ("сколько" in lower or "скольких" in lower):
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} ":
        return None

    first_groups = nums[0]
    total_amount = nums[1]
    target_value = nums[2]

    if "таких же" in lower or re.search(r"(?:сколько[^.?!]*\bв\s+\d+\s+[а-яё]+\b)", question):
        solved = explain_bring_to_unit_total_word_problem(first_groups, total_amount, target_value)
        if solved:
            return solved

    if "в скольких" in question or "скольких" in question or _has_group_count_question(question):
        solved = explain_unit_rate_boxes_problem(first_groups, total_amount, target_value)
        if solved:
            return solved
    return None

# --- OPENAI HOTFIX 2026-04-11C: correct answer noun for "в скольких ..." tasks ---

def try_priority_bring_to_unit_word_problem_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or not ("сколько" in lower or "скольких" in lower):
        return None
    if extract_relation_pairs(lower) or extract_scale_pairs(lower):
        return None
    if " по " in f" {lower} ":
        return None

    first_groups = nums[0]
    total_amount = nums[1]
    target_value = nums[2]

    if "таких же" in lower or re.search(r"(?:сколько[^.?!]*\bв\s+\d+\s+[а-яё]+\b)", question):
        solved = explain_bring_to_unit_total_word_problem(first_groups, total_amount, target_value)
        if solved:
            return solved

    if "в скольких" in question or "скольких" in question or _has_group_count_question(question):
        if first_groups == 0 or total_amount % first_groups != 0:
            return None
        per_group = total_amount // first_groups
        if per_group == 0 or target_value % per_group != 0:
            return None
        result = target_value // per_group
        noun_match = re.search(r"в\s+скольких\s+([а-яё]+)", question)
        noun = noun_match.group(1) if noun_match else ""
        noun = noun.strip().rstrip("?.!,")
        answer_tail = f" {noun}" if noun else ""
        return join_explanation_lines(
            f"1) Если в {first_groups} группах {total_amount}, то в одной группе {total_amount} : {first_groups} = {per_group}",
            f"2) Если в одной группе {per_group}, то {target_value} : {per_group} = {result}",
            f"Ответ: {result}{answer_tail}",
            "Совет: в задачах на приведение к единице сначала находят значение одной группы",
        )
    return None
