"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 4354-5214."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if not remaining:
        return None

    change_value = remaining[0]
    base_total = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало", "купили")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали", "расфасовали")

    if contains_any_fragment(lower, gain_words) and contains_any_fragment(question, ("сколько", "сколько стало", "сколько всего")):
        result = base_total + change_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом добавили ещё {change_value}, то стало {base_total} + {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and contains_any_fragment(question, ("сколько", "сколько осталось", "сколько останется")):
        result = base_total - change_value
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом убрали {change_value}, то осталось {base_total} - {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_user_patch_fraction_measure_explanation(user_text)
        or try_user_patch_groups_then_change_explanation(user_text)
        or _USER_PATCH_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- USER HOTFIX 2026-04-11Z1: narrow grouped-plus-change rule ---

def _user_patch_group_word(value: int) -> str:
    return plural_form(value, "одинаковая группа", "одинаковые группы", "одинаковых групп")

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    change_value = remaining[0]
    base_total = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали", "расфасовали")

    if contains_any_fragment(lower, gain_words) and contains_any_fragment(question, ("сколько", "сколько стало", "сколько всего")):
        result = base_total + change_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} {_user_patch_group_word(groups)} по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом добавили ещё {change_value}, то стало {base_total} + {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and contains_any_fragment(question, ("сколько", "сколько осталось", "сколько останется")):
        result = base_total - change_value
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} {_user_patch_group_word(groups)} по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом убрали {change_value}, то осталось {base_total} - {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    return None

# --- USER HOTFIX 2026-04-11Z2: do not steal "total then packed" remainder tasks ---

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    change_value = remaining[0]
    base_total = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали")

    asks_gain_total = contains_any_fragment(question, ("сколько стало", "сколько всего", "сколько теперь"))
    asks_loss_total = contains_any_fragment(question, ("сколько осталось", "сколько останется"))

    if contains_any_fragment(lower, gain_words) and asks_gain_total:
        result = base_total + change_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом добавили ещё {change_value}, то стало {base_total} + {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and asks_loss_total:
        result = base_total - change_value
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом убрали {change_value}, то осталось {base_total} - {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    return None

# --- USER HOTFIX 2026-04-11Z3: broader question patterns for "стало/осталось" ---

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    change_value = remaining[0]
    base_total = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали")

    asks_gain_total = ("стало" in question) or ("всего" in question) or ("теперь" in question)
    asks_loss_total = ("остал" in question)

    if contains_any_fragment(lower, gain_words) and asks_gain_total:
        result = base_total + change_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом добавили ещё {change_value}, то стало {base_total} + {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and asks_loss_total:
        result = base_total - change_value
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {base_total}",
            f"2) Если было {base_total}, а потом убрали {change_value}, то осталось {base_total} - {change_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом часть убирают, сначала выполняют умножение",
        )

    return None

# --- USER HOTFIX 2026-04-11Z4: word-boundary question detection and better remainder handling ---

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    other_value = remaining[0]
    group_value = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали", "расфасовали", "упаковали")

    asks_gain_total = bool(re.search(r"\bстало\b|\bвсего\b|\bтеперь\b", question))
    asks_loss_total = "остал" in question

    if contains_any_fragment(lower, gain_words) and asks_gain_total:
        start_amount = min(group_value, other_value)
        added_amount = max(group_value, other_value) if min(group_value, other_value) == group_value else group_value
        # Для конструкций типа "на полках по 2 книги. Подарили ещё 10 книг" стартовым количеством является group_value.
        start_amount = group_value
        added_amount = other_value
        result = start_amount + added_amount
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {group_value}",
            f"2) Если было {group_value}, а потом добавили ещё {other_value}, то стало {group_value} + {other_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and asks_loss_total:
        total_before = max(group_value, other_value)
        removed_amount = min(group_value, other_value)
        result = total_before - removed_amount
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {groups} одинаковые группы по {per_group} в каждой, то сначала находим величину этой части: {groups} × {per_group} = {group_value}",
            f"2) Если всего было {total_before}, а эта часть равна {removed_amount}, то осталось {total_before} - {removed_amount} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если известны всё число и одна часть, другую часть находят вычитанием",
        )

    return None

# --- USER HOTFIX 2026-04-11Z5: correct group phrase agreement ---

def _user_patch_group_phrase(count: int) -> str:
    value = abs(int(count)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return f"{count} одинаковых групп"
    if tail == 1:
        return f"{count} одинаковая группа"
    if 2 <= tail <= 4:
        return f"{count} одинаковые группы"
    return f"{count} одинаковых групп"

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    other_value = remaining[0]
    group_value = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали", "расфасовали", "упаковали")

    asks_gain_total = bool(re.search(r"\bстало\b|\bвсего\b|\bтеперь\b", question))
    asks_loss_total = "остал" in question

    group_phrase = _user_patch_group_phrase(groups)

    if contains_any_fragment(lower, gain_words) and asks_gain_total:
        result = group_value + other_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {group_value}",
            f"2) Если было {group_value}, а потом добавили ещё {other_value}, то стало {group_value} + {other_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and asks_loss_total:
        total_before = max(group_value, other_value)
        removed_amount = min(group_value, other_value)
        result = total_before - removed_amount
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} в каждой, то сначала находим величину этой части: {groups} × {per_group} = {group_value}",
            f"2) Если всего было {total_before}, а эта часть равна {removed_amount}, то осталось {total_before} - {removed_amount} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если известны всё число и одна часть, другую часть находят вычитанием",
        )

    return None

# --- FINAL CONSOLIDATION PATCH 2026-04-11Z6: safer units, compound word numbers, fuller textbook cases ---

_FINAL_PATCH_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first
_FINAL_PATCH_PREV_NORMALIZE_WORD_PROBLEM_TEXT = normalize_word_problem_text

_COMPOUND_PREFIX_TO_DIGIT = {
    "двух": "2",
    "трех": "3",
    "трёх": "3",
    "четырех": "4",
    "четырёх": "4",
    "пяти": "5",
    "шести": "6",
    "семи": "7",
    "восьми": "8",
    "девяти": "9",
    "десяти": "10",
}

_COMPOUND_NUMERAL_RE = re.compile(
    r"\b(" + "|".join(map(re.escape, _COMPOUND_PREFIX_TO_DIGIT.keys())) + r")(литров[а-яё-]*|комнатн[а-яё-]*)",
    flags=re.IGNORECASE,
)

def normalize_word_problem_text(text: str) -> str:
    cleaned = _FINAL_PATCH_PREV_NORMALIZE_WORD_PROBLEM_TEXT(text)

    def _replace_compound(match: re.Match) -> str:
        stem = match.group(1).lower()
        tail = match.group(2)
        return f"{_COMPOUND_PREFIX_TO_DIGIT[stem]}-{tail}"

    cleaned = _COMPOUND_NUMERAL_RE.sub(_replace_compound, cleaned)
    return cleaned

QUESTION_NOUN_FORMS.update({
    "ведро": ("ведро", "ведра", "ведер"),
    "ведра": ("ведро", "ведра", "ведер"),
    "ведер": ("ведро", "ведра", "ведер"),
    "ведрах": ("ведро", "ведра", "ведер"),
    "вёдра": ("ведро", "ведра", "ведер"),
    "вёдер": ("ведро", "ведра", "ведер"),
    "вёдрах": ("ведро", "ведра", "ведер"),
    "ящик": ("ящик", "ящика", "ящиков"),
    "ящика": ("ящик", "ящика", "ящиков"),
    "ящиков": ("ящик", "ящика", "ящиков"),
    "ящиках": ("ящик", "ящика", "ящиков"),
    "клетках": ("клетка", "клетки", "клеток"),
    "банках": ("банка", "банки", "банок"),
    "квартира": ("квартира", "квартиры", "квартир"),
    "квартиры": ("квартира", "квартиры", "квартир"),
    "квартир": ("квартира", "квартиры", "квартир"),
    "комната": ("комната", "комнаты", "комнат"),
    "комнаты": ("комната", "комнаты", "комнат"),
    "комнат": ("комната", "комнаты", "комнат"),
    "раз": ("раз", "раза", "раз"),
})

MEASURE_QUESTION_NOUNS.update({"времени", "день", "дня", "дней", "секунда", "секунды", "секунд"})

def _extract_count_question_noun(raw_text: str) -> str:
    question = _question_lower_text(raw_text)
    patterns = [
        r"^(?:в|во|на)\s+скольких\s+([а-яё]+)",
        r"^сколько\s+(?:было\s+|будет\s+|стало\s+|осталось\s+|получилось\s+|понадобится\s+|понадобилось\s+|потребуется\s+|потребовалось\s+|можно\s+купить\s+|нужно\s+|нужно\s+купить\s+|всего\s+)?(?:таких\s+|этих\s+|эти\s+)?([а-яё]+)",
        r"^сколько\s+(?:таких\s+|этих\s+|эти\s+)?([а-яё]+)",
        r"^во\s+сколько\s+([а-яё]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, question)
        if match:
            noun = match.group(1).strip().lower().replace("ё", "е")
            if noun:
                return noun
    return ""

def _question_requests_object_count(raw_text: str) -> bool:
    noun = _extract_count_question_noun(raw_text)
    return bool(noun) and noun not in MEASURE_QUESTION_NOUNS

def _detect_question_unit(raw_text: str) -> str:
    try:
        question = _question_lower_text(raw_text)
    except Exception:
        question = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    if _question_requests_object_count(raw_text):
        return ""
    if re.search(r"\bв\s+скольких\b", question):
        return ""
    if re.search(r"\bво\s+сколько\s+раз\b", question):
        return "раз"

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        for unit in ("км/ч", "м/мин", "м/с"):
            if unit in lower_full:
                return unit

    if re.search(r"\b(?:мм|миллиметр(?:а|ов|ы)?)\b", question):
        return "мм"
    if re.search(r"(?:см²|кв\.?\s*см|квадратн[а-яё]*\s+сантиметр)", question) or (
        "площад" in question and re.search(r"\b(?:см|сантиметр(?:а|ов|ы)?)\b", question)
    ):
        return "см²"
    if re.search(r"(?:дм²|кв\.?\s*дм|квадратн[а-яё]*\s+дециметр)", question) or (
        "площад" in question and re.search(r"\b(?:дм|дециметр(?:а|ов|ы)?)\b", question)
    ):
        return "дм²"
    if re.search(r"(?:м²|кв\.?\s*м\b|квадратн[а-яё]*\s+метр)", question) or (
        "площад" in question and re.search(r"\b(?:метр(?:а|ов|ы)?|м)\b", question)
    ):
        return "м²"

    if re.search(r"\b(?:руб|рубл(?:ь|я|ей)?|денег)\b", question):
        return "руб"
    if re.search(r"\b(?:кг|килограмм(?:а|ов|ы)?)\b", question):
        return "кг"
    if re.search(r"\b(?:г|грамм(?:а|ов|ы)?)\b", question):
        return "г"
    if re.search(r"\b(?:км|километр(?:а|ов|ы)?)\b", question):
        return "км"
    if re.search(r"\b(?:см|сантиметр(?:а|ов|ы)?)\b", question):
        return "см"
    if re.search(r"\b(?:дм|дециметр(?:а|ов|ы)?)\b", question):
        return "дм"
    if re.search(r"\b(?:м|метр(?:а|ов|ы)?)\b", question):
        return "м"
    if re.search(r"\b(?:л|литр(?:а|ов|ы)?)\b", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"
    return ""

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    if re.fullmatch(r"-?\d+(?:/\d+)?", value) is None:
        return value

    noun = _extract_count_question_noun(raw_text)
    if noun and noun not in MEASURE_QUESTION_NOUNS:
        forms = _lookup_question_noun_forms(noun)
        if forms:
            try:
                count_value = int(value.split("/", 1)[0])
            except Exception:
                return value
            return f"{value} {_select_plural_by_count(count_value, forms)}"
        if noun == "раз":
            return f"{value} раз"

    unit = _detect_question_unit(raw_text)
    if unit:
        return f"{value} {unit}".strip()
    return value

def _final_patch_group_phrase(count: int) -> str:
    value = abs(int(count)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return f"{count} одинаковых групп"
    if tail == 1:
        return f"{count} одинаковая группа"
    if 2 <= tail <= 4:
        return f"{count} одинаковые группы"
    return f"{count} одинаковых групп"

def _final_patch_plural(count_value: int, forms: Tuple[str, str, str]) -> str:
    return _select_plural_by_count(count_value, forms)

def try_final_patch_simple_group_total_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if "сколько" not in question:
        return None
    if len(nums) != 2:
        return None
    if any(fragment in question for fragment in (
        "в скольких",
        "сколько потребуется",
        "сколько потребовалось",
        "сколько понадобится",
        "сколько понадобилось",
        "сколько осталось",
        "сколько останется",
        "сколько стало",
        "сколько заплатила",
        "сколько заплатил",
        "сколько стоила",
        "сколько стоит",
    )):
        return None
    if "поровну" in lower or "кажд" in question:
        return None
    if contains_any_fragment(lower, WORD_GAIN_HINTS + WORD_LOSS_HINTS):
        return None

    groups = None
    per_group = None
    unit = _detect_question_unit(raw_text)

    if len(re.findall(r"\bпо\s+\d+\b", lower)) == 1:
        pair = _first_po_pair(lower)
        if pair:
            groups, per_group = pair
    else:
        match = re.search(r"\b(\d+)\s+(\d+)-литров[а-я-]*\s+[а-я]+\b", lower)
        if match:
            groups, per_group = int(match.group(1)), int(match.group(2))
            unit = unit or "л"

    if groups is None or per_group is None:
        return None

    total = groups * per_group
    group_phrase = _final_patch_group_phrase(groups)
    if unit:
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} {unit} в каждой, то всего {groups} × {per_group} = {total} {unit}",
            f"Ответ: всего было {total} {unit}",
            "Совет: если одинаковая величина повторяется несколько раз, используют умножение",
        )
    answer_text = _detailed_maybe_enrich_answer(str(total), raw_text, "word")
    return join_explanation_lines(
        f"1) Если есть {group_phrase} по {per_group} в каждой, то всего {groups} × {per_group} = {total}",
        f"Ответ: всего было {answer_text}",
        "Совет: если одинаковое количество повторяется несколько раз, используют умножение",
    )

def try_final_patch_school_boxes_equal_price_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "школ" not in lower or "ящик" not in lower:
        return None
    if "сколько должна заплатить" not in question and "каждая школа" not in question:
        return None

    total_match = re.search(r"на\s+(\d+)\s+руб", lower)
    count_matches = [int(value) for value in re.findall(r"(\d+)\s+ящик", lower)]
    if not total_match or len(count_matches) < 2:
        return None

    total_cost = int(total_match.group(1))
    first_count, second_count = count_matches[:2]
    total_boxes = first_count + second_count
    if total_boxes == 0 or total_cost % total_boxes != 0:
        return None

    box_price = total_cost // total_boxes
    first_cost = box_price * first_count
    second_cost = box_price * second_count
    return join_explanation_lines(
        f"1) Если одна школа взяла {first_count} ящика, а другая {second_count} ящиков, то всего взяли {first_count} + {second_count} = {total_boxes} ящиков",
        f"2) Если за {total_boxes} ящиков заплатили {total_cost} руб., то один ящик стоит {total_cost} : {total_boxes} = {box_price} руб.",
        f"3) Если первая школа взяла {first_count} ящика по {box_price} руб., то она должна заплатить {box_price} × {first_count} = {first_cost} руб.",
        f"4) Если вторая школа взяла {second_count} ящиков по {box_price} руб., то она должна заплатить {box_price} × {second_count} = {second_cost} руб.",
        f"Ответ: первая школа должна заплатить {first_cost} руб., вторая — {second_cost} руб.",
        "Совет: в задачах на пропорциональное деление сначала находят общую цену одной равной части",
    )

def try_final_patch_water_bucket_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "ведр" not in lower or "одинаков" not in lower or "сколько литров" not in question:
        return None

    sizes = [int(value) for value in re.findall(r"(\d+)-литров", lower)]
    diff_match = re.search(r"на\s+(\d+)\s+литр", lower)
    if len(sizes) < 2 or not diff_match:
        return None

    big_bucket = max(sizes[0], sizes[1])
    small_bucket = min(sizes[0], sizes[1])
    diff_total = int(diff_match.group(1))
    step_diff = big_bucket - small_bucket
    if step_diff <= 0 or diff_total % step_diff != 0:
        return None

    trips = diff_total // step_diff
    big_total = big_bucket * trips
    small_total = small_bucket * trips

    if "мальчик" in lower and "девоч" in lower:
        first_label = "мальчик"
        second_label = "девочка"
        second_verb = "делала"
        second_result_verb = "принесла"
    else:
        first_label = "первый"
        second_label = "второй"
        second_verb = "делал"
        second_result_verb = "принёс"

    return join_explanation_lines(
        f"1) Если {first_label} за один раз приносил {big_bucket} л, а {second_label} {small_bucket} л, то за один раз {first_label} приносил на {big_bucket} - {small_bucket} = {step_diff} л больше",
        f"2) Если всего {first_label} принёс на {diff_total} л больше, а за один раз разница была {step_diff} л, то одинаковых ходок было {diff_total} : {step_diff} = {trips}",
        f"3) Если {first_label} делал {trips} ходок по {big_bucket} л, то он принёс {big_bucket} × {trips} = {big_total} л",
        f"4) Если {second_label} {second_verb} {trips} ходок по {small_bucket} л, то она {second_result_verb} {small_bucket} × {trips} = {small_total} л",
        f"Ответ: {first_label} принёс {big_total} л воды, {second_label} — {small_total} л.",
        "Совет: если число ходок одинаковое, сначала находят разницу за одну ходку",
    )

def try_final_patch_remaining_rooms_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "комнат" not in lower or "квартир" not in lower or "остал" not in lower:
        return None
    if "отремонт" not in question:
        return None

    total_match = re.search(r"(\d+)\s+комнат", lower)
    remain_match = re.search(r"остал[аоись]*[^0-9]{0,40}(\d+)\s+(\d+)-комнатн", lower)
    if not total_match or not remain_match:
        return None

    total_rooms = int(total_match.group(1))
    flats = int(remain_match.group(1))
    rooms_per_flat = int(remain_match.group(2))
    remaining_rooms = flats * rooms_per_flat
    repaired_rooms = total_rooms - remaining_rooms
    if repaired_rooms < 0:
        return None

    flat_word = _final_patch_plural(flats, ("квартира", "квартиры", "квартир"))
    room_word = _final_patch_plural(rooms_per_flat, ("комната", "комнаты", "комнат"))
    return join_explanation_lines(
        f"1) Если осталось отремонтировать {flats} {flat_word} по {rooms_per_flat} {room_word} в каждой, то осталось отремонтировать {flats} × {rooms_per_flat} = {remaining_rooms} комнат",
        f"2) Если всего надо было отремонтировать {total_rooms} комнаты, а осталось {remaining_rooms} комнат, то отремонтировали {total_rooms} - {remaining_rooms} = {repaired_rooms} комнат",
        f"Ответ: отремонтировали {repaired_rooms} комнат.",
        "Совет: если известны всё число и оставшаяся часть, выполненную часть находят вычитанием",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_final_patch_school_boxes_equal_price_explanation(user_text)
        or try_final_patch_water_bucket_explanation(user_text)
        or try_final_patch_remaining_rooms_explanation(user_text)
        or try_final_patch_simple_group_total_explanation(user_text)
        or _FINAL_PATCH_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- OPENAI FINAL CONSOLIDATION PATCH 2026-04-11N: punctuation, order marks, missing textbook templates ---

_OAI_FINAL_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def _oai_final_question_lower(raw_text: str) -> str:
    return _question_lower_text(raw_text).lower().replace("ё", "е")

def try_oai_final_combined_rate_pump_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _oai_final_question_lower(raw_text)
    if "насос" not in lower:
        return None
    if not contains_any_fragment(question, ("за сколько", "сколько минут", "сколько мин", "за какое время")):
        return None

    first_match = re.search(r"перв(?:ый|ого)?\s+насос[^\d]{0,40}(\d+)\s+в(?:е|ё)дер[^\d]{0,40}за\s+(\d+)\s+мин", lower)
    second_time_match = re.search(r"втор(?:ой|ого)?[^\d]{0,60}за\s+(\d+)\s+мин", lower)
    nums = extract_ordered_numbers(lower)
    if not first_match or not second_time_match or len(nums) < 4:
        return None

    amount = int(first_match.group(1))
    time1 = int(first_match.group(2))
    time2 = int(second_time_match.group(1))
    target = nums[-1]
    if amount <= 0 or time1 <= 0 or time2 <= 0 or target <= 0:
        return None

    rate1 = Fraction(amount, time1)
    rate2 = Fraction(amount, time2)
    total_rate = rate1 + rate2
    if total_rate == 0:
        return None
    total_time = Fraction(target, 1) / total_rate

    rate1_text = format_fraction(rate1)
    rate2_text = format_fraction(rate2)
    total_rate_text = format_fraction(total_rate)
    total_time_text = format_fraction(total_time)

    return join_explanation_lines(
        f"1) Если первый насос выкачивает {amount} вёдер за {time1} мин, то за 1 мин он выкачивает {amount} : {time1} = {rate1_text} вёдер",
        f"2) Если второй насос выкачивает {amount} вёдер за {time2} мин, то за 1 мин он выкачивает {amount} : {time2} = {rate2_text} вёдер",
        f"3) Если оба насоса работают вместе, то за 1 мин они выкачивают {rate1_text} + {rate2_text} = {total_rate_text} вёдер",
        f"4) Если нужно выкачать {target} вёдер, а за 1 мин выкачивают {total_rate_text} вёдер, то время равно {target} : {total_rate_text} = {total_time_text} мин",
        f"Ответ: оба насоса выкачают {target} вёдер за {total_time_text} мин",
        "Совет: в задачах на совместную работу сначала находят, сколько каждый делает за 1 минуту",
    )

def try_oai_final_advanced_brigade_unit_rate_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _oai_final_question_lower(raw_text)
    if "бригада" not in lower:
        return None
    if not contains_any_fragment(question, ("сколько метров", "сколько м", "сколько километров", "сколько км")):
        return None

    source_match = re.search(r"за\s+(\d+)\s+дн(?:я|ей)[^\d]{0,60}бригада[^\d]{0,60}(\d+)\s*(м|км)", lower)
    question_match = re.search(r"(\d+)\s+бригад[^\d]{0,60}за\s+(\d+)\s+дн(?:я|ей)", lower)
    if not source_match or not question_match:
        return None

    days1 = int(source_match.group(1))
    total_amount = int(source_match.group(2))
    unit = source_match.group(3)
    brigades = int(question_match.group(1))
    days2 = int(question_match.group(2))
    if days1 <= 0 or brigades <= 0 or days2 <= 0 or total_amount <= 0:
        return None

    one_brigade_one_day = Fraction(total_amount, days1)
    many_brigades_one_day = one_brigade_one_day * brigades
    final_amount = many_brigades_one_day * days2

    d1_text = format_fraction(one_brigade_one_day)
    d2_text = format_fraction(many_brigades_one_day)
    answer_text = format_fraction(final_amount)

    return join_explanation_lines(
        f"1) Если одна бригада проложила {total_amount} {unit} за {days1} дней, то за 1 день одна бригада проложит {total_amount} : {days1} = {d1_text} {unit}",
        f"2) Если одна бригада за 1 день прокладывает {d1_text} {unit}, то {brigades} бригады за 1 день проложат {d1_text} × {brigades} = {d2_text} {unit}",
        f"3) Если {brigades} бригады за 1 день прокладывают {d2_text} {unit}, то за {days2} дней они проложат {d2_text} × {days2} = {answer_text} {unit}",
        f"Ответ: {brigades} бригады за {days2} дней проложат {answer_text} {unit}",
        "Совет: в усложнённых задачах на приведение к единице сначала находят работу одной бригады за 1 день",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_oai_final_combined_rate_pump_explanation(user_text)
        or try_oai_final_advanced_brigade_unit_rate_explanation(user_text)
        or _OAI_FINAL_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )
