"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 5201-6072."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
# --- OPENAI HOTFIX 2026-04-11P: reliable sentence split + combined-rate matching ---

def try_oai_final_combined_rate_pump_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    if "насос" not in lower:
        return None
    if not contains_any_fragment(lower, ("за сколько", "сколько минут", "сколько мин", "за какое время", "оба насоса", "работать одновременно")):
        return None

    first_match = re.search(r"перв(?:ый|ого)?\s+насос[^\d]{0,40}(\d+)\s+в(?:е|ё)дер[^\d]{0,40}за\s+(\d+)\s+мин", lower)
    second_time_match = re.search(r"втор(?:ой|ого)?[^\d]{0,60}за\s+(\d+)\s+мин", lower)
    nums = extract_ordered_numbers(lower)
    if not first_match or not second_time_match or len(nums) < 4:
        return None

    amount = int(first_match.group(1))
    time1 = int(first_match.group(2))
    time2 = int(second_time_match.group(1))
    target = nums[-1]
    if amount <= 0 or time1 <= 0 or time2 <= 0 or target <= 0:
        return None

    rate1 = Fraction(amount, time1)
    rate2 = Fraction(amount, time2)
    total_rate = rate1 + rate2
    if total_rate == 0:
        return None
    total_time = Fraction(target, 1) / total_rate

    rate1_text = format_fraction(rate1)
    rate2_text = format_fraction(rate2)
    total_rate_text = format_fraction(total_rate)
    total_time_text = format_fraction(total_time)

    return join_explanation_lines(
        f"1) Если первый насос выкачивает {amount} вёдер за {time1} мин, то за 1 мин он выкачивает {amount} : {time1} = {rate1_text} вёдер",
        f"2) Если второй насос выкачивает {amount} вёдер за {time2} мин, то за 1 мин он выкачивает {amount} : {time2} = {rate2_text} вёдер",
        f"3) Если оба насоса работают одновременно, то за 1 мин они выкачивают {rate1_text} + {rate2_text} = {total_rate_text} вёдер",
        f"4) Если нужно выкачать {target} вёдер, а за 1 мин выкачивают {total_rate_text} вёдер, то время равно {target} : {total_rate_text} = {total_time_text} мин",
        f"Ответ: оба насоса выкачают {target} вёдер за {total_time_text} мин",
        "Совет: в задачах на совместную работу сначала находят, сколько каждый делает за 1 минуту",
    )

# --- USER PATCH 2026-04-11Z: stricter equation detection, expression with "=" support,
# --- fuller question noun extraction, and textbook-style remainder wording.



def _user_has_standalone_x(text: str) -> bool:
    return bool(re.search(r"(?<![\d)])\s*[xXхХ]\s*(?![\d(])", str(text or "")))

def _user_has_mul_x_between_numbers(text: str) -> bool:
    return bool(re.search(r"(?<=[\d)])\s*[xXхХ]\s*(?=[\d(])", str(text or "")))

def _insert_implicit_multiplication_signs(text: str) -> str:
    value = str(text or "")
    if not value:
        return value
    updated = value
    for pattern in (r"(\d)\s*(\()", r"(\))\s*(\d)", r"(\))\s*(\()"):
        updated = re.sub(pattern, r"\1*\2", updated)
    return updated



def to_expression_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None

    text = normalize_dashes(text)
    text = text.replace("×", "*").replace("·", "*").replace("÷", "/").replace(":", "/")

    # x/х между числами понимаем как умножение.
    text = re.sub(r"(?<=[\d)])\s*[xXхХ]\s*(?=[\d(])", " * ", text)
    text = _insert_implicit_multiplication_signs(text)

    # Если запись вида «25 х 4 = 100» или «6 + 7 = ?», берём только левую часть как пример.
    if "=" in text:
        left, right = text.split("=", 1)
        left = left.strip()
        right = right.strip()

        if not _user_has_standalone_x(left) and not _user_has_standalone_x(right):
            if not re.search(r"[A-Za-zА-Яа-я]", left.replace("х", "").replace("Х", "")):
                if right in {"", "?", "=?", "= ?"} or re.fullmatch(r"[\d\s()+\-*/.,]+", right):
                    text = left
                else:
                    return None
            else:
                return None
        else:
            return None

    text = re.sub(r"\s*\?\s*$", "", text).strip()
    if re.search(r"[A-Za-zА-Яа-я]", text):
        return None
    if not re.fullmatch(r"[\d\s()+\-*/]+", text):
        return None

    compact = re.sub(r"\s+", "", text)
    if not compact or not re.search(r"[+\-*/]", compact):
        return None
    return compact

def infer_task_kind(text: str) -> str:
    base = strip_known_prefix(text)
    lowered = normalize_cyrillic_x(base).lower()

    if re.search(r"\d+\s*/\s*\d+\s*[+\-]\s*\d+\s*/\s*\d+", lowered):
        return "fraction"
    if to_equation_source(text):
        return "equation"
    if re.search(r"периметр|площадь|прямоугольник|квадрат|треугольник|сторон|длина|ширина", lowered):
        return "geometry"
    if re.search(r"[а-я]", lowered):
        return "word"
    if to_expression_source(text):
        return "expression"
    if re.search(r"[+\-*/()×÷:=]", lowered):
        return "expression"
    return "other"



def _user_question_asks_remaining(raw_text: str) -> bool:
    question = _question_lower_text(raw_text)
    return bool(
        re.search(
            r"(?:сколько|какое|какова?|чему)\b[^.?!]*\b(остал(?:ось|ось|ся|ись|ись)|останется|осталось\s+прочитать|осталось\s+проехать|осталось\s+расфасовать)\b",
            question,
        )
    )

def _user_remaining_question_phrase(raw_text: str) -> str:
    question = _question_lower_text(raw_text)
    if "прочитать" in question:
        return "осталось прочитать"
    if "проехать" in question:
        return "осталось проехать"
    if "расфасовать" in question:
        return "осталось расфасовать"
    return "осталось"

def try_user_patch_simple_remaining_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None
    if not _user_question_asks_remaining(raw_text):
        return None

    first, second = nums[0], nums[1]
    if first < second:
        return None

    answer_text = _patch_answer_with_question_noun(first - second, raw_text)
    phrase = _user_remaining_question_phrase(raw_text)

    return join_explanation_lines(
        f"1) Если всего было {first}, а использовали {second}, то {phrase} {first} - {second} = {answer_text}",
        f"Ответ: {phrase} {answer_text}",
        "Совет: чтобы найти остаток, из всего вычитают использованную часть",
    )



# --- USER PATCH 2026-04-11ZA: fuller counted answers like "4 яблока", "3 страницы".

def _patch_answer_with_question_noun(value: int, raw_text: str) -> str:
    return _external_patch_answer_with_question_noun(
        value,
        raw_text,
        _detect_question_unit,
        _extract_count_question_noun,
        _extract_question_noun,
    )

# --- OPENAI USER PATCH 2026-04-11R: textbook priority fixes from uploaded books ---

QUESTION_NOUN_FORMS.update({
    "фруктов": ("фрукт", "фрукта", "фруктов"),
    "листов": ("лист", "листа", "листов"),
    "перьев": ("перо", "пера", "перьев"),
    "мешков": ("мешок", "мешка", "мешков"),
    "кустов": ("куст", "куста", "кустов"),
    "цветов": ("цветок", "цветка", "цветов"),
    "глазков": ("глазок", "глазка", "глазков"),
    "пакетов": ("пакет", "пакета", "пакетов"),
    "наборов": ("набор", "набора", "наборов"),
    "деталей": ("деталь", "детали", "деталей"),
    "фломастеров": ("фломастер", "фломастера", "фломастеров"),
    "персиков": ("персик", "персика", "персиков"),
    "груш": ("груша", "груши", "груш"),
    "магнитофонов": ("магнитофон", "магнитофона", "магнитофонов"),
    "видеоплееров": ("видеоплеер", "видеоплеера", "видеоплееров"),
})




def _oai_patch_extract_question_item_r(raw_text: str) -> str:
    question = _question_lower_text(raw_text)
    patterns = [
        r"сколько\s+стоил(?:а|о|и)?\s+([а-яё]+)",
        r"сколько\s+стоит\s+([а-яё]+)",
        r"сколько\s+книг\s+было\s+на\s+([а-яё]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, question)
        if match:
            return match.group(1).strip()
    return ""

def _oai_patch_text_has_fraction_r(text: str) -> bool:
    return bool(re.search(r"\d+\s*/\s*\d+", str(text or "")))

def try_oai_patch_unknown_addend_rest_explanation_r(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)

    if len(nums) != 2:
        return None
    if "из них" not in lower or "осталь" not in lower:
        return None
    if "на сколько" in question or "во сколько" in question:
        return None
    if "сколько" not in question:
        return None

    total, known = nums[0], nums[1]
    if total < known:
        return None

    result = total - known
    answer_text = _patch_answer_with_question_noun(result, raw_text)
    return join_explanation_lines(
        f"1) Если всего было {total}, а известная часть равна {known}, то другая часть равна {total} - {known} = {answer_text}",
        f"Ответ: {answer_text}",
        "Совет: чтобы найти неизвестную часть, из целого вычитают известную часть",
    )

def try_oai_patch_simple_total_minus_part_money_explanation_r(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)

    if len(nums) != 2:
        return None
    if not contains_any_fragment(lower, ("заплатил", "заплатила", "заплатили", "стоил", "стоила", "стоило")):
        return None
    if not contains_any_fragment(question, ("сколько стоила", "сколько стоил", "сколько стоило", "сколько стоит")):
        return None
    if "по" in lower:
        return None

    total_cost, known_cost = nums[0], nums[1]
    if total_cost < known_cost:
        return None

    result = total_cost - known_cost
    item = _oai_patch_extract_question_item_r(raw_text) or "неизвестная часть"
    return join_explanation_lines(
        f"1) Если за всю покупку заплатили {total_cost} руб., а известная часть стоила {known_cost} руб., то {item} стоил{'' if item.endswith('о') else 'а' if item.endswith('а') else ''} {total_cost} - {known_cost} = {result} руб.",
        f"Ответ: {item} стоил{'' if item.endswith('о') else 'а' if item.endswith('а') else ''} {result} руб.",
        "Совет: если известна общая стоимость и одна часть, другую часть находят вычитанием",
    )

def try_oai_patch_simple_motion_time_explanation_r(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)

    if not re.search(r"(?:какое|какова?|сколько)\s+врем(?:я|ени)|сколько\s+час", question):
        return None

    distance_values = [int(v) for v in re.findall(r"(\d+)\s*(?:км|м)(?!/)", lower)]
    speed_values = [int(v) for v in re.findall(r"(\d+)\s*(?:км/ч|м/мин|м/с)", lower)] or [int(v) for v in re.findall(r"скорост[ьяию][^\d]{0,20}(\d+)", lower)]

    if len(distance_values) != 1 or len(speed_values) != 1:
        return None
    if len(re.findall(r"\d+\s*(?:км|м)(?!/)", lower)) != 1:
        return None

    distance = distance_values[0]
    speed = speed_values[0]
    if speed <= 0 or distance < 0 or distance % speed != 0:
        return None

    time_value = distance // speed
    distance_unit = "км" if re.search(r"\d+\s*км(?!/)", lower) else "м"
    speed_unit = "км/ч" if "км/ч" in lower else "м/мин" if "м/мин" in lower else "м/с" if "м/с" in lower else "ед./ч"
    time_unit = "ч"
    if speed_unit == "м/мин":
        time_unit = "мин"
    elif speed_unit == "м/с":
        time_unit = "с"

    return join_explanation_lines(
        f"1) Если путь равен {distance} {distance_unit}, а скорость равна {speed} {speed_unit}, то время равно {distance} : {speed} = {time_value} {time_unit}",
        f"Ответ: время в пути равно {time_value} {time_unit}",
        "Совет: чтобы найти время, расстояние делят на скорость",
    )




# --- OPENAI HOTFIX 2026-04-11S: "на сколько" answers and cleaner price comparison wording ---



def try_oai_patch_price_compare_logic_explanation_r(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)

    if len(nums) != 3:
        return None
    if "за столько же" not in lower:
        return None
    if not (contains_any_fragment(question, ("на сколько", "дороже")) or contains_any_fragment(question, ("на сколько", "дешевле"))):
        return None

    quantity, cost_first, cost_second = nums
    if quantity <= 0 or cost_first % quantity != 0 or cost_second % quantity != 0:
        return None

    price_first = cost_first // quantity
    price_second = cost_second // quantity
    diff = abs(price_first - price_second)

    package_items = re.findall(r"пакет(?:ов|а)?\s+([а-яё]+)", lower)
    if len(package_items) >= 2:
        first_name = f"пакет {package_items[0]}"
        second_name = f"пакет {package_items[1]}"
        first_name_gen = f"пакета {package_items[0]}"
        second_name_gen = f"пакета {package_items[1]}"
    else:
        first_name = "первый товар"
        second_name = "второй товар"
        first_name_gen = "первого товара"
        second_name_gen = "второго товара"

    if price_first > price_second:
        relation_text = f"{first_name} дороже {second_name_gen} на {diff} руб."
    elif price_second > price_first:
        relation_text = f"{second_name} дороже {first_name_gen} на {diff} руб."
    else:
        relation_text = "цены одинаковые"

    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых пакетов первого товара заплатили {cost_first} руб., то один пакет стоит {cost_first} : {quantity} = {price_first} руб.",
        f"2) Если за {quantity} таких же пакетов второго товара заплатили {cost_second} руб., то один пакет стоит {cost_second} : {quantity} = {price_second} руб.",
        f"3) Если одна цена равна {price_first} руб., а другая {price_second} руб., то разность цен равна {max(price_first, price_second)} - {min(price_first, price_second)} = {diff} руб.",
        f"Ответ: разность в цене равна {diff} руб.; {relation_text}",
        "Совет: чтобы сравнить цену одинакового количества товаров, сначала находят цену одной штуки",
    )

# --- OPENAI HOTFIX 2026-04-11T: prefix "на" for direct comparison numeric answers ---



# --- CHATGPT FINAL PATCH 2026-04-11U: stronger textbook routing, missing unit-rate cases, safer compare logic ---

_CHATGPT_FINAL_PREV_EXPLAIN_SIMPLE_ADDITION_U = explain_simple_addition

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши строку:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. По возможности используй школьную форму:
Если ..., то ...
8. После каждого действия коротко говори, что нашли.
9. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если это выражение, сначала назови порядок действий.
Если это уравнение, оставляй x отдельно и объясняй обратное действие.
Если это дроби, сначала смотри на знаменатели.
Если это геометрия, сначала назови формулу, потом подставь числа.
Если это именованные величины, сначала переведи их в одинаковые единицы.

Используй школьные приёмы:
сложение через десяток — разложи число так, чтобы сначала получить 10 или следующее круглое число;
вычитание через десяток — вычитай по частям через 10;
двузначные числа раскладывай на десятки и единицы;
если числа большие, объясняй по разрядам;
если в сумме больше двух двузначных чисел или есть хотя бы одно трёхзначное число, можно показывать вычисление в столбик;
для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

def explain_simple_addition(left: int, right: int) -> str:
    big = max(left, right)
    small = min(left, right)
    if 10 <= big <= 99 and 1 <= small <= 99:
        jump = (10 - (big % 10)) % 10
        if jump == 0:
            jump = 10
        if 0 < jump < small:
            rounded = big + jump
            rest = small - jump
            total = left + right
            return join_explanation_lines(
                "Ищем сумму",
                f"Сначала удобно дойти от {big} до следующего круглого числа {rounded}",
                f"Для этого нужно прибавить {jump}",
                f"Разложим {small} на {jump} и {rest}",
                f"{big} + {jump} = {rounded}",
                f"{rounded} + {rest} = {total}",
                f"Ответ: {total}",
                "Совет: если сумма переходит через десяток, удобно сначала дойти до круглого числа",
            )
    return _CHATGPT_FINAL_PREV_EXPLAIN_SIMPLE_ADDITION_U(left, right)

def try_chatgpt_final_relation_then_compare_explanation_u(raw_text: str) -> Optional[str]:
    try:
        return try_priority_relation_then_compare_explanation(raw_text)
    except Exception:
        return None



def try_chatgpt_final_sum_then_relation_to_sum_explanation_u(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 3 or "сколько" not in question:
        return None
    if has_multiple_questions(raw_text):
        return None
    if "вместе" not in lower:
        return None

    first, second, third_number = nums[0], nums[1], nums[2]
    together = first + second

    same_match = re.search(r"столько(?:\s+же)?[, ]+сколько[^?.!]{0,120}?вместе", lower)
    delta_match = re.search(r"на\s+(\d+)[^?.!]{0,20}?(больше|меньше)[^?.!]{0,120}?вместе", lower)
    scale_match = re.search(r"в\s+(\d+)\s+раз(?:а)?\s+(больше|меньше)[^?.!]{0,120}?вместе", lower)

    if same_match:
        result = together
        return join_explanation_lines(
            f"1) Если первое количество равно {first}, а второе равно {second}, то вместе {first} + {second} = {together}",
            f"2) Если искомое количество столько же, сколько эти два количества вместе, то оно равно {together}",
            f"Ответ: {result}",
            "Совет: если искомое число сравнивают с суммой двух чисел, сначала находят эту сумму",
        )

    if delta_match:
        delta = int(delta_match.group(1))
        mode = delta_match.group(2)
        if delta != third_number:
            return None
        result = apply_more_less(together, delta, mode)
        if result is None:
            return None
        op = "+" if mode == "больше" else "-"
        return join_explanation_lines(
            f"1) Если первое количество равно {first}, а второе равно {second}, то вместе {first} + {second} = {together}",
            f"2) Если искомое количество на {delta} {mode}, чем эти два количества вместе, то {together} {op} {delta} = {result}",
            f"Ответ: {result}",
            "Совет: если искомое число сравнивают с суммой двух чисел, сначала находят эту сумму",
        )

    if scale_match:
        factor = int(scale_match.group(1))
        mode = scale_match.group(2)
        if factor != third_number:
            return None
        result = apply_times_relation(together, factor, mode)
        if result is None:
            return None
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если первое количество равно {first}, а второе равно {second}, то вместе {first} + {second} = {together}",
            f"2) Если искомое количество в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, чем эти два количества вместе, то {together} {op} {factor} = {result}",
            f"Ответ: {result}",
            "Совет: если искомое число сравнивают с суммой двух чисел, сначала находят эту сумму",
        )

    return None



# --- CHATGPT HOTFIX 2026-04-11V: beam unit-rate and fuller ratio answers ---

_CHATGPT_HOTFIX_PREV_RELATION_COMPARE_V = try_chatgpt_final_relation_then_compare_explanation_u

def try_chatgpt_final_relation_then_compare_explanation_u(raw_text: str) -> Optional[str]:
    text = _CHATGPT_HOTFIX_PREV_RELATION_COMPARE_V(raw_text)
    if not text:
        return text
    text = re.sub(r"^Ответ:\s*(\d+)\s+(раз|раза)\b", r"Ответ: в \1 \2", text, flags=re.MULTILINE)
    return text

def try_chatgpt_final_beam_weight_explanation_u(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "вес" not in question:
        return None

    patterns = [
        re.compile(r"балк[а-я]*\s+длиной\s*(\d+)\s*(м|метр(?:а|ов)?|дм|см|км).*?весит\s*(\d+)\s*(кг|г|т).*?длиной\s*(\d+)\s*(м|метр(?:а|ов)?|дм|см|км)", re.IGNORECASE),
        re.compile(r"(\d+)\s*(м|метр(?:а|ов)?|дм|см|км).*?весит\s*(\d+)\s*(кг|г|т).*?(\d+)\s*(м|метр(?:а|ов)?|дм|см|км)", re.IGNORECASE),
    ]

    match = None
    for pattern in patterns:
        match = pattern.search(lower)
        if match:
            break
    if not match:
        return None

    base_len = int(match.group(1))
    len_unit_1 = match.group(2)
    total_weight = int(match.group(3))
    weight_unit = match.group(4)
    target_len = int(match.group(5))
    len_unit_2 = match.group(6)

    unit_key_1 = len_unit_1[0]
    unit_key_2 = len_unit_2[0]
    if base_len <= 0 or total_weight < 0 or unit_key_1 != unit_key_2:
        return None
    if total_weight % base_len != 0:
        return None

    per_unit = total_weight // base_len
    result = per_unit * target_len
    length_name = "метр"
    if unit_key_1 == "д":
        length_name = "дециметр"
    elif unit_key_1 == "с":
        length_name = "сантиметр"
    elif unit_key_1 == "к":
        length_name = "километр"

    return join_explanation_lines(
        f"1) Если {base_len} {len_unit_1} такой же балки весят {total_weight} {weight_unit}, то один {length_name} весит {total_weight} : {base_len} = {per_unit} {weight_unit}",
        f"2) Если один {length_name} весит {per_unit} {weight_unit}, то {target_len} {len_unit_2} весят {per_unit} × {target_len} = {result} {weight_unit}",
        f"Ответ: {result}",
        "Совет: в задачах на приведение к единице сначала находят одну одинаковую часть",
    )



# --- CHATGPT HOTFIX 2026-04-11W: better unit detection from the question ---



# --- OPENAI CONSOLIDATION PATCH 2026-04-11Z: restore textbook cases lost in late patch chain ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. По возможности используй школьную форму:
Если ..., то ...
8. После каждого действия коротко говори, что нашли.
9. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Если задача дана с именованными величинами, сначала переведи их в удобные одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Сохраняй вычисления в столбик и пояснения.
Если в вычислении больше двух двузначных чисел или есть хотя бы одно трёхзначное число, можно показывать вычисление в столбик.
Для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

_CONSOLIDATION_EXTRA_QUESTION_NOUN_FORMS_Z = {
    "тюльпанов": ("тюльпан", "тюльпана", "тюльпанов"),
    "километров": ("километр", "километра", "километров"),
    "метров": ("метр", "метра", "метров"),
    "сантиметров": ("сантиметр", "сантиметра", "сантиметров"),
    "дециметров": ("дециметр", "дециметра", "дециметров"),
    "миллиметров": ("миллиметр", "миллиметра", "миллиметров"),
    "килограммов": ("килограмм", "килограмма", "килограммов"),
    "граммов": ("грамм", "грамма", "граммов"),
    "литров": ("литр", "литра", "литров"),
    "рублей": ("рубль", "рубля", "рублей"),
    "руб": ("рубль", "рубля", "рублей"),
    "часов": ("час", "часа", "часов"),
    "минут": ("минута", "минуты", "минут"),
    "тетрадей": ("тетрадь", "тетради", "тетрадей"),
    "ручек": ("ручка", "ручки", "ручек"),
    "машин": ("машина", "машины", "машин"),
    "страниц": ("страница", "страницы", "страниц"),
    "цветов": ("цветок", "цветка", "цветов"),
    "яблок": ("яблоко", "яблока", "яблок"),
    "груш": ("груша", "груши", "груш"),
    "булочек": ("булочка", "булочки", "булочек"),
    "кг": ("килограмм", "килограмма", "килограммов"),
    "л": ("литр", "литра", "литров"),
}

def _consolidation_normalize_noun_key_z(noun: str) -> str:
    return str(noun or "").strip().lower().replace("ё", "е")

def _consolidation_lookup_forms_z(noun: str) -> Optional[Tuple[str, str, str]]:
    key = _consolidation_normalize_noun_key_z(noun)
    if not key:
        return None
    forms = None
    try:
        forms = _lookup_question_noun_forms(key)
    except Exception:
        forms = None
    if forms:
        return forms
    return _CONSOLIDATION_EXTRA_QUESTION_NOUN_FORMS_Z.get(key)

def _consolidation_phrase_with_noun_z(count_value: int, noun: str) -> str:
    forms = _consolidation_lookup_forms_z(noun)
    if forms:
        return f"{count_value} {_select_plural_by_count(int(count_value), forms)}"
    return str(count_value)

def _consolidation_capitalize_z(text: str) -> str:
    value = str(text or "").strip()
    if not value:
        return value
    return value[:1].upper() + value[1:]

def _consolidation_split_question_parts_z(raw_text: str) -> List[str]:
    try:
        _, question = extract_condition_and_question(raw_text)
    except Exception:
        question = str(raw_text or "")
    return [part.strip() for part in re.split(r"\?", question) if part.strip()]

def _consolidation_answer_from_first_question_z(question_text: str, value: int, noun_hint: str = "") -> str:
    q = str(question_text or "").strip().rstrip("?.!").lower().replace("ё", "е")

    match = re.match(
        r"сколько\s+([а-яё]+)\s+(было|стало|будет|осталось|останется|получилось|оказалось|росло|лежало|ехало|шло|стоит|стоило|нужно|надо)\s+(.+)$",
        q,
    )
    if match:
        noun, verb, tail = match.groups()
        return f"{_consolidation_capitalize_z(tail)} {verb} {_consolidation_phrase_with_noun_z(value, noun)}"

    match = re.match(r"сколько\s+([а-яё]+)\s+(.+)$", q)
    if match:
        noun, tail = match.groups()
        first_word = tail.split()[0] if tail.split() else ""
        if first_word in {"в", "во", "на", "у", "из", "до", "после", "под", "над", "около"}:
            return f"{_consolidation_capitalize_z(tail)} было {_consolidation_phrase_with_noun_z(value, noun)}"
        return f"{_consolidation_capitalize_z(tail)} — {_consolidation_phrase_with_noun_z(value, noun)}"

    return _consolidation_phrase_with_noun_z(value, noun_hint)

def _consolidation_answer_from_compare_question_z(question_text: str, value: int, noun_hint: str = "") -> str:
    q = str(question_text or "").strip().rstrip("?.!").lower().replace("ё", "е")

    match = re.match(r"на\s+сколько\s+([а-яё]+)\s+(.+?)\s+(больше|меньше)(?:,?\s+чем\s+.+)?$", q)
    if match:
        noun, tail, mode = match.groups()
        return f"{_consolidation_capitalize_z(tail)} на {_consolidation_phrase_with_noun_z(value, noun)} {mode}"

    match = re.match(r"во\s+сколько\s+раз\s+([а-яё]+)\s+(.+?)\s+(больше|меньше)(?:,?\s+чем\s+.+)?$", q)
    if match:
        _, tail, mode = match.groups()
        return f"{_consolidation_capitalize_z(tail)} в {value} {plural_form(int(value), 'раз', 'раза', 'раз')} {mode}"

    if q.startswith("на сколько"):
        return f"Разность равна {_consolidation_phrase_with_noun_z(value, noun_hint)}"
    if q.startswith("во сколько"):
        return f"Отношение равно {value} {plural_form(int(value), 'раз', 'раза', 'раз')}"

    return _consolidation_phrase_with_noun_z(value, noun_hint)
