"""Auto-generated runtime shard for prepatch_build_source.py, lines 14215-15106."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _final_20260415ad_try_leftover_then_group_count(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'осталось' not in lower and 'ещё осталось' not in lower and 'еще осталось' not in lower:
        return None
    if 'на кажд' not in lower or 'по' not in lower:
        return None
    if not ('сколько' in lower and contains_any_fragment(lower, ('грядок', 'корзин', 'пакетов', 'ящиков', 'рядов'))):
        return None

    total, per_group, leftover = nums[:3]
    used = total - leftover
    if per_group <= 0 or used < 0 or used % per_group != 0:
        return None
    groups = used // per_group

    group_noun = 'грядок'
    if 'корзин' in lower:
        group_noun = 'корзин'
    elif 'ящик' in lower:
        group_noun = 'ящиков'
    elif 'пакет' in lower:
        group_noun = 'пакетов'
    elif 'ряд' in lower:
        group_noun = 'рядов'

    unit = 'ведер'
    if 'литр' in lower:
        unit = 'л'
    elif 'килограмм' in lower or 'кг' in lower:
        unit = 'кг'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: всего было {total} {unit}. На каждую группу расходовали по {per_group} {unit}. После этого осталось {leftover} {unit}.',
        f'Что нужно найти: сколько {group_noun} получилось.',
        f'1) Сначала найдём, сколько {unit} израсходовали: {total} - {leftover} = {used} {unit}.',
        f'2) Потом найдём число групп: {used} : {per_group} = {groups}.',
        f'Ответ: {groups} {group_noun}.'
    )

def _final_20260415ad_try_money_part_to_whole(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if not nums:
        return None
    if 'денег' not in lower and 'руб' not in lower:
        return None
    if 'сколько денег было' not in lower and 'сколько было денег' not in lower and 'сколько денег у' not in lower:
        return None

    multiplier = None
    fraction_label = None
    if 'половин' in lower:
        multiplier = 2
        fraction_label = 'половина'
    elif 'треть' in lower:
        multiplier = 3
        fraction_label = 'треть'
    elif 'четверт' in lower:
        multiplier = 4
        fraction_label = 'четверть'
    if multiplier is None:
        return None
    if not contains_any_fragment(lower, ('заплат', 'израсход', 'потрат', 'покупк')):
        return None

    part_value = nums[-1]
    total = part_value * multiplier
    unit = 'руб.' if 'руб' in lower else ''
    person_match = re.search(r'([А-ЯЁA-Z][а-яёa-z-]+)', text)
    person = person_match.group(1) if person_match else 'У ученика'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {part_value} {unit}'.strip() + f' — это {fraction_label} всех денег.',
        'Что нужно найти: сколько денег было сначала.',
        f'1) {part_value} {unit}'.strip() + f' — это {fraction_label} всех денег.',
        f'2) Чтобы найти все деньги, умножаем {part_value} на {multiplier}: {part_value} × {multiplier} = {total} {unit}'.rstrip(),
        f'Ответ: у {person} было {total} {unit}'.rstrip() + '.'.replace(' .','.' )
    ).replace(' .', '.').replace('..', '.')

def _final_20260415ad_try_three_pair_sums(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    pairs = re.findall(r'([а-яё-]+)\s+и\s+([а-яё-]+)\s+вместе\s+(\d+)', lower)
    if len(pairs) != 3:
        return None
    if 'сколько им лет' not in lower and 'сколько лет' not in lower:
        return None

    first_a, first_b, first_sum = pairs[0][0], pairs[0][1], int(pairs[0][2])
    second_a, second_b, second_sum = pairs[1][0], pairs[1][1], int(pairs[1][2])
    third_a, third_b, third_sum = pairs[2][0], pairs[2][1], int(pairs[2][2])

    common = set((first_a, first_b)).intersection((second_a, second_b))
    if len(common) != 1:
        return None
    common_name = list(common)[0]
    other_first = first_b if first_a == common_name else first_a
    other_second = second_b if second_a == common_name else second_a
    if set((other_first, other_second)) != set((third_a, third_b)):
        return None

    double_common = first_sum + second_sum - third_sum
    if double_common < 0 or double_common % 2 != 0:
        return None
    common_age = double_common // 2
    first_age = first_sum - common_age
    second_age = second_sum - common_age
    if min(common_age, first_age, second_age) < 0:
        return None

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {first_a} и {first_b} вместе {first_sum} лет, {second_a} и {second_b} вместе {second_sum} год, {third_a} и {third_b} вместе {third_sum} год.',
        'Что нужно найти: сколько лет каждому.',
        f'1) Сложим первую и вторую суммы: {first_sum} + {second_sum} = {first_sum + second_sum}.',
        f'2) Вычтем третью сумму: {first_sum + second_sum} - {third_sum} = {double_common}. Получили возраст {common_name}, взятый два раза.',
        f'3) Найдём возраст {common_name}: {double_common} : 2 = {common_age}.',
        f'4) Найдём возраст {other_first}: {first_sum} - {common_age} = {first_age}.',
        f'5) Найдём возраст {other_second}: {second_sum} - {common_age} = {second_age}.',
        f'Ответ: {common_name} {common_age} лет, {other_first} {first_age} лет, {other_second} {second_age} лет.'
    )

def _final_20260415ad_try_read_and_remaining(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'прочитал' not in lower or 'осталось' not in lower:
        return None
    if 'на' not in lower or ('меньше' not in lower and 'больше' not in lower):
        return None
    if 'сколько страниц в книге' not in lower and 'сколько страниц' not in lower:
        return None

    read_pages, diff = nums[:2]
    if 'меньше' in lower:
        left = read_pages - diff
        compare_text = 'меньше'
        expr = f'{read_pages} - {diff}'
    else:
        left = read_pages + diff
        compare_text = 'больше'
        expr = f'{read_pages} + {diff}'
    if left < 0:
        return None
    total = read_pages + left

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: мальчик прочитал {read_pages} страниц. До конца книги осталось на {diff} страниц {compare_text}.',
        'Что нужно найти: сколько страниц в книге.',
        f'1) Сначала найдём, сколько страниц осталось прочитать: {expr} = {left}.',
        f'2) Потом найдём, сколько страниц в книге всего: {read_pages} + {left} = {total}.',
        f'Ответ: в книге {total} страниц.'
    )

def _final_20260415ad_try_relation_times_bigger(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'в ' not in lower or 'раза больше' not in lower:
        return None
    if 'чем' not in lower:
        return None
    if not contains_any_fragment(lower, ('сколько километров в час', 'какая скорость', 'с какой скоростью', 'сколько проходит')):
        return None

    bigger_value, times = nums[:2]
    if times <= 0 or bigger_value % times != 0:
        return None
    smaller = bigger_value // times
    unit = 'км/ч' if ('км/ч' in lower or 'километров в час' in lower) else ''

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: одно расстояние или скорость равно {bigger_value} {unit}'.strip() + f'. Это в {times} раза больше, чем другое.',
        'Что нужно найти: меньшее значение.',
        f'1) Если одно значение в {times} раза больше другого, то меньшее значение находим делением.',
        f'2) Считаем: {bigger_value} : {times} = {smaller} {unit}'.rstrip(),
        f'Ответ: {smaller} {unit}'.rstrip() + '.'.replace(' .','.')
    ).replace(' .', '.').replace('..', '.')

def _final_20260415ad_try_rectangle_width_from_perimeter(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 2:
        return None
    if 'периметр прямоугольника' not in lower or 'длина' not in lower:
        return None
    if 'ширин' not in lower:
        return None

    perimeter, length = nums[:2]
    if perimeter % 2 != 0:
        return None
    half = perimeter // 2
    width = half - length
    if width < 0:
        return None
    unit = 'см'
    if 'дм' in lower:
        unit = 'дм'
    elif re.search(r'\bм\b', lower):
        unit = 'м'
    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: периметр прямоугольника {perimeter} {unit}, длина {length} {unit}.',
        'Что нужно найти: ширину прямоугольника.',
        '1) Периметр прямоугольника равен сумме длины и ширины, умноженной на 2: P = 2 × (a + b).',
        f'2) Найдём сумму длины и ширины: {perimeter} : 2 = {half}.',
        f'3) Теперь найдём ширину: {half} - {length} = {width}.',
        f'Ответ: ширина прямоугольника {width} {unit}.'
    )

def _final_20260415ad_parse_simple_linear_equation(eq: str):
    match = re.fullmatch(r'([A-Za-zА-Яа-я])([+\-])([A-Za-zА-Яа-я])=(-?\d+)', eq)
    if not match:
        return None
    left, operator, right, value = match.groups()
    return left, operator, right, int(value)

def _final_20260415ad_try_simple_system(raw_text: str) -> Optional[str]:
    compact = normalize_cyrillic_x(strip_known_prefix(raw_text)).replace(' ', '').replace(';', ',')
    if compact.count('=') != 2 or ',' not in compact:
        return None
    parts = [part for part in compact.split(',') if part]
    if len(parts) != 2:
        return None
    parsed = [_final_20260415ad_parse_simple_linear_equation(part) for part in parts]
    if any(item is None for item in parsed):
        return None

    plus_eq = next((item for item in parsed if item[1] == '+'), None)
    minus_eq = next((item for item in parsed if item[1] == '-'), None)
    if plus_eq is None or minus_eq is None:
        return None

    a1, _, b1, total_sum = plus_eq
    a2, _, b2, diff_value = minus_eq
    if {a1.lower(), b1.lower()} != {a2.lower(), b2.lower()}:
        return None

    if a2.lower() == a1.lower() and b2.lower() == b1.lower():
        x_name, y_name = a1, b1
        x_value = Fraction(total_sum + diff_value, 2)
        y_value = Fraction(total_sum, 1) - x_value
    elif a2.lower() == b1.lower() and b2.lower() == a1.lower():
        y_name, x_name = a2, b2
        y_value = Fraction(total_sum + diff_value, 2)
        x_value = Fraction(total_sum, 1) - y_value
    else:
        return None

    if x_value.denominator != 1 or y_value.denominator != 1:
        return None
    x_int = x_value.numerator
    y_int = y_value.numerator

    return _audit_join_lines(
        'Система уравнений:',
        f'{a1} + {b1} = {total_sum}',
        f'{a2} - {b2} = {diff_value}' if a2.lower() == a1.lower() and b2.lower() == b1.lower() else f'{a2} - {b2} = {diff_value}',
        'Решение.',
        f'1) Сложим правые части и учтём, что в одном уравнении {y_name} прибавляется, а в другом вычитается.',
        f'2) Получаем: 2{x_name} = {total_sum} + {diff_value} = {total_sum + diff_value}.',
        f'3) Находим {x_name}: {total_sum + diff_value} : 2 = {x_int}.',
        f'4) Подставляем {x_name} в первое уравнение: {x_int} + {y_name} = {total_sum}.',
        f'5) Находим {y_name}: {total_sum} - {x_int} = {y_int}.',
        f'Ответ: {x_name} = {x_int}, {y_name} = {y_int}.'
    )

def _final_20260415ad_try_textbook_fixes(raw_text: str) -> Optional[str]:
    return (
        _final_20260415ad_try_garage_indirect_counts(raw_text)
        or _final_20260415ad_try_times_more_and_equal_groups(raw_text)
        or _final_20260415ad_try_each_brought_then_total(raw_text)
        or _final_20260415ad_try_first_day_second_more_remaining(raw_text)
        or _final_20260415ad_try_leftover_then_group_count(raw_text)
        or _final_20260415ad_try_money_part_to_whole(raw_text)
        or _final_20260415ad_try_three_pair_sums(raw_text)
        or _final_20260415ad_try_read_and_remaining(raw_text)
        or _final_20260415ad_try_relation_times_bigger(raw_text)
        or _final_20260415ad_try_rectangle_width_from_perimeter(raw_text)
        or _final_20260415ad_try_simple_system(raw_text)
    )

async def build_explanation(user_text: str) -> dict:
    local = _final_20260415ad_try_textbook_fixes(user_text)
    if local:
        return _final_20260415ad_result_dict(local)
    return await _FINAL_20260415AD_PREV_BUILD_EXPLANATION(user_text)

# --- FINAL PATCH 2026-04-15AE: cleaner textbook wording and answer grammar ---

def _final_20260415ae_plural(number: int, one: str, few: str, many: str) -> str:
    number = abs(int(number))
    mod100 = number % 100
    mod10 = number % 10
    if 11 <= mod100 <= 14:
        return many
    if mod10 == 1:
        return one
    if 2 <= mod10 <= 4:
        return few
    return many

def _final_20260415ad_try_garage_indirect_counts(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'автобус' not in lower or 'грузов' not in lower or 'легков' not in lower:
        return None
    if 'сколько всего' not in lower or 'гараж' not in lower:
        return None
    if 'это на' not in lower or 'больше, чем грузов' not in lower:
        return None
    if 'меньше, чем грузов' not in lower:
        return None

    buses, diff_to_trucks, diff_to_cars = nums[:3]
    trucks = buses - diff_to_trucks
    cars = trucks - diff_to_cars
    if min(buses, trucks, cars) < 0:
        return None
    total = buses + trucks + cars
    machine_word = _final_20260415ae_plural(total, 'машина', 'машины', 'машин')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: автобусов {buses}. Это на {diff_to_trucks} больше, чем грузовых машин. Легковых машин на {diff_to_cars} меньше, чем грузовых.',
        'Что нужно найти: сколько всего машин в гараже.',
        f'1) Сначала найдём количество грузовых машин. Если автобусов на {diff_to_trucks} больше, чем грузовых, то грузовых на {diff_to_trucks} меньше: {buses} - {diff_to_trucks} = {trucks}.',
        f'2) Потом найдём количество легковых машин. Если легковых на {diff_to_cars} меньше, чем грузовых, то {trucks} - {diff_to_cars} = {cars}.',
        f'3) Теперь найдём, сколько всего машин в гараже: {buses} + {trucks} + {cars} = {total}.',
        f'Ответ: всего {total} {machine_word}.'
    )

def _final_20260415ad_try_leftover_then_group_count(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'осталось' not in lower and 'ещё осталось' not in lower and 'еще осталось' not in lower:
        return None
    if 'на кажд' not in lower or 'по' not in lower:
        return None
    if not ('сколько' in lower and contains_any_fragment(lower, ('грядок', 'корзин', 'пакетов', 'ящиков', 'рядов'))):
        return None

    total, per_group, leftover = nums[:3]
    used = total - leftover
    if per_group <= 0 or used < 0 or used % per_group != 0:
        return None
    groups = used // per_group

    group_noun = 'грядок'
    group_phrase = 'на каждую грядку вылили'
    if 'гряд' in lower:
        group_noun = _final_20260415ae_plural(groups, 'грядку', 'грядки', 'грядок')
        group_phrase = 'на каждую грядку вылили'
    elif 'корзин' in lower:
        group_noun = _final_20260415ae_plural(groups, 'корзину', 'корзины', 'корзин')
        group_phrase = 'в каждую корзину положили'
    elif 'ящик' in lower:
        group_noun = _final_20260415ae_plural(groups, 'ящик', 'ящика', 'ящиков')
        group_phrase = 'в каждый ящик положили'
    elif 'пакет' in lower:
        group_noun = _final_20260415ae_plural(groups, 'пакет', 'пакета', 'пакетов')
        group_phrase = 'в каждый пакет положили'
    elif 'ряд' in lower:
        group_noun = _final_20260415ae_plural(groups, 'ряд', 'ряда', 'рядов')
        group_phrase = 'в каждый ряд положили'

    unit_many = 'вёдер' if 'вёдер' in lower or 'ведер' in lower else 'единиц'
    unit_for_per = 'ведра' if 'вёдер' in lower or 'ведер' in lower else unit_many
    if 'литр' in lower:
        unit_many = _final_20260415ae_plural(total, 'литр', 'литра', 'литров')
        unit_for_per = _final_20260415ae_plural(per_group, 'литр', 'литра', 'литров')
    elif 'килограмм' in lower or 'кг' in lower:
        unit_many = _final_20260415ae_plural(total, 'килограмм', 'килограмма', 'килограммов')
        unit_for_per = _final_20260415ae_plural(per_group, 'килограмм', 'килограмма', 'килограммов')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: всего было {total} {unit_many}. {group_phrase} по {per_group} {unit_for_per}. После этого осталось {leftover} {unit_many}.',
        f'Что нужно найти: сколько {group_noun} получилось.',
        f'1) Сначала найдём, сколько {unit_many} израсходовали: {total} - {leftover} = {used}.',
        f'2) Потом найдём число групп: {used} : {per_group} = {groups}.',
        f'Ответ: полили {groups} {group_noun}.' if 'гряд' in lower else f'Ответ: получилось {groups} {group_noun}.'
    )

def _final_20260415ad_try_money_part_to_whole(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if not nums:
        return None
    if 'денег' not in lower and 'руб' not in lower:
        return None
    if 'сколько денег было' not in lower and 'сколько было денег' not in lower and 'сколько денег у' not in lower:
        return None

    multiplier = None
    fraction_label = None
    if 'половин' in lower:
        multiplier = 2
        fraction_label = 'половина'
    elif 'треть' in lower:
        multiplier = 3
        fraction_label = 'треть'
    elif 'четверт' in lower:
        multiplier = 4
        fraction_label = 'четверть'
    if multiplier is None:
        return None
    if not contains_any_fragment(lower, ('заплат', 'израсход', 'потрат', 'покупк')):
        return None

    part_value = nums[-1]
    total = part_value * multiplier

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {part_value} руб. — это {fraction_label} всех денег.',
        'Что нужно найти: сколько денег было сначала.',
        f'1) {part_value} руб. — это {fraction_label} всех денег.',
        f'2) Чтобы найти все деньги, умножаем {part_value} на {multiplier}: {part_value} × {multiplier} = {total} руб.',
        f'Ответ: было {total} руб.'
    )

def _final_20260415ad_try_three_pair_sums(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    pairs = re.findall(r'([а-яё-]+)\s+и\s+([а-яё-]+)\s+вместе\s+(\d+)', lower)
    if len(pairs) != 3:
        return None
    if 'сколько им лет' not in lower and 'сколько лет' not in lower:
        return None

    first_a, first_b, first_sum = pairs[0][0], pairs[0][1], int(pairs[0][2])
    second_a, second_b, second_sum = pairs[1][0], pairs[1][1], int(pairs[1][2])
    third_a, third_b, third_sum = pairs[2][0], pairs[2][1], int(pairs[2][2])

    common = set((first_a, first_b)).intersection((second_a, second_b))
    if len(common) != 1:
        return None
    common_name = list(common)[0]
    other_first = first_b if first_a == common_name else first_a
    other_second = second_b if second_a == common_name else second_a
    if set((other_first, other_second)) != set((third_a, third_b)):
        return None

    double_common = first_sum + second_sum - third_sum
    if double_common < 0 or double_common % 2 != 0:
        return None
    common_age = double_common // 2
    first_age = first_sum - common_age
    second_age = second_sum - common_age
    if min(common_age, first_age, second_age) < 0:
        return None

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {first_a} и {first_b} вместе {first_sum} лет, {second_a} и {second_b} вместе {second_sum} лет, {third_a} и {third_b} вместе {third_sum} лет.',
        'Что нужно найти: сколько лет каждому.',
        f'1) Сложим первую и вторую суммы: {first_sum} + {second_sum} = {first_sum + second_sum}.',
        f'2) Вычтем третью сумму: {first_sum + second_sum} - {third_sum} = {double_common}. Получили возраст {common_name}, взятый два раза.',
        f'3) Найдём возраст {common_name}: {double_common} : 2 = {common_age}.',
        f'4) Найдём возраст {other_first}: {first_sum} - {common_age} = {first_age}.',
        f'5) Найдём возраст {other_second}: {second_sum} - {common_age} = {second_age}.',
        f'Ответ: {common_name} {common_age} {_final_20260415ae_plural(common_age, "год", "года", "лет")}, {other_first} {first_age} {_final_20260415ae_plural(first_age, "год", "года", "лет")}, {other_second} {second_age} {_final_20260415ae_plural(second_age, "год", "года", "лет")}.'
    )

# --- FINAL PATCH 2026-04-15AF: wording cleanup for watering and age-sum tasks ---

def _final_20260415ad_try_leftover_then_group_count(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    if len(nums) < 3:
        return None
    if 'осталось' not in lower and 'ещё осталось' not in lower and 'еще осталось' not in lower:
        return None
    if 'на кажд' not in lower or 'по' not in lower:
        return None
    if not ('сколько' in lower and contains_any_fragment(lower, ('грядок', 'корзин', 'пакетов', 'ящиков', 'рядов'))):
        return None

    total, per_group, leftover = nums[:3]
    used = total - leftover
    if per_group <= 0 or used < 0 or used % per_group != 0:
        return None
    groups = used // per_group

    ask_phrase = 'сколько грядок полили'
    known_phrase = f'На каждую грядку вылили по {per_group} ведра.'
    answer_phrase = f'Ответ: полили {groups} грядок.'
    unit_name = 'ведер'

    if 'корзин' in lower:
        ask_phrase = 'сколько корзин получилось'
        known_phrase = f'В каждую корзину положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} корзин.'
        unit_name = 'единиц'
    elif 'ящик' in lower:
        ask_phrase = 'сколько ящиков получилось'
        known_phrase = f'В каждый ящик положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} ящиков.'
        unit_name = 'единиц'
    elif 'пакет' in lower:
        ask_phrase = 'сколько пакетов получилось'
        known_phrase = f'В каждый пакет положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} пакетов.'
        unit_name = 'единиц'
    elif 'ряд' in lower and 'гряд' not in lower:
        ask_phrase = 'сколько рядов получилось'
        known_phrase = f'В каждый ряд положили по {per_group} единиц.'
        answer_phrase = f'Ответ: получилось {groups} рядов.'
        unit_name = 'единиц'

    if 'вёдер' in lower or 'ведер' in lower:
        unit_name = 'ведер'
    elif 'литр' in lower:
        unit_name = 'литров'
        if 'гряд' in lower:
            known_phrase = f'На каждую грядку вылили по {per_group} литра.'
    elif 'килограмм' in lower or 'кг' in lower:
        unit_name = 'килограммов'

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: всего было {total} {unit_name}. {known_phrase} После этого осталось {leftover} {unit_name}.',
        f'Что нужно найти: {ask_phrase}.',
        f'1) Сначала найдём, сколько {unit_name} израсходовали: {total} - {leftover} = {used}.',
        f'2) Потом найдём число групп: {used} : {per_group} = {groups}.',
        answer_phrase
    )

def _final_20260415ad_try_three_pair_sums(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    pairs = re.findall(r'([а-яё-]+)\s+и\s+([а-яё-]+)\s+вместе\s+(\d+)', lower)
    if len(pairs) != 3:
        return None
    if 'сколько им лет' not in lower and 'сколько лет' not in lower:
        return None

    first_a, first_b, first_sum = pairs[0][0], pairs[0][1], int(pairs[0][2])
    second_a, second_b, second_sum = pairs[1][0], pairs[1][1], int(pairs[1][2])
    third_a, third_b, third_sum = pairs[2][0], pairs[2][1], int(pairs[2][2])

    common = set((first_a, first_b)).intersection((second_a, second_b))
    if len(common) != 1:
        return None
    common_name = list(common)[0]
    other_first = first_b if first_a == common_name else first_a
    other_second = second_b if second_a == common_name else second_a
    if set((other_first, other_second)) != set((third_a, third_b)):
        return None

    double_common = first_sum + second_sum - third_sum
    if double_common < 0 or double_common % 2 != 0:
        return None
    common_age = double_common // 2
    first_age = first_sum - common_age
    second_age = second_sum - common_age
    if min(common_age, first_age, second_age) < 0:
        return None

    first_sum_word = _final_20260415ae_plural(first_sum, 'год', 'года', 'лет')
    second_sum_word = _final_20260415ae_plural(second_sum, 'год', 'года', 'лет')
    third_sum_word = _final_20260415ae_plural(third_sum, 'год', 'года', 'лет')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {first_a} и {first_b} вместе {first_sum} {first_sum_word}, {second_a} и {second_b} вместе {second_sum} {second_sum_word}, {third_a} и {third_b} вместе {third_sum} {third_sum_word}.',
        'Что нужно найти: сколько лет каждому.',
        f'1) Сложим первую и вторую суммы: {first_sum} + {second_sum} = {first_sum + second_sum}.',
        f'2) Вычтем третью сумму: {first_sum + second_sum} - {third_sum} = {double_common}. Это возраст одного и того же человека, взятый два раза.',
        f'3) Этот человек — {common_name}. Находим его возраст: {double_common} : 2 = {common_age}.',
        f'4) Найдём возраст {other_first}: {first_sum} - {common_age} = {first_age}.',
        f'5) Найдём возраст {other_second}: {second_sum} - {common_age} = {second_age}.',
        f'Ответ: {common_name} {common_age} {_final_20260415ae_plural(common_age, "год", "года", "лет")}, {other_first} {first_age} {_final_20260415ae_plural(first_age, "год", "года", "лет")}, {other_second} {second_age} {_final_20260415ae_plural(second_age, "год", "года", "лет")}.'
    )

# --- FINAL PATCH 2026-04-15AG: neutral wording for age-pair sums ---

def _final_20260415ad_try_three_pair_sums(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260415ad_prepare_word_text(raw_text)
    pairs = re.findall(r'([а-яё-]+)\s+и\s+([а-яё-]+)\s+вместе\s+(\d+)', lower)
    if len(pairs) != 3:
        return None
    if 'сколько им лет' not in lower and 'сколько лет' not in lower:
        return None

    first_a, first_b, first_sum = pairs[0][0], pairs[0][1], int(pairs[0][2])
    second_a, second_b, second_sum = pairs[1][0], pairs[1][1], int(pairs[1][2])
    third_a, third_b, third_sum = pairs[2][0], pairs[2][1], int(pairs[2][2])

    common = set((first_a, first_b)).intersection((second_a, second_b))
    if len(common) != 1:
        return None
    common_name = list(common)[0]
    other_first = first_b if first_a == common_name else first_a
    other_second = second_b if second_a == common_name else second_a
    if set((other_first, other_second)) != set((third_a, third_b)):
        return None

    double_common = first_sum + second_sum - third_sum
    if double_common < 0 or double_common % 2 != 0:
        return None
    common_age = double_common // 2
    first_age = first_sum - common_age
    second_age = second_sum - common_age
    if min(common_age, first_age, second_age) < 0:
        return None

    first_sum_word = _final_20260415ae_plural(first_sum, 'год', 'года', 'лет')
    second_sum_word = _final_20260415ae_plural(second_sum, 'год', 'года', 'лет')
    third_sum_word = _final_20260415ae_plural(third_sum, 'год', 'года', 'лет')

    return _audit_join_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: {first_a} и {first_b} вместе {first_sum} {first_sum_word}, {second_a} и {second_b} вместе {second_sum} {second_sum_word}, {third_a} и {third_b} вместе {third_sum} {third_sum_word}.',
        'Что нужно найти: сколько лет каждому.',
        f'1) Сложим первую и вторую суммы: {first_sum} + {second_sum} = {first_sum + second_sum}.',
        f'2) Вычтем третью сумму: {first_sum + second_sum} - {third_sum} = {double_common}. Получили возраст одного человека два раза.',
        f'3) Найдём этот возраст: {double_common} : 2 = {common_age}.',
        f'4) По первой сумме найдём второй возраст: {first_sum} - {common_age} = {first_age}.',
        f'5) По второй сумме найдём третий возраст: {second_sum} - {common_age} = {second_age}.',
        f'Ответ: {common_name} {common_age} {_final_20260415ae_plural(common_age, "год", "года", "лет")}, {other_first} {first_age} {_final_20260415ae_plural(first_age, "год", "года", "лет")}, {other_second} {second_age} {_final_20260415ae_plural(second_age, "год", "года", "лет")}.'
    )

# --- FINAL PATCH 2026-04-16: eliminate remaining textbook audit failures without touching stable flows ---

_FINAL_20260416_PREV_BUILD_EXPLANATION = build_explanation
_FINAL_20260416_PREV_GEOMETRY = try_local_geometry_explanation

def _final_20260416_prepare(raw_text: str):
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    return text, lower, nums

def _final_20260416_result_dict(text: str, source: str = 'local-final-20260416') -> dict:
    return {'result': text, 'source': source, 'validated': True}

def _final_20260416_fraction_word_to_pair(word: str):
    word = (word or '').lower()
    mapping = {
        'половина': (1, 2),
        'треть': (1, 3),
        'четверть': (1, 4),
        'четвёртая часть': (1, 4),
    }
    return mapping.get(word)

def _final_20260416_normalize_fraction_expression_source(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text)
    if not text:
        return None
    text = normalize_dashes(normalize_cyrillic_x(text))
    text = text.replace('×', '*').replace('·', '*').replace('÷', '/').replace(':', '/')
    text = re.sub(r'\s+', '', text)
    if not text or re.search(r'[A-Za-zА-Яа-яЁё]', text):
        return None
    if re.search(r'[^0-9+\-*/()]', text):
        return None
    if not re.search(r'\d+/\d+', text):
        return None
    if re.fullmatch(r'\d+/\d+', text):
        return None

    all_numbers = [int(value) for value in re.findall(r'\d+', text)]
    if not all_numbers:
        return None
    if max(abs(value) for value in all_numbers) > 1000:
        return None

    fraction_matches = list(re.finditer(r'(\d+)/(\d+)', text))
    if not fraction_matches:
        return None

    placeholder = re.sub(r'\d+/\d+', 'F', text)
    if not re.fullmatch(r'[F0-9+\-*/()]+', placeholder):
        return None
    if placeholder == 'F':
        return None

    pairs = [(int(match.group(1)), int(match.group(2))) for match in fraction_matches]
    if any(den == 0 for _, den in pairs):
        return None

    # Одно обычное деление вроде 24/4 в длинном выражении не должно уходить в блок дробей.
    # Для дробных выражений начальной школы оставляем:
    # - хотя бы две дроби;
    # - или одну правильную дробь вроде 1/2 + 3.
    if len(pairs) == 1:
        numerator, denominator = pairs[0]
        if not (0 < numerator < denominator <= 20):
            return None
        start, end = fraction_matches[0].span()
        if '+' not in placeholder and '-' not in placeholder and '*' not in placeholder:
            return None
        if start > 0 and text[start - 1].isdigit():
            return None
        if end < len(text) and text[end:end + 1].isdigit():
            return None
    else:
        if not all(0 < num <= 50 and 0 < den <= 50 for num, den in pairs):
            return None
        if not any(num < den for num, den in pairs):
            return None

    return text

# Переопределяем нормализатор, чтобы обычные выражения с делением не шли в блок дробей.
_final_20260415_normalize_fraction_expression_source = _final_20260416_normalize_fraction_expression_source

def try_local_geometry_explanation(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    unit = geometry_unit(lower)

    square_side_match = re.search(
        r'(?:квадрат[^.?!]{0,60}?со\s+сторон(?:ой|ою|ой\s+)?[^\d]{0,20}(\d+))|(?:сторона\s+квадрата[^\d]{0,20}(\d+))',
        lower,
    )
    square_side_val = int(next(group for group in square_side_match.groups() if group)) if square_side_match else None

    question_parts = [part.strip() for part in re.split(r'[?.!]', lower) if part.strip()]
    question = question_parts[-1] if question_parts else lower
    asks_perimeter = 'периметр' in question or 'найди его периметр' in lower or 'найдите его периметр' in lower
    asks_width = 'найдите ширину' in lower or 'найди ширину' in lower or 'какова ширина' in lower
    asks_length = ('найдите длину' in lower or 'найди длину' in lower or 'какова длина' in lower) and not asks_width

    if 'квадрат' in lower and square_side_val is not None and asks_perimeter:
        result = square_side_val * 4
        return join_explanation_lines(
            'Задача.',
            _audit_task_line(raw_text),
            'Решение.',
            f'Что известно: сторона квадрата равна {square_side_val} {unit}.',
            'Что нужно найти: периметр квадрата.',
            '1) У квадрата все четыре стороны равны.',
            f'2) Периметр квадрата — это сумма четырёх равных сторон: {square_side_val} × 4 = {result}.',
            f'Ответ: {with_unit(result, unit)}.'
        )

    # Формулировки вида «прямоугольной формы» тоже считаем задачами про прямоугольник.
    if 'прямоугольн' in lower and 'площад' in lower and ('длина' in lower or 'ширина' in lower):
        area_val = extract_keyword_number(lower, 'площад')
        length_val = extract_keyword_number(lower, 'длина')
        width_val = extract_keyword_number(lower, 'ширина')
        if asks_width and area_val is not None and length_val is not None and length_val != 0 and area_val % length_val == 0:
            width = area_val // length_val
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, длина {with_unit(length_val, unit)}.',
                'Что нужно найти: ширину прямоугольника.',
                '1) Площадь прямоугольника равна длине, умноженной на ширину.',
                f'2) Чтобы найти ширину, делим площадь на длину: {area_val} : {length_val} = {width}.',
                f'Ответ: {with_unit(width, unit)}.'
            )
        if asks_length and area_val is not None and width_val is not None and width_val != 0 and area_val % width_val == 0:
            length = area_val // width_val
            return join_explanation_lines(
                'Задача.',
                _audit_task_line(raw_text),
                'Решение.',
                f'Что известно: площадь прямоугольника {with_unit(area_val, unit, square=True)}, ширина {with_unit(width_val, unit)}.',
                'Что нужно найти: длину прямоугольника.',
                '1) Площадь прямоугольника равна длине, умноженной на ширину.',
                f'2) Чтобы найти длину, делим площадь на ширину: {area_val} : {width_val} = {length}.',
                f'Ответ: {with_unit(length, unit)}.'
            )

    return _FINAL_20260416_PREV_GEOMETRY(raw_text)

def _final_20260416_try_pickles_two_days(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if len(nums) < 3:
        return None
    if 'в первый день' not in lower or 'во второй день' not in lower:
        return None
    if 'по' not in lower or 'в каждом' not in lower:
        return None
    if 'на' not in lower or 'больше, чем в первый день' not in lower:
        return None
    if not contains_any_fragment(lower, ('сколько кг', 'сколько килограмм', 'сколько огурцов засолили за два дня', 'сколько засолили за два дня')):
        return None
    if not contains_any_fragment(lower, ('огурц', 'бочон', 'ящик', 'банк')):
        return None

    groups, per_group, diff = nums[:3]
    first_day = groups * per_group
    second_day = first_day + diff
    total = first_day + second_day
    if min(groups, per_group, diff, first_day, second_day, total) < 0:
        return None

    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: в первый день засолили {groups} бочонков по {per_group} кг в каждом. Во второй день засолили на {diff} кг больше, чем в первый день.',
        'Что нужно найти: сколько килограммов огурцов засолили за два дня.',
        f'1) Сначала найдём, сколько килограммов засолили в первый день: {groups} × {per_group} = {first_day} кг.',
        f'2) Потом найдём, сколько килограммов засолили во второй день: {first_day} + {diff} = {second_day} кг.',
        f'3) Теперь найдём, сколько килограммов засолили за два дня: {first_day} + {second_day} = {total} кг.',
        f'Ответ: за два дня засолили {total} кг огурцов.'
    )

def _final_20260416_try_motion_compare_two_distances(raw_text: str) -> Optional[str]:
    text, lower, nums = _final_20260416_prepare(raw_text)
    if 'на сколько больше' not in lower and 'на сколько меньше' not in lower:
        return None
    if not ('автобус' in lower and 'пеш' in lower):
        return None
    times = [int(v) for v in re.findall(r'(\d+)\s*(?:ч|час)', lower)]
    speeds = [int(v) for v in re.findall(r'(\d+)\s*км/ч', lower)]
    if len(times) < 2 or len(speeds) < 2:
        return None
    bus_time, walk_time = times[0], times[1]
    bus_speed, walk_speed = speeds[0], speeds[1]
    bus_distance = bus_speed * bus_time
    walk_distance = walk_speed * walk_time
    difference = bus_distance - walk_distance
    if difference < 0:
        return None
    return join_explanation_lines(
        'Задача.',
        _audit_task_line(raw_text),
        'Решение.',
        f'Что известно: на автобусе ехали {bus_time} ч со скоростью {bus_speed} км/ч, пешком шли {walk_time} ч со скоростью {walk_speed} км/ч.',
        'Что нужно найти: на сколько больше путь на автобусе, чем пешком.',
        f'1) Сначала найдём путь на автобусе: {bus_speed} × {bus_time} = {bus_distance} км.',
        f'2) Потом найдём путь пешком: {walk_speed} × {walk_time} = {walk_distance} км.',
        f'3) Теперь сравним пути: {bus_distance} - {walk_distance} = {difference} км.',
        f'Ответ: путь на автобусе больше на {difference} км.'
    )
