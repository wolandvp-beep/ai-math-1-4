"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 11394-11758."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def explain_whole_by_remaining_fraction(remaining_value: int, spent_numerator: int, denominator: int) -> Optional[str]:
    remaining_numerator = denominator - spent_numerator
    if denominator == 0 or remaining_numerator <= 0:
        return None
    if remaining_value % remaining_numerator != 0:
        return None
    one_part = remaining_value // remaining_numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег.",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part}.",
        f"3) Если одна доля равна {one_part}, то все деньги равны {one_part} × {denominator} = {whole}.",
        f"Ответ: всего было {whole}",
        "Совет: если известен остаток после расхода части, сначала находят оставшуюся долю",
    )

def explain_fraction_of_number_word_problem(total: int, numerator: int, denominator: int, ask_remaining: bool = False) -> Optional[str]:
    if denominator == 0 or numerator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    taken = one_part * numerator
    if ask_remaining:
        remaining = total - taken
        return join_explanation_lines(
            f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}.",
            f"3) Если всего было {total}, а использовали {taken}, то осталось {total} - {taken} = {remaining}.",
            f"Ответ: {remaining}",
            "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
        )
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
        f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {taken}.",
        f"Ответ: {taken}",
        "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
    )

def explain_number_by_fraction_word_problem(part_value: int, numerator: int, denominator: int) -> Optional[str]:
    if numerator == 0 or part_value % numerator != 0:
        return None
    one_part = part_value // numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если {numerator}/{denominator} числа равны {part_value}, то сначала найдём одну долю: {part_value} : {numerator} = {one_part}.",
        f"2) Если одна доля равна {one_part}, то всё число равно {one_part} × {denominator} = {whole}.",
        f"Ответ: {whole}",
        "Совет: чтобы найти всё число по его доле, сначала находят одну долю",
    )

def explain_two_fraction_parts_remaining(total: int, first_fraction: Tuple[int, int], second_fraction: Tuple[int, int]) -> Optional[str]:
    n1, d1 = first_fraction
    n2, d2 = second_fraction
    if d1 == 0 or d2 == 0 or total % math.lcm(d1, d2) != 0:
        return None
    first_part = total * n1 // d1
    second_part = total * n2 // d2
    used = first_part + second_part
    remaining = total - used
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то первая часть равна {total} : {d1} × {n1} = {first_part}.",
        f"2) Если всё число равно {total}, то вторая часть равна {total} : {d2} × {n2} = {second_part}.",
        f"3) Если использовали {first_part} и {second_part}, то всего использовали {first_part} + {second_part} = {used}.",
        f"4) Тогда осталось {total} - {used} = {remaining}.",
        f"Ответ: {remaining}",
        "Совет: если от одного и того же целого берут две части, каждую часть находят отдельно",
    )

def explain_second_part_after_fraction(total: int, numerator: int, denominator: int) -> Optional[str]:
    if denominator == 0 or total % denominator != 0:
        return None
    one_part = total // denominator
    first_part = one_part * numerator
    second_part = total - first_part
    return join_explanation_lines(
        f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}.",
        f"2) Если первая часть составляет {numerator}/{denominator}, то первая часть равна {one_part} × {numerator} = {first_part}.",
        f"3) Тогда вторая часть равна {total} - {first_part} = {second_part}.",
        f"Ответ: {second_part}",
        "Совет: чтобы найти другую часть, сначала находят известную часть, потом вычитают её из целого",
    )

def explain_simple_motion_distance(speed: int, time_value: int, unit: str = "") -> str:
    result = speed * time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти расстояние, нужно скорость умножить на время.",
        f"2) Если скорость равна {speed}, а время равно {time_value}, то расстояние равно {speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом S = v × t",
    )

def explain_simple_motion_speed(distance: int, time_value: int, unit: str = "") -> Optional[str]:
    if time_value == 0 or distance % time_value != 0:
        return None
    result = distance // time_value
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти скорость, нужно расстояние разделить на время.",
        f"2) Если расстояние равно {distance}, а время равно {time_value}, то скорость равна {distance} : {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом v = S : t",
    )

def explain_simple_motion_time(distance: int, speed: int, unit: str = "") -> Optional[str]:
    if speed == 0 or distance % speed != 0:
        return None
    result = distance // speed
    answer = f"{result} {unit}".strip() if unit else str(result)
    return join_explanation_lines(
        "1) Чтобы найти время, нужно расстояние разделить на скорость.",
        f"2) Если расстояние равно {distance}, а скорость равна {speed}, то время равно {distance} : {speed} = {answer}.",
        f"Ответ: {answer}",
        "Совет: пользуйся правилом t = S : v",
    )

def explain_meeting_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    closing_speed = v1 + v2
    distance = closing_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2}, то скорость сближения равна {v1} + {v2} = {closing_speed}.",
        f"2) Если скорость сближения равна {closing_speed}, а время равно {time_value}, то расстояние равно {closing_speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: при встречном движении сначала находят скорость сближения",
    )

def explain_opposite_motion(v1: int, v2: int, time_value: int, unit: str = "") -> str:
    removal_speed = v1 + v2
    distance = removal_speed * time_value
    answer = f"{distance} {unit}".strip() if unit else str(distance)
    return join_explanation_lines(
        f"1) Если один участник движется со скоростью {v1}, а другой со скоростью {v2} в противоположных направлениях, то скорость удаления равна {v1} + {v2} = {removal_speed}.",
        f"2) Если скорость удаления равна {removal_speed}, а время равно {time_value}, то расстояние между ними равно {removal_speed} × {time_value} = {answer}.",
        f"Ответ: {answer}",
        "Совет: при движении в противоположных направлениях сначала находят скорость удаления",
    )

def _final_20260412e_together_as_much_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if "столько, сколько" not in lower:
        return None
    if not has_multiple_questions(text):
        return None
    relation_pairs = extract_relation_pairs(lower)
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2 or not relation_pairs:
        return None
    base = nums[0]
    delta, mode = relation_pairs[0]
    second = apply_more_less(base, delta, mode)
    if second is None:
        return None
    third = base + second
    total = base + second + third
    sign = "+" if mode == "больше" else "-"
    third_name = ""
    m = re.search(r"а\s+([а-яё]+)\s+столько,\s+сколько", lower)
    if m:
        third_name = m.group(1)
    all_name = ""
    if "цвет" in lower:
        all_name = "цветов"
    answer_third = f"{third_name} было {third}" if third_name else f"третье количество равно {third}"
    answer_total = f"всего было {total} {all_name}".strip()
    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {sign} {delta} = {second}.",
        f"2) Если третье количество равно первому и второму вместе, то оно равно {base} + {second} = {third}.",
        f"3) Если первое количество равно {base}, второе равно {second}, а третье равно {third}, то всего {base} + {second} + {third} = {total}.",
        f"Ответ: {answer_third}; {answer_total}",
        "Совет: если сказано «столько, сколько вместе», сначала находят сумму этих частей",
    )

_FINAL_20260412E_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_20260412e_together_as_much_explanation(user_text)
        or _FINAL_20260412E_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи.",
            "Запишите пример или задачу полнее и без сокращений.",
            "Ответ: пока нужен более понятный ввод.",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 2400,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- FINAL CONSOLIDATION PATCH 2026-04-12F: broader math guard + tasks with letters ---

MATH_INPUT_HINTS = (
    "сколько", "сколько всего", "сколько стало", "сколько осталось", "на сколько", "во сколько",
    "больше", "меньше", "поровну", "по ", "стоимость", "цена", "количество", "купили",
    "скорость", "расстояние", "время", "площадь", "периметр", "доля", "часть",
    "уравнение", "пример", "выражение", "реши", "найди", "найдите",
)

def looks_like_math_input(text: str) -> bool:
    base = normalize_word_problem_text(text).lower()
    if re.search(r"\d|x|х|[+\-*/=×÷:]", base):
        return True
    if re.search(r"\b[a-z]\b", base) and any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    # допускаем словесные задачи без цифр, если в них есть школьные математические маркеры
    if any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    return False

def _final_letter_task_shelf_more_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"на первой полке\s+([a-z])\s+книг[^.?!]*на\s+([a-z])\s+больше[^.?!]*на второй",
        lower,
    )
    if not match:
        return None
    total_symbol = match.group(1)
    delta_symbol = match.group(2)
    return join_explanation_lines(
        f"1) Если на первой полке {total_symbol} книг и это на {delta_symbol} больше, чем на второй, то на второй полке на {delta_symbol} книг меньше.",
        f"2) Если на первой полке {total_symbol} книг, а на второй на {delta_symbol} книг меньше, то на второй полке {total_symbol} - {delta_symbol} книг.",
        f"Ответ: на второй полке {total_symbol} - {delta_symbol} книг.",
        "Совет: в задаче с буквами действуй так же, как в задаче с числами: сначала переведи косвенную форму в прямую.",
    )

def _final_letter_task_tourist_remaining_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"турист должен пройти\s+([a-z])\s+км[^.?!]*в первый день[^.?!]*прош[её]л\s+([a-z])\s+км[^.?!]*во второй\s+([a-z])\s+км",
        lower,
    )
    if not match:
        return None
    total_symbol, first_symbol, second_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если в первый день турист прошёл {first_symbol} км, а во второй {second_symbol} км, то за два дня он прошёл {first_symbol} + {second_symbol} км.",
        f"2) Если турист должен пройти {total_symbol} км, а уже прошёл {first_symbol} + {second_symbol} км, то ему осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        f"Ответ: туристу осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        "Совет: в буквенной задаче сначала находят уже пройденный путь, потом вычитают его из всего пути.",
    )

def _final_letter_task_trains_passengers_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"прибыл[ао]?|прибыло", lower
    )
    if not match:
        return None
    match = re.search(
        r"на вокзал прибыл[ао]?\s+([a-z])\s+поезд[ао]в?\s+по\s+([a-z])\s+пассажир",
        lower,
    )
    if not match:
        return None
    trains_symbol, passengers_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если на вокзал прибыло {trains_symbol} поездов по {passengers_symbol} пассажиров в каждом, то всего прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        f"Ответ: прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        "Совет: если одно и то же количество повторяется несколько раз, используют умножение.",
    )

def _final_letter_task_garland_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зеленых|гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зелёных",
        lower,
    )
    if not match:
        return None
    groups = [g for g in match.groups() if g]
    if len(groups) != 2:
        return None
    red_symbol, green_symbol = groups
    return join_explanation_lines(
        f"1) Чтобы узнать, во сколько раз зелёных лампочек больше, чем красных, нужно количество зелёных разделить на количество красных.",
        f"2) Значит, нужно вычислить {green_symbol} : {red_symbol}.",
        f"Ответ: в {green_symbol} : {red_symbol} раза.",
        "Совет: вопрос «во сколько раз» решают делением большего количества на меньшее.",
    )

def _final_letter_task_factories_total_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"один завод выпустил\s+([a-z])\s+станков[^.?!]*в\s+([a-z])\s+раз\s+меньше",
        lower,
    )
    if not match:
        return None
    first_symbol, factor_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если один завод выпустил {first_symbol} станков, а второй в {factor_symbol} раз меньше, то второй завод выпустил {first_symbol} : {factor_symbol} станков.",
        f"2) Если первый завод выпустил {first_symbol} станков, а второй {first_symbol} : {factor_symbol} станков, то вместе они выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        f"Ответ: вместе заводы выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        "Совет: если число дано через «в несколько раз меньше», сначала делят, а потом находят сумму.",
    )

def _final_letter_word_problem_explanation(raw_text: str) -> Optional[str]:
    return (
        _final_letter_task_shelf_more_explanation(raw_text)
        or _final_letter_task_tourist_remaining_explanation(raw_text)
        or _final_letter_task_trains_passengers_explanation(raw_text)
        or _final_letter_task_garland_ratio_explanation(raw_text)
        or _final_letter_task_factories_total_explanation(raw_text)
    )

SYSTEM_PROMPT = SYSTEM_PROMPT + "\nЕсли в задаче вместо чисел стоят буквы, решай её теми же школьными методами и давай ответ буквенным выражением."

_FINAL_20260412F_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_letter_word_problem_explanation(user_text)
        or _FINAL_20260412F_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )
