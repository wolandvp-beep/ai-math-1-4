"""Auto-generated runtime shard for prepatch_cascade_source.py, lines 3483-4353."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_cascade_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_patch_labeled_indirect_two_question_total_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "?" not in raw_text:
        return None
    if not (("во втором" in question or "на второй" in question) and ("в двух" in question or "в двух кружках" in question or "всего" in question or "обоих" in question)):
        return None

    base = nums[0]
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)

    if len(relation_pairs) == 1 and "это" in lower:
        delta, relation = relation_pairs[0]
        if relation == "больше":
            second = base - delta
            op = "-"
            relation_text = "на столько же меньше"
        else:
            second = base + delta
            op = "+"
            relation_text = "на столько же больше"
        if second < 0:
            return None
        total = base + second
        answer = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь на {delta} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {delta} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer}",
            f"Ответ: во втором количестве — {second}; всего — {answer}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )

    if len(scale_pairs) == 1 and "это" in lower:
        factor, relation = scale_pairs[0]
        if relation == "больше":
            if factor == 0 or base % factor != 0:
                return None
            second = base // factor
            op = ":"
            relation_text = "во столько же раз меньше"
        else:
            second = base * factor
            op = "×"
            relation_text = "во столько же раз больше"
        total = base + second
        answer = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {factor} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer}",
            f"Ответ: во втором количестве — {second}; всего — {answer}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_patch_same_quantity_price_compare_explanation(user_text)
        or try_patch_named_sum_of_two_products_money_explanation(user_text)
        or try_patch_unknown_minuend_simple_explanation(user_text)
        or try_patch_part_then_compare_explanation(user_text)
        or try_patch_implicit_total_with_relation_explanation(user_text)
        or try_patch_labeled_proportional_division_explanation(user_text)
        or try_patch_labeled_two_differences_bag_counts_explanation(user_text)
        or try_patch_labeled_indirect_two_question_total_explanation(user_text)
        or _PATCH20260411G_PREVIOUS_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL PATCH 2026-04-11H: grammar polishing for named tasks ---

def _patch_after_za_name(name: str) -> str:
    text = re.sub(r"\s+", " ", str(name or "").strip())
    parts = text.split()
    if not parts:
        return text
    mapping = {
        "тетрадей": "тетради",
        "книг": "книги",
        "ручек": "ручки",
        "карандашей": "карандаши",
        "цветов": "цветы",
        "яблок": "яблоки",
        "груш": "груши",
        "роз": "розы",
        "гвоздик": "гвоздики",
        "фломастеров": "фломастеры",
        "альбомов": "альбомы",
        "карандашей": "карандаши",
        "пакетов": "пакеты",
        "наборов": "наборы",
    }
    parts[-1] = mapping.get(parts[-1], parts[-1])
    return " ".join(parts)

def try_patch_named_sum_of_two_products_money_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in lower:
        return None
    if not (contains_any_fragment(lower, ("заплат", "стоим")) or contains_any_fragment(question, ("сколько денег", "сколько заплат", "сколько стоила", "сколько стоит"))):
        return None

    products = _po_product_matches(raw_text)
    if len(products) < 2:
        return None
    if contains_any_fragment(question, ("сколько стоит 1", "сколько стоила 1", "сколько стоила одна", "сколько стоит одна")):
        return None

    first = products[0]
    second = products[1]
    first_total = first["count"] * first["value"]
    second_total = second["count"] * second["value"]
    total = first_total + second_total
    first_name = _patch_after_za_name(first["name"])
    second_name = _patch_after_za_name(second["name"])

    return join_explanation_lines(
        f"1) Если купили {first['count']} {first['name']} по {first['value']} руб., то за {first_name} заплатили {first['count']} × {first['value']} = {first_total} руб",
        f"2) Если купили {second['count']} {second['name']} по {second['value']} руб., то за {second_name} заплатили {second['count']} × {second['value']} = {second_total} руб",
        f"3) Если за {first_name} заплатили {first_total} руб., а за {second_name} {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: за всю покупку заплатили {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
    )

def try_patch_part_then_compare_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "из них" not in lower or "осталь" not in lower:
        return None
    if not ("на сколько" in question or "во сколько" in question):
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None

    total, known = nums[0], nums[1]
    if known > total:
        return None
    other = total - known

    pattern = re.search(r"из\s+них\s+(\d+)\s+([а-яё]+).*?остальн[а-яё]*\s*[—-]?\s*([а-яё]+)", lower)
    known_name = pattern.group(2) if pattern else "известной части"
    other_name = pattern.group(3) if pattern else "другой части"
    q_left, q_right = _patch_pick_compare_names_from_question(raw_text)
    if q_left:
        known_name = q_left
    if q_right:
        other_name = q_right

    if "во сколько" in question:
        bigger = max(known, other)
        smaller = min(known, other)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        return join_explanation_lines(
            f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
        )

    bigger = max(known, other)
    smaller = min(known, other)
    diff = bigger - smaller
    if known >= other:
        answer_line = f"Ответ: {known_name} на {diff} больше, чем {other_name}"
    else:
        answer_line = f"Ответ: {other_name} на {diff} больше, чем {known_name}"
    return join_explanation_lines(
        f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
        f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
        answer_line,
        "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
    )

def try_patch_labeled_indirect_two_question_total_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "?" not in raw_text:
        return None
    if not (("во втором" in question or "на второй" in question) and ("в двух" in question or "в двух кружках" in question or "всего" in question or "обоих" in question)):
        return None

    base = nums[0]
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    has_indirect_marker = ("это" in lower) or ("что" in lower)
    if not has_indirect_marker:
        return None

    second_label = "во втором кружке" if "кружке" in question else "во втором"
    if "полке" in question:
        second_label = "на второй полке"
    total_label = "всего"
    answer_total = ""

    if len(relation_pairs) == 1:
        delta, relation = relation_pairs[0]
        if relation == "больше":
            second = base - delta
            op = "-"
            relation_text = "на столько же меньше"
        else:
            second = base + delta
            op = "+"
            relation_text = "на столько же больше"
        if second < 0:
            return None
        total = base + second
        answer_total = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь на {delta} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {delta} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer_total}",
            f"Ответ: {second_label} — {second}; {total_label} — {answer_total}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )

    if len(scale_pairs) == 1:
        factor, relation = scale_pairs[0]
        if relation == "больше":
            if factor == 0 or base % factor != 0:
                return None
            second = base // factor
            op = ":"
            relation_text = "во столько же раз меньше"
        else:
            second = base * factor
            op = "×"
            relation_text = "во столько же раз больше"
        total = base + second
        answer_total = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {factor} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer_total}",
            f"Ответ: {second_label} — {second}; {total_label} — {answer_total}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )
    return None

# --- FINAL PATCH 2026-04-11I: question compare noun extraction fix ---

# --- FINAL PATCH 2026-04-11J: two-question relation-and-compare tasks ---

def _patch_secondary_place_label(raw_text: str) -> str:
    lower = _statement_lower_text(raw_text)
    for pattern in [r"во\s+второй\s+[а-яё]+", r"во\s+втором\s+[а-яё]+", r"на\s+второй\s+[а-яё]+", r"на\s+втором\s+[а-яё]+"]:
        match = re.search(pattern, lower)
        if match:
            return match.group(0)
    return "во второй части"

def try_patch_relation_then_compare_two_question_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    if raw_text.count("?") < 2:
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    base = nums[0]
    second_label = _patch_secondary_place_label(raw_text)

    if len(relation_pairs) == 1:
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        diff = bigger - smaller
        op = "+" if mode == "больше" else "-"
        if mode == "больше":
            compare_line = f"Ответ: {second_label} было {related}; в первом месте было на {diff} больше"
        else:
            compare_line = f"Ответ: {second_label} было {related}; в первом месте было на {diff} больше"
        return join_explanation_lines(
            f"1) Если во втором месте на {delta} {mode}, то {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            compare_line,
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )

    if len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если во втором месте в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: {second_label} было {related}; отличие — в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_patch_same_quantity_price_compare_explanation(user_text)
        or try_patch_named_sum_of_two_products_money_explanation(user_text)
        or try_patch_unknown_minuend_simple_explanation(user_text)
        or try_patch_relation_then_compare_two_question_explanation(user_text)
        or try_patch_part_then_compare_explanation(user_text)
        or try_patch_implicit_total_with_relation_explanation(user_text)
        or try_patch_labeled_proportional_division_explanation(user_text)
        or try_patch_labeled_two_differences_bag_counts_explanation(user_text)
        or try_patch_labeled_indirect_two_question_total_explanation(user_text)
        or _PATCH20260411G_PREVIOUS_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL PATCH 2026-04-11K: support mixed-question punctuation in two-question tasks ---

def try_patch_relation_then_compare_two_question_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    has_find_second = bool(re.search(r"сколько[^?.!]*?(?:во\s+второй|во\s+втором|на\s+второй|на\s+втором)", lower))
    has_compare = ("на сколько" in lower) or ("во сколько" in lower)
    if not (has_find_second and has_compare):
        return None

    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    base = nums[0]
    second_label = _patch_secondary_place_label(raw_text)
    first_label = second_label.replace("второй", "первой").replace("втором", "первом")

    if len(relation_pairs) == 1:
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        diff = bigger - smaller
        op = "+" if mode == "больше" else "-"
        relation_text = "больше" if base >= related else "меньше"
        return join_explanation_lines(
            f"1) Если {second_label} на {delta} {mode}, то {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            f"Ответ: {second_label} было {related}; {first_label} было на {diff} {relation_text}",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )

    if len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если {second_label} в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, то {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: {second_label} было {related}; отличие — в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_patch_same_quantity_price_compare_explanation(user_text)
        or try_patch_named_sum_of_two_products_money_explanation(user_text)
        or try_patch_unknown_minuend_simple_explanation(user_text)
        or try_patch_relation_then_compare_two_question_explanation(user_text)
        or try_patch_part_then_compare_explanation(user_text)
        or try_patch_implicit_total_with_relation_explanation(user_text)
        or try_patch_labeled_proportional_division_explanation(user_text)
        or try_patch_labeled_two_differences_bag_counts_explanation(user_text)
        or try_patch_labeled_indirect_two_question_total_explanation(user_text)
        or _PATCH20260411G_PREVIOUS_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL PATCH 2026-04-11L: better place labels for two-question tasks ---

def _patch_secondary_place_label(raw_text: str) -> str:
    normalized = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    match = re.search(r"сколько[^?.!]*?(во\s+второй\s+[а-яё]+|во\s+втором\s+[а-яё]+|на\s+второй\s+[а-яё]+|на\s+втором\s+[а-яё]+)", normalized)
    if match:
        return match.group(1)
    for label in ("во второй вазе", "на второй полке", "во втором кружке", "во второй день", "на второй стоянке"):
        if label in normalized:
            return label
    return "во второй части"

def _patch_first_place_label(second_label: str) -> str:
    text = str(second_label or "").strip()
    text = text.replace("во второй", "в первой")
    text = text.replace("во втором", "в первом")
    text = text.replace("на второй", "на первой")
    text = text.replace("на втором", "на первом")
    return text

def try_patch_relation_then_compare_two_question_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    has_find_second = bool(re.search(r"сколько[^?.!]*?(?:во\s+второй|во\s+втором|на\s+второй|на\s+втором)", lower))
    has_compare = ("на сколько" in lower) or ("во сколько" in lower)
    if not (has_find_second and has_compare):
        return None

    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    base = nums[0]
    second_label = _patch_secondary_place_label(raw_text)
    first_label = _patch_first_place_label(second_label)

    if len(relation_pairs) == 1:
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        diff = bigger - smaller
        op = "+" if mode == "больше" else "-"
        return join_explanation_lines(
            f"1) Если {second_label} на {delta} {mode}, чем {first_label}, то {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            f"Ответ: {second_label} было {related}; {first_label} было на {diff} больше",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )

    if len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если {second_label} в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, чем {first_label}, то {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: {second_label} было {related}; отличие — в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )
    return None

# --- FINAL PATCH 2026-04-11M: safer count answers, missing simple templates, cleaner fraction remainder ---

_PREVIOUS_20260411M_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first
_PREVIOUS_20260411M_DETECT_QUESTION_UNIT = _detect_question_unit

def _question_requests_object_count(raw_text: str) -> bool:
    return _external_question_requests_object_count(raw_text, _question_lower_text, MEASURE_QUESTION_NOUNS)

def _detect_question_unit(raw_text: str) -> str:
    return _external_initial_detect_question_unit(raw_text, _question_requests_object_count, _PREVIOUS_20260411M_DETECT_QUESTION_UNIT)

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    return _external_initial_detailed_maybe_enrich_answer(
        answer,
        raw_text,
        _detect_question_unit,
        _extract_question_noun,
        _question_requests_object_count,
    )

    if remaining_numerator == 1:
        whole = remaining_value * denominator
        return join_explanation_lines(
            f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось 1/{denominator} всех денег",
            f"2) Если 1/{denominator} всех денег равна {remaining_value} руб., то одна доля равна {remaining_value} руб.",
            f"3) Если одна доля равна {remaining_value} руб., то все деньги равны {remaining_value} × {denominator} = {whole} руб.",
            f"Ответ: всего было {whole} руб.",
            "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
        )
    if remaining_value % remaining_numerator != 0:
        return None
    one_part = remaining_value // remaining_numerator
    whole = one_part * denominator
    return join_explanation_lines(
        f"1) Если израсходовали {spent_numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
        f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_value} руб., то одна доля равна {remaining_value} : {remaining_numerator} = {one_part} руб.",
        f"3) Если одна доля равна {one_part} руб., то все деньги равны {one_part} × {denominator} = {whole} руб.",
        f"Ответ: всего было {whole} руб.",
        "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
    )

def try_patch_single_group_total_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    if "сколько" not in question:
        return None
    if _has_group_count_question(question) or "кажд" in question or "поровну" in lower:
        return None
    if not re.search(r"\b(?:в\s+одной|в\s+одном|на\s+одной|на\s+одном)\b", lower):
        return None
    if not re.search(r"\b(?:в|на)\s+\d+\s+[а-яё]+", question):
        return None

    per_group, groups = nums[0], nums[1]
    total = per_group * groups
    return join_explanation_lines(
        f"1) Если в одной группе {per_group} предметов, а таких групп {groups}, то всего {per_group} × {groups} = {total}",
        f"Ответ: {total}",
        "Совет: если одинаковое количество повторяется несколько раз, используют умножение",
    )

def try_patch_unknown_multiplier_by_content_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    if "сколько" not in question:
        return None
    if not contains_any_fragment(question, ("сеток", "пакетов", "коробок", "клеток", "корзин", "групп", "потребовалось", "понадобилось", "понадобится")):
        return None
    po_match = re.search(r"по\s+(\d+)\s+[а-яё]+", lower)
    if not po_match:
        return None

    total = max(nums)
    per_group = int(po_match.group(1))
    if per_group == 0 or total % per_group != 0:
        return None
    groups = total // per_group
    return join_explanation_lines(
        f"1) Если по {per_group} предметов брали несколько раз и получили {total} предметов, то число групп равно {total} : {per_group} = {groups}",
        f"Ответ: {groups}",
        "Совет: чтобы найти неизвестный множитель, произведение делят на известный множитель",
    )

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_patch_unknown_multiplier_by_content_explanation(user_text)
        or try_patch_single_group_total_explanation(user_text)
        or _PREVIOUS_20260411M_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

# --- FINAL PATCH 2026-04-11N: better noun extraction in count questions ---

def _extract_count_question_noun(raw_text: str) -> str:
    question = _question_lower_text(raw_text)
    patterns = [
        r"^сколько\s+(?:было\s+|будет\s+|стало\s+|осталось\s+|получилось\s+|потребуется\s+|потребовалось\s+|понадобится\s+|понадобилось\s+|можно\s+купить\s+)?(?:таких\s+|этих\s+|эти\s+)?([а-яё]+)",
        r"^сколько\s+(?:таких\s+|этих\s+|эти\s+)?([а-яё]+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, question)
        if match:
            noun = match.group(1).strip().lower().replace("ё", "е")
            if noun:
                return noun
    return ""

def _question_requests_object_count(raw_text: str) -> bool:
    noun = _extract_count_question_noun(raw_text)
    return bool(noun) and noun not in MEASURE_QUESTION_NOUNS

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value

    is_numeric = re.fullmatch(r"-?\d+(?:/\d+)?", value) is not None
    if not is_numeric:
        return value

    noun = _extract_count_question_noun(raw_text)
    if noun and noun not in MEASURE_QUESTION_NOUNS:
        forms = _lookup_question_noun_forms(noun)
        if forms:
            try:
                count_value = int(value.split("/", 1)[0])
            except Exception:
                return value
            return f"{value} {_select_plural_by_count(count_value, forms)}"
        return value

    unit = _detect_question_unit(raw_text)
    if unit:
        return f"{value} {unit}".strip()
    return value

# --- USER CONSOLIDATION PATCH 2026-04-11Z: cleaner final answers, textbook priority cases, stronger prompt ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже обязательно:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. Если можно, используй школьную форму:
Если ..., то ...
6. Если сразу нельзя ответить на главный вопрос, сначала найди то, что нужно для ответа.
7. После каждого действия коротко говори, что нашли.
8. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

_USER_PATCH_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first
_USER_PATCH_PREV_DETAILED_MAYBE_ENRICH_ANSWER = _detailed_maybe_enrich_answer

def _user_patch_pick_measure_unit(raw_text: str) -> str:
    try:
        question = _question_lower_text(raw_text)
    except Exception:
        question = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    statement = _statement_lower_text(raw_text)

    existing = ""
    try:
        existing = _detect_question_unit(raw_text) or ""
    except Exception:
        existing = ""
    if existing:
        return existing

    if contains_any_fragment(question, ("сколько весит", "какова масса", "чему равна масса")):
        for unit in ("т", "кг", "г"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    if contains_any_fragment(question, ("сколько литров", "сколько л", "каков объем", "каков объём", "чему равен объем", "чему равен объём")):
        for unit in ("л", "мл"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    if contains_any_fragment(question, ("какова скорость", "с какой скоростью")):
        for unit in ("км/ч", "м/с", "м/мин"):
            if unit in statement:
                return unit

    if contains_any_fragment(question, ("каково расстояние", "сколько километров", "сколько метров", "какова длина", "какова ширина", "какова сторона")):
        for unit in ("км", "м", "дм", "см", "мм"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    return ""

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value

    if re.search(r"[;]|, остаток", value):
        return value

    if re.fullmatch(r"-?\d+(?:/\d+)?", value) is None:
        return value

    unit = _user_patch_pick_measure_unit(raw_text)
    if unit:
        return f"{value} {unit}".strip()

    try:
        patched = _patch_answer_with_question_noun(int(value.split("/", 1)[0]) if "/" not in value else value, raw_text)
        patched = str(patched).strip()
        if patched and patched != value:
            return patched
    except Exception:
        pass

    try:
        return _USER_PATCH_PREV_DETAILED_MAYBE_ENRICH_ANSWER(answer, raw_text, kind)
    except Exception:
        return value

def explain_equal_rate_distribution(total: int, first_count: int, second_count: int, first_label: str = "первая группа", second_label: str = "вторая группа") -> Optional[str]:
    group_total = first_count + second_count
    if group_total == 0 or total % group_total != 0:
        return None
    one_unit = total // group_total
    first_total = first_count * one_unit
    second_total = second_count * one_unit
    return join_explanation_lines(
        f"1) Если в первой части {first_count} равных долей, а во второй {second_count} равных долей, то всего долей {first_count} + {second_count} = {group_total}",
        f"2) Если всего долей {group_total}, а общее количество равно {total}, то одна доля равна {total} : {group_total} = {one_unit}",
        f"3) Если одна доля равна {one_unit}, то {first_label} равна {one_unit} × {first_count} = {first_total}",
        f"4) Если одна доля равна {one_unit}, то {second_label} равна {one_unit} × {second_count} = {second_total}",
        f"Ответ: {first_label} — {first_total}; {second_label} — {second_total}",
        "Совет: в задачах на пропорциональное деление сначала находят одну равную часть",
    )

def try_user_patch_fraction_measure_explanation(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower()
    fracs = extract_all_fraction_pairs(lower)
    values = extract_non_fraction_numbers(lower)
    if len(fracs) != 1 or not values:
        return None

    question = _question_lower_text(raw_text)
    if not contains_any_fragment(question, ("сколько весит", "сколько кг", "сколько г", "сколько литров", "сколько л")):
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None
    total = max(values)
    unit = _user_patch_pick_measure_unit(raw_text)

    if total % denominator != 0:
        return None

    one_part = total // denominator
    part_value = one_part * numerator

    if numerator == 1:
        return join_explanation_lines(
            f"1) Если целое равно {total}{(' ' + unit) if unit else ''}, то одна доля равна {total} : {denominator} = {one_part}{(' ' + unit) if unit else ''}",
            f"Ответ: {part_value}{(' ' + unit) if unit else ''}",
            "Совет: чтобы найти одну долю числа, делят число на знаменатель",
        )

    return join_explanation_lines(
        f"1) Если целое равно {total}{(' ' + unit) if unit else ''}, то одна доля равна {total} : {denominator} = {one_part}{(' ' + unit) if unit else ''}",
        f"2) Если нужна дробь {numerator}/{denominator}, то берём {numerator} такие доли: {one_part} × {numerator} = {part_value}{(' ' + unit) if unit else ''}",
        f"Ответ: {part_value}{(' ' + unit) if unit else ''}",
        "Совет: чтобы найти долю от числа, сначала делят на знаменатель, потом умножают на числитель",
    )
