"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 4332-5200."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_patch_part_then_compare_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "из них" not in lower or "осталь" not in lower:
        return None
    if not ("на сколько" in question or "во сколько" in question):
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None

    total, known = nums[0], nums[1]
    if known > total:
        return None
    other = total - known

    pattern = re.search(r"из\s+них\s+(\d+)\s+([а-яё]+).*?остальн[а-яё]*\s*[—-]?\s*([а-яё]+)", lower)
    known_name = pattern.group(2) if pattern else "известной части"
    other_name = pattern.group(3) if pattern else "другой части"
    q_left, q_right = _patch_pick_compare_names_from_question(raw_text)
    if q_left:
        known_name = q_left
    if q_right:
        other_name = q_right

    if "во сколько" in question:
        bigger = max(known, other)
        smaller = min(known, other)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        return join_explanation_lines(
            f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
        )

    bigger = max(known, other)
    smaller = min(known, other)
    diff = bigger - smaller
    if known >= other:
        answer_line = f"Ответ: {known_name} на {diff} больше, чем {other_name}"
    else:
        answer_line = f"Ответ: {other_name} на {diff} больше, чем {known_name}"
    return join_explanation_lines(
        f"1) Если всего было {total}, а {known_name} было {known}, то {other_name} было {total} - {known} = {other}",
        f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
        answer_line,
        "Совет: если сначала нужно найти неизвестную часть, а потом сравнить, выполняй действия по порядку",
    )

def try_patch_labeled_indirect_two_question_total_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "?" not in raw_text:
        return None
    if not (("во втором" in question or "на второй" in question) and ("в двух" in question or "в двух кружках" in question or "всего" in question or "обоих" in question)):
        return None

    base = nums[0]
    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    has_indirect_marker = ("это" in lower) or ("что" in lower)
    if not has_indirect_marker:
        return None

    second_label = "во втором кружке" if "кружке" in question else "во втором"
    if "полке" in question:
        second_label = "на второй полке"
    total_label = "всего"
    answer_total = ""

    if len(relation_pairs) == 1:
        delta, relation = relation_pairs[0]
        if relation == "больше":
            second = base - delta
            op = "-"
            relation_text = "на столько же меньше"
        else:
            second = base + delta
            op = "+"
            relation_text = "на столько же больше"
        if second < 0:
            return None
        total = base + second
        answer_total = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь на {delta} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {delta} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer_total}",
            f"Ответ: {second_label} — {second}; {total_label} — {answer_total}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )

    if len(scale_pairs) == 1:
        factor, relation = scale_pairs[0]
        if relation == "больше":
            if factor == 0 or base % factor != 0:
                return None
            second = base // factor
            op = ":"
            relation_text = "во столько же раз меньше"
        else:
            second = base * factor
            op = "×"
            relation_text = "во столько же раз больше"
        total = base + second
        answer_total = _patch_answer_with_question_noun(total, raw_text)
        return join_explanation_lines(
            f"1) Это косвенная форма: если здесь в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {relation}, то другое число {relation_text}",
            f"2) Находим второе количество: {base} {op} {factor} = {second}",
            f"3) Находим всё вместе: {base} + {second} = {answer_total}",
            f"Ответ: {second_label} — {second}; {total_label} — {answer_total}",
            "Совет: в косвенной задаче сначала переведи условие в прямую форму",
        )
    return None

# --- FINAL PATCH 2026-04-11I: question compare noun extraction fix ---

# --- FINAL PATCH 2026-04-11J: two-question relation-and-compare tasks ---





# --- FINAL PATCH 2026-04-11K: support mixed-question punctuation in two-question tasks ---



# --- FINAL PATCH 2026-04-11L: better place labels for two-question tasks ---

def _patch_secondary_place_label(raw_text: str) -> str:
    normalized = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    match = re.search(r"сколько[^?.!]*?(во\s+второй\s+[а-яё]+|во\s+втором\s+[а-яё]+|на\s+второй\s+[а-яё]+|на\s+втором\s+[а-яё]+)", normalized)
    if match:
        return match.group(1)
    for label in ("во второй вазе", "на второй полке", "во втором кружке", "во второй день", "на второй стоянке"):
        if label in normalized:
            return label
    return "во второй части"

def _patch_first_place_label(second_label: str) -> str:
    text = str(second_label or "").strip()
    text = text.replace("во второй", "в первой")
    text = text.replace("во втором", "в первом")
    text = text.replace("на второй", "на первой")
    text = text.replace("на втором", "на первом")
    return text

def try_patch_relation_then_compare_two_question_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    has_find_second = bool(re.search(r"сколько[^?.!]*?(?:во\s+второй|во\s+втором|на\s+второй|на\s+втором)", lower))
    has_compare = ("на сколько" in lower) or ("во сколько" in lower)
    if not (has_find_second and has_compare):
        return None

    relation_pairs = extract_relation_pairs(lower)
    scale_pairs = extract_scale_pairs(lower)
    base = nums[0]
    second_label = _patch_secondary_place_label(raw_text)
    first_label = _patch_first_place_label(second_label)

    if len(relation_pairs) == 1:
        delta, mode = relation_pairs[0]
        related = apply_more_less(base, delta, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        diff = bigger - smaller
        op = "+" if mode == "больше" else "-"
        return join_explanation_lines(
            f"1) Если {second_label} на {delta} {mode}, чем {first_label}, то {base} {op} {delta} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то разность равна {bigger} - {smaller} = {diff}",
            f"Ответ: {second_label} было {related}; {first_label} было на {diff} больше",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )

    if len(scale_pairs) == 1:
        factor, mode = scale_pairs[0]
        related = apply_times_relation(base, factor, mode)
        if related is None:
            return None
        bigger = max(base, related)
        smaller = min(base, related)
        if smaller == 0 or bigger % smaller != 0:
            return None
        result = bigger // smaller
        op = "×" if mode == "больше" else ":"
        return join_explanation_lines(
            f"1) Если {second_label} в {factor} {plural_form(factor, 'раз', 'раза', 'раз')} {mode}, чем {first_label}, то {base} {op} {factor} = {related}",
            f"2) Если одно количество равно {bigger}, а другое равно {smaller}, то {bigger} : {smaller} = {result}",
            f"Ответ: {second_label} было {related}; отличие — в {result} {plural_form(result, 'раз', 'раза', 'раз')}",
            "Совет: если после нахождения второго числа нужно ещё сравнить числа, выполняй действия по порядку",
        )
    return None

# --- FINAL PATCH 2026-04-11M: safer count answers, missing simple templates, cleaner fraction remainder ---






def try_patch_single_group_total_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    if "сколько" not in question:
        return None
    if _has_group_count_question(question) or "кажд" in question or "поровну" in lower:
        return None
    if not re.search(r"\b(?:в\s+одной|в\s+одном|на\s+одной|на\s+одном)\b", lower):
        return None
    if not re.search(r"\b(?:в|на)\s+\d+\s+[а-яё]+", question):
        return None

    per_group, groups = nums[0], nums[1]
    total = per_group * groups
    return join_explanation_lines(
        f"1) Если в одной группе {per_group} предметов, а таких групп {groups}, то всего {per_group} × {groups} = {total}",
        f"Ответ: {total}",
        "Совет: если одинаковое количество повторяется несколько раз, используют умножение",
    )

def try_patch_unknown_multiplier_by_content_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2:
        return None
    if "сколько" not in question:
        return None
    if not contains_any_fragment(question, ("сеток", "пакетов", "коробок", "клеток", "корзин", "групп", "потребовалось", "понадобилось", "понадобится")):
        return None
    po_match = re.search(r"по\s+(\d+)\s+[а-яё]+", lower)
    if not po_match:
        return None

    total = max(nums)
    per_group = int(po_match.group(1))
    if per_group == 0 or total % per_group != 0:
        return None
    groups = total // per_group
    return join_explanation_lines(
        f"1) Если по {per_group} предметов брали несколько раз и получили {total} предметов, то число групп равно {total} : {per_group} = {groups}",
        f"Ответ: {groups}",
        "Совет: чтобы найти неизвестный множитель, произведение делят на известный множитель",
    )



# --- FINAL PATCH 2026-04-11N: better noun extraction in count questions ---





# --- USER CONSOLIDATION PATCH 2026-04-11Z: cleaner final answers, textbook priority cases, stronger prompt ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже обязательно:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. Если можно, используй школьную форму:
Если ..., то ...
6. Если сразу нельзя ответить на главный вопрос, сначала найди то, что нужно для ответа.
7. После каждого действия коротко говори, что нашли.
8. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Для деления столбиком называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()


def _user_patch_pick_measure_unit(raw_text: str) -> str:
    try:
        question = _question_lower_text(raw_text)
    except Exception:
        question = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    statement = _statement_lower_text(raw_text)

    existing = ""
    try:
        existing = _detect_question_unit(raw_text) or ""
    except Exception:
        existing = ""
    if existing:
        return existing

    if contains_any_fragment(question, ("сколько весит", "какова масса", "чему равна масса")):
        for unit in ("т", "кг", "г"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    if contains_any_fragment(question, ("сколько литров", "сколько л", "каков объем", "каков объём", "чему равен объем", "чему равен объём")):
        for unit in ("л", "мл"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    if contains_any_fragment(question, ("какова скорость", "с какой скоростью")):
        for unit in ("км/ч", "м/с", "м/мин"):
            if unit in statement:
                return unit

    if contains_any_fragment(question, ("каково расстояние", "сколько километров", "сколько метров", "какова длина", "какова ширина", "какова сторона")):
        for unit in ("км", "м", "дм", "см", "мм"):
            if re.search(rf"(?<!/)\b{re.escape(unit)}\b", statement):
                return unit

    return ""




def try_user_patch_fraction_measure_explanation(raw_text: str) -> Optional[str]:
    text = replace_common_fraction_words(normalize_word_problem_text(raw_text))
    lower = text.lower()
    fracs = extract_all_fraction_pairs(lower)
    values = extract_non_fraction_numbers(lower)
    if len(fracs) != 1 or not values:
        return None

    question = _question_lower_text(raw_text)
    if not contains_any_fragment(question, ("сколько весит", "сколько кг", "сколько г", "сколько литров", "сколько л")):
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None
    total = max(values)
    unit = _user_patch_pick_measure_unit(raw_text)

    if total % denominator != 0:
        return None

    one_part = total // denominator
    part_value = one_part * numerator

    if numerator == 1:
        return join_explanation_lines(
            f"1) Если целое равно {total}{(' ' + unit) if unit else ''}, то одна доля равна {total} : {denominator} = {one_part}{(' ' + unit) if unit else ''}",
            f"Ответ: {part_value}{(' ' + unit) if unit else ''}",
            "Совет: чтобы найти одну долю числа, делят число на знаменатель",
        )

    return join_explanation_lines(
        f"1) Если целое равно {total}{(' ' + unit) if unit else ''}, то одна доля равна {total} : {denominator} = {one_part}{(' ' + unit) if unit else ''}",
        f"2) Если нужна дробь {numerator}/{denominator}, то берём {numerator} такие доли: {one_part} × {numerator} = {part_value}{(' ' + unit) if unit else ''}",
        f"Ответ: {part_value}{(' ' + unit) if unit else ''}",
        "Совет: чтобы найти долю от числа, сначала делят на знаменатель, потом умножают на числитель",
    )




# --- USER HOTFIX 2026-04-11Z1: narrow grouped-plus-change rule ---

def _user_patch_group_word(value: int) -> str:
    return plural_form(value, "одинаковая группа", "одинаковые группы", "одинаковых групп")



# --- USER HOTFIX 2026-04-11Z2: do not steal "total then packed" remainder tasks ---


# --- USER HOTFIX 2026-04-11Z3: broader question patterns for "стало/осталось" ---


# --- USER HOTFIX 2026-04-11Z4: word-boundary question detection and better remainder handling ---


# --- USER HOTFIX 2026-04-11Z5: correct group phrase agreement ---

def _user_patch_group_phrase(count: int) -> str:
    value = abs(int(count)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return f"{count} одинаковых групп"
    if tail == 1:
        return f"{count} одинаковая группа"
    if 2 <= tail <= 4:
        return f"{count} одинаковые группы"
    return f"{count} одинаковых групп"

def try_user_patch_groups_then_change_explanation(raw_text: str) -> Optional[str]:
    lower = _statement_lower_text(raw_text)
    question = _question_lower_text(raw_text)
    if "сколько" not in question or "по" not in lower:
        return None

    po_matches = list(re.finditer(r"\bпо\s+\d+\b", lower))
    if len(po_matches) != 1:
        return None

    pair = None
    try:
        pair = _first_po_pair(lower)
    except Exception:
        pair = None
    if not pair:
        return None

    groups, per_group = pair
    nums = extract_ordered_numbers(lower)
    remaining = list(nums)
    for value in (groups, per_group):
        if value in remaining:
            remaining.remove(value)
    if len(remaining) != 1:
        return None

    other_value = remaining[0]
    group_value = groups * per_group

    gain_words = WORD_GAIN_HINTS + ("подарили", "добавили", "поставили", "вошло", "приехало")
    loss_words = WORD_LOSS_HINTS + ("уехали", "вышли", "забрали", "сняли", "продали", "расфасовали", "упаковали")

    asks_gain_total = bool(re.search(r"\bстало\b|\bвсего\b|\bтеперь\b", question))
    asks_loss_total = "остал" in question

    group_phrase = _user_patch_group_phrase(groups)

    if contains_any_fragment(lower, gain_words) and asks_gain_total:
        result = group_value + other_value
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} в каждой, то сначала находим, сколько было всего: {groups} × {per_group} = {group_value}",
            f"2) Если было {group_value}, а потом добавили ещё {other_value}, то стало {group_value} + {other_value} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если сначала есть одинаковые группы, а потом что-то прибавляют, сначала выполняют умножение",
        )

    if contains_any_fragment(lower, loss_words) and asks_loss_total:
        total_before = max(group_value, other_value)
        removed_amount = min(group_value, other_value)
        result = total_before - removed_amount
        if result < 0:
            return None
        answer_text = _detailed_maybe_enrich_answer(str(result), raw_text, "word")
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} в каждой, то сначала находим величину этой части: {groups} × {per_group} = {group_value}",
            f"2) Если всего было {total_before}, а эта часть равна {removed_amount}, то осталось {total_before} - {removed_amount} = {result}",
            f"Ответ: {answer_text}",
            "Совет: если известны всё число и одна часть, другую часть находят вычитанием",
        )

    return None

# --- FINAL CONSOLIDATION PATCH 2026-04-11Z6: safer units, compound word numbers, fuller textbook cases ---

_FINAL_PATCH_PREV_NORMALIZE_WORD_PROBLEM_TEXT = normalize_word_problem_text

_COMPOUND_PREFIX_TO_DIGIT = {
    "двух": "2",
    "трех": "3",
    "трёх": "3",
    "четырех": "4",
    "четырёх": "4",
    "пяти": "5",
    "шести": "6",
    "семи": "7",
    "восьми": "8",
    "девяти": "9",
    "десяти": "10",
}

_COMPOUND_NUMERAL_RE = re.compile(
    r"\b(" + "|".join(map(re.escape, _COMPOUND_PREFIX_TO_DIGIT.keys())) + r")(литров[а-яё-]*|комнатн[а-яё-]*)",
    flags=re.IGNORECASE,
)

def normalize_word_problem_text(text: str) -> str:
    cleaned = _FINAL_PATCH_PREV_NORMALIZE_WORD_PROBLEM_TEXT(text)

    def _replace_compound(match: re.Match) -> str:
        stem = match.group(1).lower()
        tail = match.group(2)
        return f"{_COMPOUND_PREFIX_TO_DIGIT[stem]}-{tail}"

    cleaned = _COMPOUND_NUMERAL_RE.sub(_replace_compound, cleaned)
    return cleaned

QUESTION_NOUN_FORMS.update({
    "ведро": ("ведро", "ведра", "ведер"),
    "ведра": ("ведро", "ведра", "ведер"),
    "ведер": ("ведро", "ведра", "ведер"),
    "ведрах": ("ведро", "ведра", "ведер"),
    "вёдра": ("ведро", "ведра", "ведер"),
    "вёдер": ("ведро", "ведра", "ведер"),
    "вёдрах": ("ведро", "ведра", "ведер"),
    "ящик": ("ящик", "ящика", "ящиков"),
    "ящика": ("ящик", "ящика", "ящиков"),
    "ящиков": ("ящик", "ящика", "ящиков"),
    "ящиках": ("ящик", "ящика", "ящиков"),
    "клетках": ("клетка", "клетки", "клеток"),
    "банках": ("банка", "банки", "банок"),
    "квартира": ("квартира", "квартиры", "квартир"),
    "квартиры": ("квартира", "квартиры", "квартир"),
    "квартир": ("квартира", "квартиры", "квартир"),
    "комната": ("комната", "комнаты", "комнат"),
    "комнаты": ("комната", "комнаты", "комнат"),
    "комнат": ("комната", "комнаты", "комнат"),
    "раз": ("раз", "раза", "раз"),
})

MEASURE_QUESTION_NOUNS.update({"времени", "день", "дня", "дней", "секунда", "секунды", "секунд"})



def _question_requests_object_count(raw_text: str) -> bool:
    noun = _extract_count_question_noun(raw_text)
    return bool(noun) and noun not in MEASURE_QUESTION_NOUNS




def _final_patch_group_phrase(count: int) -> str:
    value = abs(int(count)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return f"{count} одинаковых групп"
    if tail == 1:
        return f"{count} одинаковая группа"
    if 2 <= tail <= 4:
        return f"{count} одинаковые группы"
    return f"{count} одинаковых групп"

def _final_patch_plural(count_value: int, forms: Tuple[str, str, str]) -> str:
    return _select_plural_by_count(count_value, forms)

def try_final_patch_simple_group_total_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    nums = extract_ordered_numbers(lower)
    if "сколько" not in question:
        return None
    if len(nums) != 2:
        return None
    if any(fragment in question for fragment in (
        "в скольких",
        "сколько потребуется",
        "сколько потребовалось",
        "сколько понадобится",
        "сколько понадобилось",
        "сколько осталось",
        "сколько останется",
        "сколько стало",
        "сколько заплатила",
        "сколько заплатил",
        "сколько стоила",
        "сколько стоит",
    )):
        return None
    if "поровну" in lower or "кажд" in question:
        return None
    if contains_any_fragment(lower, WORD_GAIN_HINTS + WORD_LOSS_HINTS):
        return None

    groups = None
    per_group = None
    unit = _detect_question_unit(raw_text)

    if len(re.findall(r"\bпо\s+\d+\b", lower)) == 1:
        pair = _first_po_pair(lower)
        if pair:
            groups, per_group = pair
    else:
        match = re.search(r"\b(\d+)\s+(\d+)-литров[а-я-]*\s+[а-я]+\b", lower)
        if match:
            groups, per_group = int(match.group(1)), int(match.group(2))
            unit = unit or "л"

    if groups is None or per_group is None:
        return None

    total = groups * per_group
    group_phrase = _final_patch_group_phrase(groups)
    if unit:
        return join_explanation_lines(
            f"1) Если есть {group_phrase} по {per_group} {unit} в каждой, то всего {groups} × {per_group} = {total} {unit}",
            f"Ответ: всего было {total} {unit}",
            "Совет: если одинаковая величина повторяется несколько раз, используют умножение",
        )
    answer_text = _detailed_maybe_enrich_answer(str(total), raw_text, "word")
    return join_explanation_lines(
        f"1) Если есть {group_phrase} по {per_group} в каждой, то всего {groups} × {per_group} = {total}",
        f"Ответ: всего было {answer_text}",
        "Совет: если одинаковое количество повторяется несколько раз, используют умножение",
    )

def try_final_patch_school_boxes_equal_price_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "школ" not in lower or "ящик" not in lower:
        return None
    if "сколько должна заплатить" not in question and "каждая школа" not in question:
        return None

    total_match = re.search(r"на\s+(\d+)\s+руб", lower)
    count_matches = [int(value) for value in re.findall(r"(\d+)\s+ящик", lower)]
    if not total_match or len(count_matches) < 2:
        return None

    total_cost = int(total_match.group(1))
    first_count, second_count = count_matches[:2]
    total_boxes = first_count + second_count
    if total_boxes == 0 or total_cost % total_boxes != 0:
        return None

    box_price = total_cost // total_boxes
    first_cost = box_price * first_count
    second_cost = box_price * second_count
    return join_explanation_lines(
        f"1) Если одна школа взяла {first_count} ящика, а другая {second_count} ящиков, то всего взяли {first_count} + {second_count} = {total_boxes} ящиков",
        f"2) Если за {total_boxes} ящиков заплатили {total_cost} руб., то один ящик стоит {total_cost} : {total_boxes} = {box_price} руб.",
        f"3) Если первая школа взяла {first_count} ящика по {box_price} руб., то она должна заплатить {box_price} × {first_count} = {first_cost} руб.",
        f"4) Если вторая школа взяла {second_count} ящиков по {box_price} руб., то она должна заплатить {box_price} × {second_count} = {second_cost} руб.",
        f"Ответ: первая школа должна заплатить {first_cost} руб., вторая — {second_cost} руб.",
        "Совет: в задачах на пропорциональное деление сначала находят общую цену одной равной части",
    )

def try_final_patch_water_bucket_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "ведр" not in lower or "одинаков" not in lower or "сколько литров" not in question:
        return None

    sizes = [int(value) for value in re.findall(r"(\d+)-литров", lower)]
    diff_match = re.search(r"на\s+(\d+)\s+литр", lower)
    if len(sizes) < 2 or not diff_match:
        return None

    big_bucket = max(sizes[0], sizes[1])
    small_bucket = min(sizes[0], sizes[1])
    diff_total = int(diff_match.group(1))
    step_diff = big_bucket - small_bucket
    if step_diff <= 0 or diff_total % step_diff != 0:
        return None

    trips = diff_total // step_diff
    big_total = big_bucket * trips
    small_total = small_bucket * trips

    if "мальчик" in lower and "девоч" in lower:
        first_label = "мальчик"
        second_label = "девочка"
        second_verb = "делала"
        second_result_verb = "принесла"
    else:
        first_label = "первый"
        second_label = "второй"
        second_verb = "делал"
        second_result_verb = "принёс"

    return join_explanation_lines(
        f"1) Если {first_label} за один раз приносил {big_bucket} л, а {second_label} {small_bucket} л, то за один раз {first_label} приносил на {big_bucket} - {small_bucket} = {step_diff} л больше",
        f"2) Если всего {first_label} принёс на {diff_total} л больше, а за один раз разница была {step_diff} л, то одинаковых ходок было {diff_total} : {step_diff} = {trips}",
        f"3) Если {first_label} делал {trips} ходок по {big_bucket} л, то он принёс {big_bucket} × {trips} = {big_total} л",
        f"4) Если {second_label} {second_verb} {trips} ходок по {small_bucket} л, то она {second_result_verb} {small_bucket} × {trips} = {small_total} л",
        f"Ответ: {first_label} принёс {big_total} л воды, {second_label} — {small_total} л.",
        "Совет: если число ходок одинаковое, сначала находят разницу за одну ходку",
    )

def try_final_patch_remaining_rooms_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    if "комнат" not in lower or "квартир" not in lower or "остал" not in lower:
        return None
    if "отремонт" not in question:
        return None

    total_match = re.search(r"(\d+)\s+комнат", lower)
    remain_match = re.search(r"остал[аоись]*[^0-9]{0,40}(\d+)\s+(\d+)-комнатн", lower)
    if not total_match or not remain_match:
        return None

    total_rooms = int(total_match.group(1))
    flats = int(remain_match.group(1))
    rooms_per_flat = int(remain_match.group(2))
    remaining_rooms = flats * rooms_per_flat
    repaired_rooms = total_rooms - remaining_rooms
    if repaired_rooms < 0:
        return None

    flat_word = _final_patch_plural(flats, ("квартира", "квартиры", "квартир"))
    room_word = _final_patch_plural(rooms_per_flat, ("комната", "комнаты", "комнат"))
    return join_explanation_lines(
        f"1) Если осталось отремонтировать {flats} {flat_word} по {rooms_per_flat} {room_word} в каждой, то осталось отремонтировать {flats} × {rooms_per_flat} = {remaining_rooms} комнат",
        f"2) Если всего надо было отремонтировать {total_rooms} комнаты, а осталось {remaining_rooms} комнат, то отремонтировали {total_rooms} - {remaining_rooms} = {repaired_rooms} комнат",
        f"Ответ: отремонтировали {repaired_rooms} комнат.",
        "Совет: если известны всё число и оставшаяся часть, выполненную часть находят вычитанием",
    )



# --- OPENAI FINAL CONSOLIDATION PATCH 2026-04-11N: punctuation, order marks, missing textbook templates ---


def _oai_final_question_lower(raw_text: str) -> str:
    return _question_lower_text(raw_text).lower().replace("ё", "е")



def try_oai_final_advanced_brigade_unit_rate_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = _oai_final_question_lower(raw_text)
    if "бригада" not in lower:
        return None
    if not contains_any_fragment(question, ("сколько метров", "сколько м", "сколько километров", "сколько км")):
        return None

    source_match = re.search(r"за\s+(\d+)\s+дн(?:я|ей)[^\d]{0,60}бригада[^\d]{0,60}(\d+)\s*(м|км)", lower)
    question_match = re.search(r"(\d+)\s+бригад[^\d]{0,60}за\s+(\d+)\s+дн(?:я|ей)", lower)
    if not source_match or not question_match:
        return None

    days1 = int(source_match.group(1))
    total_amount = int(source_match.group(2))
    unit = source_match.group(3)
    brigades = int(question_match.group(1))
    days2 = int(question_match.group(2))
    if days1 <= 0 or brigades <= 0 or days2 <= 0 or total_amount <= 0:
        return None

    one_brigade_one_day = Fraction(total_amount, days1)
    many_brigades_one_day = one_brigade_one_day * brigades
    final_amount = many_brigades_one_day * days2

    d1_text = format_fraction(one_brigade_one_day)
    d2_text = format_fraction(many_brigades_one_day)
    answer_text = format_fraction(final_amount)

    return join_explanation_lines(
        f"1) Если одна бригада проложила {total_amount} {unit} за {days1} дней, то за 1 день одна бригада проложит {total_amount} : {days1} = {d1_text} {unit}",
        f"2) Если одна бригада за 1 день прокладывает {d1_text} {unit}, то {brigades} бригады за 1 день проложат {d1_text} × {brigades} = {d2_text} {unit}",
        f"3) Если {brigades} бригады за 1 день прокладывают {d2_text} {unit}, то за {days2} дней они проложат {d2_text} × {days2} = {answer_text} {unit}",
        f"Ответ: {brigades} бригады за {days2} дней проложат {answer_text} {unit}",
        "Совет: в усложнённых задачах на приведение к единице сначала находят работу одной бригады за 1 день",
    )
