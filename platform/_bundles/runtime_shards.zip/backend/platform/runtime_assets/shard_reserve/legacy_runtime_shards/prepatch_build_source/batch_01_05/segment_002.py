"""Auto-generated runtime shard for prepatch_build_source.py, lines 896-1780."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def explain_price_quantity_cost_problem(quantity: int, total_cost: int, wanted_cost: int) -> Optional[str]:
    if quantity == 0 or total_cost % quantity != 0:
        return None
    price = total_cost // quantity
    if price == 0 or wanted_cost % price != 0:
        return None
    result = wanted_cost // price
    return join_explanation_lines(
        f"1) Если за {quantity} одинаковых коробок заплатили {total_cost}, то цена одной коробки равна {total_cost} : {quantity} = {price}",
        f"2) Если одна коробка стоит {price}, то на {wanted_cost} руб. можно купить {wanted_cost} : {price} = {result}",
        f"Ответ: {result}",
        "Совет: если цена одинаковая, сначала находят цену одной коробки",
    )

def explain_unknown_red_price(known_count: int, known_price: int, unknown_count: int, total_cost: int) -> Optional[str]:
    known_total = known_count * known_price
    other_total = total_cost - known_total
    if unknown_count == 0 or other_total < 0 or other_total % unknown_count != 0:
        return None
    unit_price = other_total // unknown_count
    return join_explanation_lines(
        f"1) Если известные цветы купили {known_count} раза по {known_price} руб., то за них заплатили {known_count} × {known_price} = {known_total} руб",
        f"2) Если за всю покупку заплатили {total_cost} руб., а за известные цветы {known_total} руб., то за остальные цветы заплатили {total_cost} - {known_total} = {other_total} руб",
        f"3) Если за {unknown_count} остальных цветов заплатили {other_total} руб., то одна штука стоит {other_total} : {unknown_count} = {unit_price} руб",
        f"Ответ: одна красная гвоздика стоила {unit_price} руб",
        "Совет: если известна общая стоимость покупки, сначала вычти известную часть",
    )

def explain_simple_price_per_item(count: int, total_cost: int) -> Optional[str]:
    if count == 0 or total_cost % count != 0:
        return None
    price = total_cost // count
    return join_explanation_lines(
        f"1) Если {count} одинаковых предметов стоят {total_cost} руб., то один предмет стоит {total_cost} : {count} = {price} руб",
        f"Ответ: один предмет стоит {price} руб",
        "Совет: цену одной штуки находят делением общей стоимости на количество",
    )

def explain_simple_total_cost(price: int, count: int) -> str:
    total = price * count
    return join_explanation_lines(
        f"1) Если один предмет стоит {price} руб., а купили {count} предметов, то вся покупка стоит {price} × {count} = {total} руб",
        f"Ответ: вся покупка стоит {total} руб",
        "Совет: стоимость находят умножением цены на количество",
    )

def try_high_priority_named_sum_of_two_products_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower or ("заплат" not in lower and "стоил" not in lower and "стоимость" not in lower):
        return None

    matches = list(re.finditer(r"(\d+)\s+([^?.!,]{1,30}?)\s+по\s+(\d+)", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_name = matches[0].group(2).strip()
    first_price = int(matches[0].group(3))
    second_count = int(matches[1].group(1))
    second_name = matches[1].group(2).strip()
    second_price = int(matches[1].group(3))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если купили {first_count} {first_name} по {first_price} руб., то за {first_name} заплатили {first_count} × {first_price} = {first_total} руб",
        f"2) Если купили {second_count} {second_name} по {second_price} руб., то за {second_name} заплатили {second_count} × {second_price} = {second_total} руб",
        f"3) Если за первую покупку заплатили {first_total} руб., а за вторую {second_total} руб., то за всю покупку заплатили {first_total} + {second_total} = {total} руб",
        f"Ответ: за всю покупку заплатили {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
    )

def try_high_priority_unknown_addend_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None

    if re.search(r"(?:на двух|на обеих|на обоих|за два дня|всего|из них|на всем теле|на всём теле)", lower) and not _has_total_like_question(raw_text):
        total, known = nums[0], nums[1]
        if total < known:
            return None
        result = total - known
        return join_explanation_lines(
            f"1) Если всего было {total}, а одна часть равна {known}, то другая часть равна {total} - {known} = {result}",
            f"Ответ: {result}",
            "Совет: чтобы найти неизвестную часть, из целого вычитают известную часть",
        )
    return None

def try_high_priority_added_removed_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) != 2 or "сколько" not in lower:
        return None

    if re.search(r"\b(стало|их стало|теперь стало|получилось)\b", lower) and contains_any_fragment(lower, WORD_GAIN_HINTS + ("постав", "добав", "приех", "вошло", "прибав")):
        before, after = nums[0], nums[1]
        if after < before:
            return None
        added = after - before
        return join_explanation_lines(
            f"1) Если сначала было {before}, а потом стало {after}, то добавили {after} - {before} = {added}",
            f"Ответ: {added}",
            "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
        )

    if re.search(r"\b(осталось|осталось прочитать|пришло|осталось расфасовать)\b", lower) and contains_any_fragment(lower, WORD_LOSS_HINTS + ("забрали", "сняли", "вышло", "заболело", "заболели", "заболел")):
        before, after = nums[0], nums[1]
        if before < after:
            return None
        removed = before - after
        return join_explanation_lines(
            f"1) Если сначала было {before}, а потом осталось {after}, то убрали {before} - {after} = {removed}",
            f"Ответ: {removed}",
            "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
        )

    if ("сколько было" in lower or "сколько было сначала" in lower) and re.search(r"\b(осталось|осталось на|осталось в)\b", lower):
        removed, left = nums[0], nums[1]
        result = removed + left
        return join_explanation_lines(
            f"1) Если убрали {removed}, а осталось {left}, то сначала было {removed} + {left} = {result}",
            f"Ответ: {result}",
            "Совет: неизвестное уменьшаемое находят сложением",
        )
    return None

def try_high_priority_simple_group_total_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower:
        return None
    if _has_group_count_question(lower) or "поровну" in lower or "кажд" in lower:
        return None
    if not (asks_total_like(lower) or contains_any_fragment(lower, ("сколько килограммов", "сколько книг", "сколько карандашей", "сколько литров", "сколько огурцов", "сколько конфет"))):
        return None

    pair = _first_po_pair(lower)
    if not pair:
        return None
    groups, per_group = pair
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {groups * per_group}",
        f"Ответ: {groups * per_group}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def try_high_priority_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if not fracs:
        return None

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower) and values:
        total = max(values)
        solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
        if solved:
            return solved

    if len(fracs) != 1:
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None

    total_like_match = re.search(r"\b(?:было|всего|масса|длина|путь|прошли|прошёл|прошла|прошли за|на складе было|у мальчика было|у мамы было|у туристов было|листов было|руды)\b", lower)
    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)

    # Известно всё число, нужно найти часть или остаток.
    if values and (total_like_match or not remain_match):
        total = max(values)
        if ("остал" in lower or "во 2 день" in lower or "во второй день" in lower):
            if total % denominator != 0:
                return None
            one_part = total // denominator
            part = one_part * numerator
            remaining = total - part
            if "во 2 день" in lower or "во второй день" in lower:
                return join_explanation_lines(
                    f"1) Если весь путь равен {total}, то одна доля равна {total} : {denominator} = {one_part}",
                    f"2) Если в первый день прошли {numerator}/{denominator} пути, то в первый день прошли {one_part} × {numerator} = {part}",
                    f"3) Если весь путь {total}, а в первый день прошли {part}, то во второй день прошли {total} - {part} = {remaining}",
                    f"Ответ: во второй день прошли {remaining}",
                    "Совет: чтобы найти другую часть пути, сначала найди известную часть, потом вычти её из всего пути",
                )
            return join_explanation_lines(
                f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}",
                f"2) Если требуется найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part}",
                f"3) Если всего было {total}, а израсходовали {part}, то осталось {total} - {part} = {remaining}",
                f"Ответ: осталось {remaining}",
                "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
            )

        if total % denominator == 0:
            one_part = total // denominator
            part = one_part * numerator
            return join_explanation_lines(
                f"1) Если всё число равно {total}, то одна доля равна {total} : {denominator} = {one_part}",
                f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part}",
                f"Ответ: {part}",
                "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
            )

    # Известно, сколько осталось после расхода части.
    if remain_match:
        remaining_value = int(remain_match.group(1))
        solved = explain_whole_by_remaining_fraction(remaining_value, numerator, denominator)
        if solved:
            return solved

    return None

def try_high_priority_unknown_price_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) >= 4 and "за всю покупку заплатили" in lower and "по" in lower and contains_any_fragment(lower, ("сколько стоила 1", "сколько стоит 1", "сколько стоила одна", "сколько стоит одна")):
        return explain_unknown_red_price(nums[0], nums[1], nums[2], nums[3])
    return None

def try_high_priority_total_cost_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    nums = extract_ordered_numbers(lower)
    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоит 1", "сколько стоит одна", "сколько стоит один", "сколько стоит 1 ")):
        return explain_simple_price_per_item(nums[0], nums[1])
    if len(nums) >= 2 and contains_any_fragment(lower, ("сколько стоят", "сколько стоила вся покупка", "сколько стоит вся покупка")):
        return explain_simple_total_cost(nums[0], nums[1])
    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_high_priority_named_sum_of_two_products_word_problem_explanation(user_text)
        or try_high_priority_unknown_price_word_problem_explanation(user_text)
        or try_high_priority_total_cost_word_problem_explanation(user_text)
        or try_high_priority_fraction_word_problem_explanation(user_text)
        or try_high_priority_unknown_addend_word_problem_explanation(user_text)
        or try_high_priority_added_removed_word_problem_explanation(user_text)
        or try_high_priority_simple_group_total_word_problem_explanation(user_text)
        or _PREVIOUS_build_explanation_local_first(user_text, kind)
    )

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи",
            "Запишите пример или задачу полнее и без сокращений",
            "Ответ: пока нужен более понятный ввод",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 1800,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- FINAL SCHOOL PATCH 2: units, group totals, cleaner purchase wording ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower = normalize_word_problem_text(raw_text).lower()
    if "скорост" in question:
        if "км/ч" in lower:
            return "км/ч"
        if "м/мин" in lower:
            return "м/мин"
        if "м/с" in lower:
            return "м/с"
    for unit in ("руб.", "руб", "кг", "г", "км", "м", "см", "дм", "мм", "л", "ч", "мин"):
        if unit in question:
            return unit.replace(".", "")
    if "деньг" in question or "денег" in question:
        return "руб"
    return ""

def _append_unit_to_number_text(value: int, raw_text: str) -> str:
    unit = _detect_question_unit(raw_text)
    if not unit:
        return str(value)
    return f"{value} {unit}"

def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    if re.fullmatch(r"-?\d+(?:/\d+)?", value):
        unit = _detect_question_unit(raw_text)
        if unit:
            return f"{value} {unit}"
        lower = str(raw_text or "").lower().replace("ё", "е")
        if "руб" in lower or "денег" in lower:
            return f"{value} руб."
    return value

def try_high_priority_named_sum_of_two_products_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower or ("заплат" not in lower and "стоил" not in lower and "стоимость" not in lower):
        return None

    matches = list(re.finditer(r"(\d+)\s+([^?.!,]{1,30}?)\s+по\s+(\d+)", lower))
    if len(matches) < 2:
        return None

    first_count = int(matches[0].group(1))
    first_price = int(matches[0].group(3))
    second_count = int(matches[1].group(1))
    second_price = int(matches[1].group(3))

    first_total = first_count * first_price
    second_total = second_count * second_price
    total = first_total + second_total

    return join_explanation_lines(
        f"1) Если первая покупка состоит из {first_count} предметов по {first_price} руб., то её стоимость равна {first_count} × {first_price} = {first_total} руб",
        f"2) Если вторая покупка состоит из {second_count} предметов по {second_price} руб., то её стоимость равна {second_count} × {second_price} = {second_total} руб",
        f"3) Если первая покупка стоит {first_total} руб., а вторая {second_total} руб., то вся покупка стоит {first_total} + {second_total} = {total} руб",
        f"Ответ: за всю покупку заплатили {total} руб",
        "Совет: если в задаче есть две покупки вида «по столько-то», сначала находят стоимость каждой покупки отдельно",
    )

def try_high_priority_simple_group_total_word_problem_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    if "сколько" not in lower:
        return None
    if _has_group_count_question(lower) or "поровну" in lower:
        return None
    if not (asks_total_like(lower) or contains_any_fragment(lower, ("сколько килограммов", "сколько книг", "сколько карандашей", "сколько литров", "сколько огурцов", "сколько конфет"))):
        return None

    pair = _first_po_pair(lower)
    if not pair:
        return None
    groups, per_group = pair
    total = groups * per_group
    answer_value = _append_unit_to_number_text(total, raw_text)
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего {groups} × {per_group} = {total}",
        f"Ответ: {answer_value}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )

def try_high_priority_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if not fracs:
        return None

    unit = _detect_question_unit(raw_text)

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower) and values:
        total = max(values)
        solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
        if solved:
            return solved

    if len(fracs) != 1:
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None

    total_like_match = re.search(r"\b(?:было|всего|масса|длина|путь|прошли|прошёл|прошла|прошли за|на складе было|у мальчика было|у мамы было|листов было|руды)\b", lower)
    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)

    if values and (total_like_match or not remain_match):
        total = max(values)
        if ("остал" in lower or "во 2 день" in lower or "во второй день" in lower):
            if total % denominator != 0:
                return None
            one_part = total // denominator
            part = one_part * numerator
            remaining = total - part
            remaining_text = f"{remaining} {unit}".strip()
            total_text = f"{total} {unit}".strip()
            one_part_text = f"{one_part} {unit}".strip()
            part_text = f"{part} {unit}".strip()
            if "во 2 день" in lower or "во второй день" in lower:
                return join_explanation_lines(
                    f"1) Если весь путь равен {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                    f"2) Если в первый день прошли {numerator}/{denominator} пути, то в первый день прошли {one_part} × {numerator} = {part_text}",
                    f"3) Если весь путь {total_text}, а в первый день прошли {part_text}, то во второй день прошли {total} - {part} = {remaining_text}",
                    f"Ответ: во второй день прошли {remaining_text}",
                    "Совет: чтобы найти другую часть пути, сначала найди известную часть, потом вычти её из всего пути",
                )
            return join_explanation_lines(
                f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если требуется найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
                f"3) Если всего было {total_text}, а израсходовали {part_text}, то осталось {total} - {part} = {remaining_text}",
                f"Ответ: осталось {remaining_text}",
                "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
            )

        if total % denominator == 0:
            one_part = total // denominator
            part = one_part * numerator
            total_text = f"{total} {unit}".strip()
            one_part_text = f"{one_part} {unit}".strip()
            part_text = f"{part} {unit}".strip()
            return join_explanation_lines(
                f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
                f"Ответ: {part_text}",
                "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
            )

    if remain_match:
        remaining_value = int(remain_match.group(1))
        solved = explain_whole_by_remaining_fraction(remaining_value, numerator, denominator)
        if solved:
            if unit:
                solved = solved.replace(f"равны {remaining_value}", f"равны {remaining_value} {unit}")
                solved = re.sub(rf"Ответ:\s*всего было (\d+)([.!?])", rf"Ответ: всего было \1 {unit}\2", solved)
            return solved

    return None

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        try_local_equation_explanation(user_text)
        or try_local_fraction_explanation(user_text)
        or try_local_expression_explanation(user_text)
        or try_local_measurement_word_problem_explanation(user_text)
        or try_local_geometry_explanation(user_text)
        or try_high_priority_named_sum_of_two_products_word_problem_explanation(user_text)
        or try_high_priority_unknown_price_word_problem_explanation(user_text)
        or try_high_priority_total_cost_word_problem_explanation(user_text)
        or try_high_priority_fraction_word_problem_explanation(user_text)
        or try_high_priority_unknown_addend_word_problem_explanation(user_text)
        or try_high_priority_added_removed_word_problem_explanation(user_text)
        or try_high_priority_simple_group_total_word_problem_explanation(user_text)
        or _PREVIOUS_build_explanation_local_first(user_text, kind)
    )

# --- FINAL SCHOOL PATCH 3: safer unit detection ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower()

    if "скорост" in question:
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if re.search(r"руб|денег", question) or ("руб" in lower_full and re.search(r"сколько|каков|какова|чему", question)):
        return "руб"
    if re.search(r"килограмм|кг", question):
        return "кг"
    if re.search(r"\bграмм|\bг\b", question):
        return "г"
    if re.search(r"километр|км", question):
        return "км"
    if re.search(r"\bметр|\bм\b", question):
        return "м"
    if re.search(r"сантиметр|см", question):
        return "см"
    if re.search(r"дециметр|дм", question):
        return "дм"
    if re.search(r"миллиметр|мм", question):
        return "мм"
    if re.search(r"литр|\bл\b", question):
        return "л"
    if re.search(r"час|сколько времени|за какое время", question):
        return "ч"
    if re.search(r"минут|мин", question):
        return "мин"
    return ""

# --- FINAL SCHOOL PATCH 4: reliable fraction routing for total-known vs remaining-known cases ---

def try_high_priority_fraction_word_problem_explanation(raw_text: str) -> Optional[str]:
    text, lower, fracs, values = _fraction_numbers_and_text(raw_text)
    if not fracs:
        return None

    unit = _detect_question_unit(raw_text)

    if len(fracs) >= 2 and ("остал" in lower or "сколько" in lower) and values:
        total = max(values)
        solved = explain_two_fraction_parts_remaining(total, fracs[0], fracs[1])
        if solved:
            return solved

    if len(fracs) != 1:
        return None

    numerator, denominator = fracs[0]
    if denominator == 0:
        return None

    remain_match = re.search(r"остал[аоись]*[^\d]{0,20}(\d+)", lower)
    explicit_total_match = re.search(r"(?:\bбыло\b|\bвсего\b|\bмасса\b|\bдлина\b|\bпуть\b|\bпрошли\b|\bпрошёл\b|\bпрошла\b|\bлистов\b|\bруды\b)[^\d]{0,40}(\d+)", lower)

    # 1) Случай: известен остаток после расхода дробной части, а всё число неизвестно.
    if remain_match and (not explicit_total_match or explicit_total_match.start() > remain_match.start()):
        remaining_value = int(remain_match.group(1))
        remaining_numerator = denominator - numerator
        if remaining_numerator <= 0 or remaining_value % remaining_numerator != 0:
            return None
        one_part = remaining_value // remaining_numerator
        whole = one_part * denominator
        remaining_text = f"{remaining_value} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        whole_text = f"{whole} {unit}".strip()
        return join_explanation_lines(
            f"1) Если израсходовали {numerator}/{denominator} всех денег, то осталось {remaining_numerator}/{denominator} всех денег",
            f"2) Если {remaining_numerator}/{denominator} всех денег равны {remaining_text}, то одна доля равна {remaining_value} : {remaining_numerator} = {one_part_text}",
            f"3) Если одна доля равна {one_part_text}, то все деньги равны {one_part} × {denominator} = {whole_text}",
            f"Ответ: всего было {whole_text}",
            "Совет: если известен остаток после расхода части, сначала найди оставшуюся долю",
        )

    # 2) Случай: всё число известно, нужно найти часть или остаток.
    if values:
        total = max(values)
        if total % denominator != 0:
            return None
        one_part = total // denominator
        part = one_part * numerator
        remaining = total - part
        total_text = f"{total} {unit}".strip()
        one_part_text = f"{one_part} {unit}".strip()
        part_text = f"{part} {unit}".strip()
        remaining_text = f"{remaining} {unit}".strip()

        if "во 2 день" in lower or "во второй день" in lower:
            return join_explanation_lines(
                f"1) Если весь путь равен {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если в первый день прошли {numerator}/{denominator} пути, то в первый день прошли {one_part} × {numerator} = {part_text}",
                f"3) Если весь путь {total_text}, а в первый день прошли {part_text}, то во второй день прошли {total} - {part} = {remaining_text}",
                f"Ответ: во второй день прошли {remaining_text}",
                "Совет: чтобы найти другую часть пути, сначала найди известную часть, потом вычти её из всего пути",
            )

        if "остал" in lower:
            return join_explanation_lines(
                f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
                f"2) Если требуется найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
                f"3) Если всего было {total_text}, а израсходовали {part_text}, то осталось {total} - {part} = {remaining_text}",
                f"Ответ: осталось {remaining_text}",
                "Совет: чтобы найти остаток после дробной части, сначала находят эту часть",
            )

        return join_explanation_lines(
            f"1) Если всё число равно {total_text}, то одна доля равна {total} : {denominator} = {one_part_text}",
            f"2) Если нужно найти {numerator}/{denominator} числа, то эта часть равна {one_part} × {numerator} = {part_text}",
            f"Ответ: {part_text}",
            "Совет: чтобы найти часть от числа, сначала делят на знаменатель, потом умножают на числитель",
        )

    return None

# --- FINAL SCHOOL PATCH 5: only attach units when the question itself asks for that unit ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower()

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:килограмм|кг)\b", question):
        return "кг"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:сколько|какова|какое расстояние|какой путь|чему равно расстояние)[^?.!]{0,25}(?:километр|км)\b", question):
        return "км"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:сантиметр|см)\b", question):
        return "см"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:дециметр|дм)\b", question):
        return "дм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:миллиметр|мм)\b", question):
        return "мм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"

    if "сколько денег" in question or ("руб" in lower_full and "сколько сто" in question):
        return "руб"
    return ""

# --- FINAL SCHOOL PATCH 6: fix "килограммов" vs "граммов" distinction ---

def _detect_question_unit(raw_text: str) -> str:
    question = _question_text_only(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower()

    if re.search(r"(?:с какой скоростью|какова скорость)", question):
        if "км/ч" in lower_full:
            return "км/ч"
        if "м/мин" in lower_full:
            return "м/мин"
        if "м/с" in lower_full:
            return "м/с"

    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:руб|рубл|денег)", question):
        return "руб"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:килограмм|кг)", question):
        return "кг"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:(?<!кило)грамм|\bг\b)", question):
        return "г"
    if re.search(r"(?:сколько|какова|какое расстояние|какой путь|чему равно расстояние)[^?.!]{0,25}(?:километр|км)", question):
        return "км"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:сантиметр|см)", question):
        return "см"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:дециметр|дм)", question):
        return "дм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:миллиметр|мм)", question):
        return "мм"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:метр|\bм\b)", question):
        return "м"
    if re.search(r"(?:сколько|какова|какое|чему равна?)[^?.!]{0,25}(?:литр|\bл\b)", question):
        return "л"
    if re.search(r"(?:сколько часов|сколько времени|за какое время|сколько час)", question):
        return "ч"
    if re.search(r"(?:сколько минут|сколько мин)", question):
        return "мин"

    if "сколько денег" in question or ("руб" in lower_full and "сколько сто" in question):
        return "руб"
    return ""

# --- OPENAI FINAL PATCH 2026-04-10: routing fixes, textbook-style compound tasks, safer answer units, ASCII columns ---

_PATCH8_PREVIOUS_build_explanation_local_first = build_explanation_local_first
_PATCH8_PREVIOUS_explain_column_addition = explain_column_addition
_PATCH8_PREVIOUS_explain_column_subtraction = explain_column_subtraction
_PATCH8_PREVIOUS_explain_long_multiplication = explain_long_multiplication
_PATCH8_PREVIOUS_explain_long_division = explain_long_division

_PREFIX_NUMBER_MAP = {
    "одн": 1,
    "одно": 1,
    "двух": 2,
    "трех": 3,
    "трёх": 3,
    "четырех": 4,
    "четырёх": 4,
    "пяти": 5,
    "шести": 6,
    "семи": 7,
    "восьми": 8,
    "девяти": 9,
    "десяти": 10,
}

def _remove_one_value(seq: List[int], value: int) -> List[int]:
    data = list(seq)
    try:
        data.remove(value)
    except ValueError:
        pass
    return data

def _word_multiplier_value(word: str) -> Optional[int]:
    token = str(word or "").lower().replace("ё", "е")
    for prefix, value in _PREFIX_NUMBER_MAP.items():
        if token.startswith(prefix):
            return value
    return None

def _ascii_rule(width: int) -> str:
    return "-" * max(3, width)

def _render_column_addition_ascii(numbers: List[int]) -> List[str]:
    ordered = sorted(numbers, key=lambda x: (len(str(abs(x))), abs(x)), reverse=True)
    width = max(len(str(abs(n))) for n in ordered) + 1
    lines = ["Запись столбиком:"]
    for index, number in enumerate(ordered):
        sign = "+" if index > 0 else " "
        lines.append(f"{sign}{str(number).rjust(width - 1)}")
    lines.append(_ascii_rule(width))
    lines.append(f" {str(sum(ordered)).rjust(width - 1)}")
    return lines

def _render_column_subtraction_ascii(minuend: int, subtrahend: int) -> List[str]:
    width = max(len(str(abs(minuend))), len(str(abs(subtrahend)))) + 1
    result = minuend - subtrahend
    return [
        "Запись столбиком:",
        f" {str(minuend).rjust(width - 1)}",
        f"-{str(subtrahend).rjust(width - 1)}",
        _ascii_rule(width),
        f" {str(result).rjust(width - 1)}",
    ]

def _render_long_multiplication_ascii(left: int, right: int) -> List[str]:
    a, b = left, right
    if len(str(abs(a))) < len(str(abs(b))):
        a, b = b, a
    width = max(len(str(abs(a))), len(str(abs(b))) + 1, len(str(abs(a * b)))) + 1
    lines = ["Запись столбиком:", f" {str(a).rjust(width - 1)}", f"×{str(b).rjust(width - 1)}", _ascii_rule(width)]
    digits_b = list(reversed(str(abs(b))))
    partials = []
    for index, digit in enumerate(digits_b):
        if digit == "0":
            continue
        partials.append(a * int(digit) * (10 ** index))
    if len(partials) <= 1:
        lines.append(f" {str(a * b).rjust(width - 1)}")
        return lines
    for partial in partials:
        lines.append(f" {str(partial).rjust(width - 1)}")
    lines.append(_ascii_rule(width))
    lines.append(f" {str(a * b).rjust(width - 1)}")
    return lines

def _render_long_division_ascii(dividend: int, divisor: int) -> List[str]:
    if divisor == 0:
        return ["Запись столбиком:", "Деление на ноль невозможно"]
    quotient, remainder = divmod(dividend, divisor)
    lines = ["Запись столбиком:", f"{divisor}) {dividend}", f"Частное: {quotient}"]
    if remainder:
        lines.append(f"Остаток: {remainder}")
    return lines

def explain_column_addition(numbers: List[int]) -> str:
    base = _PATCH8_PREVIOUS_explain_column_addition(numbers)
    parts = _detailed_split_sections(base)
    lines = _render_column_addition_ascii(numbers) + parts["body"] + [
        f"Ответ: {parts['answer'] or sum(numbers)}",
        f"Совет: {parts['advice'] or 'в столбике всегда начинай с младшего разряда'}",
    ]
    return _detailed_finalize_text(lines)

def explain_column_subtraction(minuend: int, subtrahend: int) -> str:
    base = _PATCH8_PREVIOUS_explain_column_subtraction(minuend, subtrahend)
    parts = _detailed_split_sections(base)
    lines = _render_column_subtraction_ascii(minuend, subtrahend) + parts["body"] + [
        f"Ответ: {parts['answer'] or (minuend - subtrahend)}",
        f"Совет: {parts['advice'] or 'если разряда не хватает, занимаем 1 из соседнего старшего разряда'}",
    ]
    return _detailed_finalize_text(lines)

def explain_long_multiplication(left: int, right: int) -> str:
    base = _PATCH8_PREVIOUS_explain_long_multiplication(left, right)
    parts = _detailed_split_sections(base)
    lines = _render_long_multiplication_ascii(left, right) + parts["body"] + [
        f"Ответ: {parts['answer'] or (left * right)}",
        f"Совет: {parts['advice'] or 'в умножении столбиком сначала находят неполные произведения, потом их складывают'}",
    ]
    return _detailed_finalize_text(lines)

def explain_long_division(dividend: int, divisor: int) -> str:
    base = _PATCH8_PREVIOUS_explain_long_division(dividend, divisor)
    parts = _detailed_split_sections(base)
    answer_value = parts["answer"] or (f"{dividend // divisor}, остаток {dividend % divisor}" if divisor else "деление невозможно")
    lines = _render_long_division_ascii(dividend, divisor) + parts["body"] + [
        f"Ответ: {answer_value}",
        f"Совет: {parts['advice'] or 'в столбике повторяй шаги: взял, подобрал, умножил, вычел, снес цифру'}",
    ]
    return _detailed_finalize_text(lines)

def _is_ascii_math_layout_line(line: str) -> bool:
    stripped = str(line or "").rstrip()
    if not stripped:
        return False
    return bool(re.fullmatch(r"[ 0-9+\-×:=()/]+", stripped))

def _split_ascii_layout_block(body_lines: List[str]) -> Tuple[List[str], List[str]]:
    lines = [str(line or "") for line in body_lines]
    if not lines or not lines[0].lower().startswith("запись столбиком"):
        return [], lines
    block = [lines[0]]
    index = 1
    while index < len(lines) and _is_ascii_math_layout_line(lines[index]):
        block.append(lines[index])
        index += 1
    return block, lines[index:]

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_expression_source(raw_text)
    if not source:
        return _detailed_format_generic_solution(raw_text, base_text, "expression")
    node = parse_expression_ast(source)
    pretty_expression = render_node(node) if node is not None else _detailed_compact_expression(source)
    answer = parts["answer"] or _detailed_expression_answer(source) or "проверь запись"
    body_lines = [line for line in parts["body"] if not line.lower().startswith(("что известно:", "что нужно найти:"))]
    column_block, remaining_body = _split_ascii_layout_block(body_lines)
    if not remaining_body and not column_block:
        remaining_body = [re.sub(r"^\d+\)\s*", "", line) for line in _detailed_build_generic_steps_from_expression(source)]
    lines: List[str] = [f"Пример: {pretty_expression} = {answer}"]
    order_block = _detailed_build_order_block(source)
    if order_block and not column_block:
        lines.extend(order_block)
        lines.append("Решение по действиям:")
    else:
        lines.append("Решение.")
    if column_block:
        lines.extend(column_block)
        if remaining_body:
            lines.append("Пояснение:")
    lines.extend(_detailed_number_lines(remaining_body))
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice("expression")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)
