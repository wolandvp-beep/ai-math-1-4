"""Auto-generated runtime shard for prepatch_build_source.py, lines 11561-12460."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_20260412e_together_as_much_explanation(user_text)
        or _FINAL_20260412E_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи.",
            "Запишите пример или задачу полнее и без сокращений.",
            "Ответ: пока нужен более понятный ввод.",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 2400,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- FINAL CONSOLIDATION PATCH 2026-04-12F: broader math guard + tasks with letters ---

MATH_INPUT_HINTS = (
    "сколько", "сколько всего", "сколько стало", "сколько осталось", "на сколько", "во сколько",
    "больше", "меньше", "поровну", "по ", "стоимость", "цена", "количество", "купили",
    "скорость", "расстояние", "время", "площадь", "периметр", "доля", "часть",
    "уравнение", "пример", "выражение", "реши", "найди", "найдите",
)

def looks_like_math_input(text: str) -> bool:
    base = normalize_word_problem_text(text).lower()
    if re.search(r"\d|x|х|[+\-*/=×÷:]", base):
        return True
    if re.search(r"\b[a-z]\b", base) and any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    # допускаем словесные задачи без цифр, если в них есть школьные математические маркеры
    if any(hint in base for hint in MATH_INPUT_HINTS):
        return True
    return False

def _final_letter_task_shelf_more_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"на первой полке\s+([a-z])\s+книг[^.?!]*на\s+([a-z])\s+больше[^.?!]*на второй",
        lower,
    )
    if not match:
        return None
    total_symbol = match.group(1)
    delta_symbol = match.group(2)
    return join_explanation_lines(
        f"1) Если на первой полке {total_symbol} книг и это на {delta_symbol} больше, чем на второй, то на второй полке на {delta_symbol} книг меньше.",
        f"2) Если на первой полке {total_symbol} книг, а на второй на {delta_symbol} книг меньше, то на второй полке {total_symbol} - {delta_symbol} книг.",
        f"Ответ: на второй полке {total_symbol} - {delta_symbol} книг.",
        "Совет: в задаче с буквами действуй так же, как в задаче с числами: сначала переведи косвенную форму в прямую.",
    )

def _final_letter_task_tourist_remaining_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"турист должен пройти\s+([a-z])\s+км[^.?!]*в первый день[^.?!]*прош[её]л\s+([a-z])\s+км[^.?!]*во второй\s+([a-z])\s+км",
        lower,
    )
    if not match:
        return None
    total_symbol, first_symbol, second_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если в первый день турист прошёл {first_symbol} км, а во второй {second_symbol} км, то за два дня он прошёл {first_symbol} + {second_symbol} км.",
        f"2) Если турист должен пройти {total_symbol} км, а уже прошёл {first_symbol} + {second_symbol} км, то ему осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        f"Ответ: туристу осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        "Совет: в буквенной задаче сначала находят уже пройденный путь, потом вычитают его из всего пути.",
    )

def _final_letter_task_trains_passengers_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"прибыл[ао]?|прибыло", lower
    )
    if not match:
        return None
    match = re.search(
        r"на вокзал прибыл[ао]?\s+([a-z])\s+поезд[ао]в?\s+по\s+([a-z])\s+пассажир",
        lower,
    )
    if not match:
        return None
    trains_symbol, passengers_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если на вокзал прибыло {trains_symbol} поездов по {passengers_symbol} пассажиров в каждом, то всего прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        f"Ответ: прибыло {trains_symbol} × {passengers_symbol} пассажиров.",
        "Совет: если одно и то же количество повторяется несколько раз, используют умножение.",
    )

def _final_letter_task_garland_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зеленых|гирлянде\s+([a-z])\s+красных лампочек\s+и\s+([a-z])\s+зелёных",
        lower,
    )
    if not match:
        return None
    groups = [g for g in match.groups() if g]
    if len(groups) != 2:
        return None
    red_symbol, green_symbol = groups
    return join_explanation_lines(
        f"1) Чтобы узнать, во сколько раз зелёных лампочек больше, чем красных, нужно количество зелёных разделить на количество красных.",
        f"2) Значит, нужно вычислить {green_symbol} : {red_symbol}.",
        f"Ответ: в {green_symbol} : {red_symbol} раза.",
        "Совет: вопрос «во сколько раз» решают делением большего количества на меньшее.",
    )

def _final_letter_task_factories_total_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"один завод выпустил\s+([a-z])\s+станков[^.?!]*в\s+([a-z])\s+раз\s+меньше",
        lower,
    )
    if not match:
        return None
    first_symbol, factor_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если один завод выпустил {first_symbol} станков, а второй в {factor_symbol} раз меньше, то второй завод выпустил {first_symbol} : {factor_symbol} станков.",
        f"2) Если первый завод выпустил {first_symbol} станков, а второй {first_symbol} : {factor_symbol} станков, то вместе они выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        f"Ответ: вместе заводы выпустили {first_symbol} + {first_symbol} : {factor_symbol} станков.",
        "Совет: если число дано через «в несколько раз меньше», сначала делят, а потом находят сумму.",
    )

def _final_letter_word_problem_explanation(raw_text: str) -> Optional[str]:
    return (
        _final_letter_task_shelf_more_explanation(raw_text)
        or _final_letter_task_tourist_remaining_explanation(raw_text)
        or _final_letter_task_trains_passengers_explanation(raw_text)
        or _final_letter_task_garland_ratio_explanation(raw_text)
        or _final_letter_task_factories_total_explanation(raw_text)
    )

SYSTEM_PROMPT = SYSTEM_PROMPT + "\nЕсли в задаче вместо чисел стоят буквы, решай её теми же школьными методами и давай ответ буквенным выражением."

_FINAL_20260412F_PREV_BUILD_EXPLANATION_LOCAL_FIRST = build_explanation_local_first

def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    return (
        _final_letter_word_problem_explanation(user_text)
        or _FINAL_20260412F_PREV_BUILD_EXPLANATION_LOCAL_FIRST(user_text, kind)
    )

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи.",
            "Запишите пример или задачу полнее и без сокращений.",
            "Ответ: пока нужен более понятный ввод.",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 2400,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- PATCH 2026-04-12F1: robust tourist-letter task ---

def _final_letter_task_tourist_remaining_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    match = re.search(
        r"турист должен пройти\s+([a-z])\s+км[\s\S]*?в первый день[\s\S]*?прош[её]л\s+([a-z])\s+км[\s\S]*?во второй[\s\S]*?([a-z])\s+км",
        lower,
    )
    if not match:
        return None
    total_symbol, first_symbol, second_symbol = match.groups()
    return join_explanation_lines(
        f"1) Если в первый день турист прошёл {first_symbol} км, а во второй {second_symbol} км, то за два дня он прошёл {first_symbol} + {second_symbol} км.",
        f"2) Если турист должен пройти {total_symbol} км, а уже прошёл {first_symbol} + {second_symbol} км, то ему осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        f"Ответ: туристу осталось пройти {total_symbol} - ({first_symbol} + {second_symbol}) км.",
        "Совет: в буквенной задаче сначала находят уже пройденный путь, потом вычитают его из всего пути.",
    )

# --- USER FINAL CONSOLIDATION PATCH 2026-04-12G: fuller textbook answers, better known/question extraction ---

_USER_FINAL_20260412G_PREV_EXTRACT_CONDITION_AND_QUESTION = extract_condition_and_question

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку:
Порядок действий:
и ниже тот же пример, где над математическими знаками стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши строку:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. Если пример удобнее решать в столбик, сохраняй запись столбиком и подробное пояснение по шагам.
6. Вычисления в столбик используй, когда в выражении больше двух двузначных чисел или когда есть число из трёх и более цифр.
7. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом перепиши условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно пиши:
Что известно: ...
Что нужно найти: ...
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. В каждом действии, где это уместно, используй школьную форму:
Если ..., то ...
8. После каждого действия коротко говори, что нашли.
9. Если решение записывается по действиям, то в каждом действии, кроме последнего, полезно писать пояснение, что именно нашли.
10. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Если задача дана с именованными величинами, сначала переведи их в удобные одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если это выражение, сначала назови порядок действий.
Если это уравнение, оставляй x отдельно и объясняй обратное действие.
Если это геометрия, сначала назови формулу, потом подставь числа.
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
""".strip()

def _user_final_is_short_answer_value(text: str) -> bool:
    value = str(text or "").strip().rstrip(".")
    if not value:
        return False
    return bool(re.fullmatch(r"-?\d+(?:/\d+)?(?:\s+[A-Za-zА-Яа-яЁё./²%-]+){0,3}", value))

def _user_final_answer_phrase_from_question(answer: str, raw_text: str, kind: str) -> str:
    value = str(answer or "").strip().rstrip(".")
    if not value:
        return value
    if not _user_final_is_short_answer_value(value):
        return value

    question = _question_lower_text(raw_text).lower().replace("ё", "е")

    if question.startswith("во сколько раз"):
        return value if value.startswith("в ") else f"в {value}"

    if re.search(r"\bсколько[^.?!]*\bзабрали\b", question):
        return f"забрали {value}"
    if re.search(r"\bсколько[^.?!]*\bотдали\b", question):
        return f"отдали {value}"
    if re.search(r"\bсколько[^.?!]*\bсъели\b", question):
        return f"съели {value}"
    if re.search(r"\bсколько[^.?!]*\bпродали\b", question):
        return f"продали {value}"
    if re.search(r"\bсколько[^.?!]*\bдобавили\b", question):
        return f"добавили {value}"
    if re.search(r"\bсколько[^.?!]*\bзаболел[аои]?\b", question):
        return f"заболело {value}"
    if re.search(r"\bсколько[^.?!]*\bостал(?:ось|ись|ся)\b", question):
        return f"осталось {value}"
    if re.search(r"\bсколько[^.?!]*\bстал(?:о|и)\b", question):
        return f"стало {value}"
    if re.search(r"\bсколько[^.?!]*\bпотребуется\b", question) or re.search(r"\bсколько[^.?!]*\bпотребовалось\b", question):
        return f"потребуется {value}"
    if re.search(r"\bсколько[^.?!]*\bможно купить\b", question):
        return f"можно купить {value}"

    price_one = re.search(r"\bсколько\s+стоит\s+(?:1|один|одна|одно)\s+([а-яё-]+)", question)
    if price_one:
        return f"{price_one.group(1)} стоит {value}"

    price_many = re.search(r"\bсколько\s+стоят\s+(.+)$", question)
    if price_many:
        subject = price_many.group(1).strip(" ?")
        if subject:
            return f"{subject} стоят {value}"

    if re.search(r"\bс какой скоростью\b|\bкакова скорость\b|\bчему равна скорость\b", question):
        return f"скорость равна {value}"
    if re.search(r"\bкакое расстояние\b|\bкаково расстояние\b|\bчему равно расстояние\b", question):
        return f"расстояние равно {value}"
    if re.search(r"\bсколько времени\b|\bза какое время\b|\bсколько часов\b", question):
        return f"время равно {value}"
    if re.search(r"\bчему равна площадь\b|\bнайти площадь\b|\bузнайте площадь\b", question):
        return f"площадь равна {value}"
    if re.search(r"\bчему равен периметр\b|\bнайти периметр\b|\bузнайте периметр\b", question):
        return f"периметр равен {value}"

    shelf_match = re.search(r"\bсколько[^.?!]*\bна\s+(первой|второй|третьей)\s+полке\b", question)
    if shelf_match:
        return f"на {shelf_match.group(1)} полке было {value}"

    day_match = re.search(r"\bсколько[^.?!]*\bво\s+(первый|второй|третий)\s+день\b", question)
    if day_match:
        return f"в {day_match.group(1)} день {value}"

    if question.startswith("сколько денег"):
        return f"заплатили {value}"

    return value

def _detailed_format_word_like_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    statement = _detailed_statement_text(raw_text)
    info_lines: List[str] = []
    body_lines: List[str] = []

    for line in parts["body"]:
        lower = line.lower()
        if lower.startswith("что известно:") or lower.startswith("что нужно найти:"):
            info_lines.append(line)
        else:
            body_lines.append(line)

    if not info_lines:
        condition, question = extract_condition_and_question(raw_text)
        if condition:
            info_lines.append(f"Что известно: {condition}")
        if question:
            info_lines.append(f"Что нужно найти: {question}")

    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    answer = _user_final_answer_phrase_from_question(answer, raw_text, kind)

    lines: List[str] = []
    if statement:
        lines.append("Задача.")
        lines.append(statement)
    lines.append("Решение.")
    lines.extend(info_lines)
    lines.extend(_detailed_number_lines(body_lines))
    if parts["check"]:
        lines.append(parts["check"])
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind if kind in DEFAULT_ADVICE else "other")
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

def _detailed_format_generic_solution(raw_text: str, base_text: str, kind: str) -> str:
    parts = _detailed_split_sections(base_text)
    lines: List[str] = []
    statement = _detailed_statement_text(raw_text)
    if statement and kind in {"word", "geometry"}:
        lines.append("Задача.")
        lines.append(statement)
        lines.append("Решение.")
    else:
        lines.append("Решение.")
    lines.extend(_detailed_number_lines(parts["body"]))
    if parts["check"]:
        lines.append(parts["check"])
    answer = _detailed_maybe_enrich_answer(parts["answer"], raw_text, kind) or "проверь запись"
    answer = _user_final_answer_phrase_from_question(answer, raw_text, kind)
    lines.append(f"Ответ: {answer}")
    advice = parts["advice"] or default_advice(kind)
    lines.append(f"Совет: {advice}")
    return _detailed_finalize_text(lines)

async def build_explanation(user_text: str) -> dict:
    kind = infer_task_kind(user_text)
    local_explanation = build_explanation_local_first(user_text, kind)
    if local_explanation:
        formatted = _detailed_format_solution(user_text, local_explanation, kind)
        return {"result": formatted, "source": "local", "validated": True}

    if not DEEPSEEK_API_KEY:
        fallback = join_explanation_lines(
            "Не удалось подобрать готовый локальный шаблон для этой записи.",
            "Запишите пример или задачу полнее и без сокращений.",
            "Ответ: пока нужен более понятный ввод.",
            "Совет: пишите условие полностью, со всеми числами и вопросом",
        )
        return {"result": _detailed_format_solution(user_text, fallback, kind), "source": "fallback", "validated": False}

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": 2600,
        "temperature": 0.03,
    }
    llm_result = await call_deepseek(payload, timeout_seconds=45.0)
    if llm_result.get("error"):
        return llm_result
    formatted = _detailed_format_solution(user_text, llm_result["result"], kind)
    return {"result": formatted, "source": "llm", "validated": False}

# --- USER FINAL HOTFIX 2026-04-12H: geometry known-line extraction for "найти ..." formulations ---

_USER_FINAL_20260412H_PREV_EXTRACT_CONDITION_AND_QUESTION = extract_condition_and_question

# --- USER DELIVERY PATCH 2026-04-13: fuller final answers, architecture preserved ---

_PREV_USER_DELIVERY_ANSWER_PHRASE = _user_final_answer_phrase_from_question

def _user_final_answer_phrase_from_question(answer: str, raw_text: str, kind: str) -> str:
    original_value = str(answer or '').strip().rstrip('.')
    base = _PREV_USER_DELIVERY_ANSWER_PHRASE(answer, raw_text, kind)
    if not original_value:
        return base
    if not _user_final_is_short_answer_value(original_value):
        return base
    if str(base).strip().rstrip('.') != original_value:
        return base

    question = _question_lower_text(raw_text).lower().replace('ё', 'е').strip(' ?.')

    if question.startswith('сколько'):
        if ' было ' in f' {question} ' or question.endswith(' было'):
            if re.search(r'\b(кг|г|л|м|см|дм|мм|км|руб|листов|книг|клеток|деревьев|фруктов|деталей)\b', question) or 'всего' in question:
                return f'всего было {original_value}'
            return f'было {original_value}'
        if ' осталось ' in f' {question} ' or question.endswith(' осталось'):
            return f'осталось {original_value}'
        if ' стало ' in f' {question} ' or question.endswith(' стало'):
            return f'стало {original_value}'
        if re.search(r'\bсколько[^?]*\bклеток\b', question):
            return f'было {original_value}'
        if re.search(r'\bсколько[^?]*\bкоробок\b', question):
            return f'получилось {original_value}'
        if re.search(r'\bсколько[^?]*\bмешков\b', question):
            return f'было {original_value}'
        if re.search(r'\bсколько[^?]*\bкниг\b', question) and ('на полках' in question or 'на двух полках' in question or 'на трех полках' in question or 'на трёх полках' in question):
            return f'всего было {original_value}'
        if re.search(r'\bсколько[^?]*\bфруктов\b', question) and ('в ларьке' in question or 'в магазине' in question or 'было' in question):
            return f'всего было {original_value}'

    return base

# --- USER PATCH 2026-04-13I: DeepSeek-only topic rules + detailed first incomplete dividend ---

_USER_PATCH_20260413I_PREV_BUILD_EXPLANATION = build_explanation

_RULE_STYLE_HINTS = (
    "Сформулируй правило как короткое определение.",
    "Сформулируй правило как краткое правило действия.",
    "Сформулируй правило как учебное напоминание по теме.",
)

def _strip_rule_lines(text: str) -> str:
    kept: List[str] = []
    for raw in str(text or "").replace("\r", "").split("\n"):
        line = raw.strip()
        if re.match(r"^(?:совет|правило)\s*:\s*", line, flags=re.IGNORECASE):
            continue
        kept.append(raw.rstrip())
    while kept and not kept[-1].strip():
        kept.pop()
    return "\n".join(kept).strip()

def _normalize_rule_text(text: str) -> str:
    cleaned = sanitize_model_text(str(text or ""))
    for raw in cleaned.replace("\r", "").split("\n"):
        line = raw.strip().strip('"').strip("' ")
        if not line:
            continue
        line = re.sub(r"^(?:совет|правило)\s*:\s*", "", line, flags=re.IGNORECASE).strip()
        line = re.sub(r"\s+", " ", line)
        line = line.rstrip(" .!?")
        if not line:
            continue
        if len(line) > 220:
            line = line[:220].rstrip(" ,;:")
        return line
    return ""

def _append_rule_line(text: str, rule: str) -> str:
    base = _strip_rule_lines(text)
    normalized_rule = _normalize_rule_text(rule)
    if not normalized_rule:
        return base
    rule_line = _detailed_finalize_line(f"Совет: {normalized_rule}")
    if not base:
        return rule_line
    return f"{base}\n{rule_line}".strip()

def _compare_first_incomplete_candidate(candidate: int, divisor: int) -> str:
    if candidate < divisor:
        return f"{candidate} меньше {divisor} – не подходит"
    if candidate == divisor:
        return f"{candidate} равно {divisor} – подходит"
    return f"{candidate} больше {divisor} – подходит"

def _first_incomplete_dividend_intro_lines(dividend: int, divisor: int) -> Tuple[str, str]:
    dividend_text = str(abs(int(dividend)))
    divisor_text = str(abs(int(divisor)))
    if not dividend_text or not divisor_text or divisor <= 0:
        return (
            "Определяем первое неполное делимое. Оно должно быть больше или равно делителю.",
            "Подобрали первое неполное делимое.",
        )

    start_length = min(len(dividend_text), max(1, len(divisor_text)))
    prefix_length = start_length
    candidate = int(dividend_text[:prefix_length])
    fragments: List[str] = []

    while prefix_length < len(dividend_text) and candidate < divisor:
        fragments.append(_compare_first_incomplete_candidate(candidate, divisor))
        prefix_length += 1
        candidate = int(dividend_text[:prefix_length])

    candidate_phrase = _compare_first_incomplete_candidate(candidate, divisor)
    if not fragments or fragments[-1] != candidate_phrase:
        fragments.append(candidate_phrase)

    if fragments:
        first_line = (
            "Определяем первое неполное делимое. Оно должно быть больше или равно делителю. "
            f"Подбираем: {', '.join(fragments)}."
        )
    else:
        first_line = "Определяем первое неполное делимое. Оно должно быть больше или равно делителю."

    second_line = f"Подобрали первое неполное делимое {candidate}."
    return first_line, second_line

def explain_long_division(dividend: int, divisor: int) -> str:
    if divisor == 0:
        return join_explanation_lines(
            "На ноль делить нельзя",
            "Ответ: деление на ноль невозможно",
        )

    quotient, remainder = divmod(dividend, divisor)
    model = build_long_division_steps(dividend, divisor)
    steps = model.get("steps", [])

    if not steps:
        lines = [
            "Пишем деление столбиком",
            f"Число {dividend} меньше {divisor}, поэтому в частном будет 0",
        ]
        if remainder:
            lines.append(f"Остаток равен {remainder}")
            return join_explanation_lines(*lines, f"Ответ: 0, остаток {remainder}")
        return join_explanation_lines(*lines, "Ответ: 0")

    intro_line, picked_line = _first_incomplete_dividend_intro_lines(dividend, divisor)
    lines: List[str] = [
        "Пишем деление столбиком",
        intro_line,
        picked_line,
    ]

    for index, step in enumerate(steps):
        current = int(step["current"])
        q_digit = int(step["q_digit"])
        product = int(step["product"])
        remainder_here = int(step["remainder"])
        next_try = (q_digit + 1) * divisor
        next_step = steps[index + 1] if index + 1 < len(steps) else None

        if index > 0:
            lines.append(f"Теперь работаем с числом {current}")

        if next_try > current:
            lines.append(
                f"Смотрим, сколько раз {divisor} помещается в {current}. Берём {q_digit}, потому что {q_digit} × {divisor} = {product}, а {q_digit + 1} × {divisor} = {next_try}, это уже больше"
            )
        else:
            lines.append(
                f"Смотрим, сколько раз {divisor} помещается в {current}. Берём {q_digit}, потому что {q_digit} × {divisor} = {product}"
            )

        lines.append(f"Пишем {q_digit} в частном и вычитаем {product} из {current}. Остаётся {remainder_here}")

        if next_step is not None:
            lines.append(f"Сносим следующую цифру и получаем {int(next_step['current'])}")
        elif remainder_here == 0:
            lines.append("Деление закончено без остатка")
        else:
            lines.append(f"Получаем остаток {remainder_here}. Он меньше делителя, значит деление закончено")

    if remainder == 0:
        lines.append(f"Читаем ответ: частное равно {quotient}")
        return join_explanation_lines(*lines, f"Ответ: {quotient}")

    lines.append(f"Читаем ответ: частное равно {quotient}, остаток {remainder}")
    return join_explanation_lines(*lines, f"Ответ: {quotient}, остаток {remainder}")

async def _generate_topic_rule_with_deepseek(user_text: str, formatted_text: str, kind: str) -> str:
    if not DEEPSEEK_API_KEY:
        return ""

    import random

    compact_solution = _strip_rule_lines(formatted_text)
    style_hint = random.choice(_RULE_STYLE_HINTS)

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {
                "role": "system",
                "content": (
                    "Ты — учитель математики для детей 7–10 лет. "
                    "По задаче и уже готовому решению напиши одно краткое понятное математическое правило по теме именно этого решения. "
                    "Это должно быть правило, определение или учебное напоминание по применённому приёму, а не общий совет про аккуратность. "
                    "Пиши только по-русски. "
                    "Верни только текст правила без слова 'Совет:' и без markdown. "
                    "Допустимы 1–2 коротких предложения. "
                    "Старайся формулировать по-разному, но точно по теме."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Тип задания: {kind}\n"
                    f"Запись ученика: {user_text}\n"
                    f"Готовое решение:\n{compact_solution}\n\n"
                    "Нужно дать одно краткое правило по теме вычисления, которое реально применялось в этом решении.\n"
                    f"{style_hint}"
                ),
            },
        ],
        "max_tokens": 120,
        "temperature": 0.55,
    }

    llm_result = await call_deepseek(payload, timeout_seconds=20.0)
    if llm_result.get("error"):
        return ""
    return _normalize_rule_text(llm_result.get("result", ""))

async def build_explanation(user_text: str) -> dict:
    result = await _USER_PATCH_20260413I_PREV_BUILD_EXPLANATION(user_text)
    if not isinstance(result, dict) or "result" not in result:
        return result

    kind = infer_task_kind(user_text)
    stripped_text = _strip_rule_lines(str(result.get("result") or ""))

    rule_text = ""
    if DEEPSEEK_API_KEY:
        rule_text = await _generate_topic_rule_with_deepseek(user_text, stripped_text, kind)

    final_text = _append_rule_line(stripped_text, rule_text) if rule_text else stripped_text
    updated = dict(result)
    updated["result"] = final_text
    return updated

# --- USER PATCH 2026-04-13J: exact mixed-expression steps and complete column sequence ---

def _patch_20260413j_should_use_column_for_step(step: dict, source: str) -> bool:
    left = _patch_20260412c_parse_int_text(step.get("left", ""))
    right = _patch_20260412c_parse_int_text(step.get("right", ""))
    operator = step.get("operator")

    if left is None or right is None:
        return False

    abs_left = abs(left)
    abs_right = abs(right)

    if operator == "+":
        return abs_left >= 100 or abs_right >= 100 or (abs_left >= 10 and abs_right >= 10)
    if operator == "-":
        if left < 0 or right < 0 or left < right:
            return False
        return abs_left >= 100 or abs_right >= 100 or (abs_left >= 10 and abs_right >= 10)
    if operator == "×":
        return abs_left >= 10 or abs_right >= 10
    if operator == ":":
        if right == 0:
            return False
        return abs_left >= 100 or abs_right >= 10
    return False

_PATCH_20260413J_ACTION_NAMES = {
    "×": "умножение",
    ":": "деление",
}

def _patch_20260413j_pretty_operator(operator: str) -> str:
    if operator in {"*", "x", "X", "х", "Х", "×"}:
        return "×"
    if operator in {"/", ":", "÷"}:
        return ":"
    if operator in {"-", "−", "–"}:
        return "–"
    return operator

def _patch_20260413j_step_header(index: int, operator: str, left: str, right: str, result: str) -> str:
    pretty_operator = _patch_20260413j_pretty_operator(operator)
    expression = f"{left} {pretty_operator} {right}".strip()
    if result:
        return f"{index}) {expression} = {result}."
    return f"{index}) {expression}."

# переопределяем критерий выбора столбика для смешанных выражений
_patch_20260412c_should_use_column_for_step = _patch_20260413j_should_use_column_for_step

def _patch_20260412c_render_mixed_expression_solution(source: str) -> Optional[str]:
    node = parse_expression_ast(source)
    if node is None:
        return None

    steps = _detailed_collect_expression_steps(node, source)
    if len(steps) <= 1:
        return None

    pretty_expression = _user_final_patch_pretty_expression_from_source(source)
    answer = _detailed_expression_answer(source) or "проверь запись"

    lines: List[str] = [f"Пример: {pretty_expression} = {answer}."]
    order_block = _detailed_build_order_block(source)
    if order_block:
        lines.extend(order_block)
    lines.append("Решение по действиям:")

    for index, step in enumerate(steps, start=1):
        left = str(step.get("left", "")).strip()
        right = str(step.get("right", "")).strip()
        operator = str(step.get("operator", "")).strip()
        result = str(step.get("result", "")).strip()

        lines.append(_patch_20260413j_step_header(index, operator, left, right, result))

        use_column = _patch_20260412c_should_use_column_for_step(step, source)
        if not use_column:
            continue

        detailed = _patch_20260412c_step_explanation_text(step)
        if not detailed:
            continue

        parts = _detailed_split_sections(detailed)
        column_block, remaining_body = _split_ascii_layout_block(parts.get("body", []))
        cleaned_body = _patch_20260412c_clean_body_lines(remaining_body)

        if column_block:
            lines.extend(column_block)
        if cleaned_body:
            lines.extend(cleaned_body)

    lines.append(f"Ответ: {answer}")
    return _detailed_finalize_text(lines)

# --- USER PATCH 2026-04-14A: primary-school equation explanations with numbered steps ---

def _eq_math_line(text: str) -> str:
    return str(text or '').strip().replace('/', ':').replace('*', '×')

def _eq_transfer_name(operator_kind: str) -> Tuple[str, str]:
    mapping = {
        'plus': ('+', '-'),
        'minus': ('-', '+'),
        'mul': ('умножения', 'деление'),
        'div': ('деления', 'умножение'),
    }
    return mapping.get(operator_kind, ('знак', 'обратный знак'))

def _eq_transfer_step(variable_name: str, moved_number: str, rhs_text: str, result_expr: str, operator_kind: str) -> List[str]:
    sign_name, changed_to = _eq_transfer_name(operator_kind)
    return [
        f"1) Неизвестное {variable_name} оставляем слева, а число {moved_number} переносим вправо. При переносе знак {sign_name} меняется на {changed_to}:",
        _eq_math_line(f"{variable_name} = {result_expr}"),
    ]

def _eq_compute_and_answer_steps(variable_name: str, answer: Fraction, start_index: int = 2) -> List[str]:
    answer_text = format_fraction(answer)
    return [
        f"{start_index}) Считаем:",
        _eq_math_line(f"{variable_name} = {answer_text}"),
        f"Ответ: {answer_text}",
    ]
