"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 7840-8736."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _user_final_patch_try_geometry_formula_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    question = _question_lower_text(raw_text)
    unit = geometry_unit(lower)
    nums = extract_ordered_numbers(lower)

    asks_area = "площад" in question or "найти площадь" in lower or "узнайте площадь" in lower
    asks_perimeter = "периметр" in question or "найти периметр" in lower or "узнайте периметр" in lower

    if "прямоугольник" in lower and "со сторонами" in lower and len(nums) >= 2 and (asks_area or asks_perimeter):
        a, b = nums[0], nums[1]
        area = a * b
        perimeter = 2 * (a + b)
        lines: List[str] = []
        if asks_area:
            lines.append("1) Формула площади прямоугольника: S = a × b")
            lines.append(f"2) Подставляем числа: S = {a} × {b} = {with_unit(area, unit, square=True)}")
        if asks_perimeter:
            start_index = 3 if asks_area else 1
            lines.append(f"{start_index}) Формула периметра прямоугольника: P = 2 × (a + b)")
            lines.append(f"{start_index + 1}) Подставляем числа: P = 2 × ({a} + {b}) = {with_unit(perimeter, unit)}")
        if asks_area and asks_perimeter:
            lines.append(f"Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}")
        elif asks_area:
            lines.append(f"Ответ: {with_unit(area, unit, square=True)}")
        else:
            lines.append(f"Ответ: {with_unit(perimeter, unit)}")
        lines.append("Совет: у прямоугольника сначала называют формулу, потом подставляют числа")
        return join_explanation_lines(*lines)

    if "квадрат" in lower and len(nums) >= 1 and ("сторон" in lower or "сторона" in lower) and (asks_area or asks_perimeter):
        side = nums[0]
        area = side * side
        perimeter = side * 4
        lines = []
        if asks_area:
            lines.append("1) Формула площади квадрата: S = a × a")
            lines.append(f"2) Подставляем числа: S = {side} × {side} = {with_unit(area, unit, square=True)}")
        if asks_perimeter:
            start_index = 3 if asks_area else 1
            lines.append(f"{start_index}) Формула периметра квадрата: P = 4 × a")
            lines.append(f"{start_index + 1}) Подставляем числа: P = 4 × {side} = {with_unit(perimeter, unit)}")
        if asks_area and asks_perimeter:
            lines.append(f"Ответ: площадь — {with_unit(area, unit, square=True)}; периметр — {with_unit(perimeter, unit)}")
        elif asks_area:
            lines.append(f"Ответ: {with_unit(area, unit, square=True)}")
        else:
            lines.append(f"Ответ: {with_unit(perimeter, unit)}")
        lines.append("Совет: у квадрата площадь и периметр находят по стороне")
        return join_explanation_lines(*lines)

    return None



# --- USER FINAL PATCH 2026-04-11ZZ2: restore explicit column block for long division ---

_USER_FINAL_PATCH_ZZ2_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION = _detailed_format_expression_solution

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    source = to_expression_source(raw_text)
    if not source:
        return _USER_FINAL_PATCH_ZZ2_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

    node = parse_expression_ast(source)
    simple = try_simple_binary_int_expression(node) if node is not None else None
    parts = _detailed_split_sections(base_text)
    body_lines = [
        line for line in parts.get("body", [])
        if not line.lower().startswith(("что известно:", "что нужно найти:"))
    ]

    if simple and simple["operator"] is ast.Div and any("столбик" in line.lower() for line in body_lines):
        pretty_expr = _user_final_patch_pretty_expression_from_source(source)
        answer = parts.get("answer") or _detailed_expression_answer(source) or "проверь запись"
        advice = parts.get("advice") or default_advice("expression")
        lines = [
            f"Пример: {pretty_expr} = {answer}",
            "Решение.",
            "Запись столбиком:",
            f"{simple['right']} | {simple['left']}",
            "Пояснение по шагам:",
        ]
        lines.extend(_detailed_number_lines(body_lines))
        lines.append(f"Ответ: {answer}")
        lines.append(f"Совет: {advice}")
        return _detailed_finalize_text(lines)

    return _USER_FINAL_PATCH_ZZ2_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

# --- OPENAI FINAL PATCH 2026-04-11C: textbook-style compound wording + bucket-word detection ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. В конце пиши:
Ответ: ...
6. Если пример удобнее решать в столбик, сохрани запись столбиком и подробное пояснение по шагам.
7. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие задачи без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Если задача составная, решай только по действиям.
5. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
6. В каждом действии, где это возможно, используй школьную форму:
Если ..., то ...
7. После каждого действия коротко говори, что нашли.
8. В конце пиши:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Важные требования:
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Если в задаче два вопроса, ответь на оба по порядку.
Для многодейственных задач не перескакивай сразу к ответу.
Сначала действие, потом пояснение, потом следующее действие.
""".strip()

_BUCKET_STEM_TO_NUM = {
    "одн": 1,
    "одно": 1,
    "двух": 2,
    "трех": 3,
    "трёх": 3,
    "четырех": 4,
    "четырёх": 4,
    "пяти": 5,
    "шести": 6,
    "семи": 7,
    "восьми": 8,
    "девяти": 9,
    "десяти": 10,
}

def _extract_bucket_sizes_from_text(text: str) -> List[int]:
    lower = str(text or "").lower()
    values: List[int] = []

    for match in re.finditer(r"(\d+)\s*-\s*литров", lower):
        values.append(int(match.group(1)))

    for match in re.finditer(r"\b(\d+)литров", lower):
        values.append(int(match.group(1)))

    for match in re.finditer(r"\b([а-яё]+)литров", lower):
        stem = match.group(1)
        value = _BUCKET_STEM_TO_NUM.get(stem)
        if value is not None:
            values.append(value)

    unique_values: List[int] = []
    for value in values:
        if value not in unique_values:
            unique_values.append(value)
    return unique_values

def explain_sum_then_divide_word_problem(first: int, second: int, divisor: int) -> Optional[str]:
    if divisor == 0:
        return None
    total = first + second
    quotient, remainder = divmod(total, divisor)
    if remainder == 0:
        return join_explanation_lines(
            f"1) Если первое количество равно {first}, а второе равно {second}, то всего {first} + {second} = {total}",
            f"2) Если всего {total}, а одна группа равна {divisor}, то {total} : {divisor} = {quotient}",
            f"Ответ: {quotient}",
            "Совет: если сначала объединяют две части, а потом делят на равные группы, сначала находят сумму",
        )
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе равно {second}, то всего {first} + {second} = {total}",
        f"2) Если {total} разделить на группы по {divisor}, то получится {quotient}, остаток {remainder}",
        f"Ответ: {quotient}, остаток {remainder}",
        "Совет: сначала находят общую сумму, а потом делят её на группы",
    )

def explain_cages_with_two_parts(first: int, second: int, total: int) -> Optional[str]:
    in_one = first + second
    if in_one == 0 or total % in_one != 0:
        return None
    cages = total // in_one
    return join_explanation_lines(
        f"1) Если в каждой клетке сидело {first} синих и {second} зелёных попугая, то в одной клетке было {first} + {second} = {in_one} попугаев",
        f"2) Если всего было {total} попугаев, а в одной клетке {in_one} попугаев, то клеток было {total} : {in_one} = {cages}",
        f"Ответ: {cages}",
        "Совет: если в каждой группе есть два вида предметов, сначала находят, сколько всего в одной группе",
    )



def explain_piece_lengths_from_total_and_costs(total_length: int, first_cost: int, second_cost: int) -> Optional[str]:
    if total_length == 0:
        return None
    total_cost = first_cost + second_cost
    if total_cost % total_length != 0:
        return None
    unit_price = total_cost // total_length
    if unit_price == 0 or first_cost % unit_price != 0 or second_cost % unit_price != 0:
        return None
    first_length = first_cost // unit_price
    second_length = second_cost // unit_price
    return join_explanation_lines(
        f"1) Если один кусок стоит {first_cost}, а другой {second_cost}, то общая стоимость равна {first_cost} + {second_cost} = {total_cost}",
        f"2) Если за {total_length} м ткани заплатили {total_cost}, то один метр стоит {total_cost} : {total_length} = {unit_price}",
        f"3) Если первый кусок стоит {first_cost}, а один метр стоит {unit_price}, то длина первого куска равна {first_cost} : {unit_price} = {first_length} м",
        f"4) Если второй кусок стоит {second_cost}, а один метр стоит {unit_price}, то длина второго куска равна {second_cost} : {unit_price} = {second_length} м",
        f"Ответ: в первом куске {first_length} м, во втором — {second_length} м",
        "Совет: если цена за единицу одинаковая, сначала находят цену одной единицы",
    )



def explain_water_buckets_difference(big_bucket: int, small_bucket: int, diff_total: int) -> Optional[str]:
    step_diff = abs(big_bucket - small_bucket)
    if step_diff == 0 or diff_total % step_diff != 0:
        return None
    trips = diff_total // step_diff
    big_total = big_bucket * trips
    small_total = small_bucket * trips
    return join_explanation_lines(
        f"1) Если мальчик носил воду {big_bucket}-литровым ведром, а девочка {small_bucket}-литровым, то мальчик за один раз приносил на {big_bucket} - {small_bucket} = {step_diff} л больше",
        f"2) Если всего мальчик принёс на {diff_total} л больше, а за один раз он приносил на {step_diff} л больше, то ходок было {diff_total} : {step_diff} = {trips}",
        f"3) Если девочка носила по {small_bucket} л и сделала {trips} ходок, то она принесла {small_bucket} × {trips} = {small_total} л",
        f"4) Если мальчик носил по {big_bucket} л и сделал {trips} ходок, то он принёс {big_bucket} × {trips} = {big_total} л",
        f"Ответ: мальчик принёс {big_total} л, девочка — {small_total} л",
        "Совет: если число ходок одинаковое, сначала находят разность за одну ходку",
    )

def explain_costs_from_length_difference(first_length: int, second_length: int, diff_cost: int) -> Optional[str]:
    diff_length = abs(second_length - first_length)
    if diff_length == 0 or diff_cost % diff_length != 0:
        return None
    price_per_meter = diff_cost // diff_length
    first_cost = first_length * price_per_meter
    second_cost = second_length * price_per_meter
    return join_explanation_lines(
        f"1) Если один кусок имеет длину {first_length} м, а другой {second_length} м, то разность длин равна {max(first_length, second_length)} - {min(first_length, second_length)} = {diff_length} м",
        f"2) Если разность стоимости равна {diff_cost} руб., а разность длин {diff_length} м, то один метр стоит {diff_cost} : {diff_length} = {price_per_meter} руб.",
        f"3) Если первый кусок имеет длину {first_length} м, а один метр стоит {price_per_meter} руб., то первый кусок стоит {first_length} × {price_per_meter} = {first_cost} руб.",
        f"4) Если второй кусок имеет длину {second_length} м, а один метр стоит {price_per_meter} руб., то второй кусок стоит {second_length} × {price_per_meter} = {second_cost} руб.",
        f"Ответ: первый кусок стоит {first_cost} руб., второй — {second_cost} руб.",
        "Совет: если цена ткани за метр одинаковая, сначала находят цену одного метра",
    )

_USER_20260411C_PREV_TRY_LOCAL_DIFFERENCE_UNKNOWN = try_local_difference_unknown_word_problem

def try_local_difference_unknown_word_problem(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    bucket_sizes = _extract_bucket_sizes_from_text(lower)
    if len(bucket_sizes) >= 2 and ("ведр" in lower or "бочк" in lower):
        diff_match = re.search(r"на\s+(\d+)\s+литр", lower)
        if diff_match:
            diff_total = int(diff_match.group(1))
            big_bucket = max(bucket_sizes[0], bucket_sizes[1])
            small_bucket = min(bucket_sizes[0], bucket_sizes[1])
            solved = explain_water_buckets_difference(big_bucket, small_bucket, diff_total)
            if solved:
                return solved

    return _USER_20260411C_PREV_TRY_LOCAL_DIFFERENCE_UNKNOWN(raw_text)

# --- OPENAI FINAL PATCH 2026-04-11D: labelled answers for proportional and two-difference tasks ---

def explain_equal_rate_distribution(total: int, first_count: int, second_count: int, first_label: str = "первая группа", second_label: str = "вторая группа") -> Optional[str]:
    group_total = first_count + second_count
    if group_total == 0 or total % group_total != 0:
        return None
    one_unit = total // group_total
    first_total = first_count * one_unit
    second_total = second_count * one_unit
    return join_explanation_lines(
        f"1) Если в первой группе {first_count} равных частей, а во второй {second_count} равных частей, то всего {first_count} + {second_count} = {group_total} равных частей",
        f"2) Если всё количество равно {total}, а равных частей {group_total}, то одна часть равна {total} : {group_total} = {one_unit}",
        f"3) Если одна часть равна {one_unit}, а в первой группе {first_count} частей, то {first_label} выполнила {one_unit} × {first_count} = {first_total}",
        f"4) Если одна часть равна {one_unit}, а во второй группе {second_count} частей, то {second_label} выполнила {one_unit} × {second_count} = {second_total}",
        f"Ответ: {first_label} — {first_total}; {second_label} — {second_total}",
        "Совет: в задачах на пропорциональное деление сначала находят одну равную часть",
    )

def explain_masses_from_bag_difference(first_bags: int, second_bags: int, diff_mass: int) -> Optional[str]:
    diff_bags = abs(first_bags - second_bags)
    if diff_bags == 0 or diff_mass % diff_bags != 0:
        return None
    per_bag = diff_mass // diff_bags
    first_mass = first_bags * per_bag
    second_mass = second_bags * per_bag
    return join_explanation_lines(
        f"1) Если на одном участке {first_bags} мешков, а на другом {second_bags} мешков, то разность равна {max(first_bags, second_bags)} - {min(first_bags, second_bags)} = {diff_bags} мешков",
        f"2) Если этим {diff_bags} мешкам соответствуют {diff_mass} кг, то в одном мешке {diff_mass} : {diff_bags} = {per_bag} кг",
        f"3) Если на первом участке {first_bags} мешков по {per_bag} кг, то всего собрали {first_bags} × {per_bag} = {first_mass} кг",
        f"4) Если на втором участке {second_bags} мешков по {per_bag} кг, то всего собрали {second_bags} × {per_bag} = {second_mass} кг",
        f"Ответ: с первого участка — {first_mass} кг, со второго — {second_mass} кг",
        "Совет: если известны разности по количеству и по массе, сначала находят массу одной равной части",
    )

# --- FINAL PATCH 2026-04-12: clearer column division + noun-aware price wording + explicit sum/divide tasks ---

_FINAL_20260412_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION = _detailed_format_expression_solution

def _final_20260412_question_lower(raw_text: str) -> str:
    return _question_text_only(raw_text).lower().replace("ё", "е").strip()

def _final_20260412_extract_price_subject(raw_text: str) -> Tuple[str, str]:
    question = _question_text_only(raw_text).strip().rstrip("?.!")
    lower = question.lower().replace("ё", "е")
    patterns = [
        (r"^сколько\s+стоит\s+(.+)$", "стоит"),
        (r"^сколько\s+стоят\s+(.+)$", "стоят"),
        (r"^сколько\s+стоила\s+(.+)$", "стоила"),
        (r"^сколько\s+стоили\s+(.+)$", "стоили"),
    ]
    for pattern, verb in patterns:
        match = re.match(pattern, lower)
        if match:
            subject = question[match.start(1):match.end(1)].strip()
            return subject, verb
    return "", ""





def _final_20260412_named_sum_then_divide_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    nums = extract_ordered_numbers(lower)
    if len(nums) < 3 or "сколько" not in lower:
        return None

    if ("грядк" in lower or "сняли" in lower) and ("корзин" in lower or "корзины" in lower or "корзина" in lower) and re.search(r"по\s+\d+\s*кг", lower):
        first, second, per_group = nums[0], nums[1], nums[2]
        total = first + second
        quotient, remainder = divmod(total, per_group)
        if remainder == 0:
            return join_explanation_lines(
                f"1) Если с одной грядки сняли {first} кг, а с другой {second} кг, то всего сняли {first} + {second} = {total} кг",
                f"2) Если всего собрали {total} кг моркови и раскладывали по {per_group} кг в каждую корзину, то потребовалось {total} : {per_group} = {quotient} корзин",
                f"Ответ: потребовалось {quotient} корзин",
                "Совет: если сначала объединяют две части, а потом раскладывают по равным группам, сначала находят общую массу",
            )
    return None

def _final_20260412_render_long_division_block(dividend: int, divisor: int) -> str:
    if divisor == 0:
        return ""
    model = build_long_division_steps(dividend, divisor)
    steps = model.get("steps", [])
    quotient = model.get("quotient")
    divisor_str = str(divisor)
    dividend_str = str(dividend)
    header_indent = len(divisor_str) + 3
    lines = [
        f"{' ' * header_indent}{quotient}",
        f"{divisor_str} ) {dividend_str}",
    ]
    if not steps:
        return "\n".join(lines)

    for index, step in enumerate(steps):
        current = str(step["current"])
        product = str(step["product"])
        remainder = str(step["remainder"])
        width = max(len(current), len(product), 1)
        start_col = step["index"] - len(current) + 1
        indent = header_indent + max(0, start_col)
        if index > 0:
            lines.append(" " * indent + current)
        lines.append(" " * (indent + width - len(product)) + product)
        lines.append(" " * indent + "-" * width)
        if index == len(steps) - 1:
            lines.append(" " * (indent + width - len(remainder)) + remainder)
    return "\n".join(lines)

def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    source = to_expression_source(raw_text)
    if not source:
        return _FINAL_20260412_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

    node = parse_expression_ast(source)
    simple = try_simple_binary_int_expression(node) if node is not None else None
    parts = _detailed_split_sections(base_text)
    body_lines = [
        line for line in parts.get("body", [])
        if not line.lower().startswith(("что известно:", "что нужно найти:"))
    ]

    if simple and simple["operator"] is ast.Div and any("пишем деление столбиком" in line.lower() for line in body_lines):
        pretty_expr = _user_final_patch_pretty_expression_from_source(source)
        answer = parts.get("answer") or _detailed_expression_answer(source) or "проверь запись"
        advice = parts.get("advice") or default_advice("expression")
        block = _final_20260412_render_long_division_block(simple["left"], simple["right"])
        lines = [
            f"Пример: {pretty_expr} = {answer}",
            "Решение.",
            "Запись столбиком:",
        ]
        lines.extend(block.splitlines())
        lines.append("Пояснение по шагам:")
        lines.extend(_detailed_number_lines(body_lines))
        lines.append(f"Ответ: {answer}")
        lines.append(f"Совет: {advice}")
        return _detailed_finalize_text(lines)

    return _FINAL_20260412_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)



# --- FINAL PATCH 2026-04-12B: support singular "стоит" in count-price wording ---


def _final_20260412_named_simple_price_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    subject, verb = _final_20260412_extract_price_subject(raw_text)

    # 6 ручек стоит 18 руб. Сколько стоит 1 ручка?
    cond_total_match = re.search(r"(\d+)\s+([а-яё-]+)\s+стои(?:т|ли|ло|ла)\s+(\d+)\s*руб", lower)
    if cond_total_match and verb in {"стоит", "стоила"}:
        count = int(cond_total_match.group(1))
        item_phrase = cond_total_match.group(2)
        total_cost = int(cond_total_match.group(3))
        if count > 0 and total_cost % count == 0:
            price = total_cost // count
            answer_subject = subject or "1 предмет"
            return join_explanation_lines(
                f"1) Если {count} {item_phrase} стоят {total_cost} руб., то цена одной штуки равна {total_cost} : {count} = {price} руб",
                f"Ответ: {answer_subject} стоит {price} руб",
                "Совет: цену одной штуки находят делением общей стоимости на количество",
            )

    # Книга стоит 50 рублей. Сколько стоят 6 таких книг?
    cond_one_match = re.search(r"([а-яё-]+)\s+стоит\s+(\d+)\s*(?:руб|рубля|рублей)", lower)
    qty_match = re.search(r"сколько\s+стоят\s+(\d+|один|одна|одно|две|два|три|четыре|пять|шесть|семь|восемь|девять|десять)", lower)
    if cond_one_match and qty_match and verb in {"стоят", "стоили"}:
        item_phrase = cond_one_match.group(1)
        price = int(cond_one_match.group(2))
        quantity = parse_number_token(qty_match.group(1))
        if quantity is not None:
            total_cost = price * quantity
            answer_subject = subject or f"{quantity} {item_phrase}"
            return join_explanation_lines(
                f"1) Если одна {item_phrase} стоит {price} руб., а купили {quantity}, то вся покупка стоит {price} × {quantity} = {total_cost} руб",
                f"Ответ: {answer_subject} стоят {total_cost} руб",
                "Совет: стоимость находят умножением цены на количество",
            )

    return None



# --- OPENAI PATCH 2026-04-12: strict school order for mixed expressions ---

def _oai_20260412_flatten_add_sub_chain(node: ast.AST) -> Tuple[List[ast.AST], List[ast.BinOp]]:
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
        operands, ops = _oai_20260412_flatten_add_sub_chain(node.left)
        return operands + [node.right], ops + [node]
    return [node], []

def _oai_20260412_flatten_mul_div_chain(node: ast.AST) -> Tuple[List[ast.AST], List[ast.BinOp]]:
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Mult, ast.Div)):
        operands, ops = _oai_20260412_flatten_mul_div_chain(node.left)
        return operands + [node.right], ops + [node]
    return [node], []

def _oai_20260412_apply_operator(op: ast.operator, left: Fraction, right: Fraction) -> Fraction:
    if isinstance(op, ast.Add):
        return left + right
    if isinstance(op, ast.Sub):
        return left - right
    if isinstance(op, ast.Mult):
        return left * right
    if isinstance(op, ast.Div):
        if right == 0:
            raise ZeroDivisionError("division by zero")
        return left / right
    raise ValueError("Unsupported operator")

def _oai_20260414_expression_step_depth(source: str, position: Optional[int]) -> int:
    if not isinstance(position, int) or position < 0:
        return 0
    depth = 0
    for index, char in enumerate(source):
        if index >= position:
            break
        if char == '(':
            depth += 1
        elif char == ')' and depth > 0:
            depth -= 1
    return depth

def _oai_20260414_expression_step_precedence(operator: str) -> int:
    if operator in {'×', ':', '÷', '*', '/'}:
        return 0
    return 1

def _oai_20260414_sort_expression_steps(steps: List[dict], source: str) -> List[dict]:
    def _step_key(step: dict):
        position = step.get('pos') if isinstance(step, dict) else None
        operator = str(step.get('operator', '')) if isinstance(step, dict) else ''
        return (
            -_oai_20260414_expression_step_depth(source, position),
            _oai_20260414_expression_step_precedence(operator),
            position if isinstance(position, int) else 10 ** 9,
        )

    return sorted(steps, key=_step_key)

def _oai_20260412_eval_expression_school(node: ast.AST, source: Optional[str] = None):
    if is_int_literal_node(node):
        return eval_fraction_node(node), []
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return eval_fraction_node(node), []
    if not isinstance(node, ast.BinOp):
        return eval_fraction_node(node), []

    if isinstance(node.op, (ast.Mult, ast.Div)):
        operands, op_nodes = _oai_20260412_flatten_mul_div_chain(node)
    else:
        operands, op_nodes = _oai_20260412_flatten_add_sub_chain(node)

    operand_values: List[Fraction] = []
    steps: List[dict] = []

    for operand in operands:
        value, child_steps = _oai_20260412_eval_expression_school(operand, source)
        steps.extend(child_steps)
        operand_values.append(value)

    current_value = operand_values[0]
    for op_node, next_value in zip(op_nodes, operand_values[1:]):
        result_value = _oai_20260412_apply_operator(op_node.op, current_value, next_value)
        step = {
            "verb": OPERATOR_VERBS[type(op_node.op)],
            "left": format_fraction(current_value),
            "operator": OPERATOR_SYMBOLS[type(op_node.op)],
            "right": format_fraction(next_value),
            "result": format_fraction(result_value),
        }
        if source is not None:
            step["pos"] = _detailed_find_operator_position(source, op_node)
        steps.append(step)
        current_value = result_value

    return current_value, steps

def build_eval_steps(node: ast.AST, source: Optional[str] = None):
    value, steps = _oai_20260412_eval_expression_school(node, source)
    if source:
        steps = _oai_20260414_sort_expression_steps(steps, source)
    return value, steps

def format_step_lines(steps, raw_source: str):
    lines = []
    has_brackets = "(" in raw_source or ")" in raw_source
    for index, step in enumerate(steps):
        text = f"{step['left']} {step['operator']} {step['right']} = {step['result']}"
        prefix = "Сначала" if index == 0 else "Потом" if index == 1 else "Дальше"
        if index == 0 and has_brackets and len(steps) > 1:
            lines.append(f"Сначала выполняем действие в скобках: {text}")
        else:
            lines.append(f"{prefix} {step['verb']}: {text}")
    return lines

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. В выражениях без скобок, где есть только + и -, выполняй действия слева направо.
4. В выражениях без скобок, где есть только × и :, выполняй действия слева направо.
5. В выражениях со скобками первым выполняй действие в скобках.
6. В выражениях, где есть +, -, ×, :, сначала по порядку выполняй все умножения и деления, а потом по порядку сложения и вычитания.
7. Потом пиши:
Решение по действиям:
8. Ниже пиши все вычисления по действиям:
1) ...
2) ...
3) ...
9. Если пример удобнее решать в столбик, сохрани запись столбиком и подробное пояснение по шагам.
10. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.
11. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом само условие без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай только по действиям.
5. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
6. По возможности используй школьную форму:
Если ..., то ...
7. После каждого действия коротко говори, что нашли.
8. Если задача составная, не перескакивай к ответу: сначала найди промежуточные величины.
9. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.

Важные требования:
Если запись непонятная или это не задача по математике, попроси записать задачу понятнее.
Если в задаче два вопроса, ответь на оба по порядку.
Для многодейственных задач не перескакивай сразу к ответу.
Сначала действие, потом пояснение, потом следующее действие.
""".strip()

# --- FINAL PATCH 2026-04-12C: column steps inside mixed multi-step expressions ---

_PATCH_20260412C_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION = _detailed_format_expression_solution

_PATCH_20260412C_ORDINAL_WORDS = {
    1: "Первое",
    2: "Второе",
    3: "Третье",
    4: "Четвертое",
    5: "Пятое",
    6: "Шестое",
    7: "Седьмое",
    8: "Восьмое",
}

def _patch_20260412c_parse_int_text(value: str) -> Optional[int]:
    text = str(value or "").strip()
    if re.fullmatch(r"-?\d+", text):
        return int(text)
    return None

def _patch_20260412c_global_column_flag(source: str) -> bool:
    numbers = [int(token) for token in re.findall(r"\d+", str(source or ""))]
    return any(abs(number) >= 100 for number in numbers) or count_two_digit_numbers(numbers) > 2

def _patch_20260412c_should_use_column_for_step(step: dict, source: str) -> bool:
    left = _patch_20260412c_parse_int_text(step.get("left", ""))
    right = _patch_20260412c_parse_int_text(step.get("right", ""))
    operator = step.get("operator")

    if left is None or right is None:
        return False

    global_flag = _patch_20260412c_global_column_flag(source)

    if operator == "+":
        return abs(left) >= 100 or abs(right) >= 100 or global_flag
    if operator == "-":
        if left < 0 or right < 0 or left < right:
            return False
        return abs(left) >= 100 or abs(right) >= 100 or global_flag
    if operator == "×":
        return abs(left) >= 100 or abs(right) >= 100
    if operator == ":":
        if right == 0:
            return False
        return abs(left) >= 100 or abs(right) >= 100
    return False

def _patch_20260412c_step_explanation_text(step: dict) -> Optional[str]:
    left = _patch_20260412c_parse_int_text(step.get("left", ""))
    right = _patch_20260412c_parse_int_text(step.get("right", ""))
    operator = step.get("operator")

    if left is None or right is None:
        return None

    if operator == "+":
        return explain_column_addition([left, right])
    if operator == "-":
        if left < 0 or right < 0 or left < right:
            return None
        return explain_column_subtraction(left, right)
    if operator == "×":
        return explain_long_multiplication(left, right)
    if operator == ":":
        if right == 0:
            return None
        return explain_long_division(left, right)
    return None

def _patch_20260412c_clean_body_lines(lines: List[str]) -> List[str]:
    cleaned: List[str] = []
    for raw in lines:
        line = re.sub(r"^\d+\)\s*", "", str(raw or "").strip())
        lower = line.lower()
        if not line:
            continue
        if lower.startswith("запись столбиком"):
            continue
        if lower.startswith("читаем ответ:"):
            continue
        cleaned.append(line)
    return cleaned




def _detailed_format_expression_solution(raw_text: str, base_text: str) -> str:
    source = to_expression_source(raw_text)
    if not source:
        return _PATCH_20260412C_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

    rendered = _patch_20260412c_render_mixed_expression_solution(source)
    if rendered:
        return rendered

    return _PATCH_20260412C_PREV_DETAILED_FORMAT_EXPRESSION_SOLUTION(raw_text, base_text)

# --- FINAL PATCH 2026-04-12C.1: safe helper text ---

def _patch_20260412c_step_header(index: int, operator: str, left: str, right: str, result: str, use_column: bool) -> str:
    ordinal = _PATCH_20260412C_ORDINAL_WORDS.get(index, f"{index}-е")
    action_name = {
        "+": "сложение",
        "-": "вычитание",
        "×": "умножение",
        ":": "деление",
    }.get(operator, "действие")
    if use_column:
        return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right}. Выполним это действие в столбик"
    return f"{index}) {ordinal} действие — {action_name}: {left} {operator} {right} = {result}"
