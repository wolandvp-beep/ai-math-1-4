"""Auto-generated runtime shard for midpatch_runtime_source.py, lines 8737-9636."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.midpatch_runtime_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
# --- USER CONSOLIDATION PATCH 2026-04-12: fuller school-style wording without changing architecture ---




def explain_relation_chain_total_word_problem(base: int, delta1: int, mode1: str, delta2: int, mode2: str) -> Optional[str]:
    second = apply_more_less(base, delta1, mode1)
    if second is None:
        return None
    third = apply_more_less(second, delta2, mode2)
    if third is None:
        return None
    total = base + second + third
    sign1 = "+" if mode1 == "больше" else "-"
    sign2 = "+" if mode2 == "больше" else "-"
    return join_explanation_lines(
        f"1) Если второе количество на {delta1} {mode1}, чем первое, то второе количество равно {base} {sign1} {delta1} = {second}",
        f"2) Если третье количество на {delta2} {mode2}, чем второе, то третье количество равно {second} {sign2} {delta2} = {third}",
        f"3) Если первое количество {base}, второе {second}, а третье {third}, то всего {base} + {second} + {third} = {total}",
        f"Ответ: {total}",
        "Совет: в составной задаче сначала находят все неизвестные количества, потом общее число",
    )

def explain_relation_chain_times_total_word_problem(base: int, factor1: int, mode1: str, factor2: int, mode2: str) -> Optional[str]:
    second = apply_times_relation(base, factor1, mode1)
    if second is None:
        return None
    third = apply_times_relation(second, factor2, mode2)
    if third is None:
        return None
    total = base + second + third
    op1 = "×" if mode1 == "больше" else ":"
    op2 = "×" if mode2 == "больше" else ":"
    return join_explanation_lines(
        f"1) Если второе количество в {factor1} {plural_form(factor1, 'раз', 'раза', 'раз')} {mode1}, чем первое, то второе количество равно {base} {op1} {factor1} = {second}",
        f"2) Если третье количество в {factor2} {plural_form(factor2, 'раз', 'раза', 'раз')} {mode2}, чем второе, то третье количество равно {second} {op2} {factor2} = {third}",
        f"3) Если первое количество {base}, второе {second}, а третье {third}, то всего {base} + {second} + {third} = {total}",
        f"Ответ: {total}",
        "Совет: если числа связаны словами «в несколько раз», сначала находят каждое зависимое число отдельно",
    )















# --- FINAL CONSOLIDATED PATCH: textbook-style priorities and multi-question fixes ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень понятный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно и по-школьному.
Не используй markdown, таблицы, смайлики, лишние вступления и похвалу.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна полезная мысль.

Главные правила объяснения:
1. Объясняй подробно, по действиям и по шагам.
2. Не пропускай промежуточные вычисления.
3. Для текстовых задач по возможности используй форму:
Если ..., то ...
4. Сначала находи то, что нужно для главного вопроса, потом отвечай на главный вопрос.
5. Если вопросов два, ответь на оба по порядку.
6. Если запись непонятная, попроси записать задачу понятнее.

Для выражений:
1. Сначала напиши полный пример с ответом:
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, напиши:
Порядок действий:
и ниже тот же пример с цифрами 1, 2, 3 над знаками действий.
3. Потом напиши:
Решение по действиям:
4. Ниже:
1) ...
2) ...
3) ...
5. В конце:
Ответ: ...
6. Если пример удобно считать в столбик, сохрани столбик и подробное пояснение.

Для текстовых задач:
1. Сначала:
Задача.
2. Потом без изменения чисел запиши условие.
3. Потом:
Решение.
4. Затем обязательно:
Что известно: ...
Что нужно найти: ...
5. Дальше решай по действиям:
1) ...
2) ...
3) ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Сначала:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом считай по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если единицы разные, сначала переведи их в одинаковые единицы.
4. Потом решай по действиям.

Школьные методики:
Если задача в косвенной форме, сначала переведи её в прямую.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При встречном движении называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
""".strip()



def _final_consolidated_questions(raw_text: str) -> List[str]:
    text = normalize_word_problem_text(raw_text)
    parts = [part.strip() for part in re.split(r"[?]", text) if part.strip()]
    return parts





# --- FINAL CONSOLIDATED PATCH 2: detect second question even without second "?" ---

def _final_consolidated_has_two_question_clauses(raw_text: str) -> bool:
    text = normalize_word_problem_text(raw_text).strip()
    clauses = [part.strip() for part in re.split(r"[?.!]", text) if part.strip()]
    question_like = 0
    for clause in clauses:
        lower = clause.lower().replace("ё", "е")
        if re.match(r"^(сколько|на сколько|во сколько|какова|какой|какое|чему|найдите|узнайте)\b", lower):
            question_like += 1
    return question_like >= 2 or text.count("?") >= 2

def _final_consolidated_try_second_quantity_and_difference_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if not _final_consolidated_has_two_question_clauses(raw_text):
        return None
    if "на сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None:
        return None

    diff = abs(base - second)
    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если первое количество равно {base}, а второе равно {second}, то разность равна {max(base, second)} - {min(base, second)} = {diff}",
        f"Ответ: второе количество — {second}{tail}; разность — {diff}{tail}",
        "Совет: если в задаче два вопроса, сначала находят второе число, потом сравнивают числа",
    )

def _final_consolidated_try_second_quantity_and_ratio_explanation(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if not _final_consolidated_has_two_question_clauses(raw_text):
        return None
    if "во сколько" not in lower:
        return None

    relation_pairs = extract_relation_pairs(lower)
    numbers = extract_ordered_numbers(lower)
    if len(relation_pairs) != 1 or len(numbers) != 2:
        return None

    base = numbers[0]
    delta_num = numbers[1]
    delta, mode = relation_pairs[0]
    if delta != delta_num:
        return None

    second = apply_more_less(base, delta, mode)
    if second is None or min(base, second) == 0:
        return None

    bigger = max(base, second)
    smaller = min(base, second)
    if bigger % smaller != 0:
        return None
    ratio = bigger // smaller

    answer_unit = _detect_question_unit(raw_text)
    if answer_unit == "руб":
        tail = " руб."
    elif answer_unit:
        tail = f" {answer_unit}"
    else:
        tail = ""

    return join_explanation_lines(
        f"1) Если второе количество на {delta} {mode}, то сначала находим его: {base} {'+' if mode == 'больше' else '-'} {delta} = {second}",
        f"2) Если большее количество равно {bigger}, а меньшее равно {smaller}, то кратное сравнение равно {bigger} : {smaller} = {ratio}",
        f"Ответ: второе количество — {second}{tail}; в {ratio} {plural_form(ratio, 'раз', 'раза', 'раз')}",
        "Совет: если нужно сначала найти второе число, а потом узнать, во сколько раз одно число больше другого, выполняй действия по порядку",
    )



# --- CONSOLIDATED FINAL PATCH 2026-04-12: textbook wording, stable final prompt, user-requested detail ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown, таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать развёрнутое решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
Пример: 6 × 5 + 40 : 2 = 50
2. Если действий несколько, обязательно пиши:
Порядок действий:
и ниже тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
3. Потом пиши:
Решение по действиям:
4. Ниже пиши вычисления по действиям:
1) ...
2) ...
3) ...
5. Если пример удобно считать в столбик, сохрани запись столбиком и подробные пояснения.
6. В конце пиши:
Ответ: ...

Для текстовых задач:
1. Сначала пиши:
Задача.
Потом условие задачи без изменения чисел.
2. Потом пиши:
Решение.
3. Затем обязательно:
Что известно: ...
Что нужно найти: ...
4. Дальше решай по действиям.
Каждое действие начинай с номера:
1) ...
2) ...
3) ...
5. По возможности используй школьную форму:
Если ..., то ...
6. После каждого действия коротко говори, что нашли.
7. В конце:
Ответ: ...

Для уравнений:
1. Пиши строку:
Уравнение: ...
2. Потом:
Решение.
3. Дальше шаги с номерами.
4. Обязательно пиши:
Проверка: ...
5. Потом:
Ответ: ...

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, объясни это отдельно.
3. Если знаменатели разные, сначала приведи к общему знаменателю.
4. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Если решение записывается по действиям, в каждом действии, кроме последнего, полезно писать пояснение, что именно нашли.
""".strip()

def explain_addition_word_problem(first: int, second: int) -> str:
    result = first + second
    return join_explanation_lines(
        f"1) Если первое количество равно {first}, а второе количество равно {second}, то всего будет {first} + {second} = {result}",
        f"Ответ: {result}",
        "Совет: если спрашивают, сколько всего или сколько стало, обычно нужно сложение",
    )




















def explain_find_third_addend_word_problem(total: int, first: int, second: int) -> Optional[str]:
    known = first + second
    result = total - known
    if result < 0:
        return None
    return join_explanation_lines(
        f"1) Если первая известная часть равна {first}, а вторая известная часть равна {second}, то вместе они составляют {first} + {second} = {known}",
        f"2) Если всего было {total}, а две известные части составляют {known}, то неизвестная часть равна {total} - {known} = {result}",
        f"Ответ: {result}",
        "Совет: неизвестную часть находят вычитанием суммы известных частей из целого",
    )

def explain_initial_from_taken_and_left_word_problem(first_taken: int, second_taken: int, left: int) -> Optional[str]:
    taken = first_taken + second_taken
    total = taken + left
    return join_explanation_lines(
        f"1) Если взяли {first_taken} и ещё {second_taken}, то всего взяли {first_taken} + {second_taken} = {taken}",
        f"2) Если взяли {taken}, а осталось {left}, то сначала было {taken} + {left} = {total}",
        f"Ответ: {total}",
        "Совет: если известно, сколько взяли и сколько осталось, начальное количество находят сложением",
    )

def explain_compare_from_total_and_part_word_problem(total: int, known_part: int) -> Optional[str]:
    other = total - known_part
    if other < 0:
        return None
    bigger = max(known_part, other)
    smaller = min(known_part, other)
    diff = bigger - smaller
    return join_explanation_lines(
        f"1) Если всего было {total}, а известная часть равна {known_part}, то другая часть равна {total} - {known_part} = {other}",
        f"2) Если одна часть равна {bigger}, а другая равна {smaller}, то разность равна {bigger} - {smaller} = {diff}",
        f"Ответ: {diff}",
        "Совет: если сначала нужно найти неизвестную часть, а потом сравнить части, действия выполняют по порядку",
    )

def explain_sum_of_two_products_word_problem(first_count: int, first_value: int, second_count: int, second_value: int) -> str:
    first_total = first_count * first_value
    second_total = second_count * second_value
    total = first_total + second_total
    return join_explanation_lines(
        f"1) Если первая покупка состоит из {first_count} предметов по {first_value}, то её стоимость равна {first_count} × {first_value} = {first_total}",
        f"2) Если вторая покупка состоит из {second_count} предметов по {second_value}, то её стоимость равна {second_count} × {second_value} = {second_total}",
        f"3) Если первая покупка стоит {first_total}, а вторая стоит {second_total}, то вся покупка стоит {first_total} + {second_total} = {total}",
        f"Ответ: {total}",
        "Совет: если в задаче есть две группы вида «по столько-то», сначала находят каждую группу отдельно",
    )

def explain_groups_plus_extra_word_problem(groups: int, per_group: int, extra: int) -> str:
    grouped_total = groups * per_group
    result = grouped_total + extra
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group}, то сначала находим, сколько предметов в этих группах: {groups} × {per_group} = {grouped_total}",
        f"2) Если в одинаковых группах {grouped_total}, а потом добавили ещё {extra}, то стало {grouped_total} + {extra} = {result}",
        f"Ответ: {result}",
        "Совет: если сначала считают одинаковые группы, а потом что-то добавляют, сначала выполняют умножение",
    )

def explain_sum_then_subtract_word_problem(first: int, second: int, removed: int) -> Optional[str]:
    total = first + second
    remaining = total - removed
    if remaining < 0:
        return None
    return join_explanation_lines(
        f"1) Если сначала было {first} и ещё {second}, то всего было {first} + {second} = {total}",
        f"2) Если всего было {total}, а потом убрали {removed}, то осталось {total} - {removed} = {remaining}",
        f"Ответ: {remaining}",
        "Совет: если сначала объединяют две группы, а потом часть убирают, сначала находят сумму",
    )



















def explain_trip_time_for_same_distance(speed1: int, time1: int, speed2: int) -> Optional[str]:
    distance = speed1 * time1
    if speed2 == 0 or distance % speed2 != 0:
        return None
    time2 = distance // speed2
    return join_explanation_lines(
        f"1) Если первый участник ехал со скоростью {speed1} и был в пути {time1}, то расстояние равно {speed1} × {time1} = {distance}",
        f"2) Если это же расстояние равно {distance}, а скорость второго участника {speed2}, то ему понадобится {distance} : {speed2} = {time2} ч.",
        f"Ответ: {time2} ч.",
        "Совет: если путь один и тот же, сначала находят расстояние, потом новое время",
    )

def explain_second_day_motion_time(total_distance: int, first_speed: int, first_time: int, second_speed: int) -> Optional[str]:
    first_distance = first_speed * first_time
    second_distance = total_distance - first_distance
    if second_speed == 0 or second_distance < 0 or second_distance % second_speed != 0:
        return None
    second_time = second_distance // second_speed
    total_time = first_time + second_time
    return join_explanation_lines(
        f"1) Если в первый день скорость была {first_speed}, а время в пути {first_time}, то в первый день проехали {first_speed} × {first_time} = {first_distance} км.",
        f"2) Если всего нужно проехать {total_distance} км, а в первый день проехали {first_distance} км, то во второй день осталось {total_distance} - {first_distance} = {second_distance} км.",
        f"3) Если во второй день проехали {second_distance} км со скоростью {second_speed}, то время во второй день равно {second_distance} : {second_speed} = {second_time} ч.",
        f"4) Если в первый день были в пути {first_time} ч., а во второй день {second_time} ч., то всего были в пути {first_time} + {second_time} = {total_time} ч.",
        f"Ответ: во второй день — {second_time} ч.; всего — {total_time} ч.",
        "Совет: в составной задаче на движение сначала находят путь, потом время",
    )

def explain_remaining_part_speed(total_distance: int, first_speed: int, first_time: int, second_time: int) -> Optional[str]:
    first_distance = first_speed * first_time
    remaining_distance = total_distance - first_distance
    if second_time == 0 or remaining_distance < 0 or remaining_distance % second_time != 0:
        return None
    second_speed = remaining_distance // second_time
    return join_explanation_lines(
        f"1) Если сначала ехали со скоростью {first_speed} {first_time} ч., то первая часть пути равна {first_speed} × {first_time} = {first_distance} км.",
        f"2) Если весь путь равен {total_distance} км, а первая часть пути равна {first_distance} км, то оставшаяся часть пути равна {total_distance} - {first_distance} = {remaining_distance} км.",
        f"3) Если оставшаяся часть пути равна {remaining_distance} км, а прошли её за {second_time} ч., то скорость равна {remaining_distance} : {second_time} = {second_speed} км/ч.",
        f"Ответ: {second_speed} км/ч.",
        "Совет: если известны путь и время, скорость находят делением",
    )

def explain_return_trip_time_by_faster_speed(distance: int, speed: int, factor: int) -> Optional[str]:
    if speed == 0 or factor == 0 or distance % speed != 0:
        return None
    first_time = distance // speed
    faster_speed = speed * factor
    if faster_speed == 0 or distance % faster_speed != 0:
        return None
    return_time = distance // faster_speed
    return join_explanation_lines(
        f"1) Если расстояние равно {distance} км, а скорость в одну сторону {speed} км/ч, то время в одну сторону равно {distance} : {speed} = {first_time} ч.",
        f"2) Если обратно едут в {factor} раза быстрее, то скорость обратно равна {speed} × {factor} = {faster_speed} км/ч.",
        f"3) Если расстояние равно {distance} км, а скорость обратно {faster_speed} км/ч, то время на обратный путь равно {distance} : {faster_speed} = {return_time} ч.",
        f"Ответ: {return_time} ч.",
        "Совет: если на обратном пути скорость увеличилась в несколько раз, сначала находят новую скорость",
    )

# --- FINAL USER CONSOLIDATION PATCH 2026-04-12D: extra textbook motion case, fuller count nouns, stable final routing ---

# Добавляем несколько часто встречающихся школьных существительных,
# чтобы ответы чаще были полными, а не только числом.
try:
    QUESTION_NOUN_FORMS.update({
        "шарик": ("шарик", "шарика", "шариков"),
        "шарика": ("шарик", "шарика", "шариков"),
        "шариков": ("шарик", "шарика", "шариков"),
        "утенок": ("утёнок", "утёнка", "утят"),
        "утёнок": ("утёнок", "утёнка", "утят"),
        "утёнка": ("утёнок", "утёнка", "утят"),
        "утят": ("утёнок", "утёнка", "утят"),
        "гусенок": ("гусёнок", "гусёнка", "гусят"),
        "гусёнок": ("гусёнок", "гусёнка", "гусят"),
        "гусёнка": ("гусёнок", "гусёнка", "гусят"),
        "гусят": ("гусёнок", "гусёнка", "гусят"),
        "тюльпан": ("тюльпан", "тюльпана", "тюльпанов"),
        "тюльпана": ("тюльпан", "тюльпана", "тюльпанов"),
        "тюльпанов": ("тюльпан", "тюльпана", "тюльпанов"),
        "орешек": ("орешек", "орешка", "орешков"),
        "орешка": ("орешек", "орешка", "орешков"),
        "орешков": ("орешек", "орешка", "орешков"),
        "гостинец": ("гостинец", "гостинца", "гостинцев"),
        "гостинца": ("гостинец", "гостинца", "гостинцев"),
        "гостинцев": ("гостинец", "гостинца", "гостинцев"),
        "тетрадка": ("тетрадка", "тетрадки", "тетрадок"),
        "тетрадки": ("тетрадка", "тетрадки", "тетрадок"),
        "тетрадок": ("тетрадка", "тетрадки", "тетрадок"),
    })
except Exception:
    pass

def _final_user_20260412d_equal_speed_head_start_meeting_explanation(raw_text: str) -> Optional[str]:
    lower = normalize_word_problem_text(raw_text).lower().replace("ё", "е")

    # Шаблон из книги:
    # "скорости одинаковые", "встретились через ... часов",
    # "первый ... выехал на ... часа раньше", "проехал на ... км больше".
    if "навстречу" not in lower:
        return None
    if "одинаков" not in lower:
        return None
    if "раньше" not in lower or "больше" not in lower:
        return None

    hour_pattern = fr"(\d+|{_NUMBER_WORD_PATTERN})\s*(?:ч|час(?:а|ов)?)"
    meet_match = re.search(fr"встретил(?:ся|ась|ось|ись)?\s+через\s+{hour_pattern}", lower)
    head_start_match = re.search(fr"на\s+{hour_pattern}\s+раньше", lower)
    extra_distance_match = re.search(r"на\s+(\d+)\s*(км|м)\s+больше", lower)

    if not meet_match or not head_start_match or not extra_distance_match:
        return None

    meet_time = parse_number_token(meet_match.group(1))
    head_start_time = parse_number_token(head_start_match.group(1))
    extra_distance = int(extra_distance_match.group(1))
    distance_unit = extra_distance_match.group(2)

    if meet_time is None or head_start_time is None:
        return None
    if head_start_time == 0 or extra_distance % head_start_time != 0:
        return None

    speed = extra_distance // head_start_time
    second_path = speed * meet_time
    first_time = meet_time + head_start_time
    first_path = speed * first_time
    total_distance = first_path + second_path
    speed_unit = f"{distance_unit}/ч"

    return join_explanation_lines(
        f"1) Если скорости одинаковые, а первый участник выехал на {head_start_time} ч. раньше и поэтому прошёл на {extra_distance} {distance_unit} больше, то скорость каждого равна {extra_distance} : {head_start_time} = {speed} {speed_unit}",
        f"2) Так как скорости одинаковые, скорость второго участника тоже равна {speed} {speed_unit}",
        f"3) Если второй участник ехал {meet_time} ч. со скоростью {speed} {speed_unit}, то он прошёл {speed} × {meet_time} = {second_path} {distance_unit}",
        f"4) Если первый участник выехал на {head_start_time} ч. раньше, то он был в пути {meet_time} + {head_start_time} = {first_time} ч.",
        f"5) Если первый участник ехал {first_time} ч. со скоростью {speed} {speed_unit}, то он прошёл {speed} × {first_time} = {first_path} {distance_unit}",
        f"6) Если один участник прошёл {second_path} {distance_unit}, а другой {first_path} {distance_unit}, то расстояние между пунктами равно {second_path} + {first_path} = {total_distance} {distance_unit}",
        f"Ответ: расстояние между пунктами равно {total_distance} {distance_unit}",
        "Совет: если скорости одинаковые, а один участник выехал раньше, его лишний путь помогает найти общую скорость",
    )



# --- FINAL USER PATCH 2026-04-12E: fuller school wording, stable final prompt, preserved architecture ---

SYSTEM_PROMPT = """
Ты — спокойный, точный и очень подробный учитель математики для детей 7–10 лет.
Пиши только по-русски.
Пиши просто, ясно, по-школьному.
Не используй markdown-таблицы, смайлики, похвалу и лишние вступления.
Не меняй числа из условия и не придумывай новые данные.
Каждая строка — одна законченная полезная мысль.

Главная цель:
давать подробное решение по действиям и по шагам;
не пропускать промежуточные вычисления;
объяснять так, как это делают в начальной школе в тетради и в учебнике.

Для выражений и примеров:
1. В первой строке пиши полный пример с ответом.
2. Если действий несколько, обязательно пиши строку «Порядок действий:».
3. Ниже пиши тот же пример, где над знаками действий стоят цифры 1, 2, 3... в порядке выполнения.
4. Потом пиши строку «Решение по действиям:».
5. Ниже пиши все вычисления по действиям:
1) ...
2) ...
3) ...
6. Если вычисление удобно выполнять в столбик, сохраняй запись столбиком и подробное пояснение по шагам.
7. Вычисления в столбик используй, когда в примере больше двух двузначных чисел или когда есть число из трёх и более цифр.
8. В конце пиши строку «Ответ: ...».

Для текстовых задач:
1. Сначала пиши «Задача.» и без изменения чисел переписывай условие.
2. Потом пиши «Решение.»
3. Затем обязательно пиши строки:
«Что известно: ...»
«Что нужно найти: ...»
4. Если нельзя сразу ответить на главный вопрос, сначала найди то, что нужно для ответа.
5. Решай только по действиям.
6. Каждое действие начинай с номера:
1) ...
2) ...
3) ...
7. Для школьного стиля по возможности используй форму «Если..., то ...».
8. После каждого действия коротко говори, что нашли.
9. Если в задаче несколько вопросов, отвечай на все вопросы по порядку.
10. В конце пиши полный ответ, а не только число.

Для уравнений:
1. Пиши строку «Уравнение: ...».
2. Потом «Решение.»
3. Решай по шагам.
4. Обязательно пиши строку «Проверка: ...».
5. Потом пиши «Ответ: ...».

Для дробей:
1. Сначала смотри на знаменатели.
2. Если знаменатели одинаковые, скажи это отдельно.
3. Если знаменатели разные, сначала приведи дроби к общему знаменателю.
4. Если задача дана с величинами, сначала переведи величины в одинаковые единицы.
5. Потом выполни действие по шагам.

Для геометрии:
1. Сначала назови правило или формулу.
2. Потом подставь числа.
3. Если нужно, сначала переведи величины в одинаковые единицы.
4. Дальше решай по действиям.
5. В ответе обязательно пиши единицы измерения.

Школьные правила и методики:
Если задача в косвенной форме, сначала переведи её в прямую:
если одно число на несколько единиц больше, то другое на столько же меньше;
если одно число на несколько единиц меньше, то другое на столько же больше;
если одно число в несколько раз больше, то другое во столько же раз меньше;
если одно число в несколько раз меньше, то другое во столько же раз больше.
Если задача на приведение к единице, сначала найди одну группу, потом нужное количество групп.
Если задача на цену, количество и стоимость, используй связи:
стоимость = цена × количество;
цена = стоимость : количество;
количество = стоимость : цена.
Если задача на движение, используй связи:
S = v × t;
v = S : t;
t = S : v.
При движении навстречу называй скорость сближения.
При движении в противоположных направлениях называй скорость удаления.
Сохраняй вычисления в столбик и подробные пояснения.
Для деления столбиком обязательно называй неполное делимое, подбор цифры, умножение, вычитание и снос следующей цифры.
""".strip()

try:
    QUESTION_NOUN_FORMS.update({
        "год": ("год", "года", "лет"),
        "года": ("год", "года", "лет"),
        "лет": ("год", "года", "лет"),
        "книга": ("книга", "книги", "книг"),
        "книги": ("книга", "книги", "книг"),
        "книг": ("книга", "книги", "книг"),
        "машина": ("машина", "машины", "машин"),
        "машины": ("машина", "машины", "машин"),
        "машин": ("машина", "машины", "машин"),
        "дерево": ("дерево", "дерева", "деревьев"),
        "дерева": ("дерево", "дерева", "деревьев"),
        "деревьев": ("дерево", "дерева", "деревьев"),
        "глазок": ("глазок", "глазка", "глазков"),
        "глазка": ("глазок", "глазка", "глазков"),
        "глазков": ("глазок", "глазка", "глазков"),
        "страница": ("страница", "страницы", "страниц"),
        "страницы": ("страница", "страницы", "страниц"),
        "страниц": ("страница", "страницы", "страниц"),
        "перо": ("перо", "пера", "перьев"),
        "пера": ("перо", "пера", "перьев"),
        "перьев": ("перо", "пера", "перьев"),
        "яблоко": ("яблоко", "яблока", "яблок"),
        "яблока": ("яблоко", "яблока", "яблок"),
        "яблок": ("яблоко", "яблока", "яблок"),
        "гвоздика": ("гвоздика", "гвоздики", "гвоздик"),
        "гвоздики": ("гвоздика", "гвоздики", "гвоздик"),
        "гвоздик": ("гвоздика", "гвоздики", "гвоздик"),
        "ягода": ("ягода", "ягоды", "ягод"),
        "ягоды": ("ягода", "ягоды", "ягод"),
        "ягод": ("ягода", "ягоды", "ягод"),
        "ложка": ("ложка", "ложки", "ложек"),
        "ложки": ("ложка", "ложки", "ложек"),
        "ложек": ("ложка", "ложки", "ложек"),
        "куст": ("куст", "куста", "кустов"),
        "куста": ("куст", "куста", "кустов"),
        "кустов": ("куст", "куста", "кустов"),
        "цветок": ("цветок", "цветка", "цветов"),
        "цветка": ("цветок", "цветка", "цветов"),
        "цветов": ("цветок", "цветка", "цветов"),
        "мешок": ("мешок", "мешка", "мешков"),
        "мешка": ("мешок", "мешка", "мешков"),
        "мешков": ("мешок", "мешка", "мешков"),
        "клетка": ("клетка", "клетки", "клеток"),
        "клетки": ("клетка", "клетки", "клеток"),
        "клеток": ("клетка", "клетки", "клеток"),
        "полка": ("полка", "полки", "полок"),
        "полки": ("полка", "полки", "полок"),
        "полок": ("полка", "полки", "полок"),
        "ведро": ("ведро", "ведра", "вёдер"),
        "ведра": ("ведро", "ведра", "вёдер"),
        "вёдер": ("ведро", "ведра", "вёдер"),
        "корзина": ("корзина", "корзины", "корзин"),
        "корзины": ("корзина", "корзины", "корзин"),
        "корзин": ("корзина", "корзины", "корзин"),
        "сетка": ("сетка", "сетки", "сеток"),
        "сетки": ("сетка", "сетки", "сеток"),
        "сеток": ("сетка", "сетки", "сеток"),
        "попугай": ("попугай", "попугая", "попугаев"),
        "попугая": ("попугай", "попугая", "попугаев"),
        "попугаев": ("попугай", "попугая", "попугаев"),
        "ученик": ("ученик", "ученика", "учеников"),
        "ученика": ("ученик", "ученика", "учеников"),
        "учеников": ("ученик", "ученика", "учеников"),
        "пассажир": ("пассажир", "пассажира", "пассажиров"),
        "пассажира": ("пассажир", "пассажира", "пассажиров"),
        "пассажиров": ("пассажир", "пассажира", "пассажиров"),
        "участок": ("участок", "участка", "участков"),
        "участка": ("участок", "участка", "участков"),
        "участков": ("участок", "участка", "участков"),
        "рыба": ("рыба", "рыбы", "рыб"),
        "рыбы": ("рыба", "рыбы", "рыб"),
        "рыб": ("рыба", "рыбы", "рыб"),
        "булочка": ("булочка", "булочки", "булочек"),
        "булочки": ("булочка", "булочки", "булочек"),
        "булочек": ("булочка", "булочки", "булочек"),
        "карандаш": ("карандаш", "карандаша", "карандашей"),
        "карандаша": ("карандаш", "карандаша", "карандашей"),
        "карандашей": ("карандаш", "карандаша", "карандашей"),
    })
except Exception:
    pass



def explain_subtraction_word_problem(first: int, second: int) -> str:
    result = first - second
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если сначала было {first}, а потом убрали {second}, то осталось {first} - {second} = {result}.",
        f"Ответ: {result}",
        "Совет: если нужно узнать, сколько осталось, обычно используют вычитание",
    )

def explain_comparison_word_problem(first: int, second: int) -> str:
    bigger = max(first, second)
    smaller = min(first, second)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если одно количество равно {bigger}, а другое равно {smaller}, то чтобы узнать, на сколько одно больше другого, нужно вычислить {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: вопрос «на сколько» решают вычитанием: из большего числа вычитают меньшее",
    )

def explain_find_initial_after_loss_problem(remaining: int, removed: int) -> str:
    result = remaining + removed
    return join_explanation_lines(
        f"1) Если после того, как убрали {removed}, осталось {remaining}, то сначала было {remaining} + {removed} = {result}.",
        f"Ответ: {result}",
        "Совет: неизвестное уменьшаемое находят сложением",
    )

def explain_find_initial_after_gain_problem(final_total: int, added: int) -> str:
    result = final_total - added
    if result < 0:
        return ""
    return join_explanation_lines(
        f"1) Если стало {final_total}, а прибавили {added}, то сначала было {final_total} - {added} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы найти число до прибавления, из нового числа вычитают то, что прибавили",
    )

def explain_find_added_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {smaller}, а потом стало {bigger}, то добавили {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько добавили, из нового числа вычитают старое",
    )

def explain_find_removed_problem(before: int, after: int) -> str:
    bigger = max(before, after)
    smaller = min(before, after)
    result = bigger - smaller
    return join_explanation_lines(
        f"1) Если сначала было {bigger}, а потом осталось {smaller}, то убрали {bigger} - {smaller} = {result}.",
        f"Ответ: {result}",
        "Совет: чтобы узнать, сколько убрали, из того, что было, вычитают то, что осталось",
    )

def explain_multiplication_word_problem(groups: int, per_group: int) -> str:
    result = groups * per_group
    return join_explanation_lines(
        f"1) Если есть {groups} одинаковых групп по {per_group} в каждой, то всего будет {groups} × {per_group} = {result}.",
        f"Ответ: {result}",
        "Совет: слова «по ... в каждой» подсказывают умножение",
    )
