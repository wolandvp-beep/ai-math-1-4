"""Auto-generated runtime shard for prepatch_build_source.py, lines 12461-13324."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def try_local_equation_explanation(raw_text: str) -> Optional[str]:
    source = to_equation_source(raw_text)
    if not source:
        return None

    variable_name = _user_final_equation_variable_name(source)
    lhs, rhs = source.split('=', 1)
    if variable_name not in lhs and variable_name in rhs:
        lhs, rhs = rhs, lhs

    try:
        rhs_value = Fraction(int(rhs), 1)
    except ValueError:
        return None

    variable_re = re.escape(variable_name)
    patterns = [
        (rf'^{variable_re}\+(\d+)$', 'var_plus'),
        (rf'^{variable_re}-(\d+)$', 'var_minus'),
        (rf'^{variable_re}\*(\d+)$', 'var_mul'),
        (rf'^{variable_re}/(\d+)$', 'var_div'),
        (rf'^(\d+)\+{variable_re}$', 'plus_var'),
        (rf'^(\d+)-{variable_re}$', 'minus_var'),
        (rf'^(\d+)\*{variable_re}$', 'mul_var'),
        (rf'^(\d+)/{variable_re}$', 'div_var'),
    ]

    for pattern, kind in patterns:
        match = re.fullmatch(pattern, lhs)
        if not match:
            continue

        number = Fraction(int(match.group(1)), 1)
        number_text = format_fraction(number)
        rhs_text = format_fraction(rhs_value)

        if kind == 'var_plus':
            answer = rhs_value - number
            lines = _eq_transfer_step(variable_name, number_text, rhs_text, f"{rhs_text} - {number_text}", 'plus')
            lines.extend(_eq_compute_and_answer_steps(variable_name, answer, 2))
            return join_explanation_lines(*lines)

        if kind == 'plus_var':
            answer = rhs_value - number
            lines = [
                f"1) В левой части переставим слагаемые местами: {variable_name} + {number_text} = {rhs_text}",
                f"2) Неизвестное {variable_name} оставляем слева, а число {number_text} переносим вправо. При переносе знак плюс меняется на минус:",
                _eq_math_line(f"{variable_name} = {rhs_text} - {number_text}"),
                '3) Считаем:',
                _eq_math_line(f"{variable_name} = {format_fraction(answer)}"),
                f"Ответ: {format_fraction(answer)}",
            ]
            return join_explanation_lines(*lines)

        if kind == 'var_minus':
            answer = rhs_value + number
            lines = _eq_transfer_step(variable_name, number_text, rhs_text, f"{rhs_text} + {number_text}", 'minus')
            lines.extend(_eq_compute_and_answer_steps(variable_name, answer, 2))
            return join_explanation_lines(*lines)

        if kind == 'var_mul':
            if number == 0:
                if rhs_value == 0:
                    return join_explanation_lines(
                        '1) При умножении на 0 всегда получается 0',
                        'Ответ: подходит любое число',
                    )
                return join_explanation_lines(
                    '1) При умножении на 0 нельзя получить другое число',
                    'Ответ: решения нет',
                )
            answer = rhs_value / number
            lines = _eq_transfer_step(variable_name, number_text, rhs_text, f"{rhs_text} : {number_text}", 'mul')
            lines.extend(_eq_compute_and_answer_steps(variable_name, answer, 2))
            return join_explanation_lines(*lines)

        if kind == 'mul_var':
            if number == 0:
                if rhs_value == 0:
                    return join_explanation_lines(
                        '1) При умножении на 0 всегда получается 0',
                        'Ответ: подходит любое число',
                    )
                return join_explanation_lines(
                    '1) При умножении на 0 нельзя получить другое число',
                    'Ответ: решения нет',
                )
            answer = rhs_value / number
            lines = [
                f"1) В левой части переставим множители местами: {variable_name} × {number_text} = {rhs_text}",
                f"2) Неизвестное {variable_name} оставляем слева, а число {number_text} переносим вправо. При переносе знак умножения меняется на деление:",
                _eq_math_line(f"{variable_name} = {rhs_text} : {number_text}"),
                '3) Считаем:',
                _eq_math_line(f"{variable_name} = {format_fraction(answer)}"),
                f"Ответ: {format_fraction(answer)}",
            ]
            return join_explanation_lines(*lines)

        if kind == 'var_div':
            if number == 0:
                return join_explanation_lines(
                    '1) На ноль делить нельзя',
                    'Ответ: решения нет',
                )
            answer = rhs_value * number
            lines = _eq_transfer_step(variable_name, number_text, rhs_text, f"{rhs_text} × {number_text}", 'div')
            lines.extend(_eq_compute_and_answer_steps(variable_name, answer, 2))
            return join_explanation_lines(*lines)

        if kind == 'minus_var':
            answer = number - rhs_value
            lines = [
                '1) Ищем неизвестное вычитаемое. Чтобы найти его, из уменьшаемого вычитаем разность:',
                _eq_math_line(f"{variable_name} = {number_text} - {rhs_text}"),
                '2) Считаем:',
                _eq_math_line(f"{variable_name} = {format_fraction(answer)}"),
                f"Ответ: {format_fraction(answer)}",
            ]
            return join_explanation_lines(*lines)

        if kind == 'div_var':
            if rhs_value == 0:
                return join_explanation_lines(
                    '1) На ноль делить нельзя, поэтому такое уравнение решения не имеет',
                    'Ответ: решения нет',
                )
            answer = number / rhs_value
            lines = [
                '1) Ищем неизвестный делитель. Чтобы найти его, делимое делим на частное:',
                _eq_math_line(f"{variable_name} = {number_text} : {rhs_text}"),
                '2) Считаем:',
                _eq_math_line(f"{variable_name} = {format_fraction(answer)}"),
                f"Ответ: {format_fraction(answer)}",
            ]
            return join_explanation_lines(*lines)

    return None

def _detailed_format_equation_solution(raw_text: str, base_text: str) -> str:
    parts = _detailed_split_sections(base_text)
    source = to_equation_source(raw_text) or normalize_cyrillic_x(strip_known_prefix(raw_text))
    pretty = _detailed_pretty_equation(source)
    answer = parts['answer'] or 'проверь запись'

    lines: List[str] = ['Уравнение:', pretty, 'Решение.']
    lines.extend(parts['body'])
    if parts['check']:
        lines.append(parts['check'])
    lines.append(f'Ответ: {answer}')
    if parts['advice']:
        lines.append(f"Совет: {parts['advice']}")
    return _detailed_finalize_text(lines)

# --- USER PATCH 2026-04-14B: keep equation lines and colons without extra periods ---

def normalize_sentence(text: str) -> str:
    line = str(text or '').strip()
    if not line:
        return ''
    if re.fullmatch(r'[A-Za-zА-Яа-я0-9()+\-×:=/ ]+', line) and (('=' in line) or bool(re.search(r'[+\-×:/]', line))):
        return line
    if line[-1] not in '.!?:':
        line += '.'
    return line

# --- AUDIT PATCH 2026-04-14C: broad local coverage for school explanations ---

_AUDIT_20260414C_PREV_BUILD_EXPLANATION = build_explanation

def _audit_join_lines(*lines: str) -> str:
    cleaned = []
    for line in lines:
        text = str(line or '').strip()
        if text:
            cleaned.append(text)
    return '\n'.join(cleaned)

def _audit_extract_first_quantity_noun(text: str) -> str:
    match = re.search(r"\d+\s+([A-Za-zА-Яа-яЁё-]+)", str(text or ''))
    if not match:
        return ''
    word = match.group(1)
    if word.lower() in {'руб', 'рубля', 'рублей', 'см', 'мм', 'дм', 'м', 'км', 'ч', 'час', 'часа', 'часов', 'мин', 'минута', 'минуты', 'минут'}:
        return ''
    return word

def _audit_extract_question_noun(text: str) -> str:
    match = re.search(r"сколько\s+([A-Za-zА-Яа-яЁё-]+)", str(text or '').lower())
    if not match:
        return ''
    word = match.group(1)
    if word in {'стало', 'осталось', 'было', 'будет', 'нужно'}:
        return ''
    return word

def _audit_add_answer_noun(value_text: str, noun: str) -> str:
    noun = str(noun or '').strip()
    if not noun:
        return value_text
    return f"{value_text} {noun}".strip()

def _audit_pretty_expr_from_source(source: str) -> str:
    node = parse_expression_ast(source)
    if node is not None:
        return render_node(node)
    return str(source or '').replace('*', ' × ').replace('/', ' : ')

def _audit_try_simple_addition_explanation(raw_text: str) -> Optional[str]:
    source = to_expression_source(raw_text)
    if not source:
        return None
    node = parse_expression_ast(source)
    if node is None:
        return None
    simple = try_simple_binary_int_expression(node)
    if not simple or simple['operator'] is not ast.Add:
        return None
    left = simple['left']
    right = simple['right']
    if left < 0 or right < 0:
        return None
    if max(left, right) > 20:
        return None
    result = left + right
    expr = f"{left} + {right}"
    return _audit_join_lines(
        f"Пример: {expr} = {result}.",
        "Решение.",
        "Пример в одно действие.",
        "Нужно найти сумму чисел.",
        f"Считаем: {expr} = {result}.",
        f"Ответ: {result}."
    )

def _audit_try_one_step_equation_explanation(raw_text: str) -> Optional[str]:
    source = to_equation_source(raw_text)
    if not source:
        return None
    compact = re.sub(r"\s+", "", source)
    variable_match = re.search(r"([A-Za-zА-Яа-я])", compact)
    variable = variable_match.group(1) if variable_match else 'x'

    def fmt_value(value):
        if isinstance(value, Fraction):
            return format_fraction(value)
        return format_fraction(Fraction(value, 1)) if not isinstance(value, str) else value

    patterns = [
        (rf"^({variable})\+(\-?\d+)=([\-]?\d+)$", 'x_plus_n_eq_b'),
        (rf"^(\-?\d+)\+({variable})=([\-]?\d+)$", 'n_plus_x_eq_b'),
        (rf"^({variable})\-(\-?\d+)=([\-]?\d+)$", 'x_minus_n_eq_b'),
        (rf"^(\-?\d+)\-({variable})=([\-]?\d+)$", 'n_minus_x_eq_b'),
        (rf"^({variable})\*(\-?\d+)=([\-]?\d+)$", 'x_mul_n_eq_b'),
        (rf"^(\-?\d+)\*({variable})=([\-]?\d+)$", 'n_mul_x_eq_b'),
        (rf"^({variable})/(\-?\d+)=([\-]?\d+)$", 'x_div_n_eq_b'),
        (rf"^(\-?\d+)/({variable})=([\-]?\d+)$", 'n_div_x_eq_b'),
    ]

    for pattern, kind in patterns:
        match = re.fullmatch(pattern, compact)
        if not match:
            continue

        if kind == 'x_plus_n_eq_b':
            n = int(match.group(2)); b = int(match.group(3)); ans = Fraction(b - n, 1)
            return _audit_join_lines(
                "Уравнение:",
                f"{variable} + {n} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а известное число {n} переносим вправо. При переносе знак меняется:",
                f"{variable} = {b} - {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'n_plus_x_eq_b':
            n = int(match.group(1)); b = int(match.group(3)); ans = Fraction(b - n, 1)
            return _audit_join_lines(
                "Уравнение:",
                f"{n} + {variable} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а известное число {n} переносим вправо. При переносе знак меняется:",
                f"{variable} = {b} - {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'x_minus_n_eq_b':
            n = int(match.group(2)); b = int(match.group(3)); ans = Fraction(b + n, 1)
            return _audit_join_lines(
                "Уравнение:",
                f"{variable} - {n} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а число {n} переносим вправо. При переносе знак меняется:",
                f"{variable} = {b} + {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'n_minus_x_eq_b':
            n = int(match.group(1)); b = int(match.group(3)); ans = Fraction(n - b, 1)
            return _audit_join_lines(
                "Уравнение:",
                f"{n} - {variable} = {b}",
                "Решение.",
                f"1) Чтобы найти неизвестное вычитаемое, из уменьшаемого вычитаем разность:",
                f"{variable} = {n} - {b}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'x_mul_n_eq_b':
            n = int(match.group(2)); b = int(match.group(3))
            if n == 0:
                return None
            ans = Fraction(b, n)
            return _audit_join_lines(
                "Уравнение:",
                f"{variable} × {n} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а число {n} переносим вправо. При переносе знак умножения меняется на деление:",
                f"{variable} = {b} : {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'n_mul_x_eq_b':
            n = int(match.group(1)); b = int(match.group(3))
            if n == 0:
                return None
            ans = Fraction(b, n)
            return _audit_join_lines(
                "Уравнение:",
                f"{n} × {variable} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а число {n} переносим вправо. При переносе знак умножения меняется на деление:",
                f"{variable} = {b} : {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'x_div_n_eq_b':
            n = int(match.group(2)); b = int(match.group(3)); ans = Fraction(b * n, 1)
            return _audit_join_lines(
                "Уравнение:",
                f"{variable} : {n} = {b}",
                "Решение.",
                f"1) Неизвестное {variable} оставляем слева, а число {n} переносим вправо. При переносе знак деления меняется на умножение:",
                f"{variable} = {b} × {n}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )

        if kind == 'n_div_x_eq_b':
            n = int(match.group(1)); b = int(match.group(3))
            if b == 0:
                return None
            ans = Fraction(n, b)
            return _audit_join_lines(
                "Уравнение:",
                f"{n} : {variable} = {b}",
                "Решение.",
                "1) Чтобы найти неизвестный делитель, делимое делим на частное:",
                f"{variable} = {n} : {b}",
                "2) Считаем:",
                f"{variable} = {fmt_value(ans)}",
                f"Ответ: {fmt_value(ans)}"
            )
    return None

def _audit_try_fraction_number_tasks(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    match = re.fullmatch(r"(\d+)\s*/\s*(\d+)\s+числ[аоы]\s+равн(?:а|ы|о)\s+(\d+)", lower)
    if match:
        numerator = int(match.group(1))
        denominator = int(match.group(2))
        part_value = int(match.group(3))
        if numerator == 0 or denominator == 0:
            return None
        one_part = Fraction(part_value, numerator)
        whole = one_part * denominator
        lines = [
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: {numerator}/{denominator} числа {'равна' if numerator == 1 else 'равны'} {part_value}.",
            "Что нужно найти: всё число."
        ]
        if numerator == 1:
            lines.append(f"1) Одна {denominator}-я часть числа уже равна {part_value}.")
        else:
            lines.append(f"1) Найдём одну {denominator}-ю часть числа: {part_value} : {numerator} = {format_fraction(one_part)}.")
        lines.append(f"2) Всё число состоит из {denominator} таких частей: {format_fraction(one_part)} × {denominator} = {format_fraction(whole)}.")
        lines.append(f"Ответ: {format_fraction(whole)}")
        return _audit_join_lines(*lines)

    match = re.search(r"найд[иитеь]*\s+(\d+)\s*/\s*(\d+)\s+от\s+(\d+)", lower)
    if match:
        numerator = int(match.group(1))
        denominator = int(match.group(2))
        total = int(match.group(3))
        if denominator == 0:
            return None
        one_part = Fraction(total, denominator)
        part = one_part * numerator
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: всё число равно {total}.",
            f"Что нужно найти: {numerator}/{denominator} от этого числа.",
            f"1) Найдём одну {denominator}-ю часть: {total} : {denominator} = {format_fraction(one_part)}.",
            f"2) Найдём {numerator}/{denominator} числа: {format_fraction(one_part)} × {numerator} = {format_fraction(part)}.",
            f"Ответ: {format_fraction(part)}"
        )
    return None

def _audit_try_motion_shorthand(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    speed_match = re.search(r"скорост[ьяи]?[^\d]{0,10}(\d+)\s*([^\s,.;]+)?", lower)
    time_match = re.search(r"врем[яеи]?[^\d]{0,10}(\d+)\s*([^\s,.;]+)?", lower)
    distance_match = re.search(r"расстояни[ея]?[^\d]{0,10}(\d+)\s*([^\s,.;]+)?", lower)

    speed_value = int(speed_match.group(1)) if speed_match else None
    time_value = int(time_match.group(1)) if time_match else None
    distance_value = int(distance_match.group(1)) if distance_match else None

    speed_unit = speed_match.group(2) if speed_match and speed_match.group(2) else ''
    time_unit = time_match.group(2) if time_match and time_match.group(2) else ''
    distance_unit = distance_match.group(2) if distance_match and distance_match.group(2) else ''

    if 'найти расстояние' in lower or ('расстояни' in lower and distance_value is None and speed_value is not None and time_value is not None):
        result = speed_value * time_value
        if not distance_unit and speed_unit and '/' in speed_unit:
            distance_unit = speed_unit.split('/')[0]
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: скорость {speed_value} {speed_unit.strip()}, время {time_value} {time_unit.strip()}.".strip(),
            "Что нужно найти: расстояние.",
            "1) Чтобы найти расстояние, используем правило: S = v × t.",
            f"2) Подставляем числа: {speed_value} × {time_value} = {result}.",
            f"Ответ: {_audit_add_answer_noun(str(result), distance_unit)}"
        )

    if 'найти время' in lower or ('врем' in lower and time_value is None and speed_value is not None and distance_value is not None):
        if speed_value in (None, 0) or distance_value is None:
            return None
        result = Fraction(distance_value, speed_value)
        if not time_unit:
            if speed_unit and '/' in speed_unit:
                time_unit = speed_unit.split('/', 1)[1]
            else:
                time_unit = 'ч'
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: расстояние {distance_value} {distance_unit.strip()}, скорость {speed_value} {speed_unit.strip()}.".strip(),
            "Что нужно найти: время.",
            "1) Чтобы найти время, используем правило: t = S : v.",
            f"2) Подставляем числа: {distance_value} : {speed_value} = {format_fraction(result)}.",
            f"Ответ: {_audit_add_answer_noun(format_fraction(result), time_unit)}"
        )

    if 'найти скорость' in lower or ('скорост' in lower and speed_value is None and time_value is not None and distance_value is not None):
        if time_value in (None, 0) or distance_value is None:
            return None
        result = Fraction(distance_value, time_value)
        if not speed_unit:
            if distance_unit and time_unit:
                speed_unit = f"{distance_unit}/{time_unit}"
            else:
                speed_unit = 'км/ч'
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: расстояние {distance_value} {distance_unit.strip()}, время {time_value} {time_unit.strip()}.".strip(),
            "Что нужно найти: скорость.",
            "1) Чтобы найти скорость, используем правило: v = S : t.",
            f"2) Подставляем числа: {distance_value} : {time_value} = {format_fraction(result)}.",
            f"Ответ: {_audit_add_answer_noun(format_fraction(result), speed_unit)}"
        )
    return None

def _audit_try_price_short_tasks(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()

    price_total_match = re.search(r"цена\s*1\s+([а-яё-]+)\s*(\d+)\s*руб", lower)
    asked_cost_match = re.search(r"сколько\s+стоят\s+(\d+)\s+([а-яё-]+)", lower)
    if price_total_match and asked_cost_match:
        item = price_total_match.group(1)
        price = int(price_total_match.group(2))
        qty = int(asked_cost_match.group(1))
        total = price * qty
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: цена одной {item} {price} руб., количество {qty}.",
            "Что нужно найти: стоимость покупки.",
            "1) Чтобы найти стоимость, цену умножаем на количество.",
            f"2) Считаем: {price} × {qty} = {total}.",
            f"Ответ: {total} руб"
        )

    paid_match = re.search(r"за\s*(\d+)\s+([а-яё-]+)\s+заплатили\s*(\d+)\s*руб", lower)
    if paid_match and ('сколько стоит 1' in lower or 'сколько стоит одна' in lower):
        qty = int(paid_match.group(1))
        item = paid_match.group(2)
        total = int(paid_match.group(3))
        if qty == 0:
            return None
        price = Fraction(total, qty)
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: за {qty} {item} заплатили {total} руб.",
            "Что нужно найти: цену одного предмета.",
            "1) Чтобы найти цену, стоимость делим на количество.",
            f"2) Считаем: {total} : {qty} = {format_fraction(price)}.",
            f"Ответ: {format_fraction(price)} руб"
        )
    return None

def _audit_try_rectangle_geometry(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    unit = geometry_unit(text)

    match = re.search(r"периметр\s+прямоугольника\s*(\d+)\s*(мм|см|дм|м|км)?[^\d]{0,40}длина\s*(\d+)", lower)
    if match and 'ширин' in lower:
        perimeter = int(match.group(1))
        length = int(match.group(3))
        if not unit:
            unit = (match.group(2) or '').lower()
        half_sum = Fraction(perimeter, 2)
        width = half_sum - length
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: периметр прямоугольника {with_unit(perimeter, unit)}, длина {with_unit(length, unit)}.",
            "Что нужно найти: ширину.",
            "1) Периметр прямоугольника равен сумме длины и ширины, умноженной на 2:",
            "P = (a + b) × 2",
            f"2) Найдём сумму длины и ширины: {perimeter} : 2 = {format_fraction(half_sum)}.",
            f"3) Теперь найдём ширину: {format_fraction(half_sum)} - {length} = {format_fraction(width)}.",
            f"Ответ: {with_unit(int(width) if isinstance(width, Fraction) and width.denominator == 1 else format_fraction(width), unit)}"
        )

    match = re.search(r"длина\s+прямоугольника\s*(\d+)\s*(мм|см|дм|м|км)?[^\d]{0,40}ширина\s*(\d+)", lower)
    if match and 'периметр' in lower:
        length = int(match.group(1))
        width = int(match.group(3))
        if not unit:
            unit = (match.group(2) or '').lower()
        half = length + width
        perimeter = half * 2
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: длина {with_unit(length, unit)}, ширина {with_unit(width, unit)}.",
            "Что нужно найти: периметр.",
            "1) Периметр прямоугольника находим по формуле: P = (a + b) × 2.",
            f"2) Складываем длину и ширину: {length} + {width} = {half}.",
            f"3) Умножаем на 2: {half} × 2 = {perimeter}.",
            f"Ответ: {with_unit(perimeter, unit)}"
        )
    return None

def _audit_try_common_word_problems(raw_text: str) -> Optional[str]:
    text = normalize_word_problem_text(raw_text)
    lower = text.lower()
    numbers = extract_ordered_numbers(lower)
    if len(numbers) < 2:
        return None

    first_noun = _audit_extract_first_quantity_noun(text)
    asked_noun = _audit_extract_question_noun(text)

    if ('сначала' in lower or 'было сначала' in lower) and 'стало' in lower and any(stem in lower for stem in WORD_GAIN_HINTS):
        added_match = re.search(r"добав[а-я]*\s*(\d+)", lower)
        total_match = re.search(r"стало\s*(\d+)", lower)
        if added_match and total_match:
            added = int(added_match.group(1))
            total = int(total_match.group(1))
            initial = total - added
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: добавили {added}, стало {total}.",
                "Что нужно найти: сколько было сначала.",
                f"1) После того как добавили {added}, стало {total}.",
                f"2) Чтобы узнать, сколько было сначала, из {total} вычитаем {added}: {total} - {added} = {initial}.",
                f"Ответ: {initial}"
            )

    if any(verb in lower for verb in GROUPING_VERBS) and 'по' in lower and 'сколько' in lower and 'в каждом' not in lower:
        match = re.search(r"(\d+)[^\d]{0,40}по\s*(\d+)", lower)
        if match:
            total = int(match.group(1))
            per_group = int(match.group(2))
            if per_group == 0:
                return None
            groups = Fraction(total, per_group)
            answer_noun = asked_noun or 'групп'
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: всего {total}{(' ' + first_noun) if first_noun else ''}, в одной группе по {per_group}.",
                f"Что нужно найти: сколько {answer_noun} нужно.",
                f"1) Чтобы узнать, сколько получится групп, делим общее количество на количество в одной группе: {total} : {per_group} = {format_fraction(groups)}.",
                f"Ответ: {_audit_add_answer_noun(format_fraction(groups), answer_noun)}"
            )

    if ('поровну' in lower or 'в каждом' in lower) and 'сколько' in lower:
        total = numbers[0]
        groups = numbers[1]
        if groups != 0 and ('в каждом' in lower or 'каждом пакете' in lower or 'каждой' in lower):
            per_group = Fraction(total, groups)
            return _audit_join_lines(
                "Задача.",
                _audit_task_line(raw_text),
                "Решение.",
                f"Что известно: всего {total}{(' ' + first_noun) if first_noun else ''}, групп {groups}.",
                "Что нужно найти: сколько будет в каждой группе.",
                f"1) Чтобы узнать, сколько будет в каждой группе, делим общее количество на число групп: {total} : {groups} = {format_fraction(per_group)}.",
                f"Ответ: {'в каждой группе по ' + format_fraction(per_group) + (' ' + first_noun if first_noun else '')}"
            )

    if 'сколько стало' in lower and any(stem in lower for stem in WORD_GAIN_HINTS):
        first = numbers[0]
        added = numbers[1]
        total = first + added
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: сначала было {first}{(' ' + first_noun) if first_noun else ''}, добавили ещё {added}.",
            "Что нужно найти: сколько стало.",
            f"1) Чтобы узнать, сколько стало, складываем: {first} + {added} = {total}.",
            f"Ответ: {_audit_add_answer_noun(str(total), first_noun)}"
        )

    if 'сколько осталось' in lower and any(stem in lower for stem in WORD_LOSS_HINTS):
        first = numbers[0]
        removed = numbers[1]
        left = first - removed
        return _audit_join_lines(
            "Задача.",
            _audit_task_line(raw_text),
            "Решение.",
            f"Что известно: было {first}{(' ' + first_noun) if first_noun else ''}, убрали {removed}.",
            "Что нужно найти: сколько осталось.",
            f"1) Чтобы узнать, сколько осталось, вычитаем: {first} - {removed} = {left}.",
            f"Ответ: {_audit_add_answer_noun(str(left), first_noun)}"
        )
    return None

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _audit_try_simple_addition_explanation(raw_text)
        or _audit_try_one_step_equation_explanation(raw_text)
        or _audit_try_fraction_number_tasks(raw_text)
        or _audit_try_motion_shorthand(raw_text)
        or _audit_try_price_short_tasks(raw_text)
        or _audit_try_rectangle_geometry(raw_text)
        or _audit_try_common_word_problems(raw_text)
    )

async def build_explanation(user_text: str) -> dict:
    local = _audit_try_final_local_explanation(user_text)
    if local:
        return {"result": local, "source": "local-audit", "validated": True}

    result = await _AUDIT_20260414C_PREV_BUILD_EXPLANATION(user_text)
    text = str(result.get('result') or '')
    if looks_like_math_input(user_text) and re.search(r"техническ[а-яёa-z-]*\s+обслужив|service\s+unavailable|maintenance", text, flags=re.IGNORECASE):
        friendly = _audit_join_lines(
            "Не получилось построить объяснение для этой записи.",
            "Попробуйте записать пример или задачу чуть подробнее.",
            "Ответ: проверь запись задачи"
        )
        return {"result": friendly, "source": "fallback-audit", "validated": False}
    return result

# --- FINAL PATCH 2026-04-15 FRACTIONS SCHOOL STYLE ---
_AUDIT_20260415_PREV_FINAL_LOCAL_EXPLANATION = _audit_try_final_local_explanation

def _fraction_school_action_symbol(operator: str) -> str:
    return '+' if operator == '+' else '-'

def _fraction_school_action_word(operator: str) -> str:
    return 'Складываем' if operator == '+' else 'Вычитаем'

def _fraction_school_mixed_text(value: Fraction) -> Optional[str]:
    if value.denominator == 1:
        return None
    sign = '-' if value < 0 else ''
    numerator = abs(value.numerator)
    denominator = value.denominator
    if numerator < denominator:
        return None
    whole = numerator // denominator
    remainder = numerator % denominator
    if remainder == 0:
        return f"{sign}{whole}"
    return f"{sign}{whole} {remainder}/{denominator}"

def _build_fraction_school_explanation(raw_text: str) -> Optional[str]:
    source = to_fraction_source(raw_text)
    if not source:
        return None

    match = re.fullmatch(r"\s*(\d+)\s*/\s*(\d+)\s*([+\-])\s*(\d+)\s*/\s*(\d+)\s*", source)
    if not match:
        return None

    a, b, operator, c, d = match.groups()
    a, b, c, d = int(a), int(b), int(c), int(d)
    if b == 0 or d == 0:
        return join_explanation_lines(
            "У дроби знаменатель не может быть равен нулю",
            "Ответ: запись дроби неверная"
        )

    action_symbol = _fraction_school_action_symbol(operator)
    action_word = _fraction_school_action_word(operator)
    result = Fraction(a, b) + Fraction(c, d) if operator == '+' else Fraction(a, b) - Fraction(c, d)
    result_text = format_fraction(result)
    mixed_text = _fraction_school_mixed_text(result)
    lines: List[str] = [
        f"Пример: {a}/{b} {action_symbol} {c}/{d}",
        "Решение."
    ]

    def extend_with_optional_result_steps(current_step_number: int, raw_fraction_text: str, answer_chain: str):
        local_step_number = current_step_number
        local_answer_chain = answer_chain
        if raw_fraction_text != result_text:
            lines.append(f"{local_step_number}) Сокращаем дробь: {raw_fraction_text} = {result_text}")
            local_answer_chain += f" = {result_text}"
            local_step_number += 1
        if mixed_text and mixed_text != result_text:
            lines.append(f"{local_step_number}) Выделяем целую часть: {result_text} = {mixed_text}")
            local_answer_chain += f" = {mixed_text}"
            local_step_number += 1
        return local_step_number, local_answer_chain

    if b == d:
        top_result = a + c if operator == '+' else a - c
        raw_result = f"{top_result}/{b}"
        lines.extend([
            f"1) Находим общий знаменатель. Знаменатели уже одинаковые: {b} и {d}",
            f"2) Дроби уже имеют одинаковый знаменатель. Значит, {action_word.lower()} только числители, а знаменатель оставляем прежним: {a} {action_symbol} {c} = {top_result}",
            f"3) Получаем: {raw_result}"
        ])
        _, answer_chain = extend_with_optional_result_steps(4, raw_result, f"{a}/{b} {action_symbol} {c}/{d} = {raw_result}")
        lines.append(f"Ответ: {answer_chain}")
        return join_explanation_lines(*lines)

    common = math.lcm(b, d)
    a_multiplier = common // b
    c_multiplier = common // d
    a_scaled = a * a_multiplier
    c_scaled = c * c_multiplier
    raw_numerator = a_scaled + c_scaled if operator == '+' else a_scaled - c_scaled
    raw_result = f"{raw_numerator}/{common}"

    lines.append(
        f"1) Находим общий знаменатель. Знаменатели: {b} и {d}. Общий знаменатель = {common}, потому что {common} делится на {b} и на {d}"
    )

    step_number = 2
    if b == common:
        lines.append(f"{step_number}) Первая дробь уже имеет знаменатель {common}: {a}/{b} = {a}/{common}")
    else:
        lines.extend([
            f"{step_number}) Приводим первую дробь {a}/{b} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {b}, чтобы получить {common}?",
            f"{b} × {a_multiplier} = {common}",
            f"Нужно умножить на {a_multiplier}",
            f"Получаем: {a}/{b} = (умножаем числитель и знаменатель на {a_multiplier}) = {a_scaled}/{common}"
        ])
    step_number += 1

    if d == common:
        lines.append(f"{step_number}) Вторая дробь уже имеет знаменатель {common}: {c}/{d} = {c}/{common}")
    else:
        lines.extend([
            f"{step_number}) Приводим вторую дробь {c}/{d} к знаменателю {common}",
            f"Спрашиваем: на сколько нужно умножить {d}, чтобы получить {common}?",
            f"{d} × {c_multiplier} = {common}",
            f"Нужно умножить на {c_multiplier}",
            f"Получаем: {c}/{d} = (умножаем числитель и знаменатель на {c_multiplier}) = {c_scaled}/{common}"
        ])
    step_number += 1

    numerator_action = '+' if operator == '+' else '-'
    numerator_result = a_scaled + c_scaled if operator == '+' else a_scaled - c_scaled
    lines.extend([
        f"{step_number}) {action_word} дроби с одинаковыми знаменателями. Знаменатель {common} оставляем прежним, а числители {action_word.lower()}: {a_scaled} {numerator_action} {c_scaled} = {numerator_result}",
        f"Получаем: {raw_result}"
    ])
    step_number += 1

    base_chain = f"{a}/{b} {action_symbol} {c}/{d} = {a_scaled}/{common} {action_symbol} {c_scaled}/{common} = {raw_result}"
    _, answer_chain = extend_with_optional_result_steps(step_number, raw_result, base_chain)
    lines.append(f"Ответ: {answer_chain}")
    return join_explanation_lines(*lines)

def _audit_try_final_local_explanation(raw_text: str) -> Optional[str]:
    return (
        _build_fraction_school_explanation(raw_text)
        or _AUDIT_20260415_PREV_FINAL_LOCAL_EXPLANATION(raw_text)
    )

# --- FINAL PATCH 2026-04-15: mixed fraction expressions are fraction tasks, not plain division ---

_FINAL_20260415_PREV_AUDIT_LOCAL_EXPLANATION = _audit_try_final_local_explanation
