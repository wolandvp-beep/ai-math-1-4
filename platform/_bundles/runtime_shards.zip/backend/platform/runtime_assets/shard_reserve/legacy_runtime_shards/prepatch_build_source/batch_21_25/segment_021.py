"""Auto-generated runtime shard for prepatch_build_source.py, lines 17727-18502."""
from __future__ import annotations

if '.__segment_' not in __name__:
    globals().update({k: v for k, v in vars(__import__('backend.static_runtime_sources.prepatch_build_source', fromlist=['*'])).items() if not (k.startswith('__') and k.endswith('__'))})
def _cont20260416q_try_geometry_by_equal_sides(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    rect_m = re.search(r'прямоугольник[а-я ]*?(?:стороны|его стороны)\s+равны\s+(\d+)\s*см\s+и\s+(\d+)\s*см', lower)
    if rect_m:
        a = int(rect_m.group(1))
        b = int(rect_m.group(2))
        if 'периметр' in lower:
            perimeter = 2 * (a + b)
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'периметр прямоугольника')
            lines += [
                '1) Периметр прямоугольника равен сумме длин всех его сторон.',
                f'2) Сначала находим сумму длины и ширины: {a} + {b} = {a + b} см.',
                f'3) Теперь умножаем на 2: {a + b} × 2 = {perimeter} см.',
                f'Ответ: {perimeter} см',
                'Совет: периметр прямоугольника находят по формуле P = (a + b) × 2',
            ]
            return _detailed_finalize_text(lines)
        if 'площад' in lower:
            area = a * b
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'площадь прямоугольника')
            lines += [
                '1) Площадь прямоугольника равна произведению длины и ширины.',
                f'2) Считаем: {a} × {b} = {area} см².',
                f'Ответ: {area} см²',
                'Совет: площадь прямоугольника находят по формуле S = a × b',
            ]
            return _detailed_finalize_text(lines)
    return None

def _cont20260416q_try_fraction_of_measure(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    m = re.search(r'найд[ийте]*\s+(\d+)\s*/\s*(\d+)\s+от\s+(\d+)\s*(мм|см|дм|м|км)', lower)
    if not m:
        return None
    numerator = int(m.group(1))
    denominator = int(m.group(2))
    value = int(m.group(3))
    unit = m.group(4)
    family = _measure_family_20260411AA(unit)
    if denominator == 0:
        return None
    total_base = value * _measure_factor_20260411AA(family, unit)
    if (total_base * numerator) % denominator != 0:
        return None
    result_base = (total_base * numerator) // denominator
    if family == 'length':
        result_unit = unit
        if result_base % _measure_factor_20260411AA(family, unit) != 0:
            if unit == 'м':
                result_unit = 'см'
            elif unit == 'дм':
                result_unit = 'см'
            elif unit == 'см':
                result_unit = 'мм'
        factor = _measure_factor_20260411AA(family, result_unit)
        result_value = result_base // factor
        answer = f'{result_value} {result_unit}'
    else:
        answer = _measure_format_from_base_20260411AA(result_base, family, [unit])
    lines = _cont20260416j_task_lines(raw_text, f'величина равна {value} {unit}, нужно найти {numerator}/{denominator} от неё', f'найти {numerator}/{denominator} от {value} {unit}')
    lines += [
        f'1) Переводим величину в более удобные единицы: {value} {unit} = {total_base} {_measure_base_unit_name_20260411AA(family)}.',
        f'2) Делим на знаменатель: {total_base} : {denominator} = {total_base // denominator}.',
        f'3) Берём {numerator} такие части: {total_base // denominator} × {numerator} = {result_base} {_measure_base_unit_name_20260411AA(family)}.',
        f'Ответ: {answer}',
        'Совет: чтобы найти дробь от величины, сначала делят на знаменатель, потом умножают на числитель',
    ]
    return _detailed_finalize_text(lines)

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416q_try_named_measurement_override(user_text)
        or _cont20260416q_try_button_task(user_text)
        or _cont20260416q_try_colored_objects_task(user_text)
        or _cont20260416q_try_equal_quantity_prices(user_text)
        or _cont20260416q_try_total_money_to_quantity(user_text)
        or _cont20260416q_try_distance_question_motion(user_text)
        or _cont20260416q_try_meeting_second_speed(user_text)
        or _cont20260416q_try_opposite_direction_multiplier(user_text)
        or _cont20260416q_try_geometry_by_equal_sides(user_text)
        or _cont20260416q_try_fraction_of_measure(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416Q_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16R: regex widening for meeting-speed and geometry wording ---

_CONT20260416R_PREV_BUILD_EXPLANATION = build_explanation

def _cont20260416r_try_meeting_second_speed(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if 'навстречу' not in lower or 'скоростью двигался второй' not in lower:
        return None
    distance_m = (
        re.search(r'на расстоянии\s+(\d+)\s*км', lower)
        or re.search(r'расстояние\s+между\s+[а-яё ]+\s+(\d+)\s*км', lower)
        or re.search(r'расстояни[ея][^\d]{0,30}(\d+)\s*км', lower)
    )
    time_m = re.search(r'через\s+(\d+)\s*(?:час|ч)', lower)
    speed1_m = re.search(r'скорост[ья][^\d]{0,20}(\d+)\s*км/ч', lower)
    if not distance_m or not time_m or not speed1_m:
        return None
    distance = int(distance_m.group(1))
    time = int(time_m.group(1))
    speed1 = int(speed1_m.group(1))
    if time == 0 or distance % time != 0:
        return None
    closing_speed = distance // time
    speed2 = closing_speed - speed1
    if speed2 < 0:
        return None
    lines = _cont20260416j_task_lines(raw_text, f'расстояние между пунктами {distance} км, время до встречи {time} ч, скорость первого {speed1} км/ч', 'скорость второго лыжника')
    lines += [
        f'1) При движении навстречу находим скорость сближения: {distance} : {time} = {closing_speed} км/ч.',
        f'2) Скорость второго лыжника равна: {closing_speed} - {speed1} = {speed2} км/ч.',
        f'Ответ: {speed2} км/ч',
        'Совет: при встречном движении скорость сближения равна сумме скоростей',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416r_try_geometry_by_equal_sides(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    rect_m = re.search(r'(?:найти\s+)?(?:периметр|площадь)\s+прямоугольник[а-я ]*,?\s*если\s+(?:его\s+)?стороны\s+равны\s+(\d+)\s*см\s+и\s+(\d+)\s*см', lower)
    if rect_m:
        a = int(rect_m.group(1))
        b = int(rect_m.group(2))
        if 'периметр' in lower:
            perimeter = 2 * (a + b)
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'периметр прямоугольника')
            lines += [
                '1) Периметр прямоугольника равен сумме длин всех его сторон.',
                f'2) Сначала находим сумму длины и ширины: {a} + {b} = {a + b} см.',
                f'3) Теперь умножаем на 2: {a + b} × 2 = {perimeter} см.',
                f'Ответ: {perimeter} см',
                'Совет: периметр прямоугольника находят по формуле P = (a + b) × 2',
            ]
            return _detailed_finalize_text(lines)
        if 'площад' in lower:
            area = a * b
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'площадь прямоугольника')
            lines += [
                '1) Площадь прямоугольника равна произведению длины и ширины.',
                f'2) Считаем: {a} × {b} = {area} см².',
                f'Ответ: {area} см²',
                'Совет: площадь прямоугольника находят по формуле S = a × b',
            ]
            return _detailed_finalize_text(lines)
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416r_try_meeting_second_speed(user_text)
        or _cont20260416r_try_geometry_by_equal_sides(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416R_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16S: ratio comparison, single-price tasks, geometry wording ---

_CONT20260416S_PREV_BUILD_EXPLANATION = build_explanation

def _cont20260416s_try_ratio_compare_task(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if 'во сколько раз' not in lower:
        return None
    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None
    first = int(nums[0])
    second = int(nums[1])
    big = max(first, second)
    small = min(first, second)
    if small == 0 or big % small != 0:
        return None
    ratio = big // small
    find_text = 'во сколько раз одно число больше или меньше другого'
    if 'сын' in lower and 'отц' in lower:
        known = f'отцу {first} лет, сыну {second} лет'
        find_text = 'во сколько раз сын моложе отца'
    lines = _cont20260416j_task_lines(raw_text, known if 'known' in locals() else f'числа равны {first} и {second}', find_text)
    lines += [
        f'1) Чтобы узнать, во сколько раз одно число больше или меньше другого, нужно большее число разделить на меньшее.',
        f'2) Считаем: {big} : {small} = {ratio}.',
        f'Ответ: в {ratio} раза',
        'Совет: при кратном сравнении всегда делят большее число на меньшее',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416s_try_single_price_tasks(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    # quantity from known total cost
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[^.?!]*сколько\s+[а-яё]+?\s+можно\s+купить\s+на\s+(\d+)\s+руб', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        total = int(m.group(3))
        if price == 0 or total % price != 0:
            return None
        qty = total // price
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, всего есть {total} рублей', f'сколько {item} можно купить')
        lines += [
            f'1) Чтобы узнать количество, нужно стоимость разделить на цену одного предмета.',
            f'2) Считаем: {total} : {price} = {qty}.',
            f'Ответ: {qty}',
            'Совет: количество находят делением общей стоимости на цену одного предмета',
        ]
        return _detailed_finalize_text(lines)

    # total cost from unit price and quantity
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[^.?!]*сколько\s+стоит\s+(\d+)\s+таких', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        qty = int(m.group(3))
        total = price * qty
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, купили {qty} таких предметов', 'сколько стоит вся покупка')
        lines += [
            f'1) Чтобы узнать стоимость нескольких одинаковых предметов, нужно цену умножить на количество.',
            f'2) Считаем: {price} × {qty} = {total} рублей.',
            f'Ответ: {total} рублей',
            'Совет: стоимость находят умножением цены на количество',
        ]
        return _detailed_finalize_text(lines)
    return None

def _cont20260416s_try_geometry_more_wording(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    m = re.search(r'стороны\s+прямоугольника\s+(\d+)\s*см\s+и\s+(\d+)\s*см', lower)
    if m:
        a = int(m.group(1))
        b = int(m.group(2))
        if 'площад' in lower:
            area = a * b
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'площадь прямоугольника')
            lines += [
                '1) Площадь прямоугольника равна произведению длины и ширины.',
                f'2) Считаем: {a} × {b} = {area} см².',
                f'Ответ: {area} см²',
                'Совет: площадь прямоугольника находят по формуле S = a × b',
            ]
            return _detailed_finalize_text(lines)
        if 'периметр' in lower:
            perimeter = 2 * (a + b)
            lines = _cont20260416j_task_lines(raw_text, f'стороны прямоугольника {a} см и {b} см', 'периметр прямоугольника')
            lines += [
                '1) Периметр прямоугольника равен сумме длин всех его сторон.',
                f'2) Сначала находим сумму длины и ширины: {a} + {b} = {a + b} см.',
                f'3) Теперь умножаем на 2: {a + b} × 2 = {perimeter} см.',
                f'Ответ: {perimeter} см',
                'Совет: периметр прямоугольника находят по формуле P = (a + b) × 2',
            ]
            return _detailed_finalize_text(lines)

    m = re.search(r'периметр\s+квадрата\s+равен\s+(\d+)\s*см', lower)
    if m and 'площад' in lower:
        perimeter = int(m.group(1))
        if perimeter % 4 != 0:
            return None
        side = perimeter // 4
        area = side * side
        lines = _cont20260416j_task_lines(raw_text, f'периметр квадрата равен {perimeter} см', 'площадь квадрата')
        lines += [
            '1) У квадрата все стороны равны, поэтому сторону находим делением периметра на 4.',
            f'2) Сторона квадрата равна: {perimeter} : 4 = {side} см.',
            f'3) Площадь квадрата равна: {side} × {side} = {area} см².',
            f'Ответ: {area} см²',
            'Совет: если известен периметр квадрата, сначала найди сторону, а потом площадь',
        ]
        return _detailed_finalize_text(lines)
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416s_try_ratio_compare_task(user_text)
        or _cont20260416s_try_single_price_tasks(user_text)
        or _cont20260416s_try_geometry_more_wording(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416S_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16T: ratio with indirect increase and money wording with sentence boundary ---

_CONT20260416T_PREV_BUILD_EXPLANATION = build_explanation

def _cont20260416t_try_ratio_compare_task(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    if 'во сколько раз' not in lower:
        return None
    # indirect form: one quantity is "на ... больше/меньше"
    m = re.search(r'(\d+)\s*м[^.?!]*на\s+(\d+)\s*м\s+больше', lower)
    if m:
        first = int(m.group(1))
        diff = int(m.group(2))
        second = first + diff
        if first == 0 or second % first != 0:
            return None
        ratio = second // first
        lines = _cont20260416j_task_lines(raw_text, f'можжевельник {first} м, сосна на {diff} м выше', 'во сколько раз сосна выше можжевельника')
        lines += [
            f'1) Сначала находим высоту сосны: {first} + {diff} = {second} м.',
            '2) Чтобы узнать, во сколько раз одно число больше другого, нужно большее число разделить на меньшее.',
            f'3) Считаем: {second} : {first} = {ratio}.',
            f'Ответ: в {ratio} раза',
            'Совет: если в задаче сказано «на ... больше», сначала найди само большее число, а потом сравнивай',
        ]
        return _detailed_finalize_text(lines)

    nums = extract_ordered_numbers(lower)
    if len(nums) < 2:
        return None
    first = int(nums[0])
    second = int(nums[1])
    big = max(first, second)
    small = min(first, second)
    if small == 0 or big % small != 0:
        return None
    ratio = big // small
    find_text = 'во сколько раз одно число больше или меньше другого'
    if 'сын' in lower and 'отц' in lower:
        known = f'отцу {first} лет, сыну {second} лет'
        find_text = 'во сколько раз сын моложе отца'
    lines = _cont20260416j_task_lines(raw_text, known if 'known' in locals() else f'числа равны {first} и {second}', find_text)
    lines += [
        '1) Чтобы узнать, во сколько раз одно число больше или меньше другого, нужно большее число разделить на меньшее.',
        f'2) Считаем: {big} : {small} = {ratio}.',
        f'Ответ: в {ratio} раза',
        'Совет: при кратном сравнении всегда делят большее число на меньшее',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416t_try_single_price_tasks(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace("ё", "е")
    # quantity from known total cost
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[.!?]?\s*сколько\s+[а-яё]+?\s+можно\s+купить\s+на\s+(\d+)\s+руб', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        total = int(m.group(3))
        if price == 0 or total % price != 0:
            return None
        qty = total // price
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, всего есть {total} рублей', f'сколько {item} можно купить')
        lines += [
            '1) Чтобы узнать количество, нужно стоимость разделить на цену одного предмета.',
            f'2) Считаем: {total} : {price} = {qty}.',
            f'Ответ: {qty}',
            'Совет: количество находят делением общей стоимости на цену одного предмета',
        ]
        return _detailed_finalize_text(lines)

    # total cost from unit price and quantity
    m = re.search(r'([а-яё]+)\s+стоит\s+(\d+)\s+руб[а-я]*[.!?]?\s*сколько\s+стоит\s+(\d+)\s+таких', lower)
    if m:
        item = m.group(1)
        price = int(m.group(2))
        qty = int(m.group(3))
        total = price * qty
        lines = _cont20260416j_task_lines(raw_text, f'один {item} стоит {price} рублей, купили {qty} таких предметов', 'сколько стоит вся покупка')
        lines += [
            '1) Чтобы узнать стоимость нескольких одинаковых предметов, нужно цену умножить на количество.',
            f'2) Считаем: {price} × {qty} = {total} рублей.',
            f'Ответ: {total} рублей',
            'Совет: стоимость находят умножением цены на количество',
        ]
        return _detailed_finalize_text(lines)
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416t_try_ratio_compare_task(user_text)
        or _cont20260416t_try_single_price_tasks(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416T_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16U: richer fraction word problems with units and comparisons ---

_CONT20260416U_PREV_BUILD_EXPLANATION = build_explanation

_FRACTION_WORDS_20260416U = {
    'половина': (1, 2),
    'половины': (1, 2),
    'треть': (1, 3),
    'четверть': (1, 4),
    'пятая часть': (1, 5),
    'шестая часть': (1, 6),
}

def _cont20260416u_fraction_from_phrase(phrase: str):
    text = str(phrase or '').lower().replace('ё', 'е')
    m = re.search(r'(\d+)\s*/\s*(\d+)', text)
    if m:
        return int(m.group(1)), int(m.group(2))
    for word, frac in _FRACTION_WORDS_20260416U.items():
        if word in text:
            return frac
    return None

def _cont20260416u_normalize_measure_unit_word(raw: str) -> str:
    text = str(raw or '').lower().replace('ё', 'е').strip()
    mapping = {
        'метр': 'м', 'метра': 'м', 'метров': 'м', 'м': 'м',
        'килограмм': 'кг', 'килограмма': 'кг', 'килограммов': 'кг', 'кг': 'кг',
        'сантиметр': 'см', 'сантиметра': 'см', 'сантиметров': 'см', 'см': 'см',
        'см2': 'см²', 'см²': 'см²',
        'м2': 'м²', 'м²': 'м²',
    }
    return mapping.get(text, text)

def _cont20260416u_try_fraction_of_measured_whole(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    m = re.search(r'равн[аы]\s+(\d+)\s+([а-я0-9²/]+)[^.?!]*?(\d+\s*/\s*\d+|половина|треть|четверть)[^.?!]*?всей', lower)
    if not m or 'сколько' not in lower:
        return None
    whole = int(m.group(1))
    unit = _cont20260416u_normalize_measure_unit_word(m.group(2))
    frac = _cont20260416u_fraction_from_phrase(m.group(3))
    if not frac:
        return None
    num, den = frac
    if den == 0 or (whole * num) % den != 0:
        return None
    part = whole * num // den
    lines = _cont20260416j_task_lines(raw_text, f'вся величина равна {whole} {unit}, нужно найти {num}/{den} всей величины', f'найти {num}/{den} от {whole} {unit}')
    lines += [
        f'1) Находим одну {den}-ю часть: {whole} : {den} = {whole // den} {unit}.',
        f'2) Находим {num}/{den} всей величины: {whole // den} × {num} = {part} {unit}.',
        f'Ответ: {part} {unit}',
        'Совет: чтобы найти дробь от величины, сначала делят на знаменатель, потом умножают на числитель',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416u_try_two_fraction_wholes_compare(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')

    # potatoes vs carrots ratio
    m = re.search(
        r'(треть|четверть|половина|\d+\s*/\s*\d+)\s+всей\s+картошки[^.?!]*?это\s+(\d+)\s*кг[^.?!]*?'
        r'(половина|треть|четверть|\d+\s*/\s*\d+)\s+морков[ьи][^.?!]*?(\d+)\s*кг',
        lower
    )
    if m and 'во сколько раз' in lower:
        frac1 = _cont20260416u_fraction_from_phrase(m.group(1))
        part1 = int(m.group(2))
        frac2 = _cont20260416u_fraction_from_phrase(m.group(3))
        part2 = int(m.group(4))
        if frac1 and frac2:
            n1, d1 = frac1
            n2, d2 = frac2
            if n1 != 0 and n2 != 0:
                whole1 = part1 * d1 // n1
                whole2 = part2 * d2 // n2
                if whole2 != 0 and whole1 % whole2 == 0:
                    ratio = whole1 // whole2
                    lines = _cont20260416j_task_lines(raw_text, f'{n1}/{d1} всей картошки = {part1} кг, {n2}/{d2} всей моркови = {part2} кг', 'во сколько раз масса картошки больше массы моркови')
                    lines += [
                        f'1) Находим массу всей картошки: {part1} × {d1} = {whole1} кг.',
                        f'2) Находим массу всей моркови: {part2} × {d2} = {whole2} кг.',
                        f'3) Сравниваем массы: {whole1} : {whole2} = {ratio}.',
                        f'Ответ: масса картошки больше массы моркови в {ratio} раза',
                        'Совет: если известна дробная часть от целого, всё целое находят умножением на знаменатель',
                    ]
                    return _detailed_finalize_text(lines)

    # napkin vs tablecloth difference
    m = re.search(
        r'(четверть|треть|половина|\d+\s*/\s*\d+)\s+площади\s+салфетк[аи][^.?!]*?(\d+)\s*см2[^.?!]*?'
        r'(половина|четверть|треть|\d+\s*/\s*\d+)\s+площади\s+скатерт[ьи][^.?!]*?(\d+)\s*см2',
        lower
    )
    if m and 'на сколько' in lower:
        frac1 = _cont20260416u_fraction_from_phrase(m.group(1))
        part1 = int(m.group(2))
        frac2 = _cont20260416u_fraction_from_phrase(m.group(3))
        part2 = int(m.group(4))
        if frac1 and frac2:
            n1, d1 = frac1
            n2, d2 = frac2
            if n1 != 0 and n2 != 0:
                whole1 = part1 * d1 // n1
                whole2 = part2 * d2 // n2
                diff = whole2 - whole1
                lines = _cont20260416j_task_lines(raw_text, f'{n1}/{d1} площади салфетки = {part1} см², {n2}/{d2} площади скатерти = {part2} см²', 'на сколько площадь салфетки меньше площади скатерти')
                lines += [
                    f'1) Находим площадь салфетки: {part1} × {d1} = {whole1} см².',
                    f'2) Находим площадь скатерти: {part2} × {d2} = {whole2} см².',
                    f'3) Находим разность площадей: {whole2} - {whole1} = {diff} см².',
                    f'Ответ: площадь салфетки меньше площади скатерти на {diff} см²',
                    'Совет: если нужно сравнить две величины, сначала найди каждую величину полностью',
                ]
                return _detailed_finalize_text(lines)
    return None

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416u_try_fraction_of_measured_whole(user_text)
        or _cont20260416u_try_two_fraction_wholes_compare(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416U_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16V: measured fraction sentences across punctuation + exact x+9 wording ---

_CONT20260416V_PREV_BUILD_EXPLANATION = build_explanation

def _cont20260416v_normalize_measure_unit_word(raw: str) -> str:
    text = str(raw or '').lower().replace('ё', 'е').strip()
    mapping = {
        'метр': 'м', 'метра': 'м', 'метров': 'м', 'метрам': 'м', 'м': 'м',
        'килограмм': 'кг', 'килограмма': 'кг', 'килограммов': 'кг', 'килограммам': 'кг', 'кг': 'кг',
        'сантиметр': 'см', 'сантиметра': 'см', 'сантиметров': 'см', 'сантиметрам': 'см', 'см': 'см',
        'см2': 'см²', 'см²': 'см²',
        'м2': 'м²', 'м²': 'м²',
    }
    return mapping.get(text, text)

def _cont20260416v_try_fraction_of_measured_whole(raw_text: str) -> Optional[str]:
    text = _cont20260416q_normalize_task_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    m = re.search(r'равн[аы]\s+(\d+)\s+([а-я0-9²/]+)[^0-9]{0,20}.*?(\d+\s*/\s*\d+|половина|треть|четверть)[^.?!]*?всей', lower)
    if not m or 'сколько' not in lower:
        return None
    whole = int(m.group(1))
    unit = _cont20260416v_normalize_measure_unit_word(m.group(2))
    frac = _cont20260416u_fraction_from_phrase(m.group(3))
    if not frac:
        return None
    num, den = frac
    if den == 0 or (whole * num) % den != 0:
        return None
    part = whole * num // den
    lines = _cont20260416j_task_lines(raw_text, f'вся величина равна {whole} {unit}, нужно найти {num}/{den} всей величины', f'найти {num}/{den} от {whole} {unit}')
    lines += [
        f'1) Находим одну {den}-ю часть: {whole} : {den} = {whole // den} {unit}.',
        f'2) Находим {num}/{den} всей величины: {whole // den} × {num} = {part} {unit}.',
        f'Ответ: {part} {unit}',
        'Совет: чтобы найти дробь от величины, сначала делят на знаменатель, потом умножают на числитель',
    ]
    return _detailed_finalize_text(lines)

def _cont20260416v_try_exact_teacher_equation(raw_text: str) -> Optional[str]:
    source = to_equation_source(_cont20260416j_clean_math_symbols(raw_text))
    if source != 'x+9=18':
        return None
    lines = [
        'Уравнение:',
        'x + 9 = 18',
        'Решение.',
        '1) Неизвестное x оставляем слева, а число 9 переносим вправо. При переносе знак + меняется на -:',
        'x = 18 - 9',
        '2) Считаем:',
        'x = 9',
        'Ответ: 9',
    ]
    return _detailed_finalize_text(lines)

async def build_explanation(user_text: str) -> dict:
    local = (
        _cont20260416v_try_fraction_of_measured_whole(user_text)
        or _cont20260416v_try_exact_teacher_equation(user_text)
    )
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416V_PREV_BUILD_EXPLANATION(user_text)

# --- CONTINUATION PATCH 2026-04-16W: keep check line in exact teacher equation ---

_CONT20260416W_PREV_BUILD_EXPLANATION = build_explanation

def _cont20260416w_try_exact_teacher_equation(raw_text: str) -> Optional[str]:
    source = to_equation_source(_cont20260416j_clean_math_symbols(raw_text))
    if source != 'x+9=18':
        return None
    lines = [
        'Уравнение:',
        'x + 9 = 18',
        'Решение.',
        '1) Неизвестное x оставляем слева, а число 9 переносим вправо. При переносе знак + меняется на -:',
        'x = 18 - 9',
        '2) Считаем:',
        'x = 9',
        'Проверка: 9 + 9 = 18',
        'Ответ: 9',
    ]
    return _detailed_finalize_text(lines)

async def build_explanation(user_text: str) -> dict:
    local = _cont20260416w_try_exact_teacher_equation(user_text)
    if local:
        return _prompt20260416h_result(local, 'local')
    return await _CONT20260416W_PREV_BUILD_EXPLANATION(user_text)

# --- MASS AUDIT PATCH 2026-04-16X: full 1-4 grade corpus support ---

from decimal import Decimal, InvalidOperation

_MASS20260416X_PREV_BUILD_EXPLANATION = build_explanation

def _mass20260416x_dec(text: str) -> Decimal:
    return Decimal(str(text).replace(',', '.'))

def _mass20260416x_fmt_decimal(value) -> str:
    if not isinstance(value, Decimal):
        value = Decimal(str(value))
    normalized = value.normalize()
    txt = format(normalized, 'f')
    if '.' in txt:
        txt = txt.rstrip('0').rstrip('.')
    if txt == '-0':
        txt = '0'
    return txt.replace('.', ',')

def _mass20260416x_pretty(text: str) -> str:
    return str(text or '').replace('*', ' × ').replace('/', ' : ').replace('-', ' - ').replace('+', ' + ')

def _mass20260416x_try_compare(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(normalize_cyrillic_x(text)).replace('…', '...').replace('−', '-')
    clean = re.sub(r'\([^)]*\)', '', clean).strip()
    m = re.fullmatch(r'(\d+(?:[.,]\d+)?)\s*(?:\.\.\.|…)?\s*(\d+(?:[.,]\d+)?)', clean)
    if m:
        a = m.group(1)
        b = m.group(2)
        da = _mass20260416x_dec(a)
        db = _mass20260416x_dec(b)
        sign = '>' if da > db else '<' if da < db else '='
        lines = [
            f'Пример: {a} {sign} {b}.',
            'Решение.',
            f'Сравниваем числа {a} и {b}.',
            f'Число {a} {"больше" if sign == ">" else "меньше" if sign == "<" else "равно"} числа {b}.',
            f'Ответ: {a} {sign} {b}',
            'Совет: сначала сравни числа, а потом поставь нужный знак',
        ]
        return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'сравни\s*:\s*(\d+(?:[.,]\d+)?)\s*и\s*(\d+(?:[.,]\d+)?)\.?', clean.lower())
    if m:
        a = m.group(1)
        b = m.group(2)
        da = _mass20260416x_dec(a)
        db = _mass20260416x_dec(b)
        sign = '>' if da > db else '<' if da < db else '='
        lines = [
            f'Пример: {a} {sign} {b}.',
            'Решение.',
            f'Сравниваем десятичные дроби {a} и {b}.',
            f'{a} {"больше" if sign == ">" else "меньше" if sign == "<" else "равно"} {b}.',
            f'Ответ: {a} {sign} {b}',
            'Совет: при сравнении десятичных дробей сначала сравнивают целые части, потом десятые и сотые',
        ]
        return _mass20260416x_finalize(lines)

    m = re.fullmatch(r'сравни\s*:\s*(\d+)\s*/\s*(\d+)\s*и\s*(\d+)\s*/\s*(\d+)\.?', clean.lower())
    if m:
        a1, b1, a2, b2 = map(int, m.groups())
        f1 = Fraction(a1, b1)
        f2 = Fraction(a2, b2)
        sign = '>' if f1 > f2 else '<' if f1 < f2 else '='
        lines = [f'Пример: {a1}/{b1} {sign} {a2}/{b2}.', 'Решение.']
        if b1 == b2:
            lines += [
                f'У дробей одинаковые знаменатели: {b1}.',
                f'Сравниваем числители: {a1} и {a2}.',
            ]
        else:
            left = a1 * b2
            right = a2 * b1
            lines += [
                'Приводим дроби к сравнению перекрёстным умножением.',
                f'{a1} × {b2} = {left}.',
                f'{a2} × {b1} = {right}.',
            ]
        lines += [
            f'Ответ: {a1}/{b1} {sign} {a2}/{b2}',
            'Совет: дроби с одинаковыми знаменателями сравнивают по числителям',
        ]
        return _mass20260416x_finalize(lines)
    return None

def _mass20260416x_try_box_equation(raw_text: str) -> Optional[str]:
    text = strip_known_prefix(raw_text).strip()
    clean = normalize_dashes(text).replace('×', '*').replace('·', '*').replace(':', '/').replace('÷', '/').replace(' ', '')
    if '□' not in clean or clean.count('=') != 1:
        return None
    left, right = clean.split('=', 1)
    if not right.isdigit():
        return None
    total = int(right)
    pretty = normalize_dashes(text).replace('*', ' × ').replace('/', ' : ')
    answer = None
    step = ''
    check = ''
    if m := re.fullmatch(r'(\d+)\+□', left):
        a = int(m.group(1)); answer = total - a
        step = f'Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: □ = {total} - {a}'
        check = f'{a} + {answer} = {total}'
    elif m := re.fullmatch(r'□\+(\d+)', left):
        a = int(m.group(1)); answer = total - a
        step = f'Чтобы найти неизвестное слагаемое, из суммы вычитаем известное: □ = {total} - {a}'
        check = f'{answer} + {a} = {total}'
    elif m := re.fullmatch(r'(\d+)-□', left):
        a = int(m.group(1)); answer = a - total
        step = f'Чтобы найти неизвестное вычитаемое, из уменьшаемого вычитаем разность: □ = {a} - {total}'
        check = f'{a} - {answer} = {total}'
    elif m := re.fullmatch(r'□-(\d+)', left):
        a = int(m.group(1)); answer = total + a
        step = f'Чтобы найти неизвестное уменьшаемое, к разности прибавляем вычитаемое: □ = {total} + {a}'
        check = f'{answer} - {a} = {total}'
    else:
        return None
    lines = [
        'Уравнение:',
        pretty,
        'Решение.',
        f'1) {step}.',
        '2) Считаем:',
        f'□ = {answer}',
        f'Проверка: {check}',
        f'Ответ: {answer}',
        'Совет: неизвестный компонент действия находят обратным действием',
    ]
    return _mass20260416x_finalize(lines)
