from __future__ import annotations

from typing import Any, Iterable, Optional

from backend.input_normalization import normalize_solver_input, strip_solver_command_prefix
from backend.legacy_cascade_runtime import get_prepatch_build_explanation_local_first


WORDISH_KINDS = {'word', 'task', 'problem', 'text', 'unknown', ''}


def _call_named_handler(ns: dict[str, Any], handler_name: str, text: str) -> Optional[str]:
    handler = ns.get(handler_name)
    if not callable(handler):
        return None
    try:
        result = handler(text)
    except Exception:
        return None
    return result or None


def apply(ns: dict[str, Any], handler_names: Iterable[str] | None = None) -> dict[str, Any]:
    ordered_names = tuple(handler_names or ())

    def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
        kind_key = str(kind or '').lower()
        if kind_key in WORDISH_KINDS:
            normalized = normalize_solver_input(user_text)
            stripped = strip_solver_command_prefix(user_text)
            candidate_texts: list[str] = []
            for candidate in (normalized, stripped, user_text):
                if candidate and candidate not in candidate_texts:
                    candidate_texts.append(candidate)
            for candidate in candidate_texts:
                for handler_name in ordered_names:
                    result = _call_named_handler(ns, handler_name, candidate)
                    if result:
                        return result

        previous_build_local = get_prepatch_build_explanation_local_first()
        if callable(previous_build_local):
            return previous_build_local(user_text, kind)
        return None

    ns['build_explanation_local_first'] = build_explanation_local_first
    ns['_legacy_local_explanation_dispatcher_apply'] = apply
    return ns


__all__ = ['WORDISH_KINDS', 'apply']
