from __future__ import annotations

import re

_MATH_KEYWORD_PARTS = (
    'математ', 'арифмет', 'пример', 'выражен', 'уравнен', 'неравен',
    'сумм', 'разност', 'произведен', 'частн', 'числ', 'дроб', 'дол', 'процент',
    'периметр', 'площад', 'сторон', 'отрез', 'фигур', 'прямоуголь', 'квадрат', 'треуголь',
    'скорост', 'время', 'расстояни', 'пут', 'движен', 'цен', 'стоим', 'количеств',
    'килограмм', 'грамм', 'литр', 'миллилитр', 'сантиметр', 'метр', 'руб', 'копе',
    'температур', 'градус', 'мас', 'длин', 'объем', 'объём', 'корень',
)

_LABEL_PREFIX_RE = re.compile(
    r'^\s*(?:задача|пример|уравнение|дроби|геометрия|выражение|математика)\s*:\s*',
    re.IGNORECASE,
)


def _strip_label(text: str) -> str:
    return _LABEL_PREFIX_RE.sub('', str(text or '').strip())


def _normalize_space(text: str) -> str:
    return re.sub(r'\s+', ' ', str(text or '').replace('−', '-').replace('–', '-')).strip()


def _clean_text(text: str) -> str:
    return _normalize_space(_strip_label(text))


def _text_has_math_keyword(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    return any(part in lower for part in _MATH_KEYWORD_PARTS)


def _looks_like_math_input(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    if not lower:
        return False
    if _text_has_math_keyword(lower):
        return True
    if re.search(r'\b\d+\s*/\s*\d+\b', lower):
        return True
    if re.search(r'\b[xyzа-я]\s*[+\-*/=:×]\s*\d', lower):
        return True
    if re.search(r'\d\s*[+\-*/=×:]\s*\d', lower):
        return True
    if re.search(r'\b(?:см|мм|дм|м|км|кг|г|л|мл|ч|мин|с|руб(?:лей|ля|ль)?|р\.)\b', lower):
        return True
    return False


__all__ = [
    '_MATH_KEYWORD_PARTS',
    '_clean_text',
    '_looks_like_math_input',
    '_normalize_space',
    '_strip_label',
    '_text_has_math_keyword',
]
