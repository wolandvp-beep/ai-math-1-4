from backend.legacy_core_dependencies import *  # noqa: F401,F403
from backend.legacy_core_basics import *  # noqa: F401,F403
from backend.legacy_build_runtime import get_prepatch_build_explanation
from backend.legacy_cascade_runtime import get_prepatch_build_explanation_local_first, get_prepatch_detect_question_unit, get_prepatch_detailed_maybe_enrich_answer, get_prepatch_extract_count_question_noun
from backend.legacy_runtime_pipeline import apply_runtime_pipeline


async def build_explanation(user_text: str) -> dict:
    previous_build_explanation = get_prepatch_build_explanation()
    if callable(previous_build_explanation):
        return await previous_build_explanation(user_text)
    return _guard_result(_safe_cannot_parse(user_text, 'задачу'))


def build_explanation_local_first(user_text: str, kind: str) -> Optional[str]:
    previous_build_local = get_prepatch_build_explanation_local_first()
    if callable(previous_build_local):
        return previous_build_local(user_text, kind)
    return None


def _extract_count_question_noun(raw_text: str) -> str:
    previous_extract_count_question_noun = get_prepatch_extract_count_question_noun()
    if callable(previous_extract_count_question_noun):
        return previous_extract_count_question_noun(raw_text)
    return ''


def _detect_question_unit(raw_text: str) -> str:
    previous_detect_question_unit = get_prepatch_detect_question_unit()
    if callable(previous_detect_question_unit):
        return previous_detect_question_unit(raw_text)
    return ''


def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
    previous_maybe_enrich = get_prepatch_detailed_maybe_enrich_answer()
    if callable(previous_maybe_enrich):
        return previous_maybe_enrich(answer, raw_text, kind)
    return str(answer or '').strip()


apply_runtime_pipeline(globals())
