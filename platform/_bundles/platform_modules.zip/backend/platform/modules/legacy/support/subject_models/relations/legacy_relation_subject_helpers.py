from __future__ import annotations

import re
from typing import Any, Optional

from backend.legacy_dual_subject_action_helpers import _apply_dual_subject_transfer_step, _detect_dual_subject_action_index, _extract_dual_subject_transfer_action
from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_math_signals import _clean_text
from backend.legacy_measure_helpers import _extract_compound_quantities
from backend.legacy_question_flow_helpers import _question_subject_order, _question_text
from backend.legacy_school_helpers import _format_number, _soft_person_key, _to_fraction
from backend.legacy_sequential_action_helpers import _extract_sequential_actions

def _parse_times_related_subject_problem(raw_text: str) -> Optional[dict[str, Any]]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _extract_compound_quantities(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    forward_match = re.search(
        r'у\s+([а-яёa-z-]+)\s+(?:было\s*)?(\d+(?:[.,]\d+)?)\s+([а-яёa-z/-]+)[^?.!]*?у\s+([а-яёa-z-]+)\s+в\s*(\d+(?:[.,]\d+)?)\s+раз[а]?\s+(больше|меньше)',
        lower,
    )
    if forward_match:
        first_name = forward_match.group(1).lower().replace('ё', 'е')
        second_name = forward_match.group(4).lower().replace('ё', 'е')
        first_value = _to_fraction(forward_match.group(2))
        answer_label = forward_match.group(3).strip('.,!?')
        factor = _to_fraction(forward_match.group(5))
        relation = forward_match.group(6)
        if factor <= 0 or first_value < 0:
            return None
        if relation == 'больше':
            second_value = first_value * factor
            relation_line = f'1) Находим, сколько было у {second_name.capitalize()}: {_format_number(first_value)} × {_format_number(factor)} = {_format_number(second_value)} {answer_label}.'
        else:
            second_value = first_value / factor
            relation_line = f'1) Находим, сколько было у {second_name.capitalize()}: {_format_number(first_value)} : {_format_number(factor)} = {_format_number(second_value)} {answer_label}.'
        return {
            'text': text,
            'lower': lower,
            'question': question,
            'relation_end': forward_match.end(),
            'answer_label': answer_label,
            'subject_entries': [
                {'keys': {_soft_person_key(first_name)}, 'label': first_name.capitalize()},
                {'keys': {_soft_person_key(second_name)}, 'label': second_name.capitalize()},
            ],
            'current_values': [first_value, second_value],
            'known_line': _ensure_sentence(f'Что известно: у {first_name.capitalize()} было {_format_number(first_value)} {answer_label}, а у {second_name.capitalize()} — в {_format_number(factor)} раза {relation}'),
            'relation_line': relation_line,
        }

    reverse_match = re.search(
        r'у\s+([а-яёa-z-]+)\s+(?:было\s*)?(\d+(?:[.,]\d+)?)\s+([а-яёa-z/-]+)\s*,?\s*это\s+в\s*(\d+(?:[.,]\d+)?)\s+раз[а]?\s+(больше|меньше)[^?.!]*?чем\s+у\s+([а-яёa-z-]+)',
        lower,
    )
    if reverse_match:
        known_name = reverse_match.group(1).lower().replace('ё', 'е')
        known_value = _to_fraction(reverse_match.group(2))
        answer_label = reverse_match.group(3).strip('.,!?')
        factor = _to_fraction(reverse_match.group(4))
        relation = reverse_match.group(5)
        base_name = reverse_match.group(6).lower().replace('ё', 'е')
        if factor <= 0 or known_value < 0:
            return None
        if relation == 'меньше':
            base_value = known_value * factor
            relation_line = f'1) Так как у {known_name.capitalize()} в {_format_number(factor)} раза меньше, чем у {base_name.capitalize()}, находим количество у {base_name.capitalize()}: {_format_number(known_value)} × {_format_number(factor)} = {_format_number(base_value)} {answer_label}.'
        else:
            base_value = known_value / factor
            relation_line = f'1) Так как у {known_name.capitalize()} в {_format_number(factor)} раза больше, чем у {base_name.capitalize()}, находим количество у {base_name.capitalize()}: {_format_number(known_value)} : {_format_number(factor)} = {_format_number(base_value)} {answer_label}.'
        return {
            'text': text,
            'lower': lower,
            'question': question,
            'relation_end': reverse_match.end(),
            'answer_label': answer_label,
            'subject_entries': [
                {'keys': {_soft_person_key(base_name)}, 'label': base_name.capitalize()},
                {'keys': {_soft_person_key(known_name)}, 'label': known_name.capitalize()},
            ],
            'current_values': [base_value, known_value],
            'known_line': _ensure_sentence(f'Что известно: у {known_name.capitalize()} было {_format_number(known_value)} {answer_label}, и это в {_format_number(factor)} раза {relation}, чем у {base_name.capitalize()}'),
            'relation_line': relation_line,
        }
    return None


def _try_times_related_subject_problem(raw_text: str) -> Optional[str]:
    parsed = _parse_times_related_subject_problem(raw_text)
    if not parsed:
        return None

    text = parsed['text']
    lower = parsed['lower']
    question = parsed['question']
    answer_label = parsed['answer_label']
    subject_entries = parsed['subject_entries']
    current_values = list(parsed['current_values'])

    actions, matches = _extract_sequential_actions(lower)
    filtered_actions = [
        (action, match)
        for action, match in zip(actions, matches)
        if match.start() > parsed['relation_end']
    ]
    if not filtered_actions:
        return None

    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        parsed['known_line'],
        _ensure_sentence(f'Что нужно найти: {(question or "нужное количество после изменений").rstrip("?.!")}'),
        parsed['relation_line'],
    ]

    step_number = 2
    for action, match in filtered_actions:
        transfer = _extract_dual_subject_transfer_action(lower, match, subject_entries, action['value'])
        if transfer:
            step_number = _apply_dual_subject_transfer_step(lines, step_number, current_values, transfer, subject_entries, answer_label)
            if step_number is None:
                return None
            continue
        target_index = _detect_dual_subject_action_index(lower, match, subject_entries)
        if target_index is None:
            return None
        old_value = current_values[target_index]
        change_value = action['value']
        new_value = old_value + action['sign'] * change_value
        if new_value < 0:
            return None
        operation = '+' if action['sign'] > 0 else '-'
        lines.append(
            f'{step_number}) Изменяем количество у {subject_entries[target_index]["label"]}: '
            f'{_format_number(old_value)} {operation} {_format_number(change_value)} = {_format_number(new_value)} {answer_label}.'
        )
        current_values[target_index] = new_value
        step_number += 1

    order = _question_subject_order(question, subject_entries)
    relation_word = 'меньше' if 'меньше' in question else 'больше' if 'больше' in question else ''

    if 'вместе' in question or 'всего' in question:
        total_value = current_values[0] + current_values[1]
        lines.append(
            f'{step_number}) Находим, сколько стало вместе: '
            f'{_format_number(current_values[0])} + {_format_number(current_values[1])} = {_format_number(total_value)} {answer_label}.'
        )
        lines.append(f'Ответ: {_format_number(total_value)} {answer_label}')
        lines.append('Совет: сначала найди второе количество по сравнению “в несколько раз”, затем выполни все изменения и только потом складывай результаты.')
        return _join_lines(lines)

    if len(order) >= 2:
        first_index, second_index = order[0], order[1]
    elif len(order) == 1:
        first_index, second_index = order[0], 1 - order[0]
    else:
        first_index, second_index = 0, 1

    first_value = current_values[first_index]
    second_value = current_values[second_index]

    if 'во сколько раз' in question:
        if relation_word == 'меньше':
            if first_value <= 0 or second_value < first_value:
                return None
            numerator_value, denominator_value = second_value, first_value
        else:
            if second_value <= 0:
                return None
            if relation_word == 'больше' and first_value < second_value:
                return None
            numerator_value, denominator_value = first_value, second_value
        ratio_value = numerator_value / denominator_value
        lines.append(
            f'{step_number}) Для кратного сравнения делим одно новое количество на другое: '
            f'{_format_number(numerator_value)} : {_format_number(denominator_value)} = {_format_number(ratio_value)}.'
        )
        lines.append(f'Ответ: в {_format_number(ratio_value)} раза')
        lines.append('Совет: сначала выполни все изменения у каждого ребёнка, а потом раздели большее количество на меньшее.')
        return _join_lines(lines)

    if 'на сколько' in question:
        if relation_word == 'меньше':
            if second_value < first_value:
                return None
            bigger_value, smaller_value = second_value, first_value
        elif relation_word == 'больше':
            if first_value < second_value:
                return None
            bigger_value, smaller_value = first_value, second_value
        else:
            bigger_value, smaller_value = max(first_value, second_value), min(first_value, second_value)
        difference_value = bigger_value - smaller_value
        lines.append(
            f'{step_number}) Сравниваем новые количества: '
            f'{_format_number(bigger_value)} - {_format_number(smaller_value)} = {_format_number(difference_value)} {answer_label}.'
        )
        lines.append(f'Ответ: на {_format_number(difference_value)} {answer_label}')
        lines.append('Совет: сначала найди оба новых количества, а потом вычти меньшее из большего.')
        return _join_lines(lines)

    if not order:
        return None
    target_index = order[0]
    lines.append(
        f'{step_number}) Смотрим новое количество у {subject_entries[target_index]["label"]}: '
        f'{_format_number(current_values[target_index])} {answer_label}.'
    )
    lines.append(f'Ответ: {_format_number(current_values[target_index])} {answer_label}')
    lines.append('Совет: сначала найди второе количество по сравнению “в несколько раз”, а потом выполни все изменения по порядку.')
    return _join_lines(lines)


__all__ = ['_parse_times_related_subject_problem', '_try_times_related_subject_problem']
