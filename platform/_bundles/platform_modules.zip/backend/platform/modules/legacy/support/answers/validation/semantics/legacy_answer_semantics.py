from __future__ import annotations

import re
from typing import Optional

from backend.legacy_formatting_helpers import _clean_text, _normalize_space
from backend.legacy_school_helpers import _RUBLE_RE


def _answer_unit_family(answer_unit: str) -> Optional[str]:
    unit = _normalize_space(answer_unit).lower().replace('ё', 'е').strip(' .')
    unit = unit.replace('²', '2').replace('^2', '2')
    if unit in {'руб', 'рубль', 'рубля', 'рублей', 'р', 'р.'}:
        return 'money'
    if unit in {'мм', 'см', 'дм', 'м', 'км'}:
        return 'length'
    if unit in {'см2', 'м2', 'дм2', 'мм2', 'км2'}:
        return 'area'
    if unit in {'г', 'кг'}:
        return 'mass'
    if unit in {'л', 'мл'}:
        return 'volume'
    if unit in {'ч', 'час', 'часа', 'часов', 'мин', 'минута', 'минуты', 'минут', 'с', 'сек', 'секунда', 'секунды', 'секунд'}:
        return 'time'
    return None


def _text_mentions_unit_family(user_text: str, family: str) -> bool:
    lower = _clean_text(user_text).lower().replace('ё', 'е')
    if family == 'money':
        return re.search(_RUBLE_RE, lower) is not None or 'денег' in lower or 'сдач' in lower
    if family == 'length':
        return re.search(r'\b(?:мм|см|дм|м|км)\b', lower) is not None or any(word in lower for word in ('длина', 'периметр', 'сторона', 'отрезок'))
    if family == 'area':
        return 'площад' in lower or re.search(r'(?:см|м|дм|мм|км)(?:²|2)', lower) is not None
    if family == 'mass':
        return re.search(r'\b(?:г|кг)\b', lower) is not None or 'масса' in lower
    if family == 'volume':
        return re.search(r'\b(?:л|мл)\b', lower) is not None or 'литр' in lower
    if family == 'time':
        return re.search(r'\b(?:ч|час(?:а|ов)?|мин(?:ут(?:а|ы|у)?)?|сек(?:унд(?:а|ы|у)?)?|с)\b', lower) is not None or 'врем' in lower
    return True


def _answer_unit_matches_text(answer_unit: str, user_text: str) -> bool:
    family = _answer_unit_family(answer_unit)
    if not family:
        return True
    return _text_mentions_unit_family(user_text, family)


def _normalize_ai_equation(expression: str) -> str:
    cleaned = _normalize_space(expression)
    cleaned = cleaned.replace('×', '*').replace('x', '*').replace('X', '*').replace('х', '*').replace('Х', '*')
    cleaned = cleaned.replace(':', '/').replace('−', '-').replace('–', '-').replace('—', '-')
    cleaned = cleaned.replace('·', '*').replace(',', '.')
    cleaned = cleaned.replace(' ', '')
    return cleaned


__all__ = [
    '_answer_unit_family',
    '_answer_unit_matches_text',
    '_normalize_ai_equation',
    '_text_mentions_unit_family',
]
