from __future__ import annotations

import re
from fractions import Fraction
from typing import Any, Optional

from backend.legacy_math_signals import _clean_text, _normalize_space
from backend.legacy_question_flow_helpers import _question_count_label, _question_subject_order, _question_text, _subject_token_key
from backend.legacy_dual_subject_action_helpers import _detect_dual_subject_action_index, _extract_dual_subject_transfer_action, _extract_named_subject_entries_from_text
from backend.legacy_measure_helpers import _extract_compound_quantities
from backend.legacy_school_helpers import _RUBLE_RE, _TRANSFER_ACTION_VERBS, _format_number, _split_known_and_question, _to_fraction
from backend.legacy_sequential_action_helpers import _extract_final_change_result_value, _extract_sequential_actions
from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines

def _extract_reverse_transfer_subject_entries(text_lower: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen_keys: set[str] = set()

    generic_specs = (
        ('first', re.search(r'\b(?:перв\w*|одн\w*)\b', text_lower), 'первое количество', 'у первого количества'),
        ('second', re.search(r'\b(?:втор\w*|друг\w*)\b', text_lower), 'второе количество', 'у второго количества'),
    )
    for key, found, label, phrase in generic_specs:
        if found and key not in seen_keys:
            entries.append({'keys': {key}, 'label': label, 'phrase': phrase})
            seen_keys.add(key)
        if len(entries) >= 2:
            return entries

    for entry in _extract_named_subject_entries_from_text(text_lower):
        key = next(iter(entry['keys']), '')
        if not key or key in seen_keys:
            continue
        label = entry['label']
        entries.append({'keys': {key}, 'label': label, 'phrase': f'у {label}'})
        seen_keys.add(key)
        if len(entries) >= 2:
            return entries
    return entries


def _subject_index_from_word(word: str, subject_entries: list[dict[str, Any]]) -> Optional[int]:
    key = _subject_token_key(word)
    if not key:
        return None
    for index, entry in enumerate(subject_entries[:2]):
        if key in entry['keys']:
            return index
    return None


def _extract_known_initial_value_for_subject(text_lower: str, entry: dict[str, Any]) -> Optional[Fraction]:
    values_with_start: list[Fraction] = []
    values_simple: list[Fraction] = []
    labels = [entry.get('label', '').lower().replace('ё', 'е')]
    keys = list(entry.get('keys', set()))

    patterns_with_start: list[re.Pattern[str]] = []
    patterns_simple: list[re.Pattern[str]] = []
    for key in keys:
        if key == 'first':
            patterns_with_start.extend([
                re.compile(r'\b(?:в|во|у|из|к)\s+(?:перв\w*|одн\w*)\b[^.?!]*?\bсначала\b[^.?!]*?(\d+(?:[.,]\d+)?)', re.IGNORECASE),
                re.compile(r'\b(?:в|во|у|из|к)\s+(?:перв\w*|одн\w*)\b[^.?!]*?\bбыло\b\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE),
            ])
            patterns_simple.append(
                re.compile(r'\b(?:в|во|у)\s+(?:перв\w*|одн\w*)\b(?:\s+[а-яёa-z-]+)?\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE)
            )
        elif key == 'second':
            patterns_with_start.extend([
                re.compile(r'\b(?:в|во|у|из|к)\s+(?:втор\w*|друг\w*)\b[^.?!]*?\bсначала\b[^.?!]*?(\d+(?:[.,]\d+)?)', re.IGNORECASE),
                re.compile(r'\b(?:в|во|у|из|к)\s+(?:втор\w*|друг\w*)\b[^.?!]*?\bбыло\b\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE),
            ])
            patterns_simple.append(
                re.compile(r'\b(?:в|во|у)\s+(?:втор\w*|друг\w*)\b(?:\s+[а-яёa-z-]+)?\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE)
            )
    for label in labels:
        if label and label not in {'первое количество', 'второе количество'}:
            escaped = re.escape(label)
            patterns_with_start.extend([
                re.compile(rf'\bу\s+{escaped}\b[^.?!]*?\bсначала\b[^.?!]*?(\d+(?:[.,]\d+)?)', re.IGNORECASE),
                re.compile(rf'\bу\s+{escaped}\b[^.?!]*?\bбыло\b\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE),
            ])
            patterns_simple.append(
                re.compile(rf'\bу\s+{escaped}\b\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE)
            )

    for pattern in patterns_with_start:
        for match in pattern.finditer(text_lower):
            values_with_start.append(_to_fraction(match.group(1)))
    if values_with_start:
        return values_with_start[-1]

    for pattern in patterns_simple:
        for match in pattern.finditer(text_lower):
            values_simple.append(_to_fraction(match.group(1)))
    if values_simple:
        return values_simple[0]
    return None


def _strip_total_clause_for_relation_search(known_lower: str) -> str:
    stripped = re.sub(
        r'(?:после\s+этого\s+)?(?:у\s+них\s+)?(?:вместе|всего)\s+(?:стал(?:о|а|и|ось)|остал(?:ось|ся|ась|ись))\s*[^,.?!;]+,\s*(?:а|и)\s+',
        '',
        known_lower,
        flags=re.IGNORECASE,
    )
    stripped = re.sub(
        r'(?:после\s+этого\s+)?в\s+дв[еу]х\s+[а-яёa-z-]+(?:\s+вместе)?\s+(?:стал(?:о|а|и|ось)|остал(?:ось|ся|ась|ись))\s*[^,.?!;]+,\s*(?:а|и)\s+',
        '',
        stripped,
        flags=re.IGNORECASE,
    )
    return stripped


_EQUALITY_MARKER_PATTERN = (
    r'(?:поровну|одинаково|равны|равно|'
    r'столько\s+же(?:[^.?!]*?\bсколько\b[^.?!]*)?|'
    r'одинаков(?:ое|ые|ая)\s+(?:количеств(?:о|а)|числ(?:о|а)|сумм(?:а|ы)|величин(?:а|ы))|'
    r'одинаков(?:ыми|ым|ой|ые)|'
    r'равн(?:ыми|ым|ой))'
)


def _entry_reference_pattern(entry: dict[str, Any]) -> str:
    alternatives: list[str] = []
    keys = set(entry.get('keys') or set())
    if 'first' in keys:
        alternatives.append(r'(?:в|во|у|из|к|от)\s+(?:перв\w*|одн\w*)(?:\s+[а-яёa-z-]+)?')
    if 'second' in keys:
        alternatives.append(r'(?:в|во|у|из|к|от)\s+(?:втор\w*|друг\w*)(?:\s+[а-яёa-z-]+)?')

    for key in sorted(keys):
        if key in {'first', 'second'}:
            continue
        alternatives.append(r'(?:у|в|во|из|к|от)?\s*' + re.escape(key) + r'[а-яёa-z-]*')

    label = _normalize_space(str(entry.get('label') or '')).lower().replace('ё', 'е')
    if label and label not in {'первое количество', 'второе количество'}:
        words = [word for word in re.findall(r'[а-яёa-z-]+', label) if _subject_token_key(word)]
        if words:
            first_word = words[0]
            alternatives.append(r'(?:у|в|во|из|к|от)?\s*' + re.escape(first_word) + r'[а-яёa-z-]*')

    alternatives = list(dict.fromkeys(alternatives))
    return '(?:' + '|'.join(alternatives) + ')' if alternatives else r'[а-яёa-z-]+'


def _extract_dual_subject_equality_relation_from_known_text(
    known_lower: str,
    subject_entries: list[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    if not known_lower:
        return None

    result: Optional[dict[str, Any]] = None
    for left_index, left_entry in enumerate(subject_entries[:2]):
        left_pattern = _entry_reference_pattern(left_entry)
        for right_index, right_entry in enumerate(subject_entries[:2]):
            if left_index == right_index:
                continue
            right_pattern = _entry_reference_pattern(right_entry)
            equality_patterns = (
                re.compile(
                    rf'{left_pattern}[^.?!]*?\bи\b[^.?!]*?{right_pattern}[^.?!]*?(?:стал(?:о|а|и|ось|ся|ась|ись)?|остал(?:ось|ся|ась|ись)|получил(?:ось)?|получились?)\b[^.?!]*?{_EQUALITY_MARKER_PATTERN}',
                    re.IGNORECASE,
                ),
                re.compile(
                    rf'{left_pattern}[^.?!]*?(?:стал(?:о|а|и|ось|ся|ась|ись)?|остал(?:ось|ся|ась|ись)|получил(?:ось)?|получились?)\b[^.?!]*?\bстолько\s+же\b[^.?!]*?\bсколько\b[^.?!]*?{right_pattern}',
                    re.IGNORECASE,
                ),
                re.compile(
                    rf'{left_pattern}[^.?!]*?и[^.?!]*?{right_pattern}[^.?!]*?\bстали\s+равны\b',
                    re.IGNORECASE,
                ),
                re.compile(
                    rf'{left_pattern}[^.?!]*?и[^.?!]*?{right_pattern}[^.?!]*?\b(?:стало|стали|стала)\b[^.?!]*?\bодинаков(?:ое|ые|ая)\s+(?:количеств(?:о|а)|числ(?:о|а)|сумм(?:а|ы)|величин(?:а|ы))\b',
                    re.IGNORECASE,
                ),
            )
            if any(pattern.search(known_lower) for pattern in equality_patterns):
                result = {
                    'kind': 'difference',
                    'left_index': left_index,
                    'right_index': right_index,
                    'value': Fraction(0),
                    'word': 'равно',
                    'equal': True,
                }
    if result is not None:
        return result

    generic_equality_patterns = (
        re.compile(rf'\b(?:стал(?:о|а|и|ось|ся|ась|ись)|остал(?:ось|ся|ась|ись)|получил(?:ось)?|получились?)\b[^.?!]*?{_EQUALITY_MARKER_PATTERN}', re.IGNORECASE),
        re.compile(r'\b(?:количество|число|сумма|величина)\b[^.?!]*?\b(?:стало|стали|стала)\b[^.?!]*?\bодинаков', re.IGNORECASE),
    )
    if len(subject_entries) >= 2 and any(pattern.search(known_lower) for pattern in generic_equality_patterns):
        return {
            'kind': 'difference',
            'left_index': 0,
            'right_index': 1,
            'value': Fraction(0),
            'word': 'равно',
            'equal': True,
        }
    return None


def _extract_reverse_transfer_relation(raw_text: str, subject_entries: list[dict[str, Any]]) -> Optional[dict[str, Any]]:
    known, _ = _split_known_and_question(raw_text)
    known_lower = _normalize_space(known).lower().replace('ё', 'е')
    if not known_lower:
        return None

    known_lower = _strip_total_clause_for_relation_search(known_lower)

    relation_patterns = (
        (
            'ratio',
            re.compile(
                r'(?:у|в|во)\s+([а-яёa-z-]+)\b[^.?!]*?стал(?:о|а|и|ось)?[^.?!]*?в\s*(\d+(?:[.,]\d+)?)\s+раз[а]?\s+(больше|меньше)[^.?!]*?чем\s+(?:у|в|во)\s+([а-яёa-z-]+)\b',
                re.IGNORECASE,
            ),
        ),
        (
            'difference',
            re.compile(
                r'(?:у|в|во)\s+([а-яёa-z-]+)\b[^.?!]*?стал(?:о|а|и|ось)?[^.?!]*?на\s*(\d+(?:[.,]\d+)?)\s+(?:[а-яёa-z/-]+\s+)?(больше|меньше)[^.?!]*?чем\s+(?:у|в|во)\s+([а-яёa-z-]+)\b',
                re.IGNORECASE,
            ),
        ),
    )

    result: Optional[dict[str, Any]] = None
    for kind, pattern in relation_patterns:
        for match in pattern.finditer(known_lower):
            left_index = _subject_index_from_word(match.group(1), subject_entries)
            right_index = _subject_index_from_word(match.group(4), subject_entries)
            if left_index is None or right_index is None or left_index == right_index:
                continue
            result = {
                'kind': kind,
                'left_index': left_index,
                'right_index': right_index,
                'value': _to_fraction(match.group(2)),
                'word': match.group(3).lower().replace('ё', 'е'),
            }
    return result or _extract_dual_subject_equality_relation_from_known_text(known_lower, subject_entries)


def _extract_reverse_transfer_total_value(raw_text: str) -> Optional[Fraction]:
    known, _ = _split_known_and_question(raw_text)
    known_lower = _normalize_space(known).lower().replace('ё', 'е')
    if not known_lower:
        return None

    result: Optional[Fraction] = None
    patterns = (
        re.compile(
            r'(?:после\s+этого[^.?!]*?)?(?:у\s+них\s+)?(?:вместе|всего)\s+(?:стал(?:о|а|и)|остал(?:ось|ся|ась|ись))\s*(\d+(?:[.,]\d+)?)',
            re.IGNORECASE,
        ),
        re.compile(
            r'(?:после\s+этого[^.?!]*?)?в\s+дв[еу]х\s+[а-яёa-z-]+(?:\s+вместе)?\s+(?:стал(?:о|а|и)|остал(?:ось|ся|ась|ись))\s*(\d+(?:[.,]\d+)?)',
            re.IGNORECASE,
        ),
        re.compile(
            r'(?:после\s+этого[^.?!]*?)?(?:стал(?:о|а|и)|остал(?:ось|ся|ась|ись))\s*(\d+(?:[.,]\d+)?)\s+[а-яёa-z/-]+\s+(?:вместе|всего)',
            re.IGNORECASE,
        ),
    )
    for pattern in patterns:
        for match in pattern.finditer(known_lower):
            result = _to_fraction(match.group(1))
    return result


def _solve_reverse_transfer_final_values_from_total_relation(total_value: Fraction, relation: dict[str, Any]) -> Optional[list[Fraction]]:
    if total_value < 0:
        return None

    left_index = relation['left_index']
    right_index = relation['right_index']
    relation_value = relation['value']
    relation_word = relation['word']
    if relation_value < 0:
        return None

    if relation['kind'] == 'difference':
        if total_value < relation_value:
            return None
        smaller = (total_value - relation_value) / 2
        bigger = smaller + relation_value
        if smaller < 0 or bigger < 0:
            return None
        if relation_word == 'больше':
            left_value = bigger
            right_value = smaller
        else:
            left_value = smaller
            right_value = bigger
    else:
        if relation_value <= 0:
            return None
        part_count = relation_value + 1
        if part_count == 0:
            return None
        small_value = total_value / part_count
        big_value = total_value - small_value
        if small_value < 0 or big_value < 0:
            return None
        if relation_word == 'больше':
            left_value = big_value
            right_value = small_value
        else:
            left_value = small_value
            right_value = big_value

    result = [Fraction(0), Fraction(0)]
    result[left_index] = left_value
    result[right_index] = right_value
    return result


def _is_total_change_action(text_lower: str, action_match: re.Match[str]) -> bool:
    verb = action_match.group(1).lower().replace('ё', 'е')
    if verb in _TRANSFER_ACTION_VERBS:
        return False
    before_full = text_lower[max(0, action_match.start() - 80):action_match.start()]
    after_full = text_lower[action_match.end():action_match.end() + 80]
    before_segment = re.split(r'[,.!?;]', before_full)[-1]
    after_segment = re.split(r'[,.!?;]', after_full)[0]
    context = f'{before_segment} {after_segment}'
    return bool(re.search(
        r'\b(вместе|всего|они|оба|обе|обоим|обеим|им|у\s+них|в\s+дв[еу]х|в\s+обоих|в\s+обеих)\b',
        context,
        re.IGNORECASE,
    ))


def _classify_reverse_transfer_mixed_actions(
    text_lower: str,
    actions: list[dict[str, Any]],
    matches: list[re.Match[str]],
    subject_entries: list[dict[str, Any]],
) -> Optional[list[dict[str, Any]]]:
    classified: list[dict[str, Any]] = []
    for action, match in zip(actions, matches):
        verb = match.group(1).lower().replace('ё', 'е')
        transfer = None
        if verb in _TRANSFER_ACTION_VERBS:
            transfer = _extract_dual_subject_transfer_action(text_lower, match, subject_entries, action['value'])
        if transfer:
            classified.append({'kind': 'transfer', **transfer})
            continue

        if _is_total_change_action(text_lower, match):
            classified.append({'kind': 'total', 'sign': action['sign'], 'value': action['value'], 'verb': verb})
            continue

        target_index = _detect_dual_subject_action_index(text_lower, match, subject_entries)
        if target_index is None:
            return None
        classified.append({
            'kind': 'subject',
            'target_index': target_index,
            'sign': action['sign'],
            'value': action['value'],
            'verb': verb,
        })
    return classified


def _looks_like_reverse_transfer_mixed_total_problem(text: str) -> bool:
    cleaned = _clean_text(text)
    lower = cleaned.lower().replace('ё', 'е')
    if _extract_compound_quantities(cleaned):
        return False
    question = _question_text(cleaned).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if 'сначала' not in question and 'было' not in question:
        return False
    if _extract_reverse_transfer_total_value(cleaned) is None:
        return False
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return False
    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return False
    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified:
        return False
    kinds = {item['kind'] for item in classified}
    return 'transfer' in kinds and (('subject' in kinds) or ('total' in kinds))


def _reverse_total_through_mixed_actions(
    lines: list[str],
    step_number: int,
    final_total: Fraction,
    classified_actions: list[dict[str, Any]],
    subject_entries: list[dict[str, Any]],
    answer_label: str,
) -> Optional[tuple[int, Fraction]]:
    label_suffix = f' {answer_label}' if answer_label else ''
    current_total = final_total
    for action in reversed(classified_actions):
        kind = action['kind']
        if kind == 'transfer':
            lines.append(
                f'{step_number}) Передача между двумя объектами не меняет общее количество. Значит, вместе до этой передачи было столько же: {_format_number(current_total)}{label_suffix}.'
            )
            step_number += 1
            continue

        if action['sign'] > 0:
            previous_total = current_total - action['value']
            operation = '-'
            comment = 'Отменяем прибавление'
        else:
            previous_total = current_total + action['value']
            operation = '+'
            comment = 'Отменяем уменьшение'
        if previous_total < 0:
            return None

        if kind == 'total':
            lines.append(
                f'{step_number}) {comment} в общей сумме: {_format_number(current_total)} {operation} {_format_number(action["value"])} = {_format_number(previous_total)}{label_suffix}.'
            )
        else:
            subject_phrase = _reverse_subject_phrase(subject_entries[action['target_index']])
            lines.append(
                f'{step_number}) {comment.lower()} у {subject_phrase[2:] if subject_phrase.startswith("у ") else subject_phrase} и считаем общую сумму назад: '
                f'{_format_number(current_total)} {operation} {_format_number(action["value"])} = {_format_number(previous_total)}{label_suffix}.'
            )
        current_total = previous_total
        step_number += 1
    return step_number, current_total


def _append_final_total_relation_solution(
    lines: list[str],
    step_number: int,
    total_value: Fraction,
    relation: dict[str, Any],
    subject_entries: list[dict[str, Any]],
    answer_label: str,
) -> Optional[tuple[int, list[Fraction]]]:
    label_suffix = f' {answer_label}' if answer_label else ''
    final_values = _solve_reverse_transfer_final_values_from_total_relation(total_value, relation)
    if not final_values:
        return None

    if relation['kind'] == 'difference':
        difference_value = relation['value']
        if relation.get('equal') or difference_value == 0:
            equal_value = final_values[relation['left_index']]
            left_phrase = _reverse_subject_phrase(subject_entries[relation['left_index']])
            right_phrase = _reverse_subject_phrase(subject_entries[relation['right_index']])
            lines.append(
                f'{step_number}) После всех изменений количества стали поровну. Значит, общую сумму делим пополам: '
                f'{_format_number(total_value)} : 2 = {_format_number(equal_value)}{label_suffix}.'
            )
            step_number += 1
            lines.append(
                f'{step_number}) Получаем конечные количества: {left_phrase} стало {_format_number(equal_value)}{label_suffix}, '
                f'а {right_phrase} — {_format_number(equal_value)}{label_suffix}.'
            )
            step_number += 1
            return step_number, final_values

        equal_part = total_value - difference_value
        if equal_part < 0:
            return None
        if relation['word'] == 'больше':
            smaller_index = relation['right_index']
            bigger_index = relation['left_index']
        else:
            smaller_index = relation['left_index']
            bigger_index = relation['right_index']
        smaller_phrase = _reverse_subject_phrase(subject_entries[smaller_index])
        bigger_phrase = _reverse_subject_phrase(subject_entries[bigger_index])
        lines.append(
            f'{step_number}) После всех изменений вместе стало {_format_number(total_value)}{label_suffix}, а разница между количествами равна {_format_number(difference_value)}{label_suffix}. '
            f'Уберём разницу: {_format_number(total_value)} - {_format_number(difference_value)} = {_format_number(equal_part)}{label_suffix}. '
            f'Теперь осталось две равные части.'
        )
        step_number += 1
        smaller_final = final_values[smaller_index]
        bigger_final = final_values[bigger_index]
        lines.append(
            f'{step_number}) Находим меньшее конечное количество: {_format_number(equal_part)} : 2 = {_format_number(smaller_final)}{label_suffix}. '
            f'Значит, {smaller_phrase} стало {_format_number(smaller_final)}{label_suffix}, '
            f'а {bigger_phrase} — {_format_number(bigger_final)}{label_suffix}.'
        )
        step_number += 1
        return step_number, final_values

    if relation['value'] <= 0:
        return None
    part_count = relation['value'] + 1
    if relation['word'] == 'больше':
        smaller_index = relation['right_index']
        bigger_index = relation['left_index']
    else:
        smaller_index = relation['left_index']
        bigger_index = relation['right_index']
    smaller_phrase = _reverse_subject_phrase(subject_entries[smaller_index])
    bigger_phrase = _reverse_subject_phrase(subject_entries[bigger_index])
    smaller_final = final_values[smaller_index]
    bigger_final = final_values[bigger_index]
    lines.append(
        f'{step_number}) После всех изменений вместе стало {_format_number(total_value)}{label_suffix}. Если одно количество в {_format_number(relation["value"])} раза больше другого, '
        f'то всё вместе — это {_format_number(part_count)} равные части.'
    )
    step_number += 1
    lines.append(
        f'{step_number}) Находим одну часть: {_format_number(total_value)} : {_format_number(part_count)} = {_format_number(smaller_final)}{label_suffix}. '
        f'Значит, {smaller_phrase} стало {_format_number(smaller_final)}{label_suffix}, '
        f'а {bigger_phrase} — {_format_number(bigger_final)}{label_suffix}.'
    )
    step_number += 1
    return step_number, final_values


def _reverse_values_through_mixed_actions(
    lines: list[str],
    step_number: int,
    final_values: list[Fraction],
    classified_actions: list[dict[str, Any]],
    subject_entries: list[dict[str, Any]],
    answer_label: str,
) -> Optional[tuple[int, list[Fraction]]]:
    label_suffix = f' {answer_label}' if answer_label else ''
    current_values = final_values[:]
    for action in reversed(classified_actions):
        kind = action['kind']
        if kind == 'transfer':
            source_index = action['source_index']
            target_index = action['target_index']
            previous_source = current_values[source_index] + action['value']
            previous_target = current_values[target_index] - action['value']
            if previous_source < 0 or previous_target < 0:
                return None
            lines.append(
                f'{step_number}) Идём назад через передачу: '
                f'{subject_entries[source_index]["label"]}: {_format_number(current_values[source_index])} + {_format_number(action["value"])} = {_format_number(previous_source)}{label_suffix}, '
                f'{subject_entries[target_index]["label"]}: {_format_number(current_values[target_index])} - {_format_number(action["value"])} = {_format_number(previous_target)}{label_suffix}.'
            )
            current_values[source_index] = previous_source
            current_values[target_index] = previous_target
            step_number += 1
            continue

        if kind == 'total':
            return None

        target_index = action['target_index']
        current_value = current_values[target_index]
        if action['sign'] > 0:
            previous_value = current_value - action['value']
            operation = '-'
            comment = 'Отменяем прибавление'
        else:
            previous_value = current_value + action['value']
            operation = '+'
            comment = 'Отменяем уменьшение'
        if previous_value < 0:
            return None
        subject_phrase = _reverse_subject_phrase(subject_entries[target_index])
        lines.append(
            f'{step_number}) {comment} у {subject_phrase[2:] if subject_phrase.startswith("у ") else subject_phrase}: '
            f'{_format_number(current_value)} {operation} {_format_number(action["value"])} = {_format_number(previous_value)}{label_suffix}.'
        )
        current_values[target_index] = previous_value
        step_number += 1
    return step_number, current_values


def _forward_known_subject_value_through_actions(
    initial_value: Fraction,
    subject_index: int,
    classified_actions: list[dict[str, Any]],
) -> Optional[tuple[Fraction, list[dict[str, Any]]]]:
    current_value = initial_value
    applied_steps: list[dict[str, Any]] = []
    for action in classified_actions:
        kind = action['kind']
        if kind == 'total':
            return None
        if kind == 'subject' and action['target_index'] == subject_index:
            new_value = current_value + action['sign'] * action['value']
            if new_value < 0:
                return None
            applied_steps.append({'kind': kind, 'action': action, 'before': current_value, 'after': new_value})
            current_value = new_value
            continue
        if kind == 'transfer':
            if action['source_index'] == subject_index:
                new_value = current_value - action['value']
            elif action['target_index'] == subject_index:
                new_value = current_value + action['value']
            else:
                continue
            if new_value < 0:
                return None
            applied_steps.append({'kind': kind, 'action': action, 'before': current_value, 'after': new_value})
            current_value = new_value
            continue
    return current_value, applied_steps


def _looks_like_reverse_transfer_total_pattern(text: str) -> bool:
    cleaned = _clean_text(text)
    lower = cleaned.lower().replace('ё', 'е')
    if _extract_compound_quantities(cleaned):
        return False
    question = _question_text(cleaned).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if 'сначала' not in question and 'было' not in question:
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return False
    if not all(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return False
    if _extract_reverse_transfer_total_value(cleaned) is None:
        return False

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    return len(subject_entries) >= 2


def _looks_like_reverse_transfer_total_problem(text: str) -> bool:
    cleaned = _clean_text(text)
    lower = cleaned.lower().replace('ё', 'е')
    if _extract_compound_quantities(cleaned):
        return False
    question = _question_text(cleaned).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if 'сначала' not in question and 'было' not in question:
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return False
    if not all(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return False

    total_value = _extract_reverse_transfer_total_value(cleaned)
    if total_value is None:
        return False

    question_mode = _reverse_initial_question_mode(question)
    if question_mode == 'total':
        return True

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        return False

    relation = _extract_reverse_transfer_relation(cleaned, subject_entries)
    if relation:
        return True

    known_initials = [_extract_known_initial_value_for_subject(lower, entry) for entry in subject_entries[:2]]
    return sum(value is not None for value in known_initials) == 1


def _reverse_initial_question_mode(question_lower: str) -> str:
    question = _normalize_space(question_lower).lower().replace('ё', 'е')
    if not question:
        return 'target'
    if 'во сколько' in question:
        return 'ratio'
    if 'на сколько' in question or 'отличал' in question:
        return 'difference'
    if 'у каждого' in question or 'по отдельности' in question:
        return 'both'
    if re.search(r'\bу\s+[а-яёa-z-]+\s+и\s+у\s+[а-яёa-z-]+\b', question):
        return 'both'
    if re.search(r'\bв\s+перв\w*\b[^?.!]*?\bи\b[^?.!]*?\b(?:во|в)\s+втор\w*\b', question):
        return 'both'
    if 'вместе' in question or 'всего' in question or 'у них' in question or re.search(r'\bв\s+дв[еу]х\b', question):
        return 'total'
    return 'target'


def _reverse_subject_phrase(entry: dict[str, Any]) -> str:
    phrase = _normalize_space(str(entry.get('phrase') or ''))
    if phrase:
        return phrase
    label = _normalize_space(str(entry.get('label') or ''))
    if not label:
        return 'у первого объекта'
    return f'у {label}'


def _append_reverse_initial_summary(
    lines: list[str],
    step_number: int,
    question_lower: str,
    subject_entries: list[dict[str, Any]],
    initial_values: list[Fraction],
    answer_label: str,
) -> tuple[int, Optional[str]]:
    mode = _reverse_initial_question_mode(question_lower)
    if mode == 'target':
        return step_number, None
    if len(initial_values) < 2:
        return step_number, None
    first_value, second_value = initial_values[:2]
    label_suffix = f' {answer_label}' if answer_label else ''
    first_phrase = _reverse_subject_phrase(subject_entries[0])
    second_phrase = _reverse_subject_phrase(subject_entries[1])

    if mode == 'both':
        order = _question_subject_order(question_lower, subject_entries)
        if len(order) >= 2:
            first_index, second_index = order[:2]
        else:
            first_index, second_index = 0, 1
        first_entry = subject_entries[first_index]
        second_entry = subject_entries[second_index]
        first_subject_value = initial_values[first_index]
        second_subject_value = initial_values[second_index]
        first_subject_phrase = _reverse_subject_phrase(first_entry)
        second_subject_phrase = _reverse_subject_phrase(second_entry)
        lines.append(
            f'{step_number}) Теперь знаем начальные количества: {first_subject_phrase} было {_format_number(first_subject_value)}{label_suffix}, '
            f'{second_subject_phrase} — {_format_number(second_subject_value)}{label_suffix}.'
        )
        return step_number + 1, f'{first_subject_phrase} — {_format_number(first_subject_value)}{label_suffix}, {second_subject_phrase} — {_format_number(second_subject_value)}{label_suffix}'

    if mode == 'total':
        total_value = first_value + second_value
        lines.append(
            f'{step_number}) Теперь знаем начальные количества: {first_phrase} было {_format_number(first_value)}{label_suffix}, '
            f'{second_phrase} — {_format_number(second_value)}{label_suffix}. '
            f'Сначала вместе было: {_format_number(first_value)} + {_format_number(second_value)} = {_format_number(total_value)}{label_suffix}.'
        )
        return step_number + 1, f'{_format_number(total_value)}{label_suffix}'

    if mode == 'difference':
        bigger = max(first_value, second_value)
        smaller = min(first_value, second_value)
        diff_value = bigger - smaller
        lines.append(
            f'{step_number}) Теперь знаем начальные количества: {first_phrase} было {_format_number(first_value)}{label_suffix}, '
            f'{second_phrase} — {_format_number(second_value)}{label_suffix}. '
            f'Находим разницу: {_format_number(bigger)} - {_format_number(smaller)} = {_format_number(diff_value)}{label_suffix}.'
        )
        return step_number + 1, f'на {_format_number(diff_value)}{label_suffix}'

    if mode == 'ratio':
        bigger = max(first_value, second_value)
        smaller = min(first_value, second_value)
        if smaller == 0:
            return step_number, None
        ratio_value = bigger / smaller
        lines.append(
            f'{step_number}) Теперь знаем начальные количества: {first_phrase} было {_format_number(first_value)}{label_suffix}, '
            f'{second_phrase} — {_format_number(second_value)}{label_suffix}. '
            f'Чтобы узнать, во сколько раз одно количество больше другого, делим большее на меньшее: '
            f'{_format_number(bigger)} : {_format_number(smaller)} = {_format_number(ratio_value)}.'
        )
        return step_number + 1, f'в {_format_number(ratio_value)} раза'

    return step_number, None


def _looks_like_reverse_transfer_relation_problem(text: str) -> bool:
    cleaned = _clean_text(text)
    lower = cleaned.lower().replace('ё', 'е')
    question = _question_text(cleaned).lower().replace('ё', 'е')
    if _extract_compound_quantities(cleaned):
        return False
    if 'сколько' not in question or ('сначала' not in question and 'было' not in question):
        return False
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return False
    if not any(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return False
    if 'чем' not in lower:
        return False
    if not re.search(r'на\s*\d+(?:[.,]\d+)?[^.?!]*(?:больше|меньше)', lower) and not re.search(r'в\s*\d+(?:[.,]\d+)?\s+раз[а]?\s+(?:больше|меньше)', lower):
        return False
    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        return False
    return _extract_reverse_transfer_relation(cleaned, subject_entries) is not None


def _looks_like_reverse_transfer_problem(text: str) -> bool:
    cleaned = _clean_text(text)
    lower = cleaned.lower().replace('ё', 'е')
    if _extract_reverse_transfer_total_value(cleaned) is not None:
        return False
    if _extract_compound_quantities(cleaned):
        return False
    question = _question_text(cleaned).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if 'сначала' not in question and 'было' not in question:
        return False
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return False
    if not any(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return False
    return _extract_final_change_result_value(cleaned) is not None


def _looks_like_reverse_sequential_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    question = _question_text(text).lower().replace('ё', 'е')
    if 'число' in lower:
        return False
    if 'сколько' not in question:
        return False
    if 'сначала' not in question and 'было' not in question:
        return False
    if re.search(_RUBLE_RE, lower):
        return False
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return False
    prefix = lower[:matches[0].start()]
    if re.search(r'\d', prefix):
        return False
    return _extract_final_change_result_value(text) is not None

__all__ = [name for name in globals() if name.startswith("_")]
