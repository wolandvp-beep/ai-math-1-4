from __future__ import annotations

import re
from fractions import Fraction
from typing import Any, Optional

from backend.legacy_math_signals import _clean_text, _normalize_space
from backend.legacy_question_flow_helpers import _question_subject_order, _question_text, _subject_token_key
from backend.legacy_dual_subject_action_helpers import _detect_dual_subject_action_index, _extract_dual_subject_transfer_action
from backend.legacy_measure_helpers import _choose_measure_base_unit, _extract_compound_quantities, _format_measure_total, _measure_quantity_has_final_state_marker, _quantity_value_in_unit, _question_asks_initial_state
from backend.legacy_school_helpers import _ACTION_VERB_RE, _MEASURE_GROUP_SCALES, _MEASURE_PART_RE, _TRANSFER_ACTION_VERBS, _format_number, _split_known_and_question, _to_fraction
from backend.legacy_sequential_action_helpers import _classify_sequential_action
from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_reverse_transfer_helpers import _entry_reference_pattern, _extract_dual_subject_equality_relation_from_known_text, _is_total_change_action, _reverse_initial_question_mode, _reverse_subject_phrase, _strip_total_clause_for_relation_search

def _extract_measured_total_quantity(raw_text: str) -> Optional[dict]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    quantities = _extract_compound_quantities(text)
    if not quantities:
        return None

    total_markers = (
        re.compile(r'(?:после\s+этого[^.?!]*?)?(?:у\s+них\s+)?(?:вместе|всего)\s+(?:стал(?:о|а|и|ось)|остал(?:ось|ся|ась|ись))\s*', re.IGNORECASE),
        re.compile(r'(?:после\s+этого[^.?!]*?)?в\s+дв[еу]х\s+[а-яёa-z-]+(?:\s+вместе)?\s+(?:стал(?:о|а|и|ось)|остал(?:ось|ся|ась|ись))\s*', re.IGNORECASE),
        re.compile(r'(?:после\s+этого[^.?!]*?)?(?:в\s+обоих|в\s+обеих)\s+[а-яёa-z-]+\s+(?:стал(?:о|а|и|ось)|остал(?:ось|ся|ась|ись))\s*', re.IGNORECASE),
    )

    result: Optional[dict] = None
    for pattern in total_markers:
        for match in pattern.finditer(lower):
            clause_end_candidates = [lower.find(sep, match.end()) for sep in ',.;!?' if lower.find(sep, match.end()) >= 0]
            clause_end = min(clause_end_candidates) if clause_end_candidates else len(lower)
            for quantity in quantities:
                if not _measure_quantity_has_final_state_marker(lower, quantity):
                    continue
                if quantity['start'] < match.end() or quantity['end'] > clause_end:
                    continue
                result = quantity
                break
    if result is not None:
        return result

    fallback: Optional[dict] = None
    for quantity in quantities:
        if not _measure_quantity_has_final_state_marker(lower, quantity):
            continue
        context_before = lower[max(0, quantity['start'] - 40):quantity['start']]
        if re.search(r'\b(вместе|всего|у\s+них|в\s+дв[еу]х|в\s+обоих|в\s+обеих)\b', context_before, re.IGNORECASE):
            fallback = quantity
    return fallback


def _split_text_clauses(raw_text: str) -> list[str]:
    return [clause.strip() for clause in re.split(r'[,.!?;]+', _normalize_space(raw_text)) if clause.strip()]


def _extract_measure_subject_entry_from_clause(clause_text: str) -> Optional[dict[str, Any]]:
    clause = _normalize_space(clause_text)
    lower = clause.lower().replace('ё', 'е')
    generic_match = re.search(r'\b(в|во|из|к|у)\s+((?:перв\w*|одн\w*|втор\w*|друг\w*)(?:\s+[а-яёa-z-]+)?)', lower, re.IGNORECASE)
    if generic_match:
        prep = generic_match.group(1)
        descriptor = generic_match.group(2).strip()
        keys = {'first'} if descriptor.startswith(('перв', 'одн')) else {'second'}
        parts = descriptor.split()
        if parts:
            noun_key = _subject_token_key(parts[-1])
            if noun_key:
                keys.add(noun_key)
        label = f'{prep} {descriptor}'.strip()
        return {'keys': keys, 'label': label, 'phrase': label}

    name_match = re.search(r'\bу\s+([а-яёa-z-]+)\b', lower, re.IGNORECASE)
    if name_match:
        name = name_match.group(1)
        label = name.capitalize()
        return {'keys': {_subject_token_key(name)}, 'label': label, 'phrase': f'у {label}'}

    quantity_match = next(_MEASURE_PART_RE.finditer(clause), None)
    prefix = clause[:quantity_match.start()] if quantity_match else clause
    prefix = _normalize_space(prefix)
    prefix = re.sub(r'^\b(?:а|и|но|потом)\b\s*', '', prefix, flags=re.IGNORECASE)
    prefix = re.sub(
        r'\b(?:был(?:о|а|и)?|длил(?:ся|ась|ось|ись)|равнял(?:ся|ась|ось|ись)|составлял(?:а|о|и)?|составил(?:а|о|и)?|составило|составили|стоил(?:а|о|и)?|длиной)\b.*$',
        '',
        prefix,
        flags=re.IGNORECASE,
    )
    words = [
        word for word in re.findall(r'[а-яёa-z-]+', prefix.lower().replace('ё', 'е'))
        if word not in {
            'в', 'во', 'из', 'к', 'у', 'а', 'и', 'но', 'было', 'была', 'были', 'был',
            'несколько', 'литров', 'литра', 'литр', 'миллилитров', 'миллилитра', 'миллилитр',
            'минут', 'минута', 'минуты', 'мин', 'час', 'часа', 'часов',
            'метров', 'метра', 'метр', 'сантиметров', 'сантиметра', 'сантиметр',
            'килограммов', 'килограмма', 'килограмм', 'граммов', 'грамма', 'грамм',
        }
    ]
    if not words:
        return None
    label = ' '.join(words[-2:]) if len(words) >= 2 and words[-2] not in {'в', 'во', 'из', 'к', 'у'} else words[-1]
    keys = {_subject_token_key(word) for word in label.split() if _subject_token_key(word)}
    if not keys:
        return None
    return {'keys': keys, 'label': label, 'phrase': label}


def _extract_measure_subject_pair_entries_from_clause(clause_text: str) -> list[dict[str, Any]]:
    clause = _normalize_space(clause_text)
    lower = clause.lower().replace('ё', 'е')

    generic_match = re.search(
        r'\b(в|во|у|из|к|от)\s+((?:перв\w*|одн\w*)\s+[а-яёa-z-]+)\b[^.?!]*?\b(в|во|у|из|к|от)\s+((?:втор\w*|друг\w*)\s+[а-яёa-z-]+)\b',
        lower,
        re.IGNORECASE,
    )
    if generic_match:
        result: list[dict[str, Any]] = []
        for prep, descriptor, order_key in (
            (generic_match.group(1), generic_match.group(2), 'first'),
            (generic_match.group(3), generic_match.group(4), 'second'),
        ):
            keys = {order_key}
            parts = descriptor.split()
            if parts:
                noun_key = _subject_token_key(parts[-1])
                if noun_key:
                    keys.add(noun_key)
            label = f'{prep} {descriptor}'.strip()
            result.append({'keys': keys, 'label': label, 'phrase': label})
        return result

    pair_match = re.search(
        r'\b([а-яёa-z-]+)\s+и\s+([а-яёa-z-]+)\s+(?:длил(?:ся|ась|ось|ись)|был(?:о|а|и)?|равнял(?:ся|ась|ось|ись)|составлял(?:а|о|и)?|составил(?:а|о|и)?|составило|составили|стоил(?:а|о|и)?|лежал(?:о|а|и)?|лежали|стоял(?:о|а|и)?|стояли|находил(?:ся|ась|ось|ись)|были)\b',
        lower,
        re.IGNORECASE,
    )
    if pair_match:
        result = []
        for word in (pair_match.group(1), pair_match.group(2)):
            key = _subject_token_key(word)
            if not key:
                return []
            label = _normalize_space(word)
            result.append({'keys': {key}, 'label': label, 'phrase': label})
        return result

    return []


def _extract_dual_measure_subject_infos(prefix_text: str) -> list[dict[str, Any]]:
    infos: list[dict[str, Any]] = []
    seen_primary_keys: set[str] = set()
    last_generic_noun_word = ''
    last_generic_noun_key = ''
    for clause in _split_text_clauses(prefix_text):
        if len(infos) < 2 and not infos:
            pair_entries = _extract_measure_subject_pair_entries_from_clause(clause)
            if pair_entries:
                for entry in pair_entries:
                    primary_key = 'first' if 'first' in entry['keys'] else 'second' if 'second' in entry['keys'] else next(iter(entry['keys']), '')
                    if not primary_key or primary_key in seen_primary_keys:
                        continue
                    infos.append({'entry': entry, 'quantity': None})
                    seen_primary_keys.add(primary_key)
                    if len(infos) >= 2:
                        return infos
                continue

        entry = _extract_measure_subject_entry_from_clause(clause)
        if not entry:
            continue
        primary_key = 'first' if 'first' in entry['keys'] else 'second' if 'second' in entry['keys'] else next(iter(entry['keys']), '')
        if not primary_key or primary_key in seen_primary_keys:
            continue

        label_words = str(entry.get('label') or '').split()
        if primary_key in {'first', 'second'}:
            if len(label_words) >= 3:
                last_generic_noun_word = label_words[-1]
                last_generic_noun_key = _subject_token_key(last_generic_noun_word)
            elif len(label_words) == 2 and last_generic_noun_word:
                entry = dict(entry)
                entry['label'] = f'{entry["label"]} {last_generic_noun_word}'
                entry['phrase'] = entry['label']
                keys = set(entry['keys'])
                if last_generic_noun_key:
                    keys.add(last_generic_noun_key)
                entry['keys'] = keys

        quantities = _extract_compound_quantities(clause)
        quantity = quantities[0] if quantities else None
        infos.append({'entry': entry, 'quantity': quantity})
        seen_primary_keys.add(primary_key)
        if len(infos) >= 2:
            break
    return infos


def _measure_clause_bounds(text_lower: str, position: int) -> tuple[int, int]:
    separators = ',.;!?' 
    starts = [text_lower.rfind(sep, 0, position) for sep in separators]
    start = max(starts)
    if start < 0:
        start = 0
    else:
        start += 1
    ends = [text_lower.find(sep, position) for sep in separators if text_lower.find(sep, position) >= 0]
    end = min(ends) if ends else len(text_lower)
    return start, end


def _find_measure_quantity_for_action(
    text_lower: str,
    action_match: re.Match[str],
    next_start: int,
    candidate_quantities: list[dict],
    used_indexes: set[int],
) -> Optional[int]:
    clause_start, clause_end = _measure_clause_bounds(text_lower, action_match.start())
    best_index: Optional[int] = None
    best_score: Optional[int] = None
    for index, quantity in enumerate(candidate_quantities):
        if index in used_indexes:
            continue
        if quantity['start'] >= next_start:
            continue
        if quantity['end'] <= clause_start or quantity['start'] >= clause_end:
            continue
        distance = min(abs(quantity['start'] - action_match.end()), abs(action_match.start() - quantity['end']))
        if best_score is None or distance < best_score:
            best_score = distance
            best_index = index
    if best_index is not None:
        return best_index
    for index, quantity in enumerate(candidate_quantities):
        if index in used_indexes:
            continue
        if quantity['start'] >= next_start:
            continue
        distance = min(abs(quantity['start'] - action_match.end()), abs(action_match.start() - quantity['end']))
        if best_score is None or distance < best_score:
            best_score = distance
            best_index = index
    return best_index


def _classify_measured_mixed_actions(
    raw_text: str,
    subject_entries: list[dict[str, Any]],
    group: str,
    base_unit: str,
    final_total: dict,
) -> Optional[list[dict[str, Any]]]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return None
    all_quantities = [quantity for quantity in _extract_compound_quantities(text) if quantity['group'] == group]
    action_quantities = [
        quantity for quantity in all_quantities
        if quantity['start'] >= matches[0].start() and quantity['start'] < final_total['start'] and quantity is not final_total
    ]
    if not action_quantities:
        return None

    classified: list[dict[str, Any]] = []
    used_indexes: set[int] = set()
    for index, match in enumerate(matches):
        next_start = matches[index + 1].start() if index + 1 < len(matches) else final_total['start']
        quantity_index = _find_measure_quantity_for_action(lower, match, next_start, action_quantities, used_indexes)
        if quantity_index is None:
            continue
        quantity = action_quantities[quantity_index]
        used_indexes.add(quantity_index)
        segment_before = lower[max(0, match.start() - 35):match.start()]
        segment_after = lower[match.end():next_start]
        sign = _classify_sequential_action(match.group(1), segment_before, segment_after)
        if sign is None:
            return None
        value = _quantity_value_in_unit(quantity, base_unit)
        verb = match.group(1).lower().replace('ё', 'е')
        transfer = None
        if verb in _TRANSFER_ACTION_VERBS:
            transfer = _extract_dual_subject_transfer_action(lower, match, subject_entries, value)
        if transfer:
            classified.append({'kind': 'transfer', **transfer, 'pretty': quantity['pretty']})
            continue
        if _is_total_change_action(lower, match):
            classified.append({'kind': 'total', 'sign': sign, 'value': value, 'verb': verb, 'pretty': quantity['pretty']})
            continue
        target_index = _detect_dual_subject_action_index(lower, match, subject_entries)
        if target_index is None:
            return None
        classified.append({
            'kind': 'subject',
            'target_index': target_index,
            'sign': sign,
            'value': value,
            'verb': verb,
            'pretty': quantity['pretty'],
        })
    return classified or None


def _normalize_relation_word(word: str) -> str:
    normalized = _normalize_space(word).lower().replace('ё', 'е')
    if normalized in {'длиннее', 'больше'}:
        return 'больше'
    if normalized in {'короче', 'меньше'}:
        return 'меньше'
    return normalized


def _extract_measured_relation(
    raw_text: str,
    subject_entries: list[dict[str, Any]],
    group: str,
    base_unit: str,
) -> Optional[dict[str, Any]]:
    known, _ = _split_known_and_question(raw_text)
    known_lower = _normalize_space(known).lower().replace('ё', 'е')
    if not known_lower:
        return None

    known_lower = _strip_total_clause_for_relation_search(known_lower)

    result: Optional[dict[str, Any]] = None
    for left_index, left_entry in enumerate(subject_entries[:2]):
        left_pattern = _entry_reference_pattern(left_entry)
        for right_index, right_entry in enumerate(subject_entries[:2]):
            if left_index == right_index:
                continue
            right_pattern = _entry_reference_pattern(right_entry)

            difference_patterns = (
                re.compile(
                    rf'{left_pattern}[^.?!]*?стал(?:о|а|и|ось|ся|ась|ись)?[^.?!]*?на\s*([0-9][^,.?!;]*?)\s+(больше|меньше|длиннее|короче)[^.?!]*?(?:чем\s+)?{right_pattern}',
                    re.IGNORECASE,
                ),
                re.compile(
                    rf'{left_pattern}[^.?!]*?на\s*([0-9][^,.?!;]*?)\s+(больше|меньше|длиннее|короче)[^.?!]*?(?:чем\s+)?{right_pattern}',
                    re.IGNORECASE,
                ),
            )
            for pattern in difference_patterns:
                for match in pattern.finditer(known_lower):
                    quantity_text = _normalize_space(match.group(1))
                    quantities = [quantity for quantity in _extract_compound_quantities(quantity_text) if quantity['group'] == group]
                    if not quantities:
                        continue
                    quantity = quantities[0]
                    result = {
                        'kind': 'difference',
                        'left_index': left_index,
                        'right_index': right_index,
                        'value': _quantity_value_in_unit(quantity, base_unit),
                        'word': _normalize_relation_word(match.group(2)),
                        'pretty': quantity['pretty'],
                    }

            ratio_patterns = (
                re.compile(
                    rf'{left_pattern}[^.?!]*?стал(?:о|а|и|ось|ся|ась|ись)?[^.?!]*?в\s*(\d+(?:[.,]\d+)?)\s+раз[а]?\s+(больше|меньше|длиннее|короче)[^.?!]*?(?:чем\s+)?{right_pattern}',
                    re.IGNORECASE,
                ),
                re.compile(
                    rf'{left_pattern}[^.?!]*?в\s*(\d+(?:[.,]\d+)?)\s+раз[а]?\s+(больше|меньше|длиннее|короче)[^.?!]*?(?:чем\s+)?{right_pattern}',
                    re.IGNORECASE,
                ),
            )
            for pattern in ratio_patterns:
                for match in pattern.finditer(known_lower):
                    result = {
                        'kind': 'ratio',
                        'left_index': left_index,
                        'right_index': right_index,
                        'value': _to_fraction(match.group(1)),
                        'word': _normalize_relation_word(match.group(2)),
                    }
    return result or _extract_dual_subject_equality_relation_from_known_text(known_lower, subject_entries)


def _reverse_measured_initial_question_mode(question_lower: str, subject_entries: list[dict[str, Any]]) -> str:
    mode = _reverse_initial_question_mode(question_lower)
    if mode != 'target':
        return mode
    question = _normalize_space(question_lower).lower().replace('ё', 'е')
    if 'вместе' in question or 'всего' in question or 'у них' in question:
        return 'total'
    order = _question_subject_order(question, subject_entries)
    if len(order) >= 2 and ' и ' in question:
        return 'both'
    return mode


def _format_measured_subject_answer(entry: dict[str, Any], value: Fraction, group: str, base_unit: str, visible_units: list[str]) -> str:
    value_text = _format_measure_total(value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    label = _normalize_space(str(entry.get('label') or _reverse_subject_phrase(entry)))
    return f'{label} — {value_text}'


def _append_reverse_measured_initial_summary(
    lines: list[str],
    step_number: int,
    question_lower: str,
    subject_entries: list[dict[str, Any]],
    initial_values: list[Fraction],
    group: str,
    base_unit: str,
    visible_units: list[str],
) -> tuple[int, Optional[str]]:
    mode = _reverse_measured_initial_question_mode(question_lower, subject_entries)
    if mode == 'target' or len(initial_values) < 2:
        return step_number, None

    first_value, second_value = initial_values[:2]
    first_text = _format_measure_total(first_value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    second_text = _format_measure_total(second_value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    first_label = _normalize_space(str(subject_entries[0].get('label') or _reverse_subject_phrase(subject_entries[0])))
    second_label = _normalize_space(str(subject_entries[1].get('label') or _reverse_subject_phrase(subject_entries[1])))

    if mode == 'both':
        order = _question_subject_order(question_lower, subject_entries)
        if len(order) >= 2:
            first_index, second_index = order[:2]
        else:
            first_index, second_index = 0, 1
        first_answer = _format_measured_subject_answer(subject_entries[first_index], initial_values[first_index], group, base_unit, visible_units)
        second_answer = _format_measured_subject_answer(subject_entries[second_index], initial_values[second_index], group, base_unit, visible_units)
        lines.append(f'{step_number}) Теперь знаем начальные величины: {first_answer}, {second_answer}.')
        return step_number + 1, f'{first_answer}, {second_answer}'

    if mode == 'total':
        total_text = _format_measure_total((first_value + second_value) * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
        lines.append(
            f'{step_number}) Теперь знаем начальные величины: {first_label} — {first_text}, {second_label} — {second_text}. '
            f'Сначала вместе было {total_text}.'
        )
        return step_number + 1, total_text

    if mode == 'difference':
        diff_text = _format_measure_total(abs(first_value - second_value) * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
        lines.append(
            f'{step_number}) Теперь знаем начальные величины: {first_label} — {first_text}, {second_label} — {second_text}. '
            f'Разница сначала была {diff_text}.'
        )
        return step_number + 1, f'на {diff_text}'

    if mode == 'ratio':
        bigger = max(first_value, second_value)
        smaller = min(first_value, second_value)
        if smaller == 0:
            return step_number, None
        ratio_value = bigger / smaller
        lines.append(
            f'{step_number}) Теперь знаем начальные величины: {first_label} — {first_text}, {second_label} — {second_text}. '
            f'Чтобы узнать, во сколько раз одна величина больше другой, делим большую на меньшую: '
            f'{_format_number(bigger)} : {_format_number(smaller)} = {_format_number(ratio_value)}.'
        )
        return step_number + 1, f'в {_format_number(ratio_value)} раза'

    return step_number, None


def _reverse_measured_values_through_actions(
    lines: list[str],
    step_number: int,
    final_values: list[Fraction],
    classified_actions: list[dict[str, Any]],
    subject_entries: list[dict[str, Any]],
    unit: str,
) -> Optional[tuple[int, list[Fraction]]]:
    current_values = final_values[:]
    for action in reversed(classified_actions):
        kind = action['kind']
        if kind == 'total':
            return None
        if kind == 'transfer':
            source_index = action['source_index']
            target_index = action['target_index']
            previous_source = current_values[source_index] + action['value']
            previous_target = current_values[target_index] - action['value']
            if previous_source < 0 or previous_target < 0:
                return None
            source_label = _normalize_space(str(subject_entries[source_index].get('label') or _reverse_subject_phrase(subject_entries[source_index])))
            target_label = _normalize_space(str(subject_entries[target_index].get('label') or _reverse_subject_phrase(subject_entries[target_index])))
            lines.append(
                f'{step_number}) Идём назад через передачу: {source_label}: {_format_number(current_values[source_index])} + {_format_number(action["value"])} = {_format_number(previous_source)} {unit}, '
                f'{target_label}: {_format_number(current_values[target_index])} - {_format_number(action["value"])} = {_format_number(previous_target)} {unit}.'
            )
            current_values[source_index] = previous_source
            current_values[target_index] = previous_target
            step_number += 1
            continue

        target_index = action['target_index']
        current_value = current_values[target_index]
        if action['sign'] > 0:
            previous_value = current_value - action['value']
            operation = '-'
            comment = 'Отменяем прибавление'
        else:
            previous_value = current_value + action['value']
            operation = '+'
            comment = 'Отменяем уменьшение'
        if previous_value < 0:
            return None
        target_label = _normalize_space(str(subject_entries[target_index].get('label') or _reverse_subject_phrase(subject_entries[target_index])))
        target_phrase = target_label if re.match(r'^(?:в|во|на|из|к|от)\b', target_label.lower()) else f'у {target_label}'
        lines.append(
            f'{step_number}) {comment} {target_phrase}: {_format_number(current_value)} {operation} {_format_number(action["value"])} = {_format_number(previous_value)} {unit}.'
        )
        current_values[target_index] = previous_value
        step_number += 1
    return step_number, current_values


def _looks_like_reverse_dual_subject_measured_equality_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    question = _question_text(text).lower().replace('ё', 'е')
    if not question or not any(marker in question for marker in ('сколько', 'на сколько', 'во сколько')):
        return False
    if not _question_asks_initial_state(question):
        return False
    if _extract_measured_total_quantity(text):
        return False

    lower = text.lower().replace('ё', 'е')
    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return False
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return False
    groups = {info['quantity']['group'] for info in infos[:2] if info.get('quantity') is not None}
    if len(groups) > 1:
        return False
    if sum(info.get('quantity') is not None for info in infos[:2]) != 1:
        return False

    subject_entries = [info['entry'] for info in infos[:2]]
    known_quantities = [info['quantity'] for info in infos[:2] if info.get('quantity') is not None]
    if not known_quantities:
        return False
    group = known_quantities[0]['group']
    base_unit = _choose_measure_base_unit(group, known_quantities)
    relation = _extract_measured_relation(text, subject_entries, group, base_unit)
    if not relation or not relation.get('equal'):
        return False
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, {'start': len(text)})
    return bool(classified) and not any(action['kind'] == 'total' for action in classified)


def _looks_like_any_reverse_dual_subject_measured_total_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    question = _question_text(text).lower().replace('ё', 'е')
    if not question or not any(marker in question for marker in ('сколько', 'на сколько', 'во сколько')):
        return False
    if not _question_asks_initial_state(question):
        return False

    final_total = _extract_measured_total_quantity(text)
    if not final_total:
        return False
    group = final_total['group']

    lower = text.lower().replace('ё', 'е')
    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return False
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return False
    if any(info['quantity'] is not None and info['quantity']['group'] != group for info in infos):
        return False

    subject_entries = [info['entry'] for info in infos]
    base_unit = _choose_measure_base_unit(group, [final_total] + [info['quantity'] for info in infos if info['quantity'] is not None])
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, final_total)
    return classified is not None


def _looks_like_ambiguous_reverse_dual_subject_measured_total_after_changes_problem(raw_text: str) -> bool:
    return (
        _looks_like_any_reverse_dual_subject_measured_total_after_changes_problem(raw_text)
        and not _looks_like_reverse_dual_subject_measured_total_relation_after_changes_problem(raw_text)
        and not _looks_like_reverse_dual_subject_measured_total_problem(raw_text)
    )


def _looks_like_reverse_dual_subject_measured_total_relation_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    question = _question_text(text).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if not _question_asks_initial_state(question):
        return False

    final_total = _extract_measured_total_quantity(text)
    if not final_total:
        return False
    group = final_total['group']

    matches = list(_ACTION_VERB_RE.finditer(text.lower().replace('ё', 'е')))
    if not matches:
        return False
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return False
    if any(info['quantity'] is not None and info['quantity']['group'] != group for info in infos):
        return False

    subject_entries = [info['entry'] for info in infos]
    base_unit = _choose_measure_base_unit(group, [final_total] + [info['quantity'] for info in infos if info['quantity'] is not None])
    relation = _extract_measured_relation(text, subject_entries, group, base_unit)
    if relation is None:
        return False
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, final_total)
    if not classified:
        return False
    return not any(action['kind'] == 'total' for action in classified)


def _looks_like_reverse_dual_subject_measured_total_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    question = _question_text(text).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if not _question_asks_initial_state(question):
        return False
    if _looks_like_reverse_dual_subject_measured_total_relation_after_changes_problem(text):
        return False

    final_total = _extract_measured_total_quantity(text)
    if not final_total:
        return False
    group = final_total['group']

    matches = list(_ACTION_VERB_RE.finditer(text.lower().replace('ё', 'е')))
    if not matches:
        return False
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return False
    if any(info['quantity'] is not None and info['quantity']['group'] != group for info in infos):
        return False

    mode = _reverse_measured_initial_question_mode(question, [info['entry'] for info in infos])
    known_count = sum(info['quantity'] is not None for info in infos)
    if mode != 'total' and known_count != 1:
        return False

    subject_entries = [info['entry'] for info in infos]
    base_unit = _choose_measure_base_unit(group, [final_total] + [info['quantity'] for info in infos if info['quantity'] is not None])
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, final_total)
    return classified is not None

__all__ = [name for name in globals() if name.startswith("_")]
