from __future__ import annotations

import re
from fractions import Fraction
from typing import Callable, Optional, Tuple


QUESTION_NOUN_FORMS = {
    "книга": ("книга", "книги", "книг"),
    "книги": ("книга", "книги", "книг"),
    "книг": ("книга", "книги", "книг"),
    "полка": ("полка", "полки", "полок"),
    "полки": ("полка", "полки", "полок"),
    "полок": ("полка", "полки", "полок"),
    "коробка": ("коробка", "коробки", "коробок"),
    "коробки": ("коробка", "коробки", "коробок"),
    "коробок": ("коробка", "коробки", "коробок"),
    "сетка": ("сетка", "сетки", "сеток"),
    "сетки": ("сетка", "сетки", "сеток"),
    "сеток": ("сетка", "сетки", "сеток"),
    "клетка": ("клетка", "клетки", "клеток"),
    "клетки": ("клетка", "клетки", "клеток"),
    "клеток": ("клетка", "клетки", "клеток"),
    "пакет": ("пакет", "пакета", "пакетов"),
    "пакета": ("пакет", "пакета", "пакетов"),
    "пакетов": ("пакет", "пакета", "пакетов"),
    "мешок": ("мешок", "мешка", "мешков"),
    "мешка": ("мешок", "мешка", "мешков"),
    "мешков": ("мешок", "мешка", "мешков"),
    "карандаш": ("карандаш", "карандаша", "карандашей"),
    "карандаша": ("карандаш", "карандаша", "карандашей"),
    "карандашей": ("карандаш", "карандаша", "карандашей"),
    "ручка": ("ручка", "ручки", "ручек"),
    "ручки": ("ручка", "ручки", "ручек"),
    "ручек": ("ручка", "ручки", "ручек"),
    "тетрадь": ("тетрадь", "тетради", "тетрадей"),
    "тетради": ("тетрадь", "тетради", "тетрадей"),
    "тетрадей": ("тетрадь", "тетради", "тетрадей"),
    "страница": ("страница", "страницы", "страниц"),
    "страницы": ("страница", "страницы", "страниц"),
    "страниц": ("страница", "страницы", "страниц"),
    "машина": ("машина", "машины", "машин"),
    "машины": ("машина", "машины", "машин"),
    "машин": ("машина", "машины", "машин"),
    "дерево": ("дерево", "дерева", "деревьев"),
    "дерева": ("дерево", "дерева", "деревьев"),
    "деревьев": ("дерево", "дерева", "деревьев"),
    "яблоко": ("яблоко", "яблока", "яблок"),
    "яблока": ("яблоко", "яблока", "яблок"),
    "яблок": ("яблоко", "яблока", "яблок"),
    "груша": ("груша", "груши", "груш"),
    "груши": ("груша", "груши", "груш"),
    "груш": ("груша", "груши", "груш"),
    "человек": ("человек", "человека", "человек"),
    "пассажир": ("пассажир", "пассажира", "пассажиров"),
    "пассажира": ("пассажир", "пассажира", "пассажиров"),
    "пассажиров": ("пассажир", "пассажира", "пассажиров"),
    "ученик": ("ученик", "ученика", "учеников"),
    "ученика": ("ученик", "ученика", "учеников"),
    "учеников": ("ученик", "ученика", "учеников"),
    "мальчик": ("мальчик", "мальчика", "мальчиков"),
    "мальчика": ("мальчик", "мальчика", "мальчиков"),
    "мальчиков": ("мальчик", "мальчика", "мальчиков"),
    "фломастер": ("фломастер", "фломастера", "фломастеров"),
    "фломастера": ("фломастер", "фломастера", "фломастеров"),
    "фломастеров": ("фломастер", "фломастера", "фломастеров"),
    "цветок": ("цветок", "цветка", "цветов"),
    "цветка": ("цветок", "цветка", "цветов"),
    "цветов": ("цветок", "цветка", "цветов"),
    "птица": ("птица", "птицы", "птиц"),
    "птицы": ("птица", "птицы", "птиц"),
    "птиц": ("птица", "птицы", "птиц"),
    "рыба": ("рыба", "рыбы", "рыб"),
    "рыбы": ("рыба", "рыбы", "рыб"),
    "рыб": ("рыба", "рыбы", "рыб"),
    "попугай": ("попугай", "попугая", "попугаев"),
    "попугая": ("попугай", "попугая", "попугаев"),
    "попугаев": ("попугай", "попугая", "попугаев"),
    "набор": ("набор", "набора", "наборов"),
    "набора": ("набор", "набора", "наборов"),
    "наборов": ("набор", "набора", "наборов"),
    "банка": ("банка", "банки", "банок"),
    "банки": ("банка", "банки", "банок"),
    "банок": ("банка", "банки", "банок"),
    "булочка": ("булочка", "булочки", "булочек"),
    "булочки": ("булочка", "булочки", "булочек"),
    "булочек": ("булочка", "булочки", "булочек"),
    "гвоздика": ("гвоздика", "гвоздики", "гвоздик"),
    "гвоздики": ("гвоздика", "гвоздики", "гвоздик"),
    "гвоздик": ("гвоздика", "гвоздики", "гвоздик"),
    "куст": ("куст", "куста", "кустов"),
    "куста": ("куст", "куста", "кустов"),
    "кустов": ("куст", "куста", "кустов"),
    "корзина": ("корзина", "корзины", "корзин"),
    "корзины": ("корзина", "корзины", "корзин"),
    "корзин": ("корзина", "корзины", "корзин"),
    "ягода": ("ягода", "ягоды", "ягод"),
    "ягоды": ("ягода", "ягоды", "ягод"),
    "ягод": ("ягода", "ягоды", "ягод"),
    "пельмень": ("пельмень", "пельменя", "пельменей"),
    "пельменя": ("пельмень", "пельменя", "пельменей"),
    "пельменей": ("пельмень", "пельменя", "пельменей"),
}

MEASURE_QUESTION_NOUNS = {
    "руб", "рубль", "рубля", "рублей", "деньги", "денег",
    "кг", "килограмм", "килограмма", "килограммов",
    "г", "грамм", "грамма", "граммов",
    "км", "километр", "километра", "километров",
    "м", "метр", "метра", "метров",
    "см", "сантиметр", "сантиметра", "сантиметров",
    "дм", "дециметр", "дециметра", "дециметров",
    "мм", "миллиметр", "миллиметра", "миллиметров",
    "л", "литр", "литра", "литров",
    "ч", "час", "часа", "часов",
    "мин", "минута", "минуты", "минут",
    "скорость", "длина", "ширина", "площадь", "периметр", "масса", "расстояние",
}

_OAI_PATCH_STOP_QUESTION_WORDS_R = {
    "всего", "вместе", "нужно", "можно", "будет", "было", "стало", "останется",
    "осталось", "получилось", "понадобится", "понадобилось", "потребуется",
    "потребовалось", "такой", "таких", "такие", "этих", "эти", "этой", "этом",
}
_OAI_PATCH_ADJECTIVE_ENDINGS_R = (
    "ый", "ий", "ой", "ая", "яя", "ое", "ее", "ые", "ие",
    "ого", "его", "ому", "ему", "ым", "им", "ую", "юю",
    "ых", "их", "ыми", "ими", "ой", "ей",
)


def _lookup_question_noun_forms(noun: str) -> Optional[Tuple[str, str, str]]:
    key = str(noun or "").strip().lower().replace("ё", "е")
    if not key:
        return None
    return QUESTION_NOUN_FORMS.get(key)


def _select_plural_by_count(count_value: int, forms: Tuple[str, str, str]) -> str:
    one, few, many = forms
    value = abs(int(count_value)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return many
    if tail == 1:
        return one
    if 2 <= tail <= 4:
        return few
    return many


def _can_use_raw_plural_noun_with_count(count_value: int) -> bool:
    value = abs(int(count_value)) % 100
    tail = value % 10
    if 11 <= value <= 14:
        return True
    return tail == 0 or tail >= 5


def _oai_patch_is_likely_adjective_r(word: str) -> bool:
    value = str(word or "").strip().lower().replace("ё", "е")
    return bool(value) and value.endswith(_OAI_PATCH_ADJECTIVE_ENDINGS_R)


def _question_requests_object_count(
    raw_text: str,
    question_lower_text: Callable[[str], str],
    measure_question_nouns: set[str] | None = None,
) -> bool:
    question = question_lower_text(raw_text)
    match = re.search(
        r"^сколько\s+(?:было\s+|будет\s+|стало\s+|осталось\s+|получилось\s+|понадобится\s+|понадобилось\s+|потребовалось\s+|можно\s+купить\s+)?([а-яё]+)",
        question,
    )
    if not match:
        return False
    noun = match.group(1).strip().lower().replace("ё", "е")
    nouns = measure_question_nouns or MEASURE_QUESTION_NOUNS
    return noun not in nouns


def _initial_detect_question_unit(
    raw_text: str,
    question_requests_object_count: Callable[[str], bool],
    previous_detect_question_unit: Callable[[str], str],
) -> str:
    if question_requests_object_count(raw_text):
        return ""
    return previous_detect_question_unit(raw_text)


def _initial_detailed_maybe_enrich_answer(
    answer: str,
    raw_text: str,
    detect_question_unit: Callable[[str], str],
    extract_question_noun: Callable[[str], str],
    question_requests_object_count: Callable[[str], bool],
) -> str:
    value = str(answer or "").strip()
    if not value:
        return value
    if re.search(r"[А-Яа-я]", value):
        return value
    is_numeric = re.fullmatch(r"-?\d+(?:/\d+)?", value) is not None
    if not is_numeric:
        return value
    if question_requests_object_count(raw_text):
        noun = extract_question_noun(raw_text)
        forms = _lookup_question_noun_forms(noun)
        if forms:
            try:
                count_value = int(value.split("/", 1)[0])
            except Exception:
                return value
            return f"{value} {_select_plural_by_count(count_value, forms)}"
        return value
    unit = detect_question_unit(raw_text)
    if unit:
        return f"{value} {unit}".strip()
    return value


def _extract_count_question_noun(
    raw_text: str,
    question_lower_text: Callable[[str], str],
    previous_extract_count_question_noun: Callable[[str], str],
) -> str:
    question = question_lower_text(raw_text)
    if question:
        if re.search(r"во\s+сколько\s+раз", question):
            return "раз"
        patterns = [
            r"^сколько\s+(?:было\s+|будет\s+|стало\s+|останется\s+|осталось\s+|осталось\s+\w+\s+|получилось\s+|понадобится\s+|понадобилось\s+|потребуется\s+|потребовалось\s+|можно\s+купить\s+|нужно\s+|нужно\s+купить\s+|всего\s+)?([а-яё]+)",
            r"^на\s+сколько\s+([а-яё]+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, question)
            if not match:
                continue
            noun = match.group(1).strip().lower().replace("ё", "е")
            if noun and noun not in _OAI_PATCH_STOP_QUESTION_WORDS_R and not _oai_patch_is_likely_adjective_r(noun):
                return noun
    prev_noun = previous_extract_count_question_noun(raw_text)
    return prev_noun or ""


def _detect_question_unit(
    raw_text: str,
    previous_detect_question_unit: Callable[[str], str],
    question_lower_text: Callable[[str], str],
    normalize_word_problem_text: Callable[[str], str],
) -> str:
    unit = previous_detect_question_unit(raw_text)
    if unit:
        return unit
    question = question_lower_text(raw_text)
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    if re.search(r"(?:какое|какова?|сколько)\s+врем(?:я|ени)", question):
        if "м/с" in lower_full or re.search(r"сек|секунд|секунда|секунды|с", lower_full):
            return "с"
        if "м/мин" in lower_full or re.search(r"мин|минут|минута|минуты", lower_full):
            return "мин"
        return "ч"
    if re.search(r"на\s+сколько", question) and re.search(r"дороже|дешевле", question):
        if "руб" in lower_full or "коп" in lower_full:
            return "руб."
    return ""


def _final_detect_question_unit(
    raw_text: str,
    previous_detect_question_unit: Callable[[str], str],
    normalize_word_problem_text: Callable[[str], str],
    question_text_only: Callable[[str], str],
) -> str:
    unit = previous_detect_question_unit(raw_text)
    if unit:
        return unit
    lower_full = normalize_word_problem_text(raw_text).lower().replace("ё", "е")
    question = question_text_only(raw_text).lower().replace("ё", "е").strip()
    if (
        "сколько стоит" in question
        or "сколько стоят" in question
        or "сколько стоила" in question
        or "сколько стоили" in question
    ) and ("руб" in lower_full or "денег" in lower_full):
        return "руб."
    return ""


def _patch_answer_with_question_noun(
    value: int | str,
    raw_text: str,
    detect_question_unit: Callable[[str], str],
    extract_count_question_noun: Callable[[str], str],
    extract_question_noun: Callable[[str], str],
) -> str:
    unit = detect_question_unit(raw_text) or ""
    if unit:
        return f"{value} {unit}".strip()
    noun = extract_count_question_noun(raw_text) or extract_question_noun(raw_text)
    if noun:
        if noun == "раз":
            return f"{value} раз"
        forms = _lookup_question_noun_forms(noun)
        if forms:
            try:
                count_value = int(value)
            except Exception:
                return f"{value} {noun}".strip()
            return f"{value} {_select_plural_by_count(count_value, forms)}"
        try:
            count_value = int(value)
        except Exception:
            count_value = None
        if count_value is not None and _can_use_raw_plural_noun_with_count(count_value):
            return f"{value} {noun}".strip()
    return str(value)


def _final_detailed_maybe_enrich_answer(
    answer: str,
    raw_text: str,
    previous_enrich_answer: Callable[[str, str, str], str],
    patch_answer_with_question_noun: Callable[[int | str, str], str],
    kind: str,
) -> str:
    value = previous_enrich_answer(answer, raw_text, kind)
    stripped = str(value or "").strip()
    if not stripped:
        return stripped
    if re.fullmatch(r"-?\d+(?:/\d+)?", stripped):
        try:
            return patch_answer_with_question_noun(int(Fraction(stripped)), raw_text)
        except Exception:
            return stripped
    return stripped
