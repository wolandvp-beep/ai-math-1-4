from __future__ import annotations

import json
from typing import Any, Optional

from backend.input_normalization import strip_solver_command_prefix as _strip_solver_command_prefix
from backend.legacy_math_signals import _clean_text, _normalize_space, _strip_label


def _ensure_sentence(text: str) -> str:
    text = _normalize_space(text)
    if not text:
        return ''
    if text[-1] not in '.!?':
        return text + '.'
    return text


def _join_lines(lines: list[str]) -> str:
    return '\n'.join(line.rstrip() for line in lines if line is not None and str(line).strip())


def _parse_json_object(text: str) -> Optional[dict[str, Any]]:
    raw = str(text or '').strip()
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        start = raw.find('{')
        end = raw.rfind('}')
        if start == -1 or end == -1 or end <= start:
            return None
        try:
            data = json.loads(raw[start:end + 1])
        except json.JSONDecodeError:
            return None
    return data if isinstance(data, dict) else None


__all__ = [
    '_clean_text',
    '_ensure_sentence',
    '_join_lines',
    '_normalize_space',
    '_parse_json_object',
    '_strip_label',
    '_strip_solver_command_prefix',
]
