from __future__ import annotations

import re
from typing import Optional

from backend.legacy_math_signals import _clean_text, _normalize_space
from backend.legacy_question_flow_helpers import _subject_token_key
from backend.legacy_school_helpers import _RUBLE_RE, _split_known_and_question

def _guess_count_answer_label(text: str) -> str:
    lower = _clean_text(text).lower().replace('ё', 'е')
    if re.search(_RUBLE_RE, lower) or 'денег' in lower:
        return 'руб'
    if 'человек' in lower or 'людей' in lower:
        return 'человек'
    question_match = re.search(r'сколько\s+([а-яё]+)', lower)
    if question_match:
        word = question_match.group(1)
        if word not in {'стало', 'осталось', 'получилось', 'будет', 'было', 'сначала', 'станет', 'останется'}:
            return word
    noun_match = re.search(r'\d+\s+([а-яё]+)', lower)
    if noun_match:
        return noun_match.group(1)
    return ''


def _extract_final_state_subject(text: str) -> Optional[dict[str, str]]:
    known, _ = _split_known_and_question(text)
    known_lower = _normalize_space(known).lower().replace('ё', 'е')
    result: Optional[dict[str, str]] = None
    patterns = (
        re.compile(r'у\s+([а-яёa-z-]+)\s+(?:остал(?:ось|ся|ась|ись)|стал(?:о|а|и))', re.IGNORECASE),
        re.compile(r'после\s+этого\s+у\s+([а-яёa-z-]+)', re.IGNORECASE),
    )
    pronouns = {'он', 'она', 'оно', 'они', 'ему', 'ей', 'им', 'него', 'нее', 'неё', 'нему', 'ней', 'ее', 'её'}
    for pattern in patterns:
        for match in pattern.finditer(known_lower):
            name = match.group(1).lower().replace('ё', 'е')
            if name in pronouns:
                continue
            key = _subject_token_key(name)
            if key and key not in {'first', 'second'}:
                result = {'key': key, 'label': name.capitalize()}
    return result


__all__ = ['_guess_count_answer_label', '_extract_final_state_subject']
