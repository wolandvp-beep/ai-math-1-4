from __future__ import annotations

import re

from backend.legacy_math_signals import _clean_text
from backend.legacy_school_helpers import _soft_person_key
from backend.legacy_sequential_action_helpers import _extract_sequential_actions

def _detect_changed_subject_index(text_lower: str, action_match: re.Match, subject_words: list[str]) -> int:
    context = text_lower[max(0, action_match.start() - 30): action_match.end() + 40]
    if re.search(r'\b(перв\w*|одн\w*)\b', context):
        return 0
    if re.search(r'\b(втор\w*|друг\w*)\b', context):
        return 1
    context_words = re.findall(r'[а-яёa-z-]+', context)
    context_keys = {_soft_person_key(word) for word in context_words}
    for index, subject in enumerate(subject_words[:2]):
        if subject and _soft_person_key(subject) in context_keys:
            return index
    return 0


def _subject_words_before_numbers(prefix: str, number_matches: list[re.Match[str]]) -> list[str]:
    subjects: list[str] = []
    stopwords = {'у', 'в', 'во', 'на', 'а', 'и', 'по', 'к', 'из', 'от', 'до', 'со', 'с'}
    for match in number_matches[:2]:
        window = prefix[max(0, match.start() - 28):match.start()]
        words = [word for word in re.findall(r'[а-яёa-z-]+', window) if word not in stopwords]
        subjects.append(words[-1] if words else '')
    return subjects


def _looks_like_difference_after_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    if 'на сколько' not in lower:
        return False
    actions, matches = _extract_sequential_actions(lower)
    return bool(actions and matches)


def _looks_like_ratio_after_change_problem(text: str) -> bool:
    lower = _clean_text(text).lower().replace('ё', 'е')
    if 'во сколько раз' not in lower:
        return False
    actions, matches = _extract_sequential_actions(lower)
    return bool(actions and matches)

__all__ = [name for name in globals() if name.startswith("_")]
