from __future__ import annotations

import json
from typing import Any, Awaitable, Callable, Optional

from backend.legacy_deepseek_runtime import get_deepseek_api_key
from backend.legacy_formatting_helpers import _parse_json_object
from backend.legacy_validated_result import _build_validated_deepseek_result_from_ns

LegacyAsyncCallFn = Callable[..., Awaitable[dict[str, Any] | None]]
LegacyApiKeyFn = Callable[[dict[str, Any]], str]
LegacyBuildResultFn = Callable[[dict[str, Any], str], Optional[dict[str, Any]]]
LegacyParseJsonFn = Callable[[str], Optional[dict[str, Any]]]



def _deepseek_structured_payload(user_text: str) -> dict[str, Any]:
    system_prompt = """Ты резервный математический модуль для детей 7–10 лет.
Верни только один JSON object без markdown и без пояснений вне JSON.
Решай задачу по-школьному и коротко.
Используй только числа из условия и арифметические операторы + - * / ( ).
В шагах обязательно показывай вычисления равенствами, например: 7 + 8 = 15.
Смысл вопроса сохраняй точно: если спрашивают "во сколько раз", финальный шаг должен быть делением; если спрашивают "на сколько", финальный шаг должен быть вычитанием; если спрашивают "вместе" или "всего", отрази это и в поле find.
Допустимо использовать число 2 для периметра прямоугольника или квадрата и числа 60 или 100 для стандартных переводов единиц.
Если для решения полезна схема, не рисуй картинку, а заполни diagram_spec.
Если надёжно решить не получается, верни {"cannot_safely_solve": true, "reason": "..."}.
Нужный JSON:
{
  "known": "...",
  "find": "...",
  "steps": ["7 + 8 = 15", "15 + 9 = 24"],
  "equation": "80/4*7",
  "answer_number": "140",
  "answer_unit": "руб",
  "tip": "...",
  "diagram_spec": null
}"""
    return {
        'model': 'deepseek-chat',
        'messages': [
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': f'Реши задачу и верни только JSON. Задача: {user_text}'},
        ],
        'response_format': {'type': 'json_object'},
        'max_tokens': 900,
        'temperature': 0.0,
    }


async def _try_validated_deepseek_fallback(ns: dict[str, Any], user_text: str) -> Optional[dict[str, Any]]:
    get_api_key: Optional[LegacyApiKeyFn] = ns.get('_get_deepseek_api_key')
    call_deepseek: Optional[LegacyAsyncCallFn] = ns.get('call_deepseek')
    build_result: Optional[LegacyBuildResultFn] = ns.get('_build_validated_deepseek_result')
    parse_json: Optional[LegacyParseJsonFn] = ns.get('_parse_json_object')
    if not callable(call_deepseek):
        return None
    api_key = get_api_key(ns) if callable(get_api_key) else get_deepseek_api_key(ns)
    if not api_key:
        return None
    previous_key = ns.get('DEEPSEEK_API_KEY', '')
    ns['DEEPSEEK_API_KEY'] = api_key
    try:
        llm_result = await call_deepseek(_deepseek_structured_payload(user_text), timeout_seconds=20.0)
    finally:
        ns['DEEPSEEK_API_KEY'] = previous_key
    if not isinstance(llm_result, dict) or llm_result.get('error'):
        return None
    parser = parse_json if callable(parse_json) else _parse_json_object
    parsed = parser(llm_result.get('result'))
    if not parsed:
        return None
    if callable(build_result):
        return build_result(parsed, user_text)
    return _build_validated_deepseek_result_from_ns(ns, parsed, user_text)


__all__ = [
    '_deepseek_structured_payload',
    '_try_validated_deepseek_fallback',
]
