from __future__ import annotations

from fractions import Fraction
from typing import Any, Callable, Optional
import re

from backend.legacy_answer_semantics import _answer_unit_family, _normalize_ai_equation
from backend.legacy_question_flow_helpers import _question_text
from backend.legacy_math_signals import _clean_text
from backend.legacy_formatting_helpers import _strip_solver_command_prefix


_AI_STEP_UNIT_RE = re.compile(
    r'\b(?:км/ч|км/мин|м/ч|м/мин|м/с|см/с|руб(?:\.|ль|ля|лей)?|р\.|км|мл|мм|см|дм|кг|мин|л|г|м|ч|с)\b',
    re.IGNORECASE,
)


def _require(ns: dict[str, Any], name: str) -> Callable[..., Any]:
    fn = ns.get(name)
    if not callable(fn):
        raise KeyError(f"Missing legacy helper: {name}")
    return fn


def _extract_step_equalities(ns: dict[str, Any], step_text: str) -> list[tuple[str, str]]:
    normalize_space = _require(ns, '_normalize_space')
    normalized = normalize_space(step_text)
    operator = r'(?:\s*(?:[+\-*/×xхХ])\s*|\s:\s)'
    pattern = re.compile(
        rf'(\d+(?:[.,]\d+)?(?:{operator}\d+(?:[.,]\d+)?)+)\s*=\s*(-?\d+(?:\s+\d+/\d+|/\d+|(?:[.,]\d+)?)?)'
    )
    return [(normalize_space(left), normalize_space(right)) for left, right in pattern.findall(normalized)]


def _validate_ai_steps_arithmetic(ns: dict[str, Any], steps: list[str]) -> bool:
    safe_eval_fraction_expression = _require(ns, '_safe_eval_fraction_expression')
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    validated_equalities = 0
    for step in steps:
        equalities = _extract_step_equalities(ns, step)
        if not equalities:
            return False
        for left, right in equalities:
            left_value = safe_eval_fraction_expression(left)
            right_value = parse_fraction_like(right)
            if left_value is None or right_value is None or left_value != right_value:
                return False
            validated_equalities += 1
    return validated_equalities > 0


def _numbers_from_expression(ns: dict[str, Any], expression: str) -> set[Fraction]:
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    values = {parse_fraction_like(token) for token in re.findall(r'\d+(?:\.\d+)?', _normalize_ai_equation(expression))}
    values.discard(None)
    return values


def _validate_ai_step_number_flow(ns: dict[str, Any], steps: list[str], user_text: str, answer_number: Fraction) -> bool:
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    clean_text = _require(ns, '_clean_text')
    allowed_ai_extra_numbers_for_text = _require(ns, '_allowed_ai_extra_numbers_for_text')
    available_numbers = {parse_fraction_like(token) for token in re.findall(r'\d+(?:[.,]\d+)?', clean_text(user_text))}
    available_numbers.discard(None)
    available_numbers |= allowed_ai_extra_numbers_for_text(user_text)
    saw_final_answer = False

    for step in steps:
        equalities = _extract_step_equalities(ns, step)
        for left, right in equalities:
            right_value = parse_fraction_like(right)
            if right_value is None:
                return False
            step_numbers = _numbers_from_expression(ns, left) | ({parse_fraction_like(token) for token in re.findall(r'\d+(?:[.,]\d+)?', right)} - {None})
            if not step_numbers.issubset(available_numbers | {right_value}):
                return False
            available_numbers.add(right_value)
            if right_value == answer_number:
                saw_final_answer = True
    return saw_final_answer


def _last_ai_step_result(ns: dict[str, Any], steps: list[str]) -> Optional[Fraction]:
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    if not steps:
        return None
    last_equalities = _extract_step_equalities(ns, steps[-1])
    if not last_equalities:
        return None
    right_value = parse_fraction_like(last_equalities[-1][1])
    return right_value


def _normalize_ai_step_unit(ns: dict[str, Any], token: str) -> Optional[str]:
    normalize_space = _require(ns, '_normalize_space')
    unit = normalize_space(str(token or '')).lower().replace('ё', 'е')
    mapping = {
        'рубль': 'руб',
        'рубля': 'руб',
        'рублей': 'руб',
        'руб.': 'руб',
        'р.': 'руб',
    }
    if unit in mapping:
        return mapping[unit]
    speed_unit_parts = set(ns.get('_SPEED_UNIT_PARTS') or [])
    length_units = set(ns.get('_LENGTH_UNITS') or [])
    time_to_seconds = set((ns.get('_TIME_TO_SECONDS') or {}).keys())
    mass_units = set(ns.get('_MASS_UNITS') or [])
    volume_units = set(ns.get('_VOLUME_UNITS') or [])
    if unit in speed_unit_parts:
        return unit
    if unit in length_units:
        return unit
    if unit in time_to_seconds:
        return unit
    if unit in mass_units:
        return unit
    if unit in volume_units:
        return unit
    if unit == 'руб':
        return unit
    return None


def _extract_ai_step_units(ns: dict[str, Any], text: str) -> set[str]:
    clean_text = _require(ns, '_clean_text')
    units: set[str] = set()
    for token in _AI_STEP_UNIT_RE.findall(clean_text(text).lower()):
        normalized = _normalize_ai_step_unit(ns, token)
        if normalized:
            units.add(normalized)
    return units


def _validate_ai_step_units(ns: dict[str, Any], steps: list[str], user_text: str, answer_unit: str) -> bool:
    allowed_units = _extract_ai_step_units(ns, user_text)
    normalized_answer_unit = _normalize_ai_step_unit(ns, answer_unit)
    if normalized_answer_unit:
        allowed_units.add(normalized_answer_unit)
    if not allowed_units:
        return True
    for step in steps:
        for token in _AI_STEP_UNIT_RE.findall(step.lower()):
            normalized = _normalize_ai_step_unit(ns, token)
            if normalized and normalized not in allowed_units:
                return False
    return True


def _validation_focus_text(ns: dict[str, Any], user_text: str) -> str:
    question = _question_text(user_text)
    if question:
        return question
    stripped = _strip_solver_command_prefix(user_text)
    if stripped:
        return _clean_text(stripped)
    return _clean_text(user_text)


def _extract_simple_numeric_values(ns: dict[str, Any], text: str) -> set[Fraction]:
    clean_text = _require(ns, '_clean_text')
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    values: set[Fraction] = set()
    for token in re.findall(r'-?\d+(?:[.,]\d+)?', clean_text(text)):
        value = parse_fraction_like(token)
        if value is not None:
            values.add(value)
    return values


def _extract_ai_numeric_values(ns: dict[str, Any], equation: str, steps: list[str]) -> set[Fraction]:
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    values = _extract_simple_numeric_values(ns, equation)
    for step in steps:
        for left, right in _extract_step_equalities(ns, step):
            values |= _extract_simple_numeric_values(ns, left)
            right_value = parse_fraction_like(right)
            if right_value is not None:
                values.add(right_value)
    return values


def _question_numbers_are_used(ns: dict[str, Any], equation: str, steps: list[str], user_text: str) -> bool:
    focus_text = _validation_focus_text(ns, user_text)
    question_numbers = _extract_simple_numeric_values(ns, focus_text)
    if not question_numbers:
        return True
    used_numbers = _extract_ai_numeric_values(ns, equation, steps)
    return question_numbers.issubset(used_numbers)


def _last_ai_step_left_expression(ns: dict[str, Any], steps: list[str]) -> str:
    if not steps:
        return ''
    last_equalities = _extract_step_equalities(ns, steps[-1])
    if not last_equalities:
        return ''
    return _normalize_ai_equation(last_equalities[-1][0])


def _joined_ai_expression_text(ns: dict[str, Any], equation: str, steps: list[str]) -> str:
    parts = [_normalize_ai_equation(equation)]
    for step in steps:
        for left, _ in _extract_step_equalities(ns, step):
            parts.append(_normalize_ai_equation(left))
    return ' '.join(part for part in parts if part)


def _is_ratio_answer_unit(answer_unit: str) -> bool:
    unit = ' '.join(str(answer_unit or '').split()).lower().replace('ё', 'е').strip(' .')
    return unit in {'раз', 'раза'}


def _ai_find_matches_question(ns: dict[str, Any], find: str, user_text: str) -> bool:
    normalize_space = _require(ns, '_normalize_space')
    question = _validation_focus_text(ns, user_text).lower().replace('ё', 'е')
    normalized_find = normalize_space(find).lower().replace('ё', 'е')
    if not question or not normalized_find:
        return True

    checks: list[bool] = []
    if 'во сколько раз' in question:
        checks.append('раз' in normalized_find or 'во сколько' in normalized_find)
    if 'на сколько' in question:
        checks.append(any(marker in normalized_find for marker in ('на сколько', 'разниц', 'больше', 'меньше')))
    if 'вместе' in question:
        checks.append('вместе' in normalized_find or 'всего' in normalized_find)
    elif 'всего' in question:
        checks.append('всего' in normalized_find or 'вместе' in normalized_find)
    if any(marker in question for marker in ('осталось', 'останется', 'осталось ли', 'останется ли')):
        checks.append('остал' in normalized_find or 'остан' in normalized_find)
    if 'не хватает' in question:
        checks.append('не хватает' in normalized_find or 'нехват' in normalized_find)
    if 'периметр' in question:
        checks.append('периметр' in normalized_find)
    if 'площад' in question:
        checks.append('площад' in normalized_find)
    if 'скорост' in question:
        checks.append('скорост' in normalized_find)
    if 'сколько стоит' in question or 'сколько стоят' in question or ('цена' in question and 'сколько' in question):
        checks.append(any(marker in normalized_find for marker in ('стоим', 'цен', 'стоит', 'стоят')))
    return all(checks) if checks else True


def _answer_unit_matches_question_intent(ns: dict[str, Any], answer_unit: str, user_text: str) -> bool:
    normalize_space = _require(ns, '_normalize_space')
    speed_unit_parts = set(ns.get('_SPEED_UNIT_PARTS') or [])
    question = _validation_focus_text(ns, user_text).lower().replace('ё', 'е')
    family = _answer_unit_family(answer_unit)
    normalized_answer_unit = normalize_space(answer_unit).lower().replace('ё', 'е')

    if 'во сколько раз' in question:
        return not family and (not normalized_answer_unit or _is_ratio_answer_unit(normalized_answer_unit))
    if 'на сколько' in question and _is_ratio_answer_unit(normalized_answer_unit):
        return False
    if any(marker in question for marker in ('вместе', 'всего', 'осталось', 'останется', 'не хватает')) and _is_ratio_answer_unit(normalized_answer_unit):
        return False
    if 'сколько стоит' in question or 'сколько стоят' in question or ('цена' in question and 'сколько' in question):
        return family == 'money'
    if 'скорост' in question:
        return normalized_answer_unit in speed_unit_parts or '/' in normalized_answer_unit
    if 'периметр' in question:
        return family == 'length'
    if 'площад' in question:
        return family == 'area'
    if any(marker in question for marker in ('расстояние', 'какой путь', 'какое расстояние', 'длина', 'длины', 'длиной', 'сторона', 'отрезок')) and not any(marker in question for marker in ('периметр', 'площад')):
        return family == 'length'
    if any(marker in question for marker in ('сколько времени', 'сколько минут', 'сколько часов', 'длился', 'длилась', 'длилось', 'длились')):
        return family == 'time'
    return True


def _equation_shape_matches_question_intent(ns: dict[str, Any], equation: str, steps: list[str], user_text: str) -> bool:
    clean_text = _require(ns, '_clean_text')
    ruble_re = ns.get('_RUBLE_RE')
    question = _validation_focus_text(ns, user_text).lower().replace('ё', 'е')
    normalized_equation = _normalize_ai_equation(equation)
    last_expression = _last_ai_step_left_expression(ns, steps) or normalized_equation
    all_expressions = _joined_ai_expression_text(ns, equation, steps)
    lower_text = clean_text(user_text).lower().replace('ё', 'е')

    if 'во сколько раз' in question:
        return '/' in last_expression
    if 'на сколько' in question or 'не хватает' in question:
        return '-' in last_expression
    if 'вместе' in question or 'всего' in question:
        return '+' in last_expression or '+' in all_expressions
    if 'сколько стоит' in question or 'сколько стоят' in question:
        if 'таких' in question and ruble_re and re.search(ruble_re, lower_text) and len(re.findall(r'\d+(?:[.,]\d+)?', clean_text(user_text))) >= 3:
            return '/' in normalized_equation and '*' in normalized_equation
        if re.search(r'\bпо\b', lower_text):
            return '*' in normalized_equation or '*' in all_expressions
    if 'скорост' in question:
        return '/' in last_expression or '/' in all_expressions
    return True


__all__ = [
    '_ai_find_matches_question',
    '_answer_unit_matches_question_intent',
    '_equation_shape_matches_question_intent',
    '_extract_step_equalities',
    '_last_ai_step_result',
    '_question_numbers_are_used',
    '_validate_ai_step_number_flow',
    '_validate_ai_step_units',
    '_validate_ai_steps_arithmetic',
]
