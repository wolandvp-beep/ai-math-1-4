from __future__ import annotations

from fractions import Fraction
from typing import Any, Callable, Optional
import re

from backend.legacy_answer_semantics import _answer_unit_matches_text

from backend.legacy_school_helpers import _format_number
from backend.legacy_validation_helpers import (
    _ai_find_matches_question,
    _answer_unit_matches_question_intent,
    _equation_shape_matches_question_intent,
    _extract_step_equalities,
    _last_ai_step_result,
    _question_numbers_are_used,
    _validate_ai_step_number_flow,
    _validate_ai_step_units,
    _validate_ai_steps_arithmetic,
)


def _require(ns: dict[str, Any], name: str) -> Callable[..., Any]:
    fn = ns.get(name)
    if not callable(fn):
        raise KeyError(f"Missing legacy helper: {name}")
    return fn


def _validate_ai_solution_semantics(ns: dict[str, Any], find: str, equation: str, steps: list[str], answer_unit: str, user_text: str) -> bool:
    if not _question_numbers_are_used(ns, equation, steps, user_text):
        return False
    if not _ai_find_matches_question(ns, find, user_text):
        return False
    if not _answer_unit_matches_question_intent(ns, answer_unit, user_text):
        return False
    if not _equation_shape_matches_question_intent(ns, equation, steps, user_text):
        return False
    return True


def _validate_ai_whole_number_consistency(ns: dict[str, Any], steps: list[str], answer_number: Fraction, answer_unit: str, user_text: str) -> bool:
    school_context_requires_whole_values = _require(ns, '_school_context_requires_whole_values')
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    if not school_context_requires_whole_values(user_text, answer_unit=answer_unit):
        return True
    if answer_number.denominator != 1:
        return False
    for step in steps:
        for _, right in _extract_step_equalities(ns, step):
            right_value = parse_fraction_like(right)
            if right_value is None:
                return False
            if right_value.denominator != 1:
                return False
    return True


def _build_validated_deepseek_result_from_ns(ns: dict[str, Any], parsed: dict[str, Any], user_text: str) -> Optional[dict[str, Any]]:
    normalize_space = _require(ns, '_normalize_space')
    safe_eval_fraction_expression = _require(ns, '_safe_eval_fraction_expression')
    parse_fraction_like = _require(ns, '_parse_fraction_like')
    equation_uses_only_prompt_numbers = _require(ns, '_equation_uses_only_prompt_numbers')
    validate_diagram_spec = _require(ns, '_validate_diagram_spec')
    ensure_sentence = _require(ns, '_ensure_sentence')
    clean_text = _require(ns, '_clean_text')
    format_number = ns.get('_format_number') if callable(ns.get('_format_number')) else _format_number
    join_lines = _require(ns, '_join_lines')

    if parsed.get('cannot_safely_solve'):
        return None
    known = normalize_space(str(parsed.get('known') or ''))
    find = normalize_space(str(parsed.get('find') or ''))
    equation = normalize_space(str(parsed.get('equation') or ''))
    answer_number_raw = parsed.get('answer_number')
    answer_unit = normalize_space(str(parsed.get('answer_unit') or ''))
    tip = normalize_space(str(parsed.get('tip') or '')) or 'проверяй вычисления по шагам.'
    steps = parsed.get('steps')
    if not known or not find or not equation or answer_number_raw in (None, ''):
        return None
    if not isinstance(steps, list) or not steps:
        return None
    normalized_steps = [normalize_space(str(step)) for step in steps if normalize_space(str(step))]
    if not normalized_steps or len(normalized_steps) > 8:
        return None
    if len(answer_unit) > 24:
        return None
    if not _answer_unit_matches_text(answer_unit, user_text):
        return None
    if not _validate_ai_step_units(ns, normalized_steps, user_text, answer_unit):
        return None

    equation_value = safe_eval_fraction_expression(equation)
    answer_number = parse_fraction_like(answer_number_raw)
    if equation_value is None or answer_number is None:
        return None
    if equation_value != answer_number:
        return None
    if not equation_uses_only_prompt_numbers(equation, user_text):
        return None
    if not _validate_ai_steps_arithmetic(ns, normalized_steps):
        return None
    if not _validate_ai_step_number_flow(ns, normalized_steps, user_text, answer_number):
        return None
    if _last_ai_step_result(ns, normalized_steps) != answer_number:
        return None
    if not _validate_ai_solution_semantics(ns, find, equation, normalized_steps, answer_unit, user_text):
        return None
    if not _validate_ai_whole_number_consistency(ns, normalized_steps, answer_number, answer_unit, user_text):
        return None

    diagram_spec = validate_diagram_spec(parsed.get('diagram_spec'))
    lines = [
        'Задача.',
        ensure_sentence(clean_text(user_text)),
        'Решение.',
        ensure_sentence(f'Что известно: {known.rstrip(".")}'),
        ensure_sentence(f'Что нужно найти: {find.rstrip(".")}'),
    ]
    for index, step in enumerate(normalized_steps, start=1):
        if re.match(r'^\d+\)', step):
            lines.append(ensure_sentence(step))
        else:
            lines.append(ensure_sentence(f'{index}) {step}'))
    answer_text = format_number(answer_number)
    if answer_unit:
        answer_text = f'{answer_text} {answer_unit}'.strip()
    lines.append(f'Ответ: {answer_text}')
    lines.append(ensure_sentence(f'Совет: {tip.rstrip(".")}'))
    result: dict[str, Any] = {
        'result': join_lines(lines),
        'source': 'deepseek-validated',
        'validated': True,
        'structured_solution': {
            'known': known,
            'find': find,
            'steps': normalized_steps,
            'equation': equation,
            'answer_number': format_number(answer_number),
            'answer_unit': answer_unit,
        },
    }
    if diagram_spec:
        result['diagram_spec'] = diagram_spec
    return result


__all__ = [
    '_build_validated_deepseek_result_from_ns',
    '_validate_ai_solution_semantics',
    '_validate_ai_whole_number_consistency',
]
