from __future__ import annotations

import re
from typing import Any

from backend.legacy_formatting_helpers import _normalize_space
from backend.legacy_school_helpers import _soft_person_key, _split_known_and_question


_QUESTION_COUNT_LABEL_BLOCKED = {
    'осталось', 'стало', 'получилось', 'будет', 'будут', 'было',
    'останется', 'останутся', 'станет', 'станут',
    'заплатили', 'потратили', 'получили', 'получит', 'получат',
    'съели', 'съел', 'отдали', 'убрали', 'продали',
    'прошёл', 'прошла', 'прошли', 'прошел', 'проехал', 'проехала', 'проехали',
    'раз', 'раза',
}


def _extract_word_after(text: str, position: int) -> str:
    match = re.match(r'\s*([A-Za-zА-Яа-яё/-]+)', text[position:])
    return match.group(1).strip('.,!?') if match else ''


def _question_text(raw_text: str) -> str:
    _, question = _split_known_and_question(raw_text)
    return _normalize_space(question)


def _question_count_label(raw_text: str) -> str:
    question = _question_text(raw_text).lower()
    match = re.search(r'сколько\s+([а-яёa-z/-]+)', question)
    if match:
        label = match.group(1).strip('.,!?')
        if label not in _QUESTION_COUNT_LABEL_BLOCKED:
            return label
    match = re.search(r'какова\s+длина\s+([а-яёa-z/-]+)', question)
    if match:
        return match.group(1).strip('.,!?')
    return ''


def _subject_token_key(word: str) -> str:
    lower = _normalize_space(word).lower().replace('ё', 'е')
    if not lower:
        return ''
    if lower.startswith(('перв', 'одн')):
        return 'first'
    if lower.startswith(('втор', 'друг')):
        return 'second'
    if lower in {'у', 'в', 'во', 'на', 'а', 'и', 'по', 'к', 'из', 'от', 'до', 'со', 'с'}:
        return ''
    if lower in {'было', 'были', 'лежало', 'лежали', 'стояло', 'стояли', 'находилось', 'находились'}:
        return ''
    return _soft_person_key(lower)


def _question_subject_order(question_lower: str, subject_entries: list[dict[str, Any]]) -> list[int]:
    order: list[int] = []
    for word in re.findall(r'[а-яёa-z-]+', question_lower):
        key = _subject_token_key(word)
        if not key:
            continue
        for index, entry in enumerate(subject_entries[:2]):
            if index not in order and key in entry['keys']:
                order.append(index)
                break
    return order
