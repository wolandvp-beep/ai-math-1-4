from __future__ import annotations

import re
from fractions import Fraction
from typing import Optional

from backend.legacy_math_signals import _normalize_space
from backend.legacy_school_helpers import (
    _LENGTH_UNITS,
    _MASS_UNITS,
    _MEASURE_FINAL_STATE_MARKERS,
    _MEASURE_GROUP_ORDER,
    _MEASURE_GROUP_SCALES,
    _MEASURE_PART_RE,
    _NEGATIVE_CHANGE_MARKERS,
    _POSITIVE_CHANGE_MARKERS,
    _canonical_time_unit,
    _canonical_volume_unit,
    _format_number,
    _to_fraction,
)


def _canonical_measure_unit(raw_unit: str) -> Optional[str]:
    unit = raw_unit.lower().strip()
    if unit in _LENGTH_UNITS:
        return unit
    if unit in _MASS_UNITS:
        return unit
    volume_unit = _canonical_volume_unit(unit)
    if volume_unit:
        return volume_unit
    return _canonical_time_unit(unit)


def _measure_group_for_unit(unit: str) -> Optional[str]:
    for group, scales in _MEASURE_GROUP_SCALES.items():
        if unit in scales:
            return group
    return None


def _finalize_compound_quantity(text: str, group: str, parts: list[dict]) -> dict:
    scales = _MEASURE_GROUP_SCALES[group]
    total_smallest = Fraction(0)
    units: list[str] = []
    for part in parts:
        total_smallest += part['value'] * scales[part['unit']]
        units.append(part['unit'])
    return {
        'group': group,
        'start': parts[0]['start'],
        'end': parts[-1]['end'],
        'pretty': _normalize_space(text[parts[0]['start']:parts[-1]['end']]),
        'parts': parts,
        'units': units,
        'total_smallest': total_smallest,
    }


def _extract_compound_quantities(text: str) -> list[dict]:
    parts: list[dict] = []
    for match in _MEASURE_PART_RE.finditer(text):
        unit = _canonical_measure_unit(match.group(2))
        if not unit:
            continue
        group = _measure_group_for_unit(unit)
        if not group:
            continue
        parts.append(
            {
                'start': match.start(),
                'end': match.end(),
                'value': _to_fraction(match.group(1)),
                'unit': unit,
                'pretty': _normalize_space(match.group(0)),
                'group': group,
            }
        )
    if not parts:
        return []

    quantities: list[dict] = []
    current_group = parts[0]['group']
    current_parts = [parts[0]]
    current_end = parts[0]['end']

    for part in parts[1:]:
        gap = text[current_end:part['start']]
        if part['group'] == current_group and re.fullmatch(r'[\s,]*(?:и\s*)?', gap, flags=re.IGNORECASE):
            current_parts.append(part)
            current_end = part['end']
            continue
        quantities.append(_finalize_compound_quantity(text, current_group, current_parts))
        current_group = part['group']
        current_parts = [part]
        current_end = part['end']

    quantities.append(_finalize_compound_quantity(text, current_group, current_parts))
    return quantities


def _choose_measure_base_unit(group: str, quantities: list[dict]) -> str:
    units: list[str] = []
    for quantity in quantities:
        units.extend(quantity['units'])
    scales = _MEASURE_GROUP_SCALES[group]
    return min(units, key=lambda unit: scales[unit])


def _quantity_value_in_unit(quantity: dict, unit: str) -> Fraction:
    scales = _MEASURE_GROUP_SCALES[quantity['group']]
    return quantity['total_smallest'] / scales[unit]


def _format_measure_total(total_smallest: Fraction, group: str, visible_units: list[str]) -> str:
    order = _MEASURE_GROUP_ORDER[group]
    scales = _MEASURE_GROUP_SCALES[group]
    unit_set = set(visible_units)
    use_units = [unit for unit in order if unit in unit_set]
    if not use_units:
        use_units = [order[-1]]

    remainder = Fraction(total_smallest)
    parts: list[str] = []
    started = False
    for index, unit in enumerate(use_units):
        scale = scales[unit]
        if index == len(use_units) - 1:
            value = remainder / scale
            if not parts or value != 0:
                parts.append(f'{_format_number(value)} {unit}')
            break
        count = int(remainder / scale)
        remainder -= count * scale
        if count or started:
            parts.append(f'{count} {unit}')
            started = True
    if not parts:
        return f'0 {use_units[-1]}'
    return ' '.join(parts)


def _infer_measure_change_sign(text_lower: str, quantity: dict, previous_end: int) -> Optional[int]:
    context_before = text_lower[max(previous_end, quantity['start'] - 45):quantity['start']]
    context_after = text_lower[quantity['end']:quantity['end'] + 30]

    def _nearest_before_sign(context: str) -> Optional[int]:
        best_sign: Optional[int] = None
        best_index = -1
        for marker in _NEGATIVE_CHANGE_MARKERS:
            index = context.rfind(marker)
            if index > best_index:
                best_index = index
                best_sign = -1
        for marker in _POSITIVE_CHANGE_MARKERS:
            index = context.rfind(marker)
            if index > best_index:
                best_index = index
                best_sign = 1
        return best_sign if best_index >= 0 else None

    def _nearest_after_sign(context: str) -> Optional[int]:
        best_sign: Optional[int] = None
        best_index: Optional[int] = None
        for marker in _NEGATIVE_CHANGE_MARKERS:
            index = context.find(marker)
            if index >= 0 and (best_index is None or index < best_index):
                best_index = index
                best_sign = -1
        for marker in _POSITIVE_CHANGE_MARKERS:
            index = context.find(marker)
            if index >= 0 and (best_index is None or index < best_index):
                best_index = index
                best_sign = 1
        return best_sign

    before_sign = _nearest_before_sign(context_before)
    if before_sign is not None:
        return before_sign
    after_sign = _nearest_after_sign(context_after)
    if after_sign is not None:
        return after_sign
    return None


def _question_asks_initial_state(question_lower: str) -> bool:
    normalized = _normalize_space(question_lower).lower().replace('ё', 'е')
    if not normalized:
        return False
    if any(marker in normalized for marker in ('сначала', 'изначаль', 'вначал', 'до этого')):
        return True
    return re.search(r'\bбыл(?:о|а|и)?\b', normalized) is not None


def _measure_quantity_has_final_state_marker(text_lower: str, quantity: dict) -> bool:
    context_before = text_lower[max(0, quantity['start'] - 35):quantity['start']]
    context_after = text_lower[quantity['end']:quantity['end'] + 15]
    combined = f'{context_before} {context_after}'
    return any(marker in combined for marker in _MEASURE_FINAL_STATE_MARKERS)


__all__ = [name for name in globals() if name.startswith('_')]
