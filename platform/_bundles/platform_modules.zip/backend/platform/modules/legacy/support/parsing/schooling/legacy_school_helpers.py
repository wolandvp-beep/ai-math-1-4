from __future__ import annotations

import math
import re
from fractions import Fraction
from typing import Any, Optional

from backend.legacy_formatting_helpers import _ensure_sentence
from backend.legacy_math_signals import _clean_text, _normalize_space

_LENGTH_UNITS = {
    'км': 1_000_000,
    'м': 1_000,
    'дм': 100,
    'см': 10,
    'мм': 1,
}

_TIME_TO_SECONDS = {
    'ч': 3600,
    'мин': 60,
    'с': 1,
}

_SPEED_UNIT_PARTS = {
    'км/ч': ('км', 'ч'),
    'км/мин': ('км', 'мин'),
    'м/ч': ('м', 'ч'),
    'м/мин': ('м', 'мин'),
    'м/с': ('м', 'с'),
    'см/с': ('см', 'с'),
}

_MASS_UNITS = {'кг', 'г'}
_VOLUME_UNITS = {'л': 1000, 'мл': 1}

_MEASURE_GROUP_SCALES = {
    'length': dict(_LENGTH_UNITS),
    'time': {'ч': 3600, 'мин': 60, 'с': 1},
    'mass': {'кг': 1000, 'г': 1},
    'volume': dict(_VOLUME_UNITS),
}

_MEASURE_GROUP_ORDER = {
    'length': ['км', 'м', 'дм', 'см', 'мм'],
    'time': ['ч', 'мин', 'с'],
    'mass': ['кг', 'г'],
    'volume': ['л', 'мл'],
}

_MEASURE_PART_RE = re.compile(
    r'(\d+(?:[.,]\d+)?)\s*(км|м|дм|см|мм|кг|г|л|литр(?:а|ов)?|мл|миллилитр(?:а|ов)?|ч|час(?:а|ов)?|минут(?:а|ы|у)?|мин|секунд(?:а|ы|у)?|сек|с)\b(?!\s*/)',
    re.IGNORECASE,
)

_MEASURE_FINAL_STATE_MARKERS = (
    'осталось', 'остался', 'осталась', 'остались',
    'стало', 'стал', 'стала', 'стали',
    'получилось', 'получил', 'получила', 'получили',
    'вышло', 'вышел', 'вышла', 'вышли',
    'равно', 'теперь',
)

_NEGATIVE_CHANGE_MARKERS = (
    'отрезал', 'отрезала', 'отрезали', 'убавил', 'убавила', 'убавили',
    'уменьшил', 'уменьшила', 'уменьшили', 'вычел', 'вычла', 'вычли',
    'отнял', 'отняла', 'отняли', 'съел', 'съела', 'съели',
    'потратил', 'потратила', 'потратили', 'заплатил', 'заплатила', 'заплатили',
    'отдал', 'отдала', 'отдали', 'вышел', 'вышла', 'вышли',
    'убрал', 'убрала', 'убрали', 'забрал', 'забрала', 'забрали',
    'взял', 'взяла', 'взяли', 'подарил', 'подарила', 'подарили',
    'продал', 'продала', 'продали', 'раздал', 'раздала', 'раздали', 'прошел', 'прошла', 'прошли',
    'отпилил', 'отпилила', 'отпилили',
    'выпил', 'выпила', 'выпили',
    'убавил', 'убавила', 'убавили', 'уменьшил', 'уменьшила', 'уменьшили',
    'высыпал', 'высыпала', 'высыпали', 'вылил', 'вылила', 'вылили',
    'слил', 'слила', 'слили', 'отлил', 'отлила', 'отлили',
    'переложил', 'переложила', 'переложили', 'пересыпал', 'пересыпала', 'пересыпали',
    'перелил', 'перелила', 'перелили',
)

_POSITIVE_CHANGE_MARKERS = (
    'добавил', 'добавила', 'добавили', 'прибавил', 'прибавила', 'прибавили',
    'увеличил', 'увеличила', 'увеличили', 'купил', 'купила', 'купили',
    'получил', 'получила', 'получили', 'положил', 'положила', 'положили',
    'вошел', 'вошла', 'вошли', 'вошёл', 'вошла', 'вошли',
    'долил', 'долила', 'долили', 'налил', 'налила', 'налили',
    'еще', 'ещё', 'потом',
    'дал', 'дала', 'дали',
)

_NEGATIVE_ACTION_VERBS = {
    'потратил', 'потратила', 'потратили', 'заплатил', 'заплатила', 'заплатили',
    'съел', 'съела', 'съели', 'отдал', 'отдала', 'отдали',
    'вышел', 'вышла', 'вышли', 'вычел', 'вычла', 'вычли',
    'отнял', 'отняла', 'отняли', 'убрал', 'убрала', 'убрали',
    'забрал', 'забрала', 'забрали', 'взял', 'взяла', 'взяли',
    'отрезал', 'отрезала', 'отрезали', 'подарил', 'подарила', 'подарили',
    'продал', 'продала', 'продали', 'раздал', 'раздала', 'раздали',
    'выпил', 'выпила', 'выпили',
    'убавил', 'убавила', 'убавили', 'уменьшил', 'уменьшила', 'уменьшили',
    'высыпал', 'высыпала', 'высыпали', 'вылил', 'вылила', 'вылили',
    'слил', 'слила', 'слили', 'отлил', 'отлила', 'отлили',
    'переложил', 'переложила', 'переложили', 'пересыпал', 'пересыпала', 'пересыпали',
    'перелил', 'перелила', 'перелили',
}

_POSITIVE_ACTION_VERBS = {
    'добавил', 'добавила', 'добавили', 'прибавил', 'прибавила', 'прибавили',
    'положил', 'положила', 'положили', 'получил', 'получила', 'получили',
    'вошел', 'вошла', 'вошли', 'вошёл', 'купил', 'купила', 'купили',
    'долил', 'долила', 'долили', 'налил', 'налила', 'налили',
    'дал', 'дала', 'дали',
}

_AMBIGUOUS_ACTION_VERBS = {'купил', 'купила', 'купили'}

_TRANSFER_ACTION_VERBS = {
    'дал', 'дала', 'дали',
    'отдал', 'отдала', 'отдали',
    'подарил', 'подарила', 'подарили',
    'переложил', 'переложила', 'переложили', 'пересыпал', 'пересыпала', 'пересыпали',
    'перелил', 'перелила', 'перелили',
}

_ACTION_VERB_RE = re.compile(
    r'\b(' + '|'.join(
        sorted(
            map(re.escape, _NEGATIVE_ACTION_VERBS | _POSITIVE_ACTION_VERBS),
            key=len,
            reverse=True,
        )
    ) + r')\b',
    re.IGNORECASE,
)

_DISTRIBUTION_VERB_RE = re.compile(
    r'\b(?:раздали|раздал|раздала|разложили|разложил|разложила|разделили|разделил|разделила|поделили|поделил|поделила|распределили|распределил|распределила)\b',
    re.IGNORECASE,
)

_RUBLE_RE = r'(?:руб(?:\.|ль|ля|лей)?|р\.)'

_SMALL_NUMBER_WORDS = {
    'ноль': 0,
    'один': 1,
    'одна': 1,
    'одно': 1,
    'одну': 1,
    'одни': 1,
    'два': 2,
    'две': 2,
    'три': 3,
    'четыре': 4,
    'пять': 5,
    'шесть': 6,
    'семь': 7,
    'восемь': 8,
    'девять': 9,
    'десять': 10,
}

_SMALL_NUMBER_WORD_RE = re.compile(
    r'\b(' + '|'.join(sorted(map(re.escape, _SMALL_NUMBER_WORDS), key=len, reverse=True)) + r')\b',
    re.IGNORECASE,
)


def _replace_small_number_words(text: str) -> str:
    def _replace(match: re.Match[str]) -> str:
        return str(_SMALL_NUMBER_WORDS[match.group(1).lower().replace('ё', 'е')])

    return _SMALL_NUMBER_WORD_RE.sub(_replace, str(text or ''))


def _split_known_and_question(text: str) -> tuple[str, str]:
    cleaned = _clean_text(text)
    if not cleaned:
        return '', ''
    parts = [part.strip() for part in re.split(r'(?<=[.?!])\s+', cleaned) if part.strip()]
    if len(parts) >= 2:
        known = ' '.join(parts[:-1]).strip()
        question = parts[-1].strip()
        return _ensure_sentence(known), _ensure_sentence(question)
    if '?' in cleaned:
        left, right = cleaned.rsplit('?', 1)
        return _ensure_sentence(left), _ensure_sentence(left + '?')
    return _ensure_sentence(cleaned), ''


def _to_fraction(number_text: str) -> Fraction:
    value = str(number_text).replace(' ', '').replace(',', '.')
    return Fraction(value)


def _format_number(value: Fraction | int) -> str:
    if not isinstance(value, Fraction):
        value = Fraction(value)
    if value.denominator == 1:
        return str(value.numerator)
    sign = '-' if value < 0 else ''
    value = abs(value)
    whole = value.numerator // value.denominator
    remainder = value.numerator % value.denominator
    if whole and remainder:
        return f'{sign}{whole} {remainder}/{value.denominator}'
    if remainder:
        return f'{sign}{remainder}/{value.denominator}'
    return f'{sign}{whole}'


def _result_dict(text: str, result_factory: Optional[Callable[[str, str], dict]] = None) -> dict:
    if callable(result_factory):
        try:
            return result_factory(text, 'local-extra-20260416ak')
        except TypeError:
            pass
    return {'result': text, 'source': 'local-extra-20260416ak', 'validated': True}


def _safe_none_if_not_integer(value: Fraction) -> Optional[int]:
    if value.denominator != 1:
        return None
    return int(value.numerator)


def _perfect_square_root(value: Fraction) -> Optional[Fraction]:
    if value < 0 or value.denominator != 1:
        return None
    integer = int(value.numerator)
    root = math.isqrt(integer)
    if root * root != integer:
        return None
    return Fraction(root, 1)


def _soft_person_key(text: str) -> str:
    letters = re.sub(r'[^a-zа-яё-]', '', str(text or '').lower().replace('ё', 'е'))
    for suffix in ('ой', 'ей', 'ью'):
        if letters.endswith(suffix) and len(letters) > len(suffix) + 1:
            letters = letters[:-len(suffix)]
            break
    if letters.endswith(('а', 'я', 'е', 'и', 'у', 'ю', 'о')) and len(letters) > 2:
        letters = letters[:-1]
    return letters[:4]


def _format_clock_duration(total_minutes: Fraction) -> str:
    if total_minutes.denominator != 1:
        return f'{_format_number(total_minutes)} мин'
    minutes = int(total_minutes)
    hours, minutes = divmod(minutes, 60)
    parts: list[str] = []
    if hours:
        parts.append(f'{hours} ч')
    if minutes or not parts:
        parts.append(f'{minutes} мин')
    return ' '.join(parts)


def _canonical_time_unit(raw_unit: str) -> Optional[str]:
    unit = raw_unit.lower().strip()
    if unit in {'ч', 'час', 'часа', 'часов'}:
        return 'ч'
    if unit in {'мин', 'минута', 'минуты', 'минут', 'минуту'}:
        return 'мин'
    if unit in {'с', 'сек', 'секунда', 'секунды', 'секунд'}:
        return 'с'
    return None


def _canonical_speed_unit(raw_unit: str) -> Optional[str]:
    unit = raw_unit.lower().replace(' ', '')
    return unit if unit in _SPEED_UNIT_PARTS else None


def _canonical_volume_unit(raw_unit: str) -> Optional[str]:
    unit = raw_unit.lower().strip()
    if unit in {'л', 'литр', 'литра', 'литров'}:
        return 'л'
    if unit in {'мл', 'миллилитр', 'миллилитра', 'миллилитров'}:
        return 'мл'
    return None


def _extract_clock_times(text: str) -> list[dict[str, Any]]:
    times: list[dict[str, Any]] = []
    patterns = [
        re.compile(r'(\d{1,2})\s*(?:ч|час(?:а|ов)?)\s*(?:(\d{1,2})\s*(?:мин(?:ут(?:а|ы|у)?|ут)?))?', re.IGNORECASE),
        re.compile(r'\b(\d{1,2}):(\d{2})\b'),
    ]
    for pattern in patterns:
        for match in pattern.finditer(text):
            hour = int(match.group(1))
            minute = int(match.group(2) or 0)
            if hour > 23 or minute > 59:
                continue
            times.append(
                {
                    'start': match.start(),
                    'end': match.end(),
                    'hour': hour,
                    'minute': minute,
                    'total_minutes': hour * 60 + minute,
                    'pretty': _normalize_space(match.group(0)),
                }
            )
    times.sort(key=lambda item: item['start'])
    deduped: list[dict[str, Any]] = []
    for item in times:
        if deduped and item['start'] == deduped[-1]['start'] and item['end'] == deduped[-1]['end']:
            continue
        deduped.append(item)
    return deduped


def _extract_speeds(text: str) -> list[tuple[Fraction, str]]:
    found: list[tuple[Fraction, str]] = []
    for match in re.finditer(r'(\d+(?:[.,]\d+)?)\s*(км\s*/\s*ч|км\s*/\s*мин|м\s*/\s*ч|м\s*/\s*мин|м\s*/\s*с|см\s*/\s*с)', text, flags=re.IGNORECASE):
        value = _to_fraction(match.group(1))
        unit = _canonical_speed_unit(match.group(2))
        if unit:
            found.append((value, unit))
    return found


def _extract_time_values(text: str) -> list[tuple[Fraction, str, str]]:
    found: list[tuple[Fraction, str, str]] = []
    for match in re.finditer(r'(\d+(?:[.,]\d+)?)\s*(час(?:а|ов)?|ч|минут(?:а|ы)?|минут|мин|секунд(?:а|ы)?|секунд|сек|с)\b', text, flags=re.IGNORECASE):
        canonical = _canonical_time_unit(match.group(2))
        if canonical:
            found.append((_to_fraction(match.group(1)), canonical, match.group(0).strip()))
    return found


def _extract_distance_values(text: str) -> list[tuple[Fraction, str, str]]:
    found: list[tuple[Fraction, str, str]] = []
    for match in re.finditer(r'(\d+(?:[.,]\d+)?)\s*(км|м|дм|см|мм)\b(?!\s*/)', text, flags=re.IGNORECASE):
        found.append((_to_fraction(match.group(1)), match.group(2).lower(), match.group(0).strip()))
    return found


def _convert_time(value: Fraction, from_unit: str, to_unit: str) -> Fraction:
    return value * Fraction(_TIME_TO_SECONDS[from_unit], _TIME_TO_SECONDS[to_unit])


def _convert_length(value: Fraction, from_unit: str, to_unit: str) -> Fraction:
    return value * Fraction(_LENGTH_UNITS[from_unit], _LENGTH_UNITS[to_unit])


def _format_time_result(value: Fraction, unit: str) -> tuple[str, str]:
    if unit == 'ч' and value.denominator != 1:
        minutes = value * 60
        if minutes.denominator == 1:
            return str(minutes.numerator), 'мин'
    if unit == 'мин' and value.denominator != 1:
        seconds = value * 60
        if seconds.denominator == 1:
            return str(seconds.numerator), 'с'
    return _format_number(value), unit


def _ask_kind(text: str) -> tuple[bool, bool, bool]:
    lower = text.lower()
    asks_distance = any(
        fragment in lower
        for fragment in (
            'какое расстояние',
            'найди расстояние',
            'расстояние между',
            'какой путь',
            'найди путь',
            'сколько километров',
            'сколько метров',
        )
    )
    asks_speed = any(
        fragment in lower
        for fragment in (
            'какова скорость',
            'с какой скоростью',
            'найди скорость',
            'определи скорость',
        )
    )
    asks_time = any(
        fragment in lower
        for fragment in (
            'какое время',
            'найди время',
            'сколько времени',
            'через сколько',
            'за какое время',
        )
    )
    return asks_distance, asks_speed, asks_time


def _looks_like_relative_motion_distance(text: str) -> bool:
    lower = text.lower()
    asks_distance, _, _ = _ask_kind(lower)
    return (
        asks_distance
        and (('навстречу' in lower) or ('в противоположных направлениях' in lower) or ('в разные стороны' in lower))
        and len(_extract_speeds(lower)) >= 2
        and bool(_extract_time_values(lower))
    )


def _looks_like_direct_price_problem(text: str) -> bool:
    lower = text.lower()
    return (
        ('сколько стоят' in lower or 'какова стоимость' in lower or 'сколько заплатят' in lower)
        and re.search(_RUBLE_RE, lower) is not None
        and len(re.findall(r'\d+', lower)) >= 3
    )


__all__ = [
    '_LENGTH_UNITS',
    '_TIME_TO_SECONDS',
    '_SPEED_UNIT_PARTS',
    '_RUBLE_RE',
    '_MASS_UNITS',
    '_VOLUME_UNITS',
    '_MEASURE_GROUP_SCALES',
    '_MEASURE_GROUP_ORDER',
    '_MEASURE_PART_RE',
    '_MEASURE_FINAL_STATE_MARKERS',
    '_NEGATIVE_CHANGE_MARKERS',
    '_POSITIVE_CHANGE_MARKERS',
    '_NEGATIVE_ACTION_VERBS',
    '_POSITIVE_ACTION_VERBS',
    '_AMBIGUOUS_ACTION_VERBS',
    '_TRANSFER_ACTION_VERBS',
    '_ACTION_VERB_RE',
    '_DISTRIBUTION_VERB_RE',
    '_replace_small_number_words',
    '_split_known_and_question',
    '_to_fraction',
    '_format_number',
    '_safe_none_if_not_integer',
    '_perfect_square_root',
    '_soft_person_key',
    '_format_clock_duration',
    '_canonical_time_unit',
    '_canonical_speed_unit',
    '_canonical_volume_unit',
    '_extract_clock_times',
    '_extract_speeds',
    '_extract_time_values',
    '_extract_distance_values',
    '_convert_time',
    '_convert_length',
    '_format_time_result',
    '_ask_kind',
    '_looks_like_relative_motion_distance',
    '_looks_like_direct_price_problem',
]
