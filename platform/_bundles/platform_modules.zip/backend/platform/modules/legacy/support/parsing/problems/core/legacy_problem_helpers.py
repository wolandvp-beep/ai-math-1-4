from __future__ import annotations

import re
from typing import List, Optional, Tuple

from backend.text_utils import normalize_word_problem_text


def extract_condition_and_question(raw_text: str) -> Tuple[str, str]:
    cleaned = normalize_word_problem_text(raw_text)
    if not cleaned:
        return "", ""

    parts = [part.strip() for part in re.split(r"(?<=[.?!])\s+", cleaned) if part.strip()]
    if not parts:
        return "", ""

    starter_re = re.compile(
        r"^(?:сколько|каков|какова|какое|какая|чему|найти|найдите|узнай|узнайте|во\s+сколько|на\s+сколько)",
        re.IGNORECASE,
    )
    condition_parts: List[str] = []
    question_parts: List[str] = []

    for part in parts:
        stripped = part.strip()
        is_question = stripped.endswith('?') or bool(starter_re.match(stripped))
        if is_question:
            question_parts.append(stripped)
        else:
            condition_parts.append(stripped)

    if not question_parts and condition_parts:
        last = condition_parts[-1]
        if starter_re.match(last):
            question_parts = [last.rstrip('.?!') + '?']
            condition_parts = condition_parts[:-1]

    def _join(items: List[str], as_question: bool) -> str:
        out: List[str] = []
        for item in items:
            text = item.strip()
            if not text:
                continue
            if as_question:
                text = text.rstrip('.!')
                if not text.endswith('?'):
                    text += '?'
            else:
                text = text.rstrip('.?!')
            out.append(text)
        joined = ' '.join(out).strip()
        if len(joined) > (180 if as_question else 240):
            limit = 180 if as_question else 240
            joined = joined[: limit - 3].rstrip() + '...'
        return joined

    condition = _join(condition_parts, False)
    question = _join(question_parts, True)

    lower = cleaned.lower().replace('ё', 'е')
    pretty = cleaned.strip().rstrip('.?!')

    direct_rect = re.search(
        r"прямоугольник[а]?\s+со\s+сторонами\s+(\d+\s*[а-яa-z/²]+)\s+и\s+(\d+\s*[а-яa-z/²]+)",
        lower,
    )
    if direct_rect and not condition:
        condition = f"Стороны прямоугольника {direct_rect.group(1)} и {direct_rect.group(2)}"

    square_side = re.search(r"сторона\s+квадрата\s+(\d+\s*[а-яa-z/²]+)", lower)
    if square_side and not condition:
        condition = f"Сторона квадрата {square_side.group(1)}"

    triangle_side = re.search(r"сторона\s+равностороннего\s+треугольника\s+(\d+\s*[а-яa-z/²]+)", lower)
    if triangle_side and not condition:
        condition = f"Сторона равностороннего треугольника {triangle_side.group(1)}"

    if not condition and pretty and re.match(r"^(найти|найдите|узнай|узнайте)\b", lower):
        question = pretty.rstrip('.?!') + ('?' if not pretty.endswith('?') else '')

    return condition, question


def _question_text_only(raw_text: str) -> str:
    _, question = extract_condition_and_question(raw_text)
    return question.lower()


def _question_lower_text(raw_text: str) -> str:
    try:
        return _question_text_only(raw_text).lower().replace('ё', 'е')
    except Exception:
        _, question = extract_condition_and_question(raw_text)
        return question.lower().replace('ё', 'е')


def _statement_lower_text(raw_text: str) -> str:
    return normalize_word_problem_text(raw_text).lower().replace('ё', 'е')


def _po_product_matches(raw_text: str) -> List[dict]:
    lower = _statement_lower_text(raw_text)
    matches = []
    pattern = re.compile(r"(\d+)\s+([^?.!,]{1,40}?)\s+по\s+(\d+)\s*([а-яёa-z/²\.]+)?", re.IGNORECASE)
    for match in pattern.finditer(lower):
        count = int(match.group(1))
        name = re.sub(r"\s+", " ", match.group(2).strip())
        value = int(match.group(3))
        unit = (match.group(4) or "").strip().rstrip('.,')
        matches.append({'count': count, 'name': name, 'value': value, 'unit': unit})
    return matches


def _extract_question_noun(raw_text: str) -> str:
    try:
        _, question = extract_condition_and_question(raw_text)
    except Exception:
        question = str(raw_text or '')
    q = question.strip().rstrip('?.!').replace('ё', 'е')
    if not q:
        return ''
    ql = q.lower()
    if 'во сколько раз' in ql:
        return 'раз'
    match = re.search(
        r"^сколько\s+(?:было\s+|будет\s+|стало\s+|осталось\s+|получилось\s+|понадобится\s+|потребовалось\s+|можно\s+купить\s+)?([а-яё]+)",
        ql,
    )
    if match:
        noun = match.group(1).strip()
        if noun not in {'всего', 'вместе', 'на', 'во', 'по', 'также', 'денег'}:
            return noun
    match = re.search(r"^каков[ао]?\s+([а-яё]+)", ql)
    if match:
        return match.group(1).strip()
    return ''


def _patch_number_phrase(raw_text: str, number: int, occurrence: int = 0) -> str:
    lower = _statement_lower_text(raw_text)
    matches = re.findall(rf"{number}\s+[а-яё]+", lower)
    if matches:
        return matches[min(occurrence, len(matches) - 1)]
    return str(number)


def _patch_singular_unit(word: str) -> str:
    value = str(word or '').strip().lower().replace('ё', 'е').strip('.,;:!?')
    mapping = {
        'пакетов': 'пакет',
        'пакета': 'пакет',
        'коробок': 'коробка',
        'коробки': 'коробка',
        'наборов': 'набор',
        'набора': 'набор',
        'ящиков': 'ящик',
        'ведер': 'ведро',
        'вёдер': 'ведро',
        'книг': 'книга',
        'ручек': 'ручка',
        'тетрадей': 'тетрадь',
        'бутылок': 'бутылка',
        'банок': 'банка',
    }
    return mapping.get(value, value)


def _patch_pick_compare_names_from_question(raw_text: str) -> Tuple[str, str]:
    question = _question_lower_text(raw_text)
    match = re.search(r"на\s+сколько\s+(?:[а-яё]+\s+)?([а-яё]+)\s+(?:больше|меньше),?\s+чем\s+([а-яё]+)", question)
    if match:
        return match.group(1), match.group(2)
    match = re.search(r"во\s+сколько\s+раз\s+(?:[а-яё]+\s+)?([а-яё]+)\s+(?:больше|меньше),?\s+чем\s+([а-яё]+)", question)
    if match:
        return match.group(1), match.group(2)
    return '', ''


def _word_multiplier_value(word: str) -> Optional[int]:
    value = str(word or '').lower().replace('ё', 'е')
    mapping = {
        'двухэтажный': 2,
        'двухъярусный': 2,
        'трехэтажный': 3,
        'трёхэтажный': 3,
        'четырехэтажный': 4,
        'четырёхэтажный': 4,
        'пятиярусный': 5,
        'двухместный': 2,
        'трехместный': 3,
        'трёхместный': 3,
        'четырехместный': 4,
        'четырёхместный': 4,
        'двухлитровый': 2,
        'трехлитровый': 3,
        'трёхлитровый': 3,
    }
    return mapping.get(value)


def _find_group_pair_any(text_lower: str) -> Optional[dict]:
    text = str(text_lower or '').lower().replace('ё', 'е')
    match = re.search(r"(\d+)\s+[^\d?.!]{0,40}?\bпо\s+(\d+)\b", text)
    if match:
        return {
            'groups': int(match.group(1)),
            'per_group': int(match.group(2)),
            'start': match.start(),
            'end': match.end(),
            'kind': 'po',
        }

    for match in re.finditer(r"(\d+)\s+([а-яa-z-]+)", text):
        groups = int(match.group(1))
        word = match.group(2)
        per_group = _word_multiplier_value(word)
        if per_group is None:
            continue
        if any(fragment in word for fragment in ('литр', 'комнат', 'местн', 'ярус', 'тонн', 'метр')):
            return {
                'groups': groups,
                'per_group': per_group,
                'start': match.start(),
                'end': match.end(),
                'kind': 'compound',
            }
    return None


def _numbers_before_after(text_lower: str, start: int, end: int) -> Tuple[Optional[int], Optional[int]]:
    before_matches = [int(m.group()) for m in re.finditer(r"\d+", str(text_lower or '')) if m.start() < start]
    after_matches = [int(m.group()) for m in re.finditer(r"\d+", str(text_lower or '')) if m.start() >= end]
    before = before_matches[0] if before_matches else None
    after = after_matches[0] if after_matches else None
    return before, after
