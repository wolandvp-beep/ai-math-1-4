from __future__ import annotations

import re
from fractions import Fraction
from typing import Any, Optional

from backend.legacy_question_flow_helpers import _subject_token_key
from backend.legacy_school_helpers import _TRANSFER_ACTION_VERBS, _format_number, _to_fraction


def _extract_named_subject_entries_from_text(text_lower: str) -> list[dict[str, Any]]:
    pronouns = {'он', 'она', 'оно', 'они', 'ему', 'ей', 'им', 'него', 'нее', 'неё', 'нему', 'ней', 'ее', 'её'}
    entries: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    transfer_verbs = '|'.join(sorted(map(re.escape, _TRANSFER_ACTION_VERBS), key=len, reverse=True))
    patterns = (
        re.compile(r'\bу\s+([а-яёa-z-]+)\b', re.IGNORECASE),
        re.compile(r'\b([а-яёa-z-]+)\s+(?:' + transfer_verbs + r')\b', re.IGNORECASE),
        re.compile(r'\b(?:' + transfer_verbs + r')\s+([а-яёa-z-]+)\b', re.IGNORECASE),
        re.compile(r'\bчем\s+у\s+([а-яёa-z-]+)\b', re.IGNORECASE),
    )
    for pattern in patterns:
        for match in pattern.finditer(text_lower):
            candidate = match.group(1).lower().replace('ё', 'е')
            if candidate in pronouns:
                continue
            key = _subject_token_key(candidate)
            if not key or key in {'first', 'second'} or key in pronouns or key in seen_keys:
                continue
            entries.append({'keys': {key}, 'label': candidate.capitalize()})
            seen_keys.add(key)
            if len(entries) >= 2:
                return entries
    return entries


def _extract_dual_subject_entries(prefix_lower: str, number_matches: list[re.Match[str]]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    separators = ',.;!?'
    for index, match in enumerate(number_matches[:2], start=1):
        clause_start = 0
        for separator in separators:
            clause_start = max(clause_start, prefix_lower.rfind(separator, 0, match.start()) + 1)
        clause = prefix_lower[clause_start:match.start()]
        words = re.findall(r'[а-яёa-z-]+', clause)
        keys = {key for word in words if (key := _subject_token_key(word))}
        label = 'первое количество' if index == 1 else 'второе количество'
        if 'first' in keys or 'second' in keys:
            keys = {key for key in keys if key in {'first', 'second'}}
            label = 'первое количество' if 'first' in keys else 'второе количество'
        else:
            for word in reversed(words):
                if _subject_token_key(word):
                    label = word.capitalize()
                    break
        entries.append({'keys': keys, 'label': label})
    return entries


def _subject_indexes_in_segment(segment: str, subject_entries: list[dict[str, Any]]) -> list[int]:
    indexes: list[int] = []
    for word in re.findall(r'[а-яёa-z-]+', segment):
        key = _subject_token_key(word)
        if not key:
            continue
        matches = [index for index, entry in enumerate(subject_entries[:2]) if key in entry['keys']]
        if len(matches) == 1:
            indexes.append(matches[0])
    return indexes


def _extract_dual_subject_transfer_action(
    text_lower: str,
    action_match: re.Match[str],
    subject_entries: list[dict[str, Any]],
    value: Optional[Fraction] = None,
) -> Optional[dict[str, Any]]:
    verb = action_match.group(1).lower().replace('ё', 'е')
    if verb not in _TRANSFER_ACTION_VERBS:
        return None

    before_full = text_lower[max(0, action_match.start() - 90):action_match.start()]
    after_full = text_lower[action_match.end():action_match.end() + 90]
    before_segment = re.split(r'[,.!?;]', before_full)[-1]
    after_segment = re.split(r'[,.!?;]', after_full)[0]

    before_indexes = _subject_indexes_in_segment(before_segment, subject_entries)
    if not before_indexes:
        full_indexes = _subject_indexes_in_segment(before_full, subject_entries)
        unique_full_indexes: list[int] = []
        for index in full_indexes:
            if index not in unique_full_indexes:
                unique_full_indexes.append(index)
        if len(unique_full_indexes) == 1:
            before_indexes = unique_full_indexes
    if not before_indexes:
        return None
    source_index = before_indexes[-1]

    target_index: Optional[int] = None
    after_indexes = _subject_indexes_in_segment(after_segment, subject_entries)
    for index in after_indexes:
        if index != source_index:
            target_index = index
            break

    if target_index is None:
        for index in reversed(before_indexes[:-1]):
            if index != source_index:
                target_index = index
                break

    if target_index is None and re.search(r'^\s*(?:ему|ей|нему|ней)\b', after_segment):
        if len(subject_entries) >= 2:
            target_index = 1 - source_index

    change_value = value
    if change_value is None:
        number_match = re.search(r'(\d+(?:[.,]\d+)?)', after_segment)
        if number_match:
            change_value = _to_fraction(number_match.group(1))
    if change_value is None or change_value < 0:
        return None
    if target_index is None or target_index == source_index:
        return None

    return {
        'source_index': source_index,
        'target_index': target_index,
        'value': change_value,
        'verb': verb,
    }


def _apply_dual_subject_transfer_step(
    lines: list[str],
    step_number: int,
    current_values: list[Fraction],
    transfer: dict[str, Any],
    subject_entries: list[dict[str, Any]],
    answer_label: str,
) -> Optional[int]:
    source_index = transfer['source_index']
    target_index = transfer['target_index']
    change_value = transfer['value']

    source_old = current_values[source_index]
    target_old = current_values[target_index]
    source_new = source_old - change_value
    target_new = target_old + change_value
    if source_new < 0 or target_new < 0:
        return None

    label_suffix = f' {answer_label}' if answer_label else ''
    lines.append(
        f'{step_number}) Это передача между двумя объектами: '
        f'{subject_entries[source_index]["label"]}: {_format_number(source_old)} - {_format_number(change_value)} = {_format_number(source_new)}{label_suffix}, '
        f'{subject_entries[target_index]["label"]}: {_format_number(target_old)} + {_format_number(change_value)} = {_format_number(target_new)}{label_suffix}.'
    )
    current_values[source_index] = source_new
    current_values[target_index] = target_new
    return step_number + 1


def _detect_dual_subject_action_index(text_lower: str, action_match: re.Match[str], subject_entries: list[dict[str, Any]]) -> Optional[int]:
    segment_before = text_lower[max(0, action_match.start() - 60):action_match.start()]
    before_words = re.findall(r'[а-яёa-z-]+', segment_before)
    before_keys = [key for word in before_words if (key := _subject_token_key(word))]
    for key in reversed(before_keys):
        matches = [index for index, entry in enumerate(subject_entries[:2]) if key in entry['keys']]
        if len(matches) == 1:
            return matches[0]

    pronoun_match = None
    for candidate in re.finditer(r'\b(?:ему|ей|нему|ней)\b', segment_before):
        pronoun_match = candidate
    if pronoun_match is not None:
        pre_pronoun = segment_before[:pronoun_match.start()]
        pre_words = re.findall(r'[а-яёa-z-]+', pre_pronoun)
        pre_keys = [key for word in pre_words if (key := _subject_token_key(word))]
        for key in reversed(pre_keys):
            matches = [index for index, entry in enumerate(subject_entries[:2]) if key in entry['keys']]
            if len(matches) == 1:
                return matches[0]

    context = text_lower[max(0, action_match.start() - 50): action_match.end() + 50]
    context_words = re.findall(r'[а-яёa-z-]+', context)
    context_keys = {key for word in context_words if (key := _subject_token_key(word))}
    scores = [len(context_keys & entry['keys']) for entry in subject_entries[:2]]
    best_score = max(scores, default=0)
    if best_score > 0 and scores.count(best_score) == 1:
        return scores.index(best_score)
    if re.search(r'\b(перв\w*|одн\w*)\b', context) and not re.search(r'\b(втор\w*|друг\w*)\b', context):
        return 0
    if re.search(r'\b(втор\w*|друг\w*)\b', context) and not re.search(r'\b(перв\w*|одн\w*)\b', context):
        return 1
    return None


__all__ = [name for name in globals() if name.startswith('_')]
