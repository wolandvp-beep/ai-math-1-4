from __future__ import annotations

import ast
import re
from fractions import Fraction
from typing import List, Optional

from backend.explanation_utils import sanitize_model_text
from backend.expression_parser import parse_expression_ast
from backend.expression_rendering import pretty_expression_with_map
from backend.text_utils import strip_known_prefix

OPERATOR_SYMBOLS = {
    ast.Add: '+',
    ast.Sub: '-',
    ast.Mult: '×',
    ast.Div: ':',
}


def _is_int_literal_node(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and type(node.value) is int


def _int_from_literal_node(node: ast.AST) -> int:
    if not _is_int_literal_node(node):
        raise ValueError('Expected integer literal node')
    return int(node.value)


def format_fraction(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f'{value.numerator}/{value.denominator}'


def eval_fraction_node(node: ast.AST) -> Fraction:
    if _is_int_literal_node(node):
        return Fraction(_int_from_literal_node(node), 1)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -eval_fraction_node(node.operand)
    if isinstance(node, ast.BinOp):
        left = eval_fraction_node(node.left)
        right = eval_fraction_node(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            if right == 0:
                raise ZeroDivisionError('division by zero')
            return left / right
    raise ValueError('Unsupported expression')


def _detailed_split_sections(text: str) -> dict:
    cleaned = sanitize_model_text(text)
    body: List[str] = []
    answer = ''
    advice = ''
    check = ''
    for raw in cleaned.split('\n'):
        line = raw.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith('ответ:'):
            value = line.split(':', 1)[1].strip().rstrip('.!?').strip()
            if value and not answer:
                answer = value
            continue
        if lower.startswith('совет:'):
            value = line.split(':', 1)[1].strip().rstrip('.!?').strip()
            if value and not advice:
                advice = value
            continue
        if lower.startswith('проверка:'):
            value = line.split(':', 1)[1].strip()
            if value and not check:
                check = f'Проверка: {value}'
            continue
        body.append(line)
    return {'body': body, 'answer': answer, 'advice': advice, 'check': check}


def _detailed_finalize_line(line: str) -> str:
    raw = str(line or '').rstrip()
    if not raw:
        return ''
    stripped = raw.strip()
    if re.fullmatch(r'[ A-Za-zА-Яа-я0-9()+\-×:=/]+', raw) and (('=' in raw) or bool(re.search(r'[+\-×:/]', raw))):
        return raw
    if re.match(r'^(?:Пример|Порядок действий|Решение по действиям|Решение|Задача|Уравнение)\b', stripped, flags=re.IGNORECASE):
        return stripped
    if stripped[-1] not in '.!?:':
        stripped += '.'
    return stripped


def _detailed_finalize_text(lines: List[str]) -> str:
    finalized = []
    for line in lines:
        fixed = _detailed_finalize_line(line)
        if fixed:
            finalized.append(fixed)
    return '\n'.join(finalized).strip()


def _detailed_strip_sequence_prefix(line: str) -> str:
    text = str(line or '').strip()
    text = re.sub(r'^(?:сначала|потом|теперь|дальше)\s+', '', text, flags=re.IGNORECASE)
    text = re.sub(r'^и\s+', '', text, flags=re.IGNORECASE)
    if text:
        text = text[0].upper() + text[1:]
    return text


def _detailed_number_lines(lines: List[str]) -> List[str]:
    result: List[str] = []
    counter = 1
    for raw in lines:
        line = str(raw or '').strip()
        if not line:
            continue
        if re.match(r'^\d+\)', line):
            result.append(line)
            counter += 1
            continue
        line = _detailed_strip_sequence_prefix(line)
        result.append(f'{counter}) {line}')
        counter += 1
    return result


def _detailed_statement_text(raw_text: str) -> str:
    text = strip_known_prefix(str(raw_text or '').replace('\r', ' ').replace('\n', ' '))
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _detailed_is_column_like(body_lines: List[str]) -> bool:
    joined = ' '.join(body_lines).lower()
    markers = (
        'столбик',
        'неполное делимое',
        'неполное произведение',
        'скорость сближения',
        'скорость удаления',
    )
    return any(marker in joined for marker in markers)


def _detailed_find_operator_position(source: str, node: ast.AST) -> Optional[int]:
    if not isinstance(node, ast.BinOp):
        return None
    try:
        left_end = node.left.end_col_offset
        right_start = node.right.col_offset
        segment = source[left_end:right_start]
        for offset, char in enumerate(segment):
            if char in '+-*/':
                return left_end + offset
        for index in range(node.col_offset, node.end_col_offset):
            if 0 <= index < len(source) and source[index] in '+-*/':
                return index
    except Exception:
        return None
    return None


def _detailed_collect_expression_steps(node: ast.AST, source: str) -> List[dict]:
    if _is_int_literal_node(node):
        return []
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return []
    if not isinstance(node, ast.BinOp):
        return []
    left_steps = _detailed_collect_expression_steps(node.left, source)
    right_steps = _detailed_collect_expression_steps(node.right, source)
    try:
        left_value = format_fraction(eval_fraction_node(node.left))
        right_value = format_fraction(eval_fraction_node(node.right))
        result_value = format_fraction(eval_fraction_node(node))
    except Exception:
        return left_steps + right_steps
    position = _detailed_find_operator_position(source, node)
    return left_steps + right_steps + [{
        'left': left_value,
        'right': right_value,
        'operator': OPERATOR_SYMBOLS[type(node.op)],
        'result': result_value,
        'pos': position,
    }]


def _detailed_compact_expression(source: str) -> str:
    return source.replace('*', '×').replace('/', ':')


def _detailed_build_order_block(source: str) -> List[str]:
    node = parse_expression_ast(source)
    if node is None:
        return []
    steps = _detailed_collect_expression_steps(node, source)
    if len(steps) <= 1:
        return []

    pretty_expr, op_map = pretty_expression_with_map(source)
    marks = [' '] * len(pretty_expr)

    for step_index, step in enumerate(steps, start=1):
        raw_pos = step.get('pos')
        if raw_pos is None or raw_pos not in op_map:
            continue
        pretty_pos = op_map[raw_pos]
        label = str(step_index)
        start = max(0, pretty_pos - (len(label) - 1) // 2)
        for offset, char in enumerate(label):
            target = start + offset
            if 0 <= target < len(marks):
                marks[target] = char

    mark_line = ''.join(marks).rstrip()
    return ['Порядок действий:', mark_line, pretty_expr]


def _detailed_expression_answer(source: str) -> str:
    node = parse_expression_ast(source)
    if node is None:
        return ''
    try:
        return format_fraction(eval_fraction_node(node))
    except Exception:
        return ''


def _detailed_pretty_equation(source: str) -> str:
    text = re.sub(r'([+\-*/=])', r' \1 ', source)
    text = text.replace('*', '×').replace('/', ':')
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _detailed_pretty_fraction_expression(source: str) -> str:
    text = re.sub(r'\s+', '', source)
    text = text.replace('+', ' + ').replace('-', ' - ')
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _detailed_build_generic_steps_from_expression(source: str) -> List[str]:
    node = parse_expression_ast(source)
    if node is None:
        return []
    steps = _detailed_collect_expression_steps(node, source)
    result = []
    for index, step in enumerate(steps, start=1):
        result.append(f"{index}) {step['left']} {step['operator']} {step['right']} = {step['result']}")
    return result


__all__ = [name for name in globals() if name.startswith('_detailed_')]
