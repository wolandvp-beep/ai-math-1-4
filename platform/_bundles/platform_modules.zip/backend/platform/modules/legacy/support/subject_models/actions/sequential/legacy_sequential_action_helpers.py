from __future__ import annotations

import re
from fractions import Fraction
from typing import Optional

from backend.legacy_math_signals import _normalize_space
from backend.legacy_school_helpers import (
    _ACTION_VERB_RE,
    _AMBIGUOUS_ACTION_VERBS,
    _NEGATIVE_ACTION_VERBS,
    _POSITIVE_ACTION_VERBS,
    _RUBLE_RE,
    _split_known_and_question,
    _to_fraction,
)


def _classify_sequential_action(verb: str, segment_before: str, segment_after: str) -> Optional[int]:
    normalized_verb = verb.lower().replace('ё', 'е')
    segment_before = segment_before.lower().replace('ё', 'е')
    segment_after = segment_after.lower().replace('ё', 'е')
    tail_before = re.split(r'[,.!?;]', segment_before)[-1]

    if normalized_verb in {'подарил', 'подарила', 'подарили'}:
        if re.search(r'\b(ему|ей|мне|тебе|нам|вам|им)\b', tail_before):
            return 1
        return -1

    if normalized_verb in {'дал', 'дала', 'дали'}:
        if re.search(r'\b(ему|ей|мне|тебе|нам|вам|им)\b', tail_before):
            return 1
        last_word_match = re.search(r'([а-яёa-z-]+)\s*$', tail_before)
        last_word = last_word_match.group(1) if last_word_match else ''
        if last_word.endswith(('е', 'и', 'у', 'ю')):
            return 1
        return -1

    if normalized_verb in _AMBIGUOUS_ACTION_VERBS:
        if re.search(rf'за\s*\d+(?:[.,]\d+)?\s*{_RUBLE_RE}', segment_after):
            return -1
        return 1
    if normalized_verb in {item.replace('ё', 'е') for item in _NEGATIVE_ACTION_VERBS}:
        return -1
    if normalized_verb in {item.replace('ё', 'е') for item in _POSITIVE_ACTION_VERBS}:
        return 1
    return None


def _extract_sequential_actions(text_lower: str) -> tuple[list[dict], list[re.Match]]:
    matches = list(_ACTION_VERB_RE.finditer(text_lower))
    if not matches:
        return [], []

    actions: list[dict] = []
    for index, match in enumerate(matches):
        verb = match.group(1)
        next_start = matches[index + 1].start() if index + 1 < len(matches) else len(text_lower)
        segment_after = text_lower[match.end():next_start]
        segment_before = text_lower[max(0, match.start() - 35):match.start()]
        sign = _classify_sequential_action(verb, segment_before, segment_after)
        if sign is None:
            continue

        numbers: list[Fraction] = []
        tail_before = re.split(r'[,.!?;]', segment_before)[-1]
        normalized_verb = verb.lower().replace('ё', 'е')
        near_after_match = re.search(r'^\D{0,12}(\d+(?:[.,]\d+)?)', segment_after)
        before_action_match = re.search(
            r'(\d+(?:[.,]\d+)?)\s*(?:она|он|оно|они|ему|ей|им|мне|нам|тебе|вам|их|еще|ещё)?\s*$',
            tail_before,
        )
        before_match = re.search(r'(\d+(?:[.,]\d+)?)\D{0,12}$', tail_before)
        if normalized_verb in _AMBIGUOUS_ACTION_VERBS:
            numbers = [
                _to_fraction(price_match.group(1))
                for price_match in re.finditer(rf'за\s*(\d+(?:[.,]\d+)?)\s*{_RUBLE_RE}', segment_after)
            ]
        elif before_action_match:
            numbers = [_to_fraction(before_action_match.group(1))]
        elif near_after_match:
            numbers = [_to_fraction(near_after_match.group(1))]
        elif before_match:
            numbers = [_to_fraction(before_match.group(1))]
        if not numbers:
            numbers = [_to_fraction(number) for number in re.findall(r'\d+(?:[.,]\d+)?', segment_after)]
        if not numbers:
            before_numbers = re.findall(r'\d+(?:[.,]\d+)?', tail_before)
            if before_numbers:
                numbers = [_to_fraction(before_numbers[-1])]
        if numbers and normalized_verb not in _AMBIGUOUS_ACTION_VERBS:
            numbers = numbers[:1]
        for value in numbers:
            actions.append({'verb': verb, 'sign': sign, 'value': value})
    return actions, matches


def _extract_final_change_result_value(text: str) -> Optional[Fraction]:
    known, _ = _split_known_and_question(text)
    known_lower = _normalize_space(known).lower().replace('ё', 'е')
    if not known_lower:
        return None
    result_value: Optional[Fraction] = None
    patterns = (
        re.compile(r'(?:остал(?:ось|ся|ась|ись)|стал(?:о|а|и)|получил(?:ось)?|получилось|получили|вышло|вышла|вышли|равно)\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE),
        re.compile(r'у\s+[а-яёa-z-]+\s+(?:остал(?:ось|ся|ась|ись)|стал(?:о|а|и))\s*(\d+(?:[.,]\d+)?)', re.IGNORECASE),
    )
    for pattern in patterns:
        for match in pattern.finditer(known_lower):
            result_value = _to_fraction(match.group(1))
    return result_value


__all__ = [name for name in globals() if name.startswith('_')]
