from __future__ import annotations

from collections.abc import Callable

from backend.legacy_final_patch import apply as apply_final_patch
from backend.legacy_midpatch_runtime import apply as apply_midpatch_runtime
from backend.legacy_remaining_runtime_chain import apply as apply_remaining_runtime_chain
from backend.platform.modules.legacy.runtime.pipeline.support.apply import apply_named_pipeline


RUNTIME_PIPELINE: tuple[tuple[str, Callable[[dict], None]], ...] = (
    ('midpatch_runtime', apply_midpatch_runtime),
    ('remaining_runtime_chain', apply_remaining_runtime_chain),
    ('final_integrated_patch', apply_final_patch),
)


def apply_runtime_pipeline(ns: dict) -> None:
    apply_named_pipeline(RUNTIME_PIPELINE, ns)


__all__ = ['RUNTIME_PIPELINE', 'apply_runtime_pipeline']
