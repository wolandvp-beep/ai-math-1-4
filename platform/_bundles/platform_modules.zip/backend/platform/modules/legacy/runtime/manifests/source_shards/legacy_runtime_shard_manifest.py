from __future__ import annotations

from backend.runtime_asset_catalog import iter_runtime_source_specs
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.support.manifests import (
    build_deep_seeded_manifest,
)

LEGACY_RUNTIME_SHARD_MANIFEST = build_deep_seeded_manifest(iter_runtime_source_specs())


def get_runtime_shard_modules(filename: str) -> tuple[str, ...]:
    return LEGACY_RUNTIME_SHARD_MANIFEST.get(filename, ())


__all__ = ['LEGACY_RUNTIME_SHARD_MANIFEST', 'get_runtime_shard_modules']
