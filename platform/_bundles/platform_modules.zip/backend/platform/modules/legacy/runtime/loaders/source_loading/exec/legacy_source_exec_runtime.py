from __future__ import annotations

from backend.platform.modules.legacy.runtime.loaders.source_loading.support.exec_runtime.apply import (
    apply_legacy_runtime_module,
    apply_legacy_source,
)
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.exec_runtime.callbacks import (
    make_runtime_module_apply,
    make_source_apply,
)
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.exec_runtime.compilation import compile_legacy_source

__all__ = [
    'apply_legacy_source',
    'apply_legacy_runtime_module',
    'compile_legacy_source',
    'make_runtime_module_apply',
    'make_source_apply',
]
