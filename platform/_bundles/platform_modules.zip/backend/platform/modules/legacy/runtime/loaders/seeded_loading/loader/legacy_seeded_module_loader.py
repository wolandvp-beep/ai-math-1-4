from __future__ import annotations

from functools import lru_cache
from importlib.util import find_spec, module_from_spec, spec_from_file_location
import sys
from pathlib import Path
from typing import Any, Mapping

from backend.legacy_namespace_filters import should_seed_runtime_name
from backend.runtime_namespace_adoption import adopt_exported_names_from_mapping


def _seed_module_dict(module_dict: dict[str, Any], namespace: Mapping[str, Any]) -> None:
    module_dict.setdefault('__builtins__', __builtins__)
    for key, value in namespace.items():
        if should_seed_runtime_name(key):
            module_dict[key] = value


@lru_cache(maxsize=None)
def resolve_module_path(module_name: str) -> Path:
    spec = find_spec(module_name)
    if spec is None or not spec.origin:
        raise ModuleNotFoundError(module_name)
    return Path(spec.origin)


def execute_seeded_file(namespace: dict[str, Any], file_path: Path, runtime_module_name: str) -> None:
    spec = spec_from_file_location(runtime_module_name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f'Cannot create module spec for {file_path}')
    module = module_from_spec(spec)
    _seed_module_dict(module.__dict__, namespace)
    spec.loader.exec_module(module)
    adopt_exported_names_from_mapping(namespace, module.__dict__)


def execute_seeded_module(namespace: dict[str, Any], module_name: str, runtime_module_name: str | None = None) -> None:
    spec = find_spec(module_name)
    if spec is None or spec.loader is None:
        raise ModuleNotFoundError(module_name)
    module = module_from_spec(spec)
    _seed_module_dict(module.__dict__, namespace)
    sentinel = object()
    previous = sys.modules.get(spec.name, sentinel)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        if previous is sentinel:
            sys.modules.pop(spec.name, None)
        else:
            sys.modules[spec.name] = previous
    adopt_exported_names_from_mapping(namespace, module.__dict__)


__all__ = ['execute_seeded_file', 'execute_seeded_module', 'resolve_module_path']
