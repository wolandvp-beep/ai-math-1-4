from __future__ import annotations

from functools import lru_cache
from typing import Any, Callable

from backend.legacy_source_exec_runtime import apply_legacy_source
from backend.runtime_namespace_factory import build_core_seeded_namespace


_SOURCE_FILENAME = 'prepatch_cascade_source.py'


@lru_cache(maxsize=1)
def load_prepatch_cascade_namespace() -> dict[str, Any]:
    namespace = build_core_seeded_namespace()
    apply_legacy_source(namespace, _SOURCE_FILENAME, __name__)
    return namespace


def _get_callable(name: str) -> Callable[..., Any] | None:
    value = load_prepatch_cascade_namespace().get(name)
    return value if callable(value) else None


def get_prepatch_build_explanation_local_first() -> Callable[..., Any] | None:
    return _get_callable('build_explanation_local_first')


def get_prepatch_extract_count_question_noun() -> Callable[..., Any] | None:
    return _get_callable('_extract_count_question_noun')


def get_prepatch_detect_question_unit() -> Callable[..., Any] | None:
    return _get_callable('_detect_question_unit')


def get_prepatch_detailed_maybe_enrich_answer() -> Callable[..., Any] | None:
    return _get_callable('_detailed_maybe_enrich_answer')


__all__ = [
    '_SOURCE_FILENAME',
    'load_prepatch_cascade_namespace',
    'get_prepatch_build_explanation_local_first',
    'get_prepatch_extract_count_question_noun',
    'get_prepatch_detect_question_unit',
    'get_prepatch_detailed_maybe_enrich_answer',
]
