from __future__ import annotations

from pathlib import Path

from backend.legacy_seeded_module_loader import resolve_module_path

from .assets import (
    legacy_source_module_name,
    seeded_runtime_source_module_name,
    source_asset,
    source_module_candidates,
    static_source_module_name,
)


def resolve_existing_module_path(*module_names: str) -> Path:
    last_error: Exception | None = None
    for module_name in module_names:
        try:
            return resolve_module_path(module_name)
        except Exception as exc:  # pragma: no cover - compatibility path
            last_error = exc
    if last_error is not None:
        raise last_error
    raise FileNotFoundError('No source modules were provided')


def static_source_file_path(filename: str) -> Path:
    return resolve_module_path(static_source_module_name(filename))


def seeded_runtime_source_file_path(filename: str) -> Path:
    return resolve_module_path(seeded_runtime_source_module_name(filename))


def legacy_source_file_path(filename: str) -> Path:
    return resolve_module_path(legacy_source_module_name(filename))


def source_file_path(filename: str) -> Path:
    return resolve_existing_module_path(*source_module_candidates(filename))


def source_seeded_file_candidates(filename: str) -> tuple[Path, ...]:
    asset = source_asset(filename)
    candidates: list[Path] = []
    for module_name in (asset.seeded_fallback_module, asset.legacy_wrapper_module):
        if not module_name:
            continue
        try:
            candidates.append(resolve_module_path(module_name))
        except Exception:  # pragma: no cover - compatibility path
            continue
    return tuple(candidates)


__all__ = [
    'legacy_source_file_path',
    'resolve_existing_module_path',
    'seeded_runtime_source_file_path',
    'source_file_path',
    'source_seeded_file_candidates',
    'static_source_file_path',
]
