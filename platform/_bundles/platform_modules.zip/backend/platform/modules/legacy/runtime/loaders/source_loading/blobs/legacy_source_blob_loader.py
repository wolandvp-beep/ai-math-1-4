from __future__ import annotations

from backend.legacy_source_loader import load_legacy_source as load_legacy_source_blob


__all__ = ['load_legacy_source_blob']
