from __future__ import annotations

from backend.platform.modules.legacy.runtime.loaders.source_loading.support.resolution.assets import *
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.resolution.paths import *
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.resolution import assets as _assets
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.resolution import paths as _paths

__all__ = [*_assets.__all__, *_paths.__all__]
