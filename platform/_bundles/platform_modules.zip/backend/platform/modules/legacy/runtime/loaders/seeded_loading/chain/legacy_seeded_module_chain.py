from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from backend.legacy_seeded_module_loader import execute_seeded_module


def apply_seeded_module_chain(
    namespace: dict[str, Any],
    module_names: Iterable[str],
    runtime_module_name: str,
) -> None:
    for index, module_name in enumerate(tuple(module_names), start=1):
        execute_seeded_module(
            namespace,
            module_name,
            runtime_module_name=f'{runtime_module_name}.__segment_{index:03d}__',
        )


__all__ = ['apply_seeded_module_chain']
