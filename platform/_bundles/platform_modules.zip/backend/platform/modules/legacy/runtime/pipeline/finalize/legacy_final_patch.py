from __future__ import annotations

from typing import Any, Optional

from backend.input_normalization import strip_solver_command_prefix
from backend.legacy_dangerous_topics import dangerous_topic_for_old_solver
from backend.legacy_explanatory_ai import _looks_like_explanatory_math_question, _try_structured_deepseek_explanation
from backend.legacy_math_signals import _looks_like_math_input
from backend.legacy_safe_responses import guard_result, safe_cannot_parse, safe_cannot_reliably_explain_math, safe_cannot_reliably_solve_math
from backend.legacy_validated_ai import _try_validated_deepseek_fallback
from backend.legacy_answer_enrichment import apply as _apply_answer_enrichment_patch
from backend.legacy_local_explanation_dispatcher import apply as _apply_local_explanation_dispatcher
from backend.legacy_deepseek_runtime import get_deepseek_api_key
from backend.legacy_local_handler_registry import LEGACY_LOCAL_HANDLER_NAMES, resolve_legacy_local_handler



def _result_dict(text: str, result_factory=None) -> dict[str, Any]:
    if callable(result_factory):
        try:
            return result_factory(text, 'local-extra-20260416ak')
        except TypeError:
            pass
    return {'result': text, 'source': 'local-extra-20260416ak', 'validated': True}


def _run_legacy_local_handler(ns: dict[str, Any], handler_name: str, user_text: str) -> Optional[dict[str, Any]]:
    handler = resolve_legacy_local_handler(handler_name, ns)
    if not callable(handler):
        return None
    try:
        local = handler(user_text)
    except Exception:
        return None
    if not local:
        return None
    return _result_dict(local, ns.get('_prompt20260416h_result'))


def apply(ns: dict[str, Any]) -> dict[str, Any]:
    _apply_answer_enrichment_patch(ns)
    _apply_local_explanation_dispatcher(ns, LEGACY_LOCAL_HANDLER_NAMES)
    prev_build_explanation = ns.get('build_explanation')

    async def build_explanation(user_text: str) -> dict[str, Any]:
        async def _call_prev_without_old_ai(text_to_solve: str) -> Optional[dict[str, Any]]:
            if not callable(prev_build_explanation):
                return None
            previous_key = ns.get('DEEPSEEK_API_KEY', '')
            api_key = get_deepseek_api_key(ns)
            if api_key:
                ns['DEEPSEEK_API_KEY'] = ''
                try:
                    return await prev_build_explanation(text_to_solve)
                finally:
                    ns['DEEPSEEK_API_KEY'] = previous_key
            return await prev_build_explanation(text_to_solve)

        stripped_command = strip_solver_command_prefix(user_text)
        if stripped_command:
            prefixed_result = await _call_prev_without_old_ai(stripped_command)
            if isinstance(prefixed_result, dict) and prefixed_result.get('validated') is True:
                return prefixed_result

        for handler_name in LEGACY_LOCAL_HANDLER_NAMES:
            local_payload = _run_legacy_local_handler(ns, handler_name, user_text)
            if local_payload:
                return local_payload

        dangerous_topic = dangerous_topic_for_old_solver(user_text, ns)
        if dangerous_topic:
            ai_result = await _try_validated_deepseek_fallback(ns, user_text)
            if ai_result:
                return ai_result
            return guard_result(safe_cannot_reliably_solve_math(user_text))

        prev_result = await _call_prev_without_old_ai(user_text)
        if isinstance(prev_result, dict) and prev_result.get('validated') is True:
            return prev_result

        if _looks_like_explanatory_math_question(user_text, _looks_like_math_input):
            explained = await _try_structured_deepseek_explanation(ns, user_text, looks_like_math_input_fn=_looks_like_math_input)
            if explained:
                return explained
            return guard_result(safe_cannot_reliably_explain_math(user_text))

        if _looks_like_math_input(user_text):
            ai_result = await _try_validated_deepseek_fallback(ns, user_text)
            if ai_result:
                return ai_result
            return guard_result(safe_cannot_reliably_solve_math(user_text))

        if isinstance(prev_result, dict):
            return prev_result
        return guard_result(safe_cannot_parse(user_text, 'задачу'))

    ns['build_explanation'] = build_explanation
    ns['_extra_patch_20260416ak_apply'] = apply
    return ns


__all__ = [
    'LEGACY_LOCAL_HANDLER_NAMES',
    'apply',
]
