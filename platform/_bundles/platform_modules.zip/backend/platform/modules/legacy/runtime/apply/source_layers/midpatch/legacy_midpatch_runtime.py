from __future__ import annotations

from backend.legacy_source_exec_runtime import make_source_apply


_SOURCE_FILENAME = 'midpatch_runtime_source.py'
apply = make_source_apply(_SOURCE_FILENAME, 'backend.legacy_midpatch_runtime')


__all__ = ["apply", "_SOURCE_FILENAME"]
