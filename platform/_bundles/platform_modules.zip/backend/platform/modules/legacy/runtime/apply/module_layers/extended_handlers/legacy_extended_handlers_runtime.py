from __future__ import annotations

from backend.legacy_source_exec_runtime import make_runtime_module_apply
from backend.runtime_asset_catalog import runtime_module_asset_spec


_RUNTIME_MODULE_FILENAME = 'extended_handlers_runtime_module.py'
_RUNTIME_MODULE_SPEC = runtime_module_asset_spec(_RUNTIME_MODULE_FILENAME)
_RUNTIME_MODULE_CANDIDATES = _RUNTIME_MODULE_SPEC.apply_candidates
_RUNTIME_MODULE_NAME = str(_RUNTIME_MODULE_SPEC.static_module)
apply = make_runtime_module_apply(_RUNTIME_MODULE_CANDIDATES, 'backend.legacy_extended_handlers_runtime')


__all__ = [
    "apply",
    "_RUNTIME_MODULE_CANDIDATES",
    "_RUNTIME_MODULE_FILENAME",
    "_RUNTIME_MODULE_NAME",
    "_RUNTIME_MODULE_SPEC",
]
