from __future__ import annotations

from backend.runtime_namespace_factory import build_module_namespace_loader as build_source_namespace_loader


def compile_source_namespace(source: str) -> dict[str, object]:
    raise RuntimeError(
        'compile_source_namespace is no longer used; handler namespaces are loaded from static-first source modules.'
    )


__all__ = ['build_source_namespace_loader', 'compile_source_namespace']
