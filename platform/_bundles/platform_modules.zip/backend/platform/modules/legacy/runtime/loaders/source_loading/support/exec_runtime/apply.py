from __future__ import annotations

from typing import Any

from backend.legacy_seeded_module_loader import execute_seeded_file
from backend.legacy_source_loader import source_module_candidates, source_seeded_file_candidates
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.import_apply import apply_import_candidates

from .compilation import runtime_module_name


def apply_legacy_source(ns: dict[str, Any], filename: str, module_name: str) -> None:
    last_error: Exception | None = None
    for candidate in source_module_candidates(filename):
        try:
            apply_import_candidates(ns, (candidate,))
            return
        except Exception as exc:  # pragma: no cover - fallback compatibility path
            last_error = exc
    effective_runtime_module_name = runtime_module_name(module_name, filename)
    for file_path in source_seeded_file_candidates(filename):
        try:
            execute_seeded_file(ns, file_path, effective_runtime_module_name)
            return
        except Exception as exc:  # pragma: no cover - deep fallback compatibility path
            last_error = exc
    if last_error is not None:
        raise last_error
    raise FileNotFoundError(filename)


def apply_legacy_runtime_module(ns: dict[str, Any], runtime_module_name) -> None:
    apply_import_candidates(ns, runtime_module_name)


__all__ = ['apply_legacy_runtime_module', 'apply_legacy_source']
