from __future__ import annotations

from backend.platform.modules.legacy.runtime.loaders.source_loading.support.reader import load_legacy_source
from backend.platform.modules.legacy.runtime.loaders.source_loading.support.source_resolution import *
from backend.platform.modules.legacy.runtime.loaders.source_loading.support import source_resolution as _source_resolution

__all__ = [
    'load_legacy_source',
    *_source_resolution.__all__,
]
