from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Callable

from backend.runtime_namespace_adoption import export_import_candidate_namespace


def iter_module_candidates(runtime_module_name: str | Iterable[str]) -> tuple[str, ...]:
    if isinstance(runtime_module_name, str):
        return (runtime_module_name,)
    return tuple(str(name) for name in runtime_module_name)


def apply_import_candidates(ns: dict[str, Any], runtime_module_name: str | Iterable[str]) -> None:
    last_error: Exception | None = None
    for candidate in iter_module_candidates(runtime_module_name):
        try:
            export_import_candidate_namespace(ns, candidate)
            return
        except Exception as exc:
            last_error = exc
            continue
    if last_error is not None:
        raise last_error
    raise ModuleNotFoundError('No runtime module candidates were provided')


def make_apply_callback(callback: Callable[[dict[str, Any]], None], module_name: str) -> Callable[[dict[str, Any]], None]:
    def apply(ns: dict[str, Any]) -> None:
        callback(ns)

    apply.__name__ = 'apply'
    apply.__qualname__ = 'apply'
    apply.__module__ = module_name
    return apply


__all__ = ['apply_import_candidates', 'iter_module_candidates', 'make_apply_callback']
