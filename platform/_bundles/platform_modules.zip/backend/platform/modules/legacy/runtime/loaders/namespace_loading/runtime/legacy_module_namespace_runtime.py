from __future__ import annotations

from backend.runtime_namespace_factory import build_module_namespace_loader


__all__ = ['build_module_namespace_loader']
