from __future__ import annotations

from backend.platform.modules.legacy.runtime.loaders.source_loading.support.import_apply import make_apply_callback

from .apply import apply_legacy_runtime_module, apply_legacy_source


def make_source_apply(filename: str, module_name: str):
    return make_apply_callback(lambda ns: apply_legacy_source(ns, filename, module_name), module_name)


def make_runtime_module_apply(runtime_module_name, module_name: str):
    return make_apply_callback(lambda ns: apply_legacy_runtime_module(ns, runtime_module_name), module_name)


__all__ = ['make_runtime_module_apply', 'make_source_apply']
