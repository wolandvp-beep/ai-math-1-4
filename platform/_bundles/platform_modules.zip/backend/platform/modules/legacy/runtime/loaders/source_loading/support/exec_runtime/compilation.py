from __future__ import annotations

from functools import lru_cache

from backend.legacy_source_loader import load_legacy_source


@lru_cache(maxsize=None)
def compile_legacy_source(filename: str, module_name: str):
    source = load_legacy_source(filename)
    return compile(source, f"{module_name}:{filename}", 'exec')


def runtime_module_name(module_name: str, filename: str) -> str:
    stem = filename.rsplit('.', 1)[0]
    return f'{module_name}.{stem}'


__all__ = ['compile_legacy_source', 'runtime_module_name']
