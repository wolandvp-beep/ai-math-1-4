from __future__ import annotations

from backend.legacy_runtime_manifest import REMAINING_RUNTIME_SPECS
from backend.platform.modules.legacy.runtime.pipeline.support.apply import (
    apply_wrapper_modules,
    load_apply as _load_apply,
)


def apply(ns: dict) -> None:
    apply_wrapper_modules((spec.wrapper_module for spec in REMAINING_RUNTIME_SPECS), ns)


__all__ = ['apply', 'REMAINING_RUNTIME_SPECS', '_load_apply']
