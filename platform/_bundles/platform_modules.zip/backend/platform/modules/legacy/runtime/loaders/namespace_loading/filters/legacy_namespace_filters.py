from __future__ import annotations

from typing import Mapping


_RUNTIME_MAGIC_NAMES = frozenset({
    '__annotations__',
    '__builtins__',
    '__cached__',
    '__doc__',
    '__file__',
    '__loader__',
    '__name__',
    '__package__',
    '__spec__',
})


def is_runtime_magic_name(name: str) -> bool:
    return name in _RUNTIME_MAGIC_NAMES or (name.startswith('__') and name.endswith('__'))


def should_seed_runtime_name(name: str) -> bool:
    return name == '__builtins__' or not is_runtime_magic_name(name)


def should_export_runtime_name(name: str) -> bool:
    return not is_runtime_magic_name(name)


def collect_non_magic_dunder_names(mapping: Mapping[str, object]) -> list[str]:
    return sorted(
        name
        for name in mapping
        if name.startswith('__') and not is_runtime_magic_name(name)
    )


__all__ = [
    'collect_non_magic_dunder_names',
    'is_runtime_magic_name',
    'should_export_runtime_name',
    'should_seed_runtime_name',
]
