from __future__ import annotations

from functools import lru_cache

from backend.platform.modules.legacy.runtime.loaders.source_loading.support.source_resolution import source_file_path


@lru_cache(maxsize=None)
def load_legacy_source(filename: str) -> str:
    return source_file_path(filename).read_text(encoding='utf-8')


__all__ = ['load_legacy_source']
