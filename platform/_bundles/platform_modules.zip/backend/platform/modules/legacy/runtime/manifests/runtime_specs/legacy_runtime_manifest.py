from __future__ import annotations

from dataclasses import dataclass

from backend.runtime_asset_catalog import iter_runtime_module_specs
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.support.manifests import (
    build_remaining_runtime_specs,
)


@dataclass(frozen=True)
class LegacyRuntimeSpec:
    name: str
    wrapper_module: str
    source_kind: str
    source_ref: str


REMAINING_RUNTIME_SPECS = build_remaining_runtime_specs(iter_runtime_module_specs(), LegacyRuntimeSpec)


__all__ = ['LegacyRuntimeSpec', 'REMAINING_RUNTIME_SPECS']
