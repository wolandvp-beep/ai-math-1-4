from __future__ import annotations

from backend.runtime_asset_catalog import runtime_source_asset_spec


def source_asset(filename: str):
    return runtime_source_asset_spec(filename)


def source_module_candidates(filename: str) -> tuple[str, ...]:
    return source_asset(filename).apply_candidates


def static_source_module_name(filename: str) -> str:
    return str(source_asset(filename).static_module)


def seeded_runtime_source_module_name(filename: str) -> str:
    return str(source_asset(filename).seeded_fallback_module)


def legacy_source_module_name(filename: str) -> str:
    return str(source_asset(filename).legacy_wrapper_module)


__all__ = [
    'legacy_source_module_name',
    'seeded_runtime_source_module_name',
    'source_asset',
    'source_module_candidates',
    'static_source_module_name',
]
