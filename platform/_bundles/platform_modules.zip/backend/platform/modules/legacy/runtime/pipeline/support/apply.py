from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from functools import lru_cache
from importlib import import_module
from typing import Any


@lru_cache(maxsize=None)
def load_apply(wrapper_module: str) -> Callable[[dict[str, Any]], None]:
    module = import_module(wrapper_module)
    apply = getattr(module, 'apply', None)
    if not callable(apply):
        raise RuntimeError(f'{wrapper_module} does not expose callable apply(ns)')
    return apply


def apply_wrapper_modules(wrapper_modules: Iterable[str], ns: dict[str, Any]) -> None:
    for wrapper_module in wrapper_modules:
        load_apply(str(wrapper_module))(ns)


def apply_named_pipeline(pipeline: Sequence[tuple[str, Callable[[dict[str, Any]], None]]], ns: dict[str, Any]) -> None:
    for _name, fn in pipeline:
        fn(ns)


__all__ = ['apply_named_pipeline', 'apply_wrapper_modules', 'load_apply']
