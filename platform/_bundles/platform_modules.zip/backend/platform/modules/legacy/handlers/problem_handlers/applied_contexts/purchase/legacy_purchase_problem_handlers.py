from __future__ import annotations

import re

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_purchase_problem_handlers_source.py'

_try_reverse_money_purchase_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_reverse_money_purchase_problem', module_name='backend.legacy_purchase_problem_handlers')
_try_money_purchase_flow_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_money_purchase_flow_problem', module_name='backend.legacy_purchase_problem_handlers')
_try_unit_price_purchase_problem_raw = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_unit_price_purchase_problem', module_name='backend.legacy_purchase_problem_handlers')
_try_direct_price_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_direct_price_problem', module_name='backend.legacy_purchase_problem_handlers')


def _try_unit_price_purchase_problem(raw_text: str):
    lower = str(raw_text or '').lower().replace('ё', 'е')
    if re.search(r'\bв\s+\d+\s+раз(?:а)?\s+(?:дешев|дорог)', lower):
        return None
    return _try_unit_price_purchase_problem_raw(raw_text)


__all__ = ['_try_reverse_money_purchase_problem', '_try_money_purchase_flow_problem', '_try_unit_price_purchase_problem', '_try_direct_price_problem']
