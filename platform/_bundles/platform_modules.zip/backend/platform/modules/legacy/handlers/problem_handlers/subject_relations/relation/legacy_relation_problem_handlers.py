from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_relation_problem_handlers_source.py'

_try_sum_unknown_part_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_sum_unknown_part_problem', module_name='backend.legacy_relation_problem_handlers')
_try_difference_unknown_component_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_difference_unknown_component_problem', module_name='backend.legacy_relation_problem_handlers')
_try_distribution_subset_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_distribution_subset_problem', module_name='backend.legacy_relation_problem_handlers')
_try_post_change_equal_parts_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_post_change_equal_parts_problem', module_name='backend.legacy_relation_problem_handlers')
_try_equal_parts_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_equal_parts_problem', module_name='backend.legacy_relation_problem_handlers')


__all__ = ['_try_sum_unknown_part_problem', '_try_difference_unknown_component_problem', '_try_distribution_subset_problem', '_try_post_change_equal_parts_problem', '_try_equal_parts_problem']
