from __future__ import annotations

from fractions import Fraction
from typing import Optional

from backend.legacy_answer_label_helpers import _guess_count_answer_label
from backend.legacy_answer_semantics import _answer_unit_family
from backend.legacy_dual_subject_action_helpers import _extract_named_subject_entries_from_text
from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_math_signals import _clean_text, _normalize_space
from backend.legacy_measure_helpers import _extract_compound_quantities, _question_asks_initial_state
from backend.legacy_question_flow_helpers import _question_count_label, _question_subject_order, _question_text
from backend.legacy_reverse_transfer_helpers import _append_final_total_relation_solution, _append_reverse_initial_summary, _classify_reverse_transfer_mixed_actions, _extract_known_initial_value_for_subject, _extract_reverse_transfer_relation, _extract_reverse_transfer_subject_entries, _extract_reverse_transfer_total_value, _forward_known_subject_value_through_actions, _reverse_initial_question_mode, _reverse_subject_phrase, _reverse_total_through_mixed_actions, _reverse_values_through_mixed_actions
from backend.legacy_school_helpers import _format_number
from backend.legacy_sequential_action_helpers import _extract_sequential_actions
from backend.legacy_validation_helpers import _is_ratio_answer_unit

def _school_context_requires_whole_values(raw_text: str, answer_label: str = '', answer_unit: str = '') -> bool:
    lower = _clean_text(raw_text).lower().replace('ё', 'е')
    token = _normalize_space(answer_unit or answer_label or _question_count_label(raw_text) or _guess_count_answer_label(raw_text)).lower().replace('ё', 'е').strip(' .')
    if _is_ratio_answer_unit(token):
        return False
    family = _answer_unit_family(token) if token else None
    if family == 'money':
        return 'коп' not in lower
    if family in {'length', 'area', 'mass', 'volume', 'time'}:
        return False
    if _extract_compound_quantities(raw_text):
        return False
    return bool(token)


def _looks_like_reverse_dual_subject_equality_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _extract_compound_quantities(text):
        return False
    if _extract_reverse_transfer_total_value(text) is not None:
        return False
    question = _question_text(text).lower().replace('ё', 'е')
    if not question or not any(marker in question for marker in ('сколько', 'на сколько', 'во сколько')):
        return False
    if not _question_asks_initial_state(question):
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return False

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return False

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified or any(item['kind'] == 'total' for item in classified):
        return False

    relation = _extract_reverse_transfer_relation(text, subject_entries)
    if not relation or not relation.get('equal'):
        return False

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    return sum(value is not None for value in known_initials) == 1


def _try_reverse_dual_subject_equality_after_changes_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_dual_subject_equality_after_changes_problem(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return None

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified or any(item['kind'] == 'total' for item in classified):
        return None

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    known_indexes = [index for index, value in enumerate(known_initials) if value is not None]
    if len(known_indexes) != 1:
        return None
    known_index = known_indexes[0]
    unknown_index = 1 - known_index
    known_initial = known_initials[known_index]
    if known_initial is None:
        return None

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    known_phrase = _reverse_subject_phrase(subject_entries[known_index])
    unknown_phrase = _reverse_subject_phrase(subject_entries[unknown_index])

    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        _ensure_sentence(f'Что известно: {known_phrase} было {_format_number(known_initial)}{label_suffix}, а после всех изменений количества стали поровну'),
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
    ]

    step_number = 1
    forward = _forward_known_subject_value_through_actions(known_initial, known_index, classified)
    if not forward:
        return None
    known_final, applied_steps = forward

    if applied_steps:
        for step in applied_steps:
            action = step['action']
            before_value = step['before']
            after_value = step['after']
            if step['kind'] == 'subject':
                operation = '+' if action['sign'] > 0 else '-'
                lines.append(
                    f'{step_number}) Изменяем количество {known_phrase}: '
                    f'{_format_number(before_value)} {operation} {_format_number(action["value"])} = {_format_number(after_value)}{label_suffix}.'
                )
            else:
                operation = '-' if action['source_index'] == known_index else '+'
                lines.append(
                    f'{step_number}) Учитываем передачу для {known_phrase}: '
                    f'{_format_number(before_value)} {operation} {_format_number(action["value"])} = {_format_number(after_value)}{label_suffix}.'
                )
            step_number += 1
    else:
        lines.append(f'{step_number}) На {known_phrase} действия не влияют, поэтому после изменений там осталось {_format_number(known_final)}{label_suffix}.')
        step_number += 1

    lines.append(
        f'{step_number}) После всех изменений количества стали поровну. Значит, {unknown_phrase} стало столько же: {_format_number(known_final)}{label_suffix}.'
    )
    step_number += 1

    final_values = [Fraction(0), Fraction(0)]
    final_values[known_index] = known_final
    final_values[unknown_index] = known_final

    reversed_solution = _reverse_values_through_mixed_actions(lines, step_number, final_values, classified, subject_entries, answer_label)
    if not reversed_solution:
        return None
    step_number, initial_values = reversed_solution

    if _school_context_requires_whole_values(text, answer_label=answer_label):
        if any(value.denominator != 1 for value in initial_values + final_values):
            return None

    if initial_values[known_index] != known_initial:
        return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            target_index = unknown_index
        answer_text = _format_number(initial_values[target_index])
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после изменений стало поровну, сначала найди конечное количество у известного объекта, потом приравняй к нему второе количество и только после этого восстанавливай начало.')
    return _join_lines(lines)


def _looks_like_reverse_dual_subject_total_relation_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _extract_compound_quantities(text):
        return False
    question = _question_text(text).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if not _question_asks_initial_state(question):
        return False
    final_total = _extract_reverse_transfer_total_value(text)
    if final_total is None:
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return False

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return False

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified:
        return False
    if any(item['kind'] in {'transfer', 'total'} for item in classified):
        return False

    relation = _extract_reverse_transfer_relation(text, subject_entries)
    return relation is not None


def _try_reverse_dual_subject_total_relation_after_changes_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_dual_subject_total_relation_after_changes_problem(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    final_total = _extract_reverse_transfer_total_value(text)
    if final_total is None:
        return None

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return None

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified or any(item['kind'] in {'transfer', 'total'} for item in classified):
        return None

    relation = _extract_reverse_transfer_relation(text, subject_entries)
    if not relation:
        return None

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    relation_kind = 'равенство' if relation.get('equal') else ('разница' if relation['kind'] == 'difference' else 'кратное сравнение')
    relation_sentence = (
        f'Что известно: после всех изменений вместе стало {_format_number(final_total)}{label_suffix}, и ещё известно, что количества стали поровну.'
        if relation.get('equal')
        else f'Что известно: после всех изменений вместе стало {_format_number(final_total)}{label_suffix}, и ещё известна итоговая связь между количествами ({relation_kind}).'
    )
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        relation_sentence,
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
    ]

    step_number = 1
    relation_solution = _append_final_total_relation_solution(lines, step_number, final_total, relation, subject_entries, answer_label)
    if not relation_solution:
        return None
    step_number, final_values = relation_solution

    reversed_solution = _reverse_values_through_mixed_actions(lines, step_number, final_values, classified, subject_entries, answer_label)
    if not reversed_solution:
        return None
    step_number, initial_values = reversed_solution

    if _school_context_requires_whole_values(text, answer_label=answer_label):
        if any(value.denominator != 1 for value in final_values + initial_values):
            return None

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    for index, known_value in enumerate(known_initials):
        if known_value is not None and initial_values[index] != known_value:
            return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, value in enumerate(known_initials) if value is None]
            if len(unknown_indexes) == 1:
                target_index = unknown_indexes[0]
            else:
                return None
        answer_text = _format_number(initial_values[target_index])
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после отдельных изменений известны и общая сумма, и итоговая связь между двумя количествами, сначала найди конечные количества, а потом иди назад по каждому изменению отдельно.')
    return _join_lines(lines)


def _looks_like_reverse_dual_subject_total_after_changes_problem(raw_text: str) -> bool:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if _looks_like_reverse_dual_subject_total_relation_after_changes_problem(text):
        return False
    if _extract_compound_quantities(text):
        return False
    question = _question_text(text).lower().replace('ё', 'е')
    if 'сколько' not in question:
        return False
    if not _question_asks_initial_state(question):
        return False
    final_total = _extract_reverse_transfer_total_value(text)
    if final_total is None:
        return False

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return False

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return False

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified:
        return False
    kinds = {item['kind'] for item in classified}
    if 'transfer' in kinds:
        return False
    if not (kinds & {'subject', 'total'}):
        return False

    mode = _reverse_initial_question_mode(question)
    if mode == 'total':
        return True

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    return sum(value is not None for value in known_initials) == 1


def _try_reverse_dual_subject_total_after_changes_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_dual_subject_total_after_changes_problem(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    final_total = _extract_reverse_transfer_total_value(text)
    if final_total is None:
        return None

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches or len(actions) != len(matches):
        return None

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified or any(item['kind'] == 'transfer' for item in classified):
        return None

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после всех изменений вместе стало {_format_number(final_total)}{label_suffix}.',
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
    ]

    step_number = 1
    reversed_total_solution = _reverse_total_through_mixed_actions(lines, step_number, final_total, classified, subject_entries, answer_label)
    if not reversed_total_solution:
        return None
    step_number, initial_total = reversed_total_solution

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    initial_values: Optional[list[Fraction]] = None

    if question_mode == 'total' and all(value is None for value in known_initials):
        lines.append(f'Ответ: {_format_number(initial_total)}{label_suffix}')
        lines.append('Совет: если после изменений известна общая сумма, сначала восстанови общую сумму назад, а потом уже переходи к отдельным количествам.')
        return _join_lines(lines)

    known_indexes = [index for index, value in enumerate(known_initials) if value is not None]
    if len(known_indexes) != 1:
        return None
    known_index = known_indexes[0]
    other_index = 1 - known_index
    known_value = known_initials[known_index]
    if known_value is None:
        return None
    other_value = initial_total - known_value
    if other_value < 0:
        return None

    lines.append(
        f'{step_number}) Перед первым изменением вместе было {_format_number(initial_total)}{label_suffix}. '
        f'{subject_entries[known_index]["phrase"].capitalize()} сначала было {_format_number(known_value)}{label_suffix}. '
        f'Значит, {subject_entries[other_index]["phrase"]} было: {_format_number(initial_total)} - {_format_number(known_value)} = {_format_number(other_value)}{label_suffix}.'
    )
    step_number += 1
    initial_values = [Fraction(0), Fraction(0)]
    initial_values[known_index] = known_value
    initial_values[other_index] = other_value

    step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, value in enumerate(known_initials) if value is None]
            if len(unknown_indexes) != 1:
                return None
            target_index = unknown_indexes[0]
        answer_text = _format_number(initial_values[target_index])
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если в задаче два объекта, а известна общая сумма после изменений, сначала восстанови общую сумму, а потом найди неизвестное начальное количество.')
    return _join_lines(lines)


__all__ = [
    '_school_context_requires_whole_values',
    '_looks_like_reverse_dual_subject_equality_after_changes_problem',
    '_try_reverse_dual_subject_equality_after_changes_problem',
    '_looks_like_reverse_dual_subject_total_relation_after_changes_problem',
    '_try_reverse_dual_subject_total_relation_after_changes_problem',
    '_looks_like_reverse_dual_subject_total_after_changes_problem',
    '_try_reverse_dual_subject_total_after_changes_problem',
]
