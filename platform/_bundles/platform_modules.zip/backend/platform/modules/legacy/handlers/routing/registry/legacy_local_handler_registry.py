from __future__ import annotations

from typing import Any, Callable

from backend.legacy_change_problem_handlers import _try_difference_after_change_problem, _try_find_initial_number_after_change, _try_find_initial_number_after_two_changes, _try_ratio_after_change_problem, _try_reverse_sequential_change_problem, _try_sequential_change_word_problem
from backend.legacy_dual_subject_problem_handlers import _try_dual_subject_comparison_after_changes_problem, _try_dual_subject_measured_after_changes_problem, _try_dual_subject_money_after_changes_problem, _try_dual_subject_total_after_changes_problem, _try_related_quantity_then_change_total_problem
from backend.legacy_fraction_problem_handlers import _try_fraction_change_problem, _try_fraction_comparison_problem, _try_fraction_of_remainder_problem, _try_fraction_related_subject_problem, _try_fraction_relative_change_problem, _try_fraction_remainder_of_whole_problem, _try_fraction_then_change_problem, _try_number_by_fraction
from backend.legacy_geometry_handlers import _try_rectangle_geometry, _try_square_geometry, _try_triangle_perimeter
from backend.legacy_motion_problem_handlers import _try_clock_duration_problem, _try_relative_motion_distance, _try_simple_motion
from backend.legacy_purchase_problem_handlers import _try_direct_price_problem, _try_money_purchase_flow_problem, _try_reverse_money_purchase_problem, _try_unit_price_purchase_problem
from backend.legacy_quantity_problem_handlers import _try_age_difference_problem, _try_mass_problem, _try_measure_difference_problem, _try_measured_change_problem, _try_reverse_measured_change_problem, _try_temperature_change_problem
from backend.legacy_relation_problem_handlers import _try_difference_unknown_component_problem, _try_distribution_subset_problem, _try_equal_parts_problem, _try_post_change_equal_parts_problem, _try_sum_unknown_part_problem
from backend.legacy_relation_subject_helpers import _try_times_related_subject_problem
from backend.legacy_reverse_dual_subject_handlers import _try_reverse_dual_subject_equality_after_changes_problem, _try_reverse_dual_subject_total_after_changes_problem, _try_reverse_dual_subject_total_relation_after_changes_problem
from backend.legacy_reverse_measured_dual_subject_handlers import _try_reverse_dual_subject_measured_equality_after_changes_problem, _try_reverse_dual_subject_measured_total_problem, _try_reverse_dual_subject_measured_total_relation_after_changes_problem
from backend.legacy_reverse_transfer_handlers import _try_reverse_transfer_mixed_total_problem, _try_reverse_transfer_problem, _try_reverse_transfer_relation_problem, _try_reverse_transfer_total_problem
from backend.legacy_verbal_arithmetic_problem_handlers import _try_simple_verbal_arithmetic

LEGACY_LOCAL_HANDLER_NAMES = (
    '_try_rectangle_geometry',
    '_try_square_geometry',
    '_try_triangle_perimeter',
    '_try_sum_unknown_part_problem',
    '_try_difference_unknown_component_problem',
    '_try_post_change_equal_parts_problem',
    '_try_distribution_subset_problem',
    '_try_times_related_subject_problem',
    '_try_fraction_related_subject_problem',
    '_try_fraction_comparison_problem',
    '_try_fraction_of_remainder_problem',
    '_try_fraction_remainder_of_whole_problem',
    '_try_fraction_relative_change_problem',
    '_try_fraction_then_change_problem',
    '_try_fraction_change_problem',
    '_try_equal_parts_problem',
    '_try_clock_duration_problem',
    '_try_temperature_change_problem',
    '_try_reverse_dual_subject_measured_equality_after_changes_problem',
    '_try_reverse_dual_subject_equality_after_changes_problem',
    '_try_dual_subject_measured_after_changes_problem',
    '_try_dual_subject_money_after_changes_problem',
    '_try_measure_difference_problem',
    '_try_dual_subject_total_after_changes_problem',
    '_try_dual_subject_comparison_after_changes_problem',
    '_try_ratio_after_change_problem',
    '_try_difference_after_change_problem',
    '_try_mass_problem',
    '_try_reverse_dual_subject_measured_total_relation_after_changes_problem',
    '_try_reverse_dual_subject_measured_total_problem',
    '_try_reverse_measured_change_problem',
    '_try_measured_change_problem',
    '_try_reverse_money_purchase_problem',
    '_try_money_purchase_flow_problem',
    '_try_unit_price_purchase_problem',
    '_try_age_difference_problem',
    '_try_related_quantity_then_change_total_problem',
    '_try_reverse_dual_subject_total_relation_after_changes_problem',
    '_try_reverse_dual_subject_total_after_changes_problem',
    '_try_reverse_transfer_mixed_total_problem',
    '_try_reverse_transfer_total_problem',
    '_try_reverse_transfer_relation_problem',
    '_try_reverse_transfer_problem',
    '_try_reverse_sequential_change_problem',
    '_try_sequential_change_word_problem',
    '_try_direct_price_problem',
    '_try_relative_motion_distance',
    '_try_simple_motion',
    '_try_find_initial_number_after_two_changes',
    '_try_simple_verbal_arithmetic',
    '_try_number_by_fraction',
    '_try_find_initial_number_after_change',
)

EXTERNAL_LEGACY_HANDLER_MAP: dict[str, Callable[[str], str | None]] = {
    '_try_rectangle_geometry': _try_rectangle_geometry,
    '_try_square_geometry': _try_square_geometry,
    '_try_triangle_perimeter': _try_triangle_perimeter,
    '_try_sum_unknown_part_problem': _try_sum_unknown_part_problem,
    '_try_difference_unknown_component_problem': _try_difference_unknown_component_problem,
    '_try_post_change_equal_parts_problem': _try_post_change_equal_parts_problem,
    '_try_distribution_subset_problem': _try_distribution_subset_problem,
    '_try_times_related_subject_problem': _try_times_related_subject_problem,
    '_try_fraction_related_subject_problem': _try_fraction_related_subject_problem,
    '_try_fraction_comparison_problem': _try_fraction_comparison_problem,
    '_try_fraction_of_remainder_problem': _try_fraction_of_remainder_problem,
    '_try_fraction_remainder_of_whole_problem': _try_fraction_remainder_of_whole_problem,
    '_try_fraction_relative_change_problem': _try_fraction_relative_change_problem,
    '_try_fraction_then_change_problem': _try_fraction_then_change_problem,
    '_try_fraction_change_problem': _try_fraction_change_problem,
    '_try_equal_parts_problem': _try_equal_parts_problem,
    '_try_clock_duration_problem': _try_clock_duration_problem,
    '_try_temperature_change_problem': _try_temperature_change_problem,
    '_try_reverse_dual_subject_measured_equality_after_changes_problem': _try_reverse_dual_subject_measured_equality_after_changes_problem,
    '_try_reverse_dual_subject_equality_after_changes_problem': _try_reverse_dual_subject_equality_after_changes_problem,
    '_try_dual_subject_measured_after_changes_problem': _try_dual_subject_measured_after_changes_problem,
    '_try_dual_subject_money_after_changes_problem': _try_dual_subject_money_after_changes_problem,
    '_try_measure_difference_problem': _try_measure_difference_problem,
    '_try_dual_subject_total_after_changes_problem': _try_dual_subject_total_after_changes_problem,
    '_try_dual_subject_comparison_after_changes_problem': _try_dual_subject_comparison_after_changes_problem,
    '_try_ratio_after_change_problem': _try_ratio_after_change_problem,
    '_try_difference_after_change_problem': _try_difference_after_change_problem,
    '_try_mass_problem': _try_mass_problem,
    '_try_reverse_dual_subject_measured_total_relation_after_changes_problem': _try_reverse_dual_subject_measured_total_relation_after_changes_problem,
    '_try_reverse_dual_subject_measured_total_problem': _try_reverse_dual_subject_measured_total_problem,
    '_try_reverse_measured_change_problem': _try_reverse_measured_change_problem,
    '_try_measured_change_problem': _try_measured_change_problem,
    '_try_reverse_money_purchase_problem': _try_reverse_money_purchase_problem,
    '_try_money_purchase_flow_problem': _try_money_purchase_flow_problem,
    '_try_unit_price_purchase_problem': _try_unit_price_purchase_problem,
    '_try_age_difference_problem': _try_age_difference_problem,
    '_try_related_quantity_then_change_total_problem': _try_related_quantity_then_change_total_problem,
    '_try_reverse_dual_subject_total_relation_after_changes_problem': _try_reverse_dual_subject_total_relation_after_changes_problem,
    '_try_reverse_dual_subject_total_after_changes_problem': _try_reverse_dual_subject_total_after_changes_problem,
    '_try_reverse_transfer_mixed_total_problem': _try_reverse_transfer_mixed_total_problem,
    '_try_reverse_transfer_total_problem': _try_reverse_transfer_total_problem,
    '_try_reverse_transfer_relation_problem': _try_reverse_transfer_relation_problem,
    '_try_reverse_transfer_problem': _try_reverse_transfer_problem,
    '_try_reverse_sequential_change_problem': _try_reverse_sequential_change_problem,
    '_try_sequential_change_word_problem': _try_sequential_change_word_problem,
    '_try_direct_price_problem': _try_direct_price_problem,
    '_try_relative_motion_distance': _try_relative_motion_distance,
    '_try_simple_motion': _try_simple_motion,
    '_try_find_initial_number_after_two_changes': _try_find_initial_number_after_two_changes,
    '_try_simple_verbal_arithmetic': _try_simple_verbal_arithmetic,
    '_try_number_by_fraction': _try_number_by_fraction,
    '_try_find_initial_number_after_change': _try_find_initial_number_after_change,
}

def resolve_legacy_local_handler(handler_name: str, ns: dict[str, Any] | None = None):
    handler = EXTERNAL_LEGACY_HANDLER_MAP.get(handler_name)
    if callable(handler):
        return handler
    if isinstance(ns, dict):
        candidate = ns.get(handler_name)
        if callable(candidate):
            return candidate
    return None

__all__ = ['LEGACY_LOCAL_HANDLER_NAMES', 'EXTERNAL_LEGACY_HANDLER_MAP', 'resolve_legacy_local_handler']
