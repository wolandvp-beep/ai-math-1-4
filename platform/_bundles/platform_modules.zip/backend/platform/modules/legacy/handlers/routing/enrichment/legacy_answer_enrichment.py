from __future__ import annotations

import re
from typing import Any, Tuple

from backend.legacy_count_unit_helpers import _final_detailed_maybe_enrich_answer as _count_unit_final_detailed_maybe_enrich_answer, _final_detect_question_unit as _count_unit_final_detect_question_unit, _patch_answer_with_question_noun as _count_unit_patch_answer_with_question_noun
from backend.legacy_problem_helpers import _question_text_only
from backend.legacy_cascade_runtime import get_prepatch_detailed_maybe_enrich_answer, get_prepatch_detect_question_unit, get_prepatch_extract_count_question_noun
from backend.text_utils import normalize_word_problem_text


def _final_20260412_question_lower(raw_text: str) -> str:
    return _question_text_only(raw_text).lower().replace("ё", "е").strip()


def _final_20260412_extract_price_subject(raw_text: str) -> Tuple[str, str]:
    question = _question_text_only(raw_text).strip().rstrip("?.!")
    lower = question.lower().replace("ё", "е")
    patterns = [
        (r"^сколько\s+стоит\s+(.+)$", "стоит"),
        (r"^сколько\s+стоят\s+(.+)$", "стоят"),
        (r"^сколько\s+стоила\s+(.+)$", "стоила"),
        (r"^сколько\s+стоили\s+(.+)$", "стоили"),
    ]
    for pattern, verb in patterns:
        match = re.match(pattern, lower)
        if match:
            subject = question[match.start(1):match.end(1)].strip()
            return subject, verb
    return "", ""


def apply(ns: dict[str, Any]) -> dict[str, Any]:
    extract_question_noun = ns.get('_extract_question_noun')

    def _extract_count_question_noun(raw_text: str) -> str:
        question = _final_20260412_question_lower(raw_text)
        if question.startswith("сколько стоит") or question.startswith("сколько стоят"):
            return ""
        previous_extract_count_question_noun = get_prepatch_extract_count_question_noun()
        if callable(previous_extract_count_question_noun):
            return previous_extract_count_question_noun(raw_text)
        return ""

    def _detect_question_unit(raw_text: str) -> str:
        previous_detect_question_unit = get_prepatch_detect_question_unit()
        if callable(previous_detect_question_unit):
            return _count_unit_final_detect_question_unit(
                raw_text,
                previous_detect_question_unit,
                normalize_word_problem_text,
                _question_text_only,
            )
        return ""

    def _detailed_maybe_enrich_answer(answer: str, raw_text: str, kind: str) -> str:
        previous_maybe_enrich = get_prepatch_detailed_maybe_enrich_answer()
        if callable(previous_maybe_enrich):
            return _count_unit_final_detailed_maybe_enrich_answer(
                answer,
                raw_text,
                previous_maybe_enrich,
                lambda value, text: _count_unit_patch_answer_with_question_noun(
                    value,
                    text,
                    _detect_question_unit,
                    _extract_count_question_noun,
                    extract_question_noun,
                ),
                kind,
            )
        return str(answer or '').strip()

    ns['_final_20260412_question_lower'] = _final_20260412_question_lower
    ns['_final_20260412_extract_price_subject'] = _final_20260412_extract_price_subject
    ns['_extract_count_question_noun'] = _extract_count_question_noun
    ns['_detect_question_unit'] = _detect_question_unit
    ns['_detailed_maybe_enrich_answer'] = _detailed_maybe_enrich_answer
    ns['_legacy_answer_enrichment_apply'] = apply
    return ns


__all__ = ['_final_20260412_question_lower', '_final_20260412_extract_price_subject', 'apply']
