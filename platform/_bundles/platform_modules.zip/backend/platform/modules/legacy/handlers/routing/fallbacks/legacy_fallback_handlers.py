from __future__ import annotations

from typing import Optional

from backend.legacy_bridge import expose_core
from backend.legacy_dangerous_topics import dangerous_topic_for_old_solver
from backend.legacy_safe_responses import guard_result, safe_cannot_reliably_solve_math
from backend.legacy_validated_ai import _try_validated_deepseek_fallback

def _get_core():
    return expose_core()


def _tag_result(payload: Optional[dict[str, Any]], fallback_path: str) -> Optional[dict[str, Any]]:
    if payload is None:
        return None
    tagged = dict(payload)
    tagged.setdefault('source', fallback_path)
    tagged['fallback_path'] = fallback_path
    return tagged



async def build_legacy_external_fallback_payload(user_text: str) -> Optional[dict[str, Any]]:
    core = _get_core()

    dangerous_topic = dangerous_topic_for_old_solver(user_text, core.__dict__)
    if not dangerous_topic:
        return None

    ai_result = await _try_validated_deepseek_fallback(core.__dict__, user_text)
    if ai_result:
        return _tag_result(ai_result, 'legacy-fallback:dangerous-topic-ai')

    safe_text = safe_cannot_reliably_solve_math(user_text)
    guarded = guard_result(safe_text, source='legacy-fallback:dangerous-topic-guard')
    return _tag_result(guarded, 'legacy-fallback:dangerous-topic-guard')


__all__ = [
    'build_legacy_external_fallback_payload',
]
