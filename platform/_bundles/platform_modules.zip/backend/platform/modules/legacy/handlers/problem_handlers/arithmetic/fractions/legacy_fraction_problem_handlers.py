from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_fraction_problem_handlers_source.py'

_try_fraction_related_subject_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_related_subject_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_comparison_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_comparison_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_remainder_of_whole_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_remainder_of_whole_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_of_remainder_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_of_remainder_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_relative_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_relative_change_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_then_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_then_change_problem', module_name='backend.legacy_fraction_problem_handlers')
_try_number_by_fraction = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_number_by_fraction', module_name='backend.legacy_fraction_problem_handlers')
_try_fraction_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_fraction_change_problem', module_name='backend.legacy_fraction_problem_handlers')


__all__ = ['_try_fraction_related_subject_problem', '_try_fraction_comparison_problem', '_try_fraction_remainder_of_whole_problem', '_try_fraction_of_remainder_problem', '_try_fraction_relative_change_problem', '_try_fraction_then_change_problem', '_try_number_by_fraction', '_try_fraction_change_problem']
