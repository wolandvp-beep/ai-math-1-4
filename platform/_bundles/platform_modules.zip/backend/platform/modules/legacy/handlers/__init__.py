from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

try:  # pragma: no cover - package can be imported via backend.* or backend.platform.*
    from ....compat_paths import LEGACY_INTERNAL_IMPORT_DIRS, extend_module_path
except ImportError:  # pragma: no cover - compat import path
    from backend.compat_paths import LEGACY_INTERNAL_IMPORT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, LEGACY_INTERNAL_IMPORT_DIRS)

__all__ = ['LEGACY_INTERNAL_IMPORT_DIRS']
