from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_geometry_handlers_source.py'

_try_rectangle_geometry = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_rectangle_geometry', module_name='backend.legacy_geometry_handlers')
_try_square_geometry = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_square_geometry', module_name='backend.legacy_geometry_handlers')
_try_triangle_perimeter = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_triangle_perimeter', module_name='backend.legacy_geometry_handlers')


__all__ = ['_try_rectangle_geometry', '_try_square_geometry', '_try_triangle_perimeter']
