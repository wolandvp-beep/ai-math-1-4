from __future__ import annotations

import re
from fractions import Fraction
from typing import Any, Optional

from backend.legacy_answer_label_helpers import _extract_final_state_subject, _guess_count_answer_label
from backend.legacy_dual_subject_action_helpers import _detect_dual_subject_action_index, _extract_dual_subject_transfer_action, _extract_named_subject_entries_from_text
from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_measured_dual_subject_helpers import _reverse_measured_initial_question_mode
from backend.legacy_question_flow_helpers import _question_count_label, _question_subject_order, _question_text, _subject_token_key
from backend.legacy_reverse_transfer_helpers import _append_final_total_relation_solution, _append_reverse_initial_summary, _classify_reverse_transfer_mixed_actions, _extract_known_initial_value_for_subject, _extract_reverse_transfer_relation, _extract_reverse_transfer_subject_entries, _extract_reverse_transfer_total_value, _looks_like_reverse_transfer_mixed_total_problem, _looks_like_reverse_transfer_problem, _looks_like_reverse_transfer_relation_problem, _looks_like_reverse_transfer_total_problem, _reverse_initial_question_mode, _reverse_subject_phrase, _reverse_total_through_mixed_actions, _reverse_values_through_mixed_actions
from backend.legacy_math_signals import _clean_text
from backend.legacy_school_helpers import _TRANSFER_ACTION_VERBS, _format_number
from backend.legacy_sequential_action_helpers import _extract_final_change_result_value, _extract_sequential_actions

def _try_reverse_transfer_mixed_total_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_transfer_mixed_total_problem(text):
        return None

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return None
    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None

    classified = _classify_reverse_transfer_mixed_actions(lower, actions, matches, subject_entries)
    if not classified:
        return None

    final_total = _extract_reverse_transfer_total_value(text)
    if final_total is None:
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_measured_initial_question_mode(question, subject_entries)
    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    relation = _extract_reverse_transfer_relation(text, subject_entries)
    has_total_actions = any(action['kind'] == 'total' for action in classified)

    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после всех изменений вместе стало {_format_number(final_total)}{label_suffix}.',
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
    ]

    initial_values: Optional[list[Fraction]] = None
    step_number = 1

    if relation and not has_total_actions:
        relation_solution = _append_final_total_relation_solution(lines, step_number, final_total, relation, subject_entries, answer_label)
        if not relation_solution:
            return None
        step_number, final_values = relation_solution
        reversed_solution = _reverse_values_through_mixed_actions(lines, step_number, final_values, classified, subject_entries, answer_label)
        if not reversed_solution:
            return None
        step_number, initial_values = reversed_solution
        for index, known_value in enumerate(known_initials):
            if known_value is not None and initial_values[index] != known_value:
                return None
    else:
        reversed_total_solution = _reverse_total_through_mixed_actions(lines, step_number, final_total, classified, subject_entries, answer_label)
        if not reversed_total_solution:
            return None
        step_number, initial_total = reversed_total_solution
        if question_mode == 'total' and all(value is None for value in known_initials):
            initial_values = None
            answer_text = f'{_format_number(initial_total)}{label_suffix}'
            lines.append(f'Ответ: {answer_text}')
            lines.append('Совет: если есть передачи и ещё внешние изменения, сначала иди по общей сумме назад, потому что передача сумму не меняет.')
            return _join_lines(lines)

        known_indexes = [index for index, value in enumerate(known_initials) if value is not None]
        if len(known_indexes) != 1:
            return None
        known_index = known_indexes[0]
        other_index = 1 - known_index
        known_value = known_initials[known_index]
        if known_value is None:
            return None
        other_value = initial_total - known_value
        if other_value < 0:
            return None
        lines.append(
            f'{step_number}) Перед первым изменением вместе было {_format_number(initial_total)}{label_suffix}. '
            f'{subject_entries[known_index]["phrase"].capitalize()} сначала было {_format_number(known_value)}{label_suffix}. '
            f'Значит, {subject_entries[other_index]["phrase"]} было: {_format_number(initial_total)} - {_format_number(known_value)} = {_format_number(other_value)}{label_suffix}.'
        )
        step_number += 1
        initial_values = [Fraction(0), Fraction(0)]
        initial_values[known_index] = known_value
        initial_values[other_index] = other_value

    if initial_values is None:
        return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, value in enumerate(known_initials) if value is None]
            if len(unknown_indexes) == 1:
                target_index = unknown_indexes[0]
            else:
                return None
        answer_text = _format_number(initial_values[target_index])
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после передачи есть ещё одно изменение, иди назад от конца: сначала отменяй внешние изменения, а передачу используй только после этого.')
    return _join_lines(lines)


def _try_reverse_transfer_total_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_transfer_total_problem(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    total_value = _extract_reverse_transfer_total_value(text)
    if total_value is None:
        return None

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после передач вместе стало {_format_number(total_value)}{label_suffix}.',
        _ensure_sentence(f'Что нужно найти: {question.rstrip("?.!")}'),
    ]

    if question_mode == 'total':
        lines.append(
            f'1) Передача между двумя объектами не меняет общее количество. Значит, сначала вместе было столько же: {_format_number(total_value)}{label_suffix}.'
        )
        lines.append(f'Ответ: {_format_number(total_value)}{label_suffix}')
        lines.append('Совет: если один ребёнок или одна коробка только передаёт другому, общее количество не меняется.')
        return _join_lines(lines)

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return None
    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        return None

    transfers: list[dict[str, Any]] = []
    for action, match in zip(actions, matches):
        transfer = _extract_dual_subject_transfer_action(lower, match, subject_entries, action['value'])
        if not transfer:
            return None
        transfers.append(transfer)

    prefix_lower = lower[:matches[0].start()] if matches else lower
    known_initials = [_extract_known_initial_value_for_subject(prefix_lower, entry) for entry in subject_entries[:2]]
    relation = _extract_reverse_transfer_relation(text, subject_entries)
    initial_values: Optional[list[Fraction]] = None
    step_number = 1

    if relation:
        if relation['kind'] == 'difference':
            difference_value = relation['value']
            equal_part = total_value - difference_value
            if equal_part < 0:
                return None
            left_phrase = _reverse_subject_phrase(subject_entries[relation['left_index']])
            right_phrase = _reverse_subject_phrase(subject_entries[relation['right_index']])
            if relation['word'] == 'больше':
                smaller_index = relation['right_index']
                bigger_index = relation['left_index']
            else:
                smaller_index = relation['left_index']
                bigger_index = relation['right_index']
            smaller_phrase = _reverse_subject_phrase(subject_entries[smaller_index])
            bigger_phrase = _reverse_subject_phrase(subject_entries[bigger_index])
            lines.append(
                f'{step_number}) После передач вместе стало {_format_number(total_value)}{label_suffix}, а разница между количествами равна {_format_number(difference_value)}{label_suffix}. '
                f'Уберём разницу: {_format_number(total_value)} - {_format_number(difference_value)} = {_format_number(equal_part)}{label_suffix}. '
                f'Теперь осталось две равные части.'
            )
            step_number += 1
            smaller_final = equal_part / 2
            bigger_final = smaller_final + difference_value
            lines.append(
                f'{step_number}) Находим меньшее конечное количество: {_format_number(equal_part)} : 2 = {_format_number(smaller_final)}{label_suffix}. '
                f'Значит, {smaller_phrase} стало {_format_number(smaller_final)}{label_suffix}, '
                f'а {bigger_phrase} — {_format_number(smaller_final)} + {_format_number(difference_value)} = {_format_number(bigger_final)}{label_suffix}.'
            )
            final_values = [Fraction(0), Fraction(0)]
            final_values[smaller_index] = smaller_final
            final_values[bigger_index] = bigger_final
            step_number += 1
        else:
            if relation['value'] <= 0:
                return None
            part_count = relation['value'] + 1
            small_value = total_value / part_count
            big_value = total_value - small_value
            if relation['word'] == 'больше':
                smaller_index = relation['right_index']
                bigger_index = relation['left_index']
            else:
                smaller_index = relation['left_index']
                bigger_index = relation['right_index']
            smaller_phrase = _reverse_subject_phrase(subject_entries[smaller_index])
            bigger_phrase = _reverse_subject_phrase(subject_entries[bigger_index])
            lines.append(
                f'{step_number}) После передач вместе стало {_format_number(total_value)}{label_suffix}. Если одно количество в {_format_number(relation["value"])} раза больше другого, '
                f'то всё вместе — это {_format_number(part_count)} равные части.'
            )
            step_number += 1
            lines.append(
                f'{step_number}) Находим одну часть: {_format_number(total_value)} : {_format_number(part_count)} = {_format_number(small_value)}{label_suffix}. '
                f'Значит, {smaller_phrase} стало {_format_number(small_value)}{label_suffix}, '
                f'а {bigger_phrase} — {_format_number(big_value)}{label_suffix}.'
            )
            final_values = [Fraction(0), Fraction(0)]
            final_values[smaller_index] = small_value
            final_values[bigger_index] = big_value
            step_number += 1

        current_values = final_values[:]
        for transfer in reversed(transfers):
            source_index = transfer['source_index']
            target_index = transfer['target_index']
            previous_source = current_values[source_index] + transfer['value']
            previous_target = current_values[target_index] - transfer['value']
            if previous_target < 0 or previous_source < 0:
                return None
            lines.append(
                f'{step_number}) Идём назад через передачу и восстанавливаем начальные количества: '
                f'{subject_entries[source_index]["label"]}: {_format_number(current_values[source_index])} + {_format_number(transfer["value"])} = {_format_number(previous_source)}{label_suffix}, '
                f'{subject_entries[target_index]["label"]}: {_format_number(current_values[target_index])} - {_format_number(transfer["value"])} = {_format_number(previous_target)}{label_suffix}.'
            )
            current_values[source_index] = previous_source
            current_values[target_index] = previous_target
            step_number += 1
        initial_values = current_values

        for index, known_value in enumerate(known_initials):
            if known_value is not None and initial_values[index] != known_value:
                return None
    else:
        known_indexes = [index for index, value in enumerate(known_initials) if value is not None]
        if len(known_indexes) != 1:
            return None
        known_index = known_indexes[0]
        other_index = 1 - known_index
        known_value = known_initials[known_index]
        if known_value is None:
            return None
        other_value = total_value - known_value
        if other_value < 0:
            return None
        lines.append(
            f'{step_number}) Передачи между двумя объектами не меняют общее количество. Значит, сначала вместе тоже было {_format_number(total_value)}{label_suffix}.'
        )
        step_number += 1
        lines.append(
            f'{step_number}) {subject_entries[known_index]["phrase"].capitalize()} сначала было {_format_number(known_value)}{label_suffix}. '
            f'Тогда {subject_entries[other_index]["phrase"]} было: {_format_number(total_value)} - {_format_number(known_value)} = {_format_number(other_value)}{label_suffix}.'
        )
        initial_values = [Fraction(0), Fraction(0)]
        initial_values[known_index] = known_value
        initial_values[other_index] = other_value
        step_number += 1

    if initial_values is None:
        return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, value in enumerate(known_initials) if value is None]
            if len(unknown_indexes) == 1:
                target_index = unknown_indexes[0]
            else:
                return None
        answer_text = _format_number(initial_values[target_index])
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после передачи известно, сколько стало вместе, сначала используй то, что общее количество не изменилось, а потом восстанавливай нужные начальные количества.')
    return _join_lines(lines)


def _try_reverse_transfer_relation_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_transfer_relation_problem(text):
        return None

    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return None
    if not all(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return None

    subject_entries = _extract_reverse_transfer_subject_entries(lower)
    if len(subject_entries) < 2:
        return None
    relation = _extract_reverse_transfer_relation(text, subject_entries)
    if not relation:
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    known_initials = [_extract_known_initial_value_for_subject(lower, entry) for entry in subject_entries[:2]]
    unknown_indexes = [index for index, value in enumerate(known_initials) if value is None]

    if question_mode == 'target':
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
            other_index = 1 - target_index
        elif len(unknown_indexes) == 1:
            target_index = unknown_indexes[0]
            other_index = 1 - target_index
        else:
            return None
    else:
        if len(unknown_indexes) != 1:
            return None
        target_index = unknown_indexes[0]
        other_index = 1 - target_index

    other_initial = known_initials[other_index]
    if other_initial is None:
        return None

    transfers: list[dict[str, Any]] = []
    for action, match in zip(actions, matches):
        transfer = _extract_dual_subject_transfer_action(lower, match, subject_entries, action['value'])
        if not transfer:
            return None
        transfers.append(transfer)

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    label_suffix = f' {answer_label}' if answer_label else ''
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        _ensure_sentence(
            f'Что известно: у одного объекта начальное количество неизвестно, а {subject_entries[other_index]["phrase"]} сначала было {_format_number(other_initial)}{label_suffix}'
        ),
        _ensure_sentence(f'Что нужно найти: {question.rstrip("?.!")}'),
    ]

    step_number = 1
    other_current = other_initial
    for transfer in transfers:
        before_value = other_current
        if transfer['source_index'] == other_index:
            other_current = other_current - transfer['value']
            operation = '-'
        elif transfer['target_index'] == other_index:
            other_current = other_current + transfer['value']
            operation = '+'
        else:
            continue
        if other_current < 0:
            return None
        lines.append(
            f'{step_number}) Сначала найдём, сколько стало {subject_entries[other_index]["phrase"]}: '
            f'{_format_number(before_value)} {operation} {_format_number(transfer["value"])} = {_format_number(other_current)}{label_suffix}. '
            f'Значит, {subject_entries[other_index]["phrase"]} после этой передачи значение изменилось до {_format_number(other_current)}{label_suffix}.'
        )
        step_number += 1

    other_final = other_current
    rel_value = relation['value']
    relation_word = relation['word']
    if relation['kind'] == 'difference':
        if relation['left_index'] == target_index:
            if relation_word == 'больше':
                target_final = other_final + rel_value
                relation_expr = f'{_format_number(other_final)} + {_format_number(rel_value)}'
            else:
                target_final = other_final - rel_value
                relation_expr = f'{_format_number(other_final)} - {_format_number(rel_value)}'
        else:
            if relation_word == 'больше':
                target_final = other_final - rel_value
                relation_expr = f'{_format_number(other_final)} - {_format_number(rel_value)}'
            else:
                target_final = other_final + rel_value
                relation_expr = f'{_format_number(other_final)} + {_format_number(rel_value)}'
        if relation['left_index'] == target_index:
            target_relation_word = relation_word
        else:
            target_relation_word = 'меньше' if relation_word == 'больше' else 'больше'
        relation_hint = f'на {_format_number(rel_value)}{label_suffix} {target_relation_word}'
    else:
        if rel_value == 0:
            return None
        if relation['left_index'] == target_index:
            if relation_word == 'больше':
                target_final = other_final * rel_value
                relation_expr = f'{_format_number(other_final)} × {_format_number(rel_value)}'
            else:
                target_final = other_final / rel_value
                relation_expr = f'{_format_number(other_final)} : {_format_number(rel_value)}'
        else:
            if relation_word == 'больше':
                target_final = other_final / rel_value
                relation_expr = f'{_format_number(other_final)} : {_format_number(rel_value)}'
            else:
                target_final = other_final * rel_value
                relation_expr = f'{_format_number(other_final)} × {_format_number(rel_value)}'
        if relation['left_index'] == target_index:
            target_relation_word = relation_word
        else:
            target_relation_word = 'меньше' if relation_word == 'больше' else 'больше'
        relation_hint = f'в {_format_number(rel_value)} раза {target_relation_word}'
    if target_final < 0:
        return None

    lines.append(
        f'{step_number}) По условию после передач {subject_entries[target_index]["phrase"]} стало {relation_hint}, чем {subject_entries[other_index]["phrase"]}. '
        f'Значит, в конце {subject_entries[target_index]["phrase"]} было: {relation_expr} = {_format_number(target_final)}{label_suffix}.'
    )
    step_number += 1

    target_current = target_final
    for transfer in reversed(transfers):
        if transfer['target_index'] == target_index:
            previous_value = target_current - transfer['value']
            operation = '-'
            comment = 'отменяем то, что прибавилось'
        elif transfer['source_index'] == target_index:
            previous_value = target_current + transfer['value']
            operation = '+'
            comment = 'отменяем то, что убавилось'
        else:
            continue
        if previous_value < 0:
            return None
        lines.append(
            f'{step_number}) Идём назад и восстанавливаем, что было {subject_entries[target_index]["phrase"]}: {comment}, '
            f'{_format_number(target_current)} {operation} {_format_number(transfer["value"])} = {_format_number(previous_value)}{label_suffix}.'
        )
        target_current = previous_value
        step_number += 1

    initial_values = [Fraction(0), Fraction(0)]
    initial_values[target_index] = target_current
    initial_values[other_index] = other_initial
    step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        answer_text = _format_number(target_current)
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer
    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если одно начальное количество неизвестно, сначала найди конечное количество у второго объекта, потом восстанови конечное количество у первого и только после этого переходи к сумме или сравнению сначала.')
    return _join_lines(lines)


def _try_reverse_transfer_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    lower = text.lower().replace('ё', 'е')
    if not _looks_like_reverse_transfer_problem(text):
        return None

    question = _question_text(text).lower().replace('ё', 'е')
    question_mode = _reverse_initial_question_mode(question)
    actions, matches = _extract_sequential_actions(lower)
    if not actions or not matches:
        return None
    if not any(match.group(1).lower().replace('ё', 'е') in _TRANSFER_ACTION_VERBS for match in matches):
        return None

    final_value = _extract_final_change_result_value(text)
    if final_value is None:
        return None

    final_subject = _extract_final_state_subject(text)
    target_name_match = re.search(r'у\s+([а-яёa-z-]+)', question)
    if question_mode == 'target' and target_name_match:
        target_name = target_name_match.group(1).lower().replace('ё', 'е')
        target_key = _subject_token_key(target_name)
        target_label = target_name.capitalize()
        if final_subject and final_subject['key'] != target_key:
            return None
    else:
        if not final_subject:
            return None
        target_key = final_subject['key']
        target_label = final_subject['label']
    if not target_key or target_key in {'first', 'second'}:
        return None

    subject_entries = _extract_named_subject_entries_from_text(lower)
    if len(subject_entries) < 2:
        return None
    if all(target_key not in entry['keys'] for entry in subject_entries):
        subject_entries.insert(0, {'keys': {target_key}, 'label': target_label})
    deduped_entries: list[dict[str, Any]] = []
    seen_keys: set[str] = set()
    for entry in subject_entries:
        key = next(iter(entry['keys']), '')
        if key and key not in seen_keys:
            deduped_entries.append(entry)
            seen_keys.add(key)
        if len(deduped_entries) >= 2:
            break
    subject_entries = deduped_entries
    target_index = next((index for index, entry in enumerate(subject_entries) if target_key in entry['keys']), None)
    if target_index is None:
        return None

    answer_label = _question_count_label(text) or _guess_count_answer_label(text)
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после всех изменений у {target_label} стало {_format_number(final_value)}{(" " + answer_label) if answer_label else ""}.',
        f'Что нужно найти: {question.rstrip("?.!")}.'
    ]

    current_value = final_value
    step_number = 1
    applied_steps = 0
    for action, match in reversed(list(zip(actions, matches))):
        verb = match.group(1).lower().replace('ё', 'е')
        if verb in _TRANSFER_ACTION_VERBS and len(subject_entries) >= 2:
            transfer = _extract_dual_subject_transfer_action(lower, match, subject_entries, action['value'])
            if transfer:
                if transfer['target_index'] == target_index:
                    previous_value = current_value - action['value']
                    if previous_value < 0:
                        return None
                    lines.append(
                        f'{step_number}) Отменяем то, что у {target_label} прибавилось: '
                        f'{_format_number(current_value)} - {_format_number(action["value"])} = {_format_number(previous_value)}.'
                    )
                    current_value = previous_value
                    step_number += 1
                    applied_steps += 1
                    continue
                if transfer['source_index'] == target_index:
                    previous_value = current_value + action['value']
                    lines.append(
                        f'{step_number}) Отменяем то, что у {target_label} убавилось: '
                        f'{_format_number(current_value)} + {_format_number(action["value"])} = {_format_number(previous_value)}.'
                    )
                    current_value = previous_value
                    step_number += 1
                    applied_steps += 1
                    continue

        if len(subject_entries) >= 2:
            affected_index = _detect_dual_subject_action_index(lower, match, subject_entries)
        else:
            affected_index = 0
        if affected_index != target_index:
            continue
        if action['sign'] > 0:
            previous_value = current_value - action['value']
            if previous_value < 0:
                return None
            lines.append(
                f'{step_number}) Отменяем прибавление у {target_label}: '
                f'{_format_number(current_value)} - {_format_number(action["value"])} = {_format_number(previous_value)}.'
            )
        else:
            previous_value = current_value + action['value']
            lines.append(
                f'{step_number}) Отменяем уменьшение у {target_label}: '
                f'{_format_number(current_value)} + {_format_number(action["value"])} = {_format_number(previous_value)}.'
            )
        current_value = previous_value
        step_number += 1
        applied_steps += 1

    if applied_steps == 0:
        return None

    summary_answer: Optional[str] = None
    if question_mode != 'target' and len(subject_entries) >= 2:
        other_index = 1 - target_index
        other_initial = _extract_known_initial_value_for_subject(lower, subject_entries[other_index])
        if other_initial is None:
            return None
        initial_values = [Fraction(0), Fraction(0)]
        initial_values[target_index] = current_value
        initial_values[other_index] = other_initial
        step_number, summary_answer = _append_reverse_initial_summary(lines, step_number, question, subject_entries, initial_values, answer_label)

    if summary_answer is None:
        answer_text = _format_number(current_value)
        if answer_label:
            answer_text += f' {answer_label}'
    else:
        answer_text = summary_answer
    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если нужно узнать, сколько было сначала после передачи, иди от конца назад; когда найдёшь начальные количества, только потом переходи к сумме или сравнению сначала.')
    return _join_lines(lines)


__all__ = [
    '_try_reverse_transfer_mixed_total_problem',
    '_try_reverse_transfer_total_problem',
    '_try_reverse_transfer_relation_problem',
    '_try_reverse_transfer_problem',
]
