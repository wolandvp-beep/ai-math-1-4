from __future__ import annotations

from fractions import Fraction
from typing import Optional

from backend.legacy_formatting_helpers import _ensure_sentence, _join_lines
from backend.legacy_math_signals import _clean_text, _normalize_space
from backend.legacy_measured_dual_subject_helpers import _append_reverse_measured_initial_summary, _classify_measured_mixed_actions, _extract_dual_measure_subject_infos, _extract_measured_relation, _extract_measured_total_quantity, _looks_like_reverse_dual_subject_measured_equality_after_changes_problem, _looks_like_reverse_dual_subject_measured_total_problem, _looks_like_reverse_dual_subject_measured_total_relation_after_changes_problem, _reverse_measured_initial_question_mode, _reverse_measured_values_through_actions
from backend.legacy_measure_helpers import _choose_measure_base_unit, _extract_compound_quantities, _format_measure_total, _quantity_value_in_unit
from backend.legacy_question_flow_helpers import _question_subject_order, _question_text
from backend.legacy_reverse_dual_subject_handlers import _school_context_requires_whole_values
from backend.legacy_reverse_transfer_helpers import _append_final_total_relation_solution, _forward_known_subject_value_through_actions, _reverse_subject_phrase, _reverse_total_through_mixed_actions
from backend.legacy_school_helpers import _ACTION_VERB_RE, _MEASURE_GROUP_SCALES, _format_number

def _try_reverse_dual_subject_measured_equality_after_changes_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    if not _looks_like_reverse_dual_subject_measured_equality_after_changes_problem(text):
        return None

    lower = text.lower().replace('ё', 'е')
    question = _question_text(text).lower().replace('ё', 'е')
    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return None
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return None
    infos = infos[:2]
    subject_entries = [info['entry'] for info in infos]
    question_mode = _reverse_measured_initial_question_mode(question, subject_entries)
    known_indexes = [index for index, info in enumerate(infos) if info.get('quantity') is not None]
    if len(known_indexes) != 1:
        return None
    known_index = known_indexes[0]
    unknown_index = 1 - known_index
    known_quantity = infos[known_index]['quantity']
    if not known_quantity:
        return None
    group = known_quantity['group']
    all_quantities = [quantity for quantity in _extract_compound_quantities(text) if quantity['group'] == group]
    visible_units: list[str] = []
    for quantity in all_quantities:
        visible_units.extend(quantity['units'])
    base_unit = _choose_measure_base_unit(group, all_quantities or [known_quantity])

    relation = _extract_measured_relation(text, subject_entries, group, base_unit)
    if not relation or not relation.get('equal'):
        return None
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, {'start': len(text)})
    if not classified or any(action['kind'] == 'total' for action in classified):
        return None

    known_initial_value = _quantity_value_in_unit(known_quantity, base_unit)
    known_phrase = _normalize_space(str(subject_entries[known_index].get('label') or _reverse_subject_phrase(subject_entries[known_index])))
    unknown_phrase = _normalize_space(str(subject_entries[unknown_index].get('label') or _reverse_subject_phrase(subject_entries[unknown_index])))

    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        _ensure_sentence(f'Что известно: сначала {known_phrase.lower()} было {known_quantity["pretty"]}, а после всех изменений величины стали поровну'),
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
        f'1) Переводим известную начальную величину в {base_unit}: {known_quantity["pretty"]} = {_format_number(known_initial_value)} {base_unit}.',
    ]
    step_number = 2

    forward = _forward_known_subject_value_through_actions(known_initial_value, known_index, classified)
    if not forward:
        return None
    known_final_value, applied_steps = forward

    if applied_steps:
        for step in applied_steps:
            action = step['action']
            before_value = step['before']
            after_value = step['after']
            if step['kind'] == 'subject':
                operation = '+' if action['sign'] > 0 else '-'
                lines.append(
                    f'{step_number}) Изменяем {known_phrase.lower()}: '
                    f'{_format_number(before_value)} {operation} {_format_number(action["value"])} = {_format_number(after_value)} {base_unit}.'
                )
            else:
                operation = '-' if action['source_index'] == known_index else '+'
                lines.append(
                    f'{step_number}) Учитываем передачу для {known_phrase.lower()}: '
                    f'{_format_number(before_value)} {operation} {_format_number(action["value"])} = {_format_number(after_value)} {base_unit}.'
                )
            step_number += 1
    else:
        lines.append(f'{step_number}) Изменения не касаются {known_phrase.lower()}, поэтому после всех действий там осталось {_format_number(known_final_value)} {base_unit}.')
        step_number += 1

    equal_text = _format_measure_total(known_final_value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    lines.append(
        f'{step_number}) После всех изменений величины стали поровну. Значит, {unknown_phrase.lower()} стало столько же: {_format_number(known_final_value)} {base_unit} = {equal_text}.'
    )
    step_number += 1

    final_values = [Fraction(0), Fraction(0)]
    final_values[known_index] = known_final_value
    final_values[unknown_index] = known_final_value
    reversed_solution = _reverse_measured_values_through_actions(lines, step_number, final_values, classified, subject_entries, base_unit)
    if not reversed_solution:
        return None
    step_number, initial_values = reversed_solution

    if initial_values[known_index] != known_initial_value:
        return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_measured_initial_summary(lines, step_number, question, subject_entries, initial_values, group, base_unit, visible_units)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            target_index = unknown_index
        answer_text = _format_measure_total(initial_values[target_index] * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после изменений две величины стали равны, сначала найди конечную величину у известного объекта, приравняй к ней вторую и только потом восстанавливай начало назад.')
    return _join_lines(lines)


def _try_reverse_dual_subject_measured_total_relation_after_changes_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    if not _looks_like_reverse_dual_subject_measured_total_relation_after_changes_problem(text):
        return None

    lower = text.lower().replace('ё', 'е')
    question = _question_text(text).lower().replace('ё', 'е')
    final_total = _extract_measured_total_quantity(text)
    if not final_total:
        return None
    group = final_total['group']

    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return None
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return None
    subject_entries = [info['entry'] for info in infos]
    question_mode = _reverse_measured_initial_question_mode(question, subject_entries)
    visible_units: list[str] = []
    for quantity in _extract_compound_quantities(text):
        if quantity['group'] == group:
            visible_units.extend(quantity['units'])
    base_unit = _choose_measure_base_unit(group, [final_total] + [info['quantity'] for info in infos if info['quantity'] is not None])
    relation = _extract_measured_relation(text, subject_entries, group, base_unit)
    if not relation:
        return None
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, final_total)
    if not classified or any(action['kind'] == 'total' for action in classified):
        return None

    final_total_value = _quantity_value_in_unit(final_total, base_unit)
    relation_sentence = (
        f'Что известно: после всех изменений вместе стало {final_total["pretty"]}, и ещё известно, что величины стали поровну.'
        if relation.get('equal')
        else f'Что известно: после всех изменений вместе стало {final_total["pretty"]}, и ещё известна итоговая связь между двумя величинами.'
    )
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        relation_sentence,
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
        f'1) Переводим общую конечную величину в {base_unit}: {final_total["pretty"]} = {_format_number(final_total_value)} {base_unit}.',
    ]
    step_number = 2
    if relation['kind'] == 'difference' and not relation.get('equal') and relation['value'] != 0:
        relation_pretty = str(relation.get('pretty') or '').strip() or _format_measure_total(relation['value'] * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
        lines.append(f'{step_number}) Переводим итоговую разницу в {base_unit}: {relation_pretty} = {_format_number(relation["value"])} {base_unit}.')
        step_number += 1

    relation_solution = _append_final_total_relation_solution(lines, step_number, final_total_value, relation, subject_entries, base_unit)
    if not relation_solution:
        return None
    step_number, final_values = relation_solution

    reversed_solution = _reverse_measured_values_through_actions(lines, step_number, final_values, classified, subject_entries, base_unit)
    if not reversed_solution:
        return None
    step_number, initial_values = reversed_solution

    for index, info in enumerate(infos[:2]):
        quantity = info.get('quantity')
        if quantity is None:
            continue
        known_value = _quantity_value_in_unit(quantity, base_unit)
        if initial_values[index] != known_value:
            return None

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_measured_initial_summary(lines, step_number, question, subject_entries, initial_values, group, base_unit, visible_units)

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, info in enumerate(infos[:2]) if info.get('quantity') is None]
            if len(unknown_indexes) == 1:
                target_index = unknown_indexes[0]
            else:
                return None
        answer_text = _format_measure_total(initial_values[target_index] * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
    else:
        answer_text = summary_answer

    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: если после изменений известны и общая величина, и итоговое сравнение, сначала найди конечные величины, а потом отменяй изменения в обратном порядке.')
    return _join_lines(lines)


def _try_reverse_dual_subject_measured_total_problem(raw_text: str) -> Optional[str]:
    text = _clean_text(raw_text)
    if not _looks_like_reverse_dual_subject_measured_total_problem(text):
        return None

    lower = text.lower().replace('ё', 'е')
    question = _question_text(text).lower().replace('ё', 'е')
    final_total = _extract_measured_total_quantity(text)
    if not final_total:
        return None
    group = final_total['group']

    matches = list(_ACTION_VERB_RE.finditer(lower))
    if not matches:
        return None
    prefix_text = text[:matches[0].start()]
    infos = _extract_dual_measure_subject_infos(prefix_text)
    if len(infos) < 2:
        return None
    subject_entries = [info['entry'] for info in infos]
    question_mode = _reverse_measured_initial_question_mode(question, subject_entries)
    visible_units: list[str] = []
    all_quantities = _extract_compound_quantities(text)
    for quantity in all_quantities:
        if quantity['group'] == group:
            visible_units.extend(quantity['units'])
    base_unit = _choose_measure_base_unit(group, [final_total] + [info['quantity'] for info in infos if info['quantity'] is not None])
    classified = _classify_measured_mixed_actions(text, subject_entries, group, base_unit, final_total)
    if not classified:
        return None

    final_total_value = _quantity_value_in_unit(final_total, base_unit)
    lines = [
        'Задача.',
        _ensure_sentence(text),
        'Решение.',
        f'Что известно: после всех изменений вместе стало {final_total["pretty"]}.',
        _ensure_sentence(f'Что нужно найти: {(question or "сколько было сначала").rstrip("?.!")}'),
        f'1) Переводим общую конечную величину в {base_unit}: {final_total["pretty"]} = {_format_number(final_total_value)} {base_unit}.',
    ]
    step_number = 2
    reversed_total_solution = _reverse_total_through_mixed_actions(lines, step_number, final_total_value, classified, subject_entries, base_unit)
    if not reversed_total_solution:
        return None
    step_number, initial_total_value = reversed_total_solution

    if question_mode == 'total' and all(info['quantity'] is None for info in infos):
        initial_total_text = _format_measure_total(initial_total_value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
        lines.append(f'{step_number}) Записываем начальную общую величину в удобных единицах: {_format_number(initial_total_value)} {base_unit} = {initial_total_text}.')
        lines.append(f'Ответ: {initial_total_text}')
        lines.append('Совет: если у двух величин известен общий итог после изменений, сначала восстанавливай общий итог назад, потому что передача между ними общую величину не меняет.')
        return _join_lines(lines)

    known_indexes = [index for index, info in enumerate(infos) if info['quantity'] is not None]
    if len(known_indexes) != 1:
        return None
    known_index = known_indexes[0]
    other_index = 1 - known_index
    known_quantity = infos[known_index]['quantity']
    if known_quantity is None:
        return None
    known_value = _quantity_value_in_unit(known_quantity, base_unit)
    other_value = initial_total_value - known_value
    if other_value < 0:
        return None

    lines.append(f'{step_number}) Переводим известную начальную величину в {base_unit}: {known_quantity["pretty"]} = {_format_number(known_value)} {base_unit}.')
    step_number += 1
    lines.append(
        f'{step_number}) Находим неизвестную начальную величину: '
        f'{_format_number(initial_total_value)} - {_format_number(known_value)} = {_format_number(other_value)} {base_unit}.'
    )
    step_number += 1

    initial_values = [Fraction(0), Fraction(0)]
    initial_values[known_index] = known_value
    initial_values[other_index] = other_value

    summary_answer: Optional[str] = None
    if question_mode != 'target':
        step_number, summary_answer = _append_reverse_measured_initial_summary(
            lines,
            step_number,
            question,
            subject_entries,
            initial_values,
            group,
            base_unit,
            visible_units,
        )

    if summary_answer is None:
        order = _question_subject_order(question, subject_entries)
        if order:
            target_index = order[0]
        else:
            unknown_indexes = [index for index, info in enumerate(infos) if info['quantity'] is None]
            if len(unknown_indexes) != 1:
                return None
            target_index = unknown_indexes[0]
        target_value = initial_values[target_index]
        target_text = _format_measure_total(target_value * _MEASURE_GROUP_SCALES[group][base_unit], group, visible_units)
        subject_phrase = _reverse_subject_phrase(subject_entries[target_index])
        lines.append(
            f'{step_number}) Записываем начальную величину {subject_phrase} в удобных единицах: '
            f'{_format_number(target_value)} {base_unit} = {target_text}.'
        )
        answer_text = target_text
    else:
        answer_text = summary_answer
    lines.append(f'Ответ: {answer_text}')
    lines.append('Совет: в задачах с двумя величинами и разными единицами сначала переводи общий итог и изменения в одну единицу, а потом восстанавливай начало назад.')
    return _join_lines(lines)


__all__ = [
    '_try_reverse_dual_subject_measured_equality_after_changes_problem',
    '_try_reverse_dual_subject_measured_total_relation_after_changes_problem',
    '_try_reverse_dual_subject_measured_total_problem',
]
