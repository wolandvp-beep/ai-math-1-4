from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_motion_problem_handlers_source.py'

_try_clock_duration_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_clock_duration_problem', module_name='backend.legacy_motion_problem_handlers')
_try_relative_motion_distance = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_relative_motion_distance', module_name='backend.legacy_motion_problem_handlers')
_try_simple_motion = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_simple_motion', module_name='backend.legacy_motion_problem_handlers')


__all__ = ['_try_clock_duration_problem', '_try_relative_motion_distance', '_try_simple_motion']
