from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_quantity_problem_handlers_source.py'

_try_age_difference_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_age_difference_problem', module_name='backend.legacy_quantity_problem_handlers')
_try_mass_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_mass_problem', module_name='backend.legacy_quantity_problem_handlers')
_try_reverse_measured_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_reverse_measured_change_problem', module_name='backend.legacy_quantity_problem_handlers')
_try_measured_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_measured_change_problem', module_name='backend.legacy_quantity_problem_handlers')
_try_temperature_change_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_temperature_change_problem', module_name='backend.legacy_quantity_problem_handlers')
_try_measure_difference_problem = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_measure_difference_problem', module_name='backend.legacy_quantity_problem_handlers')


__all__ = ['_try_age_difference_problem', '_try_mass_problem', '_try_reverse_measured_change_problem', '_try_measured_change_problem', '_try_temperature_change_problem', '_try_measure_difference_problem']
