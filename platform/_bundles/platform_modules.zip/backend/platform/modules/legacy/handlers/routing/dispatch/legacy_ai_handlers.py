from __future__ import annotations

from typing import Optional

from backend.legacy_bridge import expose_core
from backend.legacy_explanatory_ai import _looks_like_explanatory_math_question, _try_structured_deepseek_explanation
from backend.legacy_math_signals import _looks_like_math_input
from backend.legacy_validated_ai import _try_validated_deepseek_fallback
from backend.legacy_safe_responses import guard_result, safe_cannot_reliably_explain_math, safe_cannot_reliably_solve_math



def _get_core():
    return expose_core()


def _tag_result(payload: Optional[dict[str, Any]], fallback_path: str) -> Optional[dict[str, Any]]:
    if payload is None:
        return None
    tagged = dict(payload)
    tagged.setdefault('source', fallback_path)
    tagged['fallback_path'] = fallback_path
    return tagged



async def build_legacy_explanatory_math_payload(user_text: str) -> Optional[dict[str, Any]]:
    core = _get_core()
    if not _looks_like_explanatory_math_question(user_text, _looks_like_math_input):
        return None

    explained = await _try_structured_deepseek_explanation(core.__dict__, user_text, looks_like_math_input_fn=_looks_like_math_input)
    if explained:
        return _tag_result(explained, 'legacy-ai:structured-explanation')

    guarded = guard_result(
        safe_cannot_reliably_explain_math(user_text),
        source='legacy-ai:structured-explanation-guard',
    )
    return _tag_result(guarded, 'legacy-ai:structured-explanation-guard')


async def build_legacy_generic_math_payload(user_text: str) -> Optional[dict[str, Any]]:
    core = _get_core()
    if not _looks_like_math_input(user_text):
        return None

    ai_result = await _try_validated_deepseek_fallback(core.__dict__, user_text)
    if ai_result:
        return _tag_result(ai_result, 'legacy-ai:validated-math')

    guarded = guard_result(
        safe_cannot_reliably_solve_math(user_text),
        source='legacy-ai:validated-math-guard',
    )
    return _tag_result(guarded, 'legacy-ai:validated-math-guard')


__all__ = [
    'build_legacy_explanatory_math_payload',
    'build_legacy_generic_math_payload',
]
