from __future__ import annotations

from backend.handler_proxy_factory import build_raw_text_handler_proxy


_SOURCE_NAME = 'legacy_verbal_arithmetic_problem_handlers_source.py'

_try_simple_verbal_arithmetic = build_raw_text_handler_proxy(_SOURCE_NAME, '_try_simple_verbal_arithmetic', module_name='backend.legacy_verbal_arithmetic_problem_handlers')


__all__ = ['_try_simple_verbal_arithmetic']
