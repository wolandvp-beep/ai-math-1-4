from __future__ import annotations

from backend.guards import division_by_zero_payload, is_direct_division_by_zero
from backend.handlers.change_word_problems import build_change_word_problem_payload
from backend.handlers.fraction_word_problems import build_fraction_word_problem_payload
from backend.handlers.geometry_word_problems import build_geometry_word_problem_payload
from backend.handlers.motion_word_problems import build_motion_word_problem_payload
from backend.handlers.purchase_word_problems import build_purchase_word_problem_payload
from backend.handlers.quantity_word_problems import build_quantity_word_problem_payload
from backend.handlers.relation_word_problems import build_relation_word_problem_payload
from backend.handlers.dual_subject_word_problems import build_dual_subject_word_problem_payload
from backend.handlers.verbal_arithmetic_word_problems import build_verbal_arithmetic_word_problem_payload
from backend.legacy_bridge import build_legacy_explanation, format_local_solution
from backend.legacy_ai_handlers import build_legacy_explanatory_math_payload
from backend.legacy_fallback_handlers import build_legacy_external_fallback_payload
from backend.math_expression_engine import build_direct_math_expression_payload
from backend.patch_registry import resolve_local_explanation
from backend.platform.request_shape_guards import (
    build_compare_expression_payload,
    build_multi_task_payload,
    build_multiline_arithmetic_payload,
    canonicalize_system_submission,
    is_multi_task_submission,
)


async def dispatch_explanation(user_text: str) -> dict:
    if is_direct_division_by_zero(user_text):
        return division_by_zero_payload()

    compare_expression_payload = build_compare_expression_payload(user_text)
    if compare_expression_payload:
        return compare_expression_payload

    canonical_system_text = canonicalize_system_submission(user_text)
    if canonical_system_text:
        # Сначала пробуем локальный школьный обработчик. Он умеет решать
        # системы вида x + y = S; x - y = D, включая отрицательную разность.
        local_explanation, handler_name, preformatted = resolve_local_explanation(user_text)
        if not local_explanation:
            local_explanation, handler_name, preformatted = resolve_local_explanation(canonical_system_text)
        if local_explanation:
            formatted = format_local_solution(user_text, local_explanation, preformatted=preformatted)
            return {
                'result': formatted,
                'source': f'local:{handler_name}',
                'validated': True,
            }
        return await build_legacy_explanation(canonical_system_text)

    multiline_arithmetic_payload = build_multiline_arithmetic_payload(user_text)
    if multiline_arithmetic_payload:
        return multiline_arithmetic_payload

    if is_multi_task_submission(user_text):
        return build_multi_task_payload(user_text)

    direct_math_expression = build_direct_math_expression_payload(user_text)
    if direct_math_expression:
        return direct_math_expression

    local_explanation, handler_name, preformatted = resolve_local_explanation(user_text)
    if local_explanation:
        formatted = format_local_solution(user_text, local_explanation, preformatted=preformatted)
        return {
            'result': formatted,
            'source': f'local:{handler_name}',
            'validated': True,
        }

    motion_word_problem = build_motion_word_problem_payload(user_text)
    if motion_word_problem:
        return motion_word_problem

    purchase_word_problem = build_purchase_word_problem_payload(user_text)
    if purchase_word_problem:
        return purchase_word_problem

    change_word_problem = build_change_word_problem_payload(user_text)
    if change_word_problem:
        return change_word_problem

    geometry_word_problem = build_geometry_word_problem_payload(user_text)
    if geometry_word_problem:
        return geometry_word_problem

    fraction_word_problem = build_fraction_word_problem_payload(user_text)
    if fraction_word_problem:
        return fraction_word_problem

    quantity_word_problem = build_quantity_word_problem_payload(user_text)
    if quantity_word_problem:
        return quantity_word_problem

    relation_word_problem = build_relation_word_problem_payload(user_text)
    if relation_word_problem:
        return relation_word_problem

    dual_subject_word_problem = build_dual_subject_word_problem_payload(user_text)
    if dual_subject_word_problem:
        return dual_subject_word_problem

    verbal_arithmetic_word_problem = build_verbal_arithmetic_word_problem_payload(user_text)
    if verbal_arithmetic_word_problem:
        return verbal_arithmetic_word_problem

    legacy_external_fallback = await build_legacy_external_fallback_payload(user_text)
    if legacy_external_fallback:
        return legacy_external_fallback

    legacy_explanatory_math = await build_legacy_explanatory_math_payload(user_text)
    if legacy_explanatory_math:
        return legacy_explanatory_math

    return await build_legacy_explanation(user_text)
