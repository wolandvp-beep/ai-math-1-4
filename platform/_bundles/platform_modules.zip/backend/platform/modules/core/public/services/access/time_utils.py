from __future__ import annotations

from datetime import UTC, datetime, time, timedelta

from backend.platform.modules.core.public.services.access.config import MSK_TIMEZONE


def utc_now() -> datetime:
    return datetime.now(UTC)


def utc_now_iso() -> str:
    return utc_now().isoformat().replace('+00:00', 'Z')


def now_msk() -> datetime:
    return utc_now().astimezone(MSK_TIMEZONE)


def today_msk_str() -> str:
    return now_msk().date().isoformat()


def coerce_msk_date(value: str | None) -> str | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value).date().isoformat()
    except ValueError:
        return None


def next_msk_midnight_iso(*, from_dt: datetime | None = None) -> str:
    local_dt = (from_dt or now_msk()).astimezone(MSK_TIMEZONE)
    next_day = local_dt.date() + timedelta(days=1)
    next_midnight = datetime.combine(next_day, time.min, tzinfo=MSK_TIMEZONE)
    return next_midnight.isoformat()


__all__ = [
    'coerce_msk_date',
    'next_msk_midnight_iso',
    'now_msk',
    'today_msk_str',
    'utc_now',
    'utc_now_iso',
]
