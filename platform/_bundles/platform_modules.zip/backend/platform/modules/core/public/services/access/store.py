from __future__ import annotations

import json
import os
import tempfile
import threading
from pathlib import Path
from typing import Any, Callable, TypeVar

T = TypeVar('T')

STATE_FILE_ENV = 'RESHAYKA_STATE_FILE'
DEFAULT_STATE_FILE = Path(tempfile.gettempdir()) / 'reshayka_dev_backend_state.json'
_STORE_LOCK = threading.RLock()


def _empty_state() -> dict[str, Any]:
    return {
        'version': 1,
        'users': {},
        'tokens': {},
        'emails': {},
    }


class JsonAccessStateStore:
    def __init__(self, path: str | os.PathLike[str] | None = None) -> None:
        self.path = Path(path or os.environ.get(STATE_FILE_ENV) or DEFAULT_STATE_FILE)

    def _load_unlocked(self) -> dict[str, Any]:
        if not self.path.exists():
            return _empty_state()
        try:
            data = json.loads(self.path.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            return _empty_state()
        if not isinstance(data, dict):
            return _empty_state()
        state = _empty_state()
        state.update({key: value for key, value in data.items() if key in state and isinstance(value, dict)})
        state['version'] = 1
        return state

    def _save_unlocked(self, state: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path = self.path.with_suffix(self.path.suffix + '.tmp')
        tmp_path.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding='utf-8')
        tmp_path.replace(self.path)

    def load(self) -> dict[str, Any]:
        with _STORE_LOCK:
            return self._load_unlocked()

    def mutate(self, callback: Callable[[dict[str, Any]], T]) -> T:
        with _STORE_LOCK:
            state = self._load_unlocked()
            result = callback(state)
            self._save_unlocked(state)
            return result


__all__ = ['DEFAULT_STATE_FILE', 'JsonAccessStateStore', 'STATE_FILE_ENV']
