from __future__ import annotations

import asyncio
import threading
from typing import Awaitable, Callable, TypeVar

T = TypeVar('T')


def run_async_compat(factory: Callable[[], Awaitable[T]]) -> T:
    """Run an async factory from sync code, even inside an active event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(factory())

    result: dict[str, T] = {}
    error: dict[str, BaseException] = {}

    def runner() -> None:
        try:
            result['value'] = asyncio.run(factory())
        except BaseException as exc:  # pragma: no cover - defensive handoff
            error['error'] = exc

    thread = threading.Thread(target=runner, name='backend-async-compat', daemon=True)
    thread.start()
    thread.join()
    if 'error' in error:
        raise error['error']
    return result['value']


__all__ = ['run_async_compat']
