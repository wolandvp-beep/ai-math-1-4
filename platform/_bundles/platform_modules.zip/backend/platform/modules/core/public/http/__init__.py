from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from backend.compat_paths import BACKEND_COMPAT_DIRS, PLATFORM_ROOT, CORE_PUBLIC_HTTP_PACKAGE_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [*CORE_PUBLIC_HTTP_PACKAGE_DIRS, *BACKEND_COMPAT_DIRS])

__all__ = ['BACKEND_COMPAT_DIRS', 'PLATFORM_ROOT', 'CORE_PUBLIC_HTTP_PACKAGE_DIRS']
