from __future__ import annotations

import hashlib
import secrets
from dataclasses import dataclass
from typing import Any

from backend.platform.modules.core.public.services.access.config import (
    CHANNEL_PROVIDER,
    FREE_DAILY_SOLUTIONS_AFTER_STARTER,
    FREE_STARTER_SOLUTIONS,
    LIMIT_REACHED_MESSAGE,
    PLAN_SPECS,
    SUBSCRIPTION_DAILY_SOLUTIONS,
    WEBSHOP_DISABLED_MESSAGE,
    build_public_product_config,
)
from backend.platform.modules.core.public.services.access.store import JsonAccessStateStore
from backend.platform.modules.core.public.services.access.time_utils import (
    next_msk_midnight_iso,
    today_msk_str,
    utc_now_iso,
)


class AccessServiceError(RuntimeError):
    status_code = 400
    code = 'access_error'

    def __init__(self, message: str, *, status_code: int | None = None, code: str | None = None) -> None:
        super().__init__(message)
        if status_code is not None:
            self.status_code = status_code
        if code is not None:
            self.code = code


class AuthRequiredError(AccessServiceError):
    status_code = 401
    code = 'auth_required'


class AuthenticationError(AccessServiceError):
    status_code = 401
    code = 'invalid_credentials'


class ConflictError(AccessServiceError):
    status_code = 409
    code = 'conflict'


class LimitExceededError(AccessServiceError):
    status_code = 429
    code = 'daily_limit_reached'


@dataclass(frozen=True)
class ResolvedIdentity:
    identity_key: str
    record: dict[str, Any]
    token: str | None
    install_id: str | None


class AccessService:
    def __init__(self, store: JsonAccessStateStore | None = None) -> None:
        self.store = store or JsonAccessStateStore()

    def _hash_password(self, password: str) -> str:
        return hashlib.sha256((password or '').encode('utf-8')).hexdigest()

    def _new_token(self) -> str:
        return secrets.token_urlsafe(24)

    def _new_user_id(self) -> str:
        return f'user_{secrets.token_hex(6)}'

    def _normalize_email(self, email: str) -> str:
        return (email or '').strip().lower()

    def _build_profile(self, *, name: str = '', email: str = '', child_name: str = '', language: str = 'ru') -> dict[str, Any]:
        return {
            'id': self._new_user_id(),
            'name': (name or '').strip() or 'Пользователь',
            'email': self._normalize_email(email),
            'childName': (child_name or '').strip(),
            'language': (language or 'ru').strip() or 'ru',
        }

    def _build_record(
        self,
        *,
        identity_type: str,
        install_id: str | None = None,
        profile: dict[str, Any] | None = None,
        password_hash: str = '',
    ) -> dict[str, Any]:
        timestamp = utc_now_iso()
        return {
            'identityType': identity_type,
            'installId': install_id,
            'profile': profile or {
                'id': f'guest_{secrets.token_hex(5)}',
                'name': 'Гость',
                'email': '',
                'childName': '',
                'language': 'ru',
            },
            'passwordHash': password_hash,
            'subscription': {
                'status': 'inactive',
                'plan': None,
                'source': CHANNEL_PROVIDER,
                'renewalAt': None,
                'expiresAt': None,
            },
            'usage': {
                'starterUsedTotal': 0,
                'dailyUsedDateMsk': None,
                'dailyUsedCount': 0,
                'lifetimeSubmissionCount': 0,
                'lastSubmissionAt': None,
            },
            'createdAt': timestamp,
            'updatedAt': timestamp,
        }

    def _resolve_auth_identity_key(self, state: dict[str, Any], token: str | None) -> str | None:
        if not token:
            return None
        return state['tokens'].get(token)

    def _resolve_guest_identity_key(self, state: dict[str, Any], install_id: str | None) -> str | None:
        if not install_id:
            return None
        identity_key = f'guest:{install_id}'
        if identity_key not in state['users']:
            state['users'][identity_key] = self._build_record(identity_type='guest', install_id=install_id)
        return identity_key

    def _resolved_identity(self, state: dict[str, Any], *, token: str | None, install_id: str | None, create_guest: bool) -> ResolvedIdentity:
        identity_key = self._resolve_auth_identity_key(state, token)
        if identity_key and identity_key in state['users']:
            return ResolvedIdentity(identity_key=identity_key, record=state['users'][identity_key], token=token, install_id=install_id)
        if create_guest:
            guest_key = self._resolve_guest_identity_key(state, install_id)
            if guest_key and guest_key in state['users']:
                return ResolvedIdentity(identity_key=guest_key, record=state['users'][guest_key], token=None, install_id=install_id)
        raise AuthRequiredError('Нужен вход в аккаунт или локальный install-id.')

    def _sync_daily_counter(self, record: dict[str, Any]) -> int:
        usage = record['usage']
        today = today_msk_str()
        if usage.get('dailyUsedDateMsk') != today:
            usage['dailyUsedDateMsk'] = today
            usage['dailyUsedCount'] = 0
        return int(usage.get('dailyUsedCount') or 0)

    def _subscription_is_active(self, record: dict[str, Any]) -> bool:
        return str(record.get('subscription', {}).get('status') or 'inactive') == 'active'

    def _current_daily_cap(self, record: dict[str, Any]) -> int:
        if self._subscription_is_active(record):
            return SUBSCRIPTION_DAILY_SOLUTIONS
        if int(record['usage'].get('starterUsedTotal') or 0) < FREE_STARTER_SOLUTIONS:
            return FREE_STARTER_SOLUTIONS
        return FREE_DAILY_SOLUTIONS_AFTER_STARTER

    def _can_submit(self, record: dict[str, Any]) -> tuple[bool, str | None]:
        daily_used_count = self._sync_daily_counter(record)
        starter_used_total = int(record['usage'].get('starterUsedTotal') or 0)
        if self._subscription_is_active(record):
            if daily_used_count >= SUBSCRIPTION_DAILY_SOLUTIONS:
                return False, 'subscription_daily_limit'
            return True, None
        if starter_used_total < FREE_STARTER_SOLUTIONS:
            return True, None
        if daily_used_count >= FREE_DAILY_SOLUTIONS_AFTER_STARTER:
            return False, 'free_daily_limit'
        return True, None

    def _build_access_status(self, record: dict[str, Any]) -> dict[str, Any]:
        daily_used_count = self._sync_daily_counter(record)
        starter_used_total = int(record['usage'].get('starterUsedTotal') or 0)
        starter_remaining = max(0, FREE_STARTER_SOLUTIONS - starter_used_total)
        subscription_active = self._subscription_is_active(record)
        can_submit, block_reason = self._can_submit(record)
        if subscription_active:
            daily_limit = SUBSCRIPTION_DAILY_SOLUTIONS
            daily_remaining = max(0, daily_limit - daily_used_count)
        elif starter_remaining > 0:
            daily_limit = None
            daily_remaining = starter_remaining
        else:
            daily_limit = FREE_DAILY_SOLUTIONS_AFTER_STARTER
            daily_remaining = max(0, daily_limit - daily_used_count)
        subscription = record['subscription']
        return {
            'provider': CHANNEL_PROVIDER,
            'access': 'premium' if subscription_active else 'free',
            'subscriptionStatus': subscription.get('status') or 'inactive',
            'plan': subscription.get('plan'),
            'source': subscription.get('source') or CHANNEL_PROVIDER,
            'renewalAt': subscription.get('renewalAt'),
            'expiresAt': subscription.get('expiresAt'),
            'timezone': build_public_product_config()['timezone'],
            'resetAt': next_msk_midnight_iso(),
            'product': build_public_product_config(),
            'usage': {
                'starterTotal': FREE_STARTER_SOLUTIONS,
                'starterUsed': starter_used_total,
                'starterRemaining': starter_remaining,
                'dailyUsed': daily_used_count,
                'dailyLimit': daily_limit,
                'dailyRemaining': daily_remaining,
                'lifetimeSubmissionCount': int(record['usage'].get('lifetimeSubmissionCount') or 0),
                'canSubmit': can_submit,
                'blockReason': block_reason,
                'limitReachedMessage': LIMIT_REACHED_MESSAGE if not can_submit else None,
            },
        }

    def _touch_record(self, record: dict[str, Any]) -> None:
        record['updatedAt'] = utc_now_iso()

    def _merge_guest_usage(self, state: dict[str, Any], *, install_id: str | None, target_record: dict[str, Any]) -> None:
        if not install_id:
            return
        guest_key = f'guest:{install_id}'
        guest_record = state['users'].get(guest_key)
        if not guest_record or guest_record is target_record:
            return
        guest_usage = guest_record.get('usage', {})
        target_usage = target_record.get('usage', {})
        target_usage['starterUsedTotal'] = max(int(target_usage.get('starterUsedTotal') or 0), int(guest_usage.get('starterUsedTotal') or 0))
        guest_date = guest_usage.get('dailyUsedDateMsk')
        target_date = target_usage.get('dailyUsedDateMsk')
        guest_daily = int(guest_usage.get('dailyUsedCount') or 0)
        if guest_date and guest_daily:
            if target_date == guest_date:
                target_usage['dailyUsedCount'] = max(int(target_usage.get('dailyUsedCount') or 0), guest_daily)
            else:
                target_usage['dailyUsedDateMsk'] = guest_date
                target_usage['dailyUsedCount'] = guest_daily
        target_usage['lifetimeSubmissionCount'] = max(
            int(target_usage.get('lifetimeSubmissionCount') or 0),
            int(guest_usage.get('lifetimeSubmissionCount') or 0),
        )
        if guest_usage.get('lastSubmissionAt') and not target_usage.get('lastSubmissionAt'):
            target_usage['lastSubmissionAt'] = guest_usage['lastSubmissionAt']

    def record_final_submission(self, *, token: str | None, install_id: str | None) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            resolved = self._resolved_identity(state, token=token, install_id=install_id, create_guest=True)
            record = resolved.record
            allowed, _reason = self._can_submit(record)
            if not allowed:
                access = self._build_access_status(record)
                raise LimitExceededError(LIMIT_REACHED_MESSAGE, code='daily_limit_reached')
            usage = record['usage']
            self._sync_daily_counter(record)
            if not self._subscription_is_active(record) and int(usage.get('starterUsedTotal') or 0) < FREE_STARTER_SOLUTIONS:
                usage['starterUsedTotal'] = int(usage.get('starterUsedTotal') or 0) + 1
            usage['dailyUsedCount'] = int(usage.get('dailyUsedCount') or 0) + 1
            usage['lifetimeSubmissionCount'] = int(usage.get('lifetimeSubmissionCount') or 0) + 1
            usage['lastSubmissionAt'] = utc_now_iso()
            self._touch_record(record)
            return self._build_access_status(record)

        return self.store.mutate(_mutate)

    def get_access_status(self, *, token: str | None, install_id: str | None) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            resolved = self._resolved_identity(state, token=token, install_id=install_id, create_guest=True)
            return self._build_access_status(resolved.record)

        return self.store.mutate(_mutate)

    def register(self, *, name: str, email: str, password: str, install_id: str | None) -> dict[str, Any]:
        email_normalized = self._normalize_email(email)
        if not email_normalized or '@' not in email_normalized:
            raise AccessServiceError('Введите корректный email.', code='invalid_email')
        if len(password or '') < 4:
            raise AccessServiceError('Пароль слишком короткий.', code='invalid_password')

        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            if email_normalized in state['emails']:
                raise ConflictError('Пользователь с таким email уже существует.', code='email_exists')
            profile = self._build_profile(name=name, email=email_normalized)
            identity_key = f'user:{profile["id"]}'
            record = self._build_record(
                identity_type='user',
                install_id=install_id,
                profile=profile,
                password_hash=self._hash_password(password),
            )
            state['users'][identity_key] = record
            self._merge_guest_usage(state, install_id=install_id, target_record=record)
            state['emails'][email_normalized] = identity_key
            token = self._new_token()
            state['tokens'][token] = identity_key
            return {
                'token': token,
                'user': profile,
                'subscription': self._build_access_status(record),
            }

        return self.store.mutate(_mutate)

    def login(self, *, email: str, password: str, install_id: str | None) -> dict[str, Any]:
        email_normalized = self._normalize_email(email)

        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            identity_key = state['emails'].get(email_normalized)
            if not identity_key or identity_key not in state['users']:
                raise AuthenticationError('Неверный email или пароль.')
            record = state['users'][identity_key]
            if record.get('passwordHash') != self._hash_password(password):
                raise AuthenticationError('Неверный email или пароль.')
            if install_id:
                record['installId'] = install_id
                self._merge_guest_usage(state, install_id=install_id, target_record=record)
            token = self._new_token()
            state['tokens'][token] = identity_key
            self._touch_record(record)
            return {
                'token': token,
                'user': record['profile'],
                'subscription': self._build_access_status(record),
            }

        return self.store.mutate(_mutate)

    def logout(self, *, token: str | None) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            if token:
                state['tokens'].pop(token, None)
            return {'ok': True}

        return self.store.mutate(_mutate)

    def recover(self, *, email: str) -> dict[str, Any]:
        email_normalized = self._normalize_email(email)
        return {
            'ok': True,
            'message': 'Если аккаунт существует, инструкция по восстановлению появится позже.',
            'email': email_normalized,
        }

    def _require_user_record(self, state: dict[str, Any], token: str | None) -> dict[str, Any]:
        identity_key = self._resolve_auth_identity_key(state, token)
        if not identity_key or identity_key not in state['users']:
            raise AuthRequiredError('Нужен вход в аккаунт.')
        return state['users'][identity_key]

    def get_profile(self, *, token: str | None) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            record = self._require_user_record(state, token)
            return dict(record['profile'])

        return self.store.mutate(_mutate)

    def update_profile(self, *, token: str | None, payload: dict[str, Any]) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            record = self._require_user_record(state, token)
            profile = record['profile']
            if 'name' in payload:
                profile['name'] = str(payload.get('name') or profile['name']).strip() or profile['name']
            if 'childName' in payload:
                profile['childName'] = str(payload.get('childName') or '').strip()
            if 'language' in payload:
                profile['language'] = str(payload.get('language') or profile.get('language') or 'ru').strip() or 'ru'
            self._touch_record(record)
            return {'ok': True, 'profile': dict(profile)}

        return self.store.mutate(_mutate)

    def get_subscription(self, *, token: str | None, install_id: str | None) -> dict[str, Any]:
        access = self.get_access_status(token=token, install_id=install_id)
        return {
            'status': access['subscriptionStatus'],
            'plan': access['plan'],
            'renewalAt': access['renewalAt'],
            'expiresAt': access['expiresAt'],
            'source': access['source'],
            'provider': access['provider'],
            'access': access['access'],
            'usage': access['usage'],
            'product': access['product'],
        }

    def restore_purchase(self, *, token: str | None) -> dict[str, Any]:
        subscription = self.get_subscription(token=token, install_id=None)
        return {
            'ok': True,
            'message': 'Восстановление покупок RuStore будет подключено позже. Текущий статус доступа обновлён.',
            'subscription': subscription,
        }

    def create_web_billing_session(self, *, token: str | None, payload: dict[str, Any]) -> dict[str, Any]:
        raise ConflictError(WEBSHOP_DISABLED_MESSAGE, code='rustore_only')

    def activate_subscription_for_tests(self, *, token: str | None = None, install_id: str | None = None, plan: str = 'monthly') -> dict[str, Any]:
        plan_key = plan if plan in PLAN_SPECS else 'monthly'

        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            resolved = self._resolved_identity(state, token=token, install_id=install_id, create_guest=True)
            record = resolved.record
            record['subscription'].update({
                'status': 'active',
                'plan': plan_key,
                'source': CHANNEL_PROVIDER,
                'renewalAt': None,
                'expiresAt': None,
            })
            self._touch_record(record)
            return self._build_access_status(record)

        return self.store.mutate(_mutate)

    def deactivate_subscription_for_tests(self, *, token: str | None = None, install_id: str | None = None) -> dict[str, Any]:
        def _mutate(state: dict[str, Any]) -> dict[str, Any]:
            resolved = self._resolved_identity(state, token=token, install_id=install_id, create_guest=True)
            record = resolved.record
            record['subscription'].update({
                'status': 'inactive',
                'plan': None,
                'source': CHANNEL_PROVIDER,
                'renewalAt': None,
                'expiresAt': None,
            })
            self._touch_record(record)
            return self._build_access_status(record)

        return self.store.mutate(_mutate)


__all__ = [
    'AccessService',
    'AccessServiceError',
    'AuthRequiredError',
    'AuthenticationError',
    'ConflictError',
    'LimitExceededError',
    'ResolvedIdentity',
]
