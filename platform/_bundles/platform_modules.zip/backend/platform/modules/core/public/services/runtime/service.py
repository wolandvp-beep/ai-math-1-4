from __future__ import annotations

from backend.expression_engine import build_explanation
from backend.postprocess import clean_result_payload
from backend.text_utils import NON_MATH_REPLY, looks_like_math_input
from backend.platform.request_shape_guards import build_multiline_arithmetic_payload, build_multi_task_payload, is_multi_task_submission


def validate_user_text(user_text: str):
    user_text = (user_text or '').strip()
    if not user_text:
        return False, {"error": "Пустой текст задачи"}
    if len(user_text) > 2000:
        return False, {"error": "Текст задачи слишком длинный"}
    return True, user_text


def get_non_math_response() -> dict:
    return {"result": NON_MATH_REPLY, "source": "guard", "validated": True}


def prevalidate_explanation_request(user_text: str) -> dict | None:
    ok, payload = validate_user_text(user_text)
    if not ok:
        return payload
    if not looks_like_math_input(payload):
        return clean_result_payload(get_non_math_response())
    multiline_payload = build_multiline_arithmetic_payload(payload)
    if multiline_payload is not None:
        return clean_result_payload(multiline_payload)
    if is_multi_task_submission(payload):
        return clean_result_payload(build_multi_task_payload(payload))
    return None


async def generate_explanation_response(user_text: str) -> dict:
    prevalidated = prevalidate_explanation_request(user_text)
    if prevalidated is not None:
        return prevalidated
    _, payload = validate_user_text(user_text)
    result = await build_explanation(payload)
    return clean_result_payload(result)
