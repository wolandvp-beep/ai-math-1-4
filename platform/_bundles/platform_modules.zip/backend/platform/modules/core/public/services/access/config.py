from __future__ import annotations

from dataclasses import dataclass
from zoneinfo import ZoneInfo

MSK_TIMEZONE_NAME = 'Europe/Moscow'
MSK_TIMEZONE = ZoneInfo(MSK_TIMEZONE_NAME)

LIMIT_REACHED_MESSAGE = 'Лимит решений на сегодня уже исчерпан. Встретимся завтра.'
WEBSHOP_DISABLED_MESSAGE = 'В этой версии монетизация идёт через RuStore. Веб-оплата пока не используется.'


@dataclass(frozen=True)
class PlanSpec:
    key: str
    title: str
    price_rub: int
    period: str
    daily_limit: int
    product_id: str


MONTHLY_PLAN = PlanSpec(
    key='monthly',
    title='Месячная подписка',
    price_rub=299,
    period='month',
    daily_limit=20,
    product_id='ru.reshayka.subscription.monthly',
)

YEARLY_PLAN = PlanSpec(
    key='yearly',
    title='Годовая подписка',
    price_rub=1990,
    period='year',
    daily_limit=20,
    product_id='ru.reshayka.subscription.yearly',
)

PLAN_SPECS: dict[str, PlanSpec] = {
    MONTHLY_PLAN.key: MONTHLY_PLAN,
    YEARLY_PLAN.key: YEARLY_PLAN,
}

FREE_STARTER_SOLUTIONS = 5
FREE_DAILY_SOLUTIONS_AFTER_STARTER = 1
SUBSCRIPTION_DAILY_SOLUTIONS = 20
CHANNEL_PROVIDER = 'rustore'
RESET_MODE = 'calendar_day_msk'
SOLUTION_UNIT = 'final_submit'


def build_public_product_config() -> dict:
    return {
        'provider': CHANNEL_PROVIDER,
        'timezone': MSK_TIMEZONE_NAME,
        'resetMode': RESET_MODE,
        'solutionUnit': SOLUTION_UNIT,
        'free': {
            'starterSolutions': FREE_STARTER_SOLUTIONS,
            'dailySolutionsAfterStarter': FREE_DAILY_SOLUTIONS_AFTER_STARTER,
            'accumulates': False,
        },
        'plans': {
            key: {
                'title': spec.title,
                'priceRub': spec.price_rub,
                'period': spec.period,
                'dailySolutions': spec.daily_limit,
                'productId': spec.product_id,
            }
            for key, spec in PLAN_SPECS.items()
        },
        'messages': {
            'dailyLimitReached': LIMIT_REACHED_MESSAGE,
            'webBillingDisabled': WEBSHOP_DISABLED_MESSAGE,
        },
    }


__all__ = [
    'CHANNEL_PROVIDER',
    'FREE_DAILY_SOLUTIONS_AFTER_STARTER',
    'FREE_STARTER_SOLUTIONS',
    'LIMIT_REACHED_MESSAGE',
    'MONTHLY_PLAN',
    'MSK_TIMEZONE',
    'MSK_TIMEZONE_NAME',
    'PLAN_SPECS',
    'PlanSpec',
    'RESET_MODE',
    'SOLUTION_UNIT',
    'SUBSCRIPTION_DAILY_SOLUTIONS',
    'WEBSHOP_DISABLED_MESSAGE',
    'YEARLY_PLAN',
    'build_public_product_config',
]
