from __future__ import annotations

from dataclasses import dataclass
import os
from zoneinfo import ZoneInfo

MSK_TIMEZONE_NAME = 'Europe/Moscow'
MSK_TIMEZONE = ZoneInfo(MSK_TIMEZONE_NAME)

LIMIT_REACHED_MESSAGE = 'Лимит решений на сегодня уже исчерпан. Встретимся завтра.'
WEBSHOP_DISABLED_MESSAGE = 'Оплата через Robokassa для RuStore будет подключена позже. Пока доступен только тестовый маршрут без реального списания.'


@dataclass(frozen=True)
class PlanSpec:
    key: str
    title: str
    price_rub: int
    period: str
    duration_days: int
    daily_limit: int
    product_id: str


WEEKLY_PLAN = PlanSpec(
    key='weekly',
    title='Подписка на 7 дней',
    price_rub=99,
    period='7_days',
    duration_days=7,
    daily_limit=20,
    product_id='robokassa.subscription.7days',
)

MONTHLY_PLAN = PlanSpec(
    key='monthly',
    title='Подписка на 30 дней',
    price_rub=349,
    period='30_days',
    duration_days=30,
    daily_limit=20,
    product_id='robokassa.subscription.30days',
)

YEARLY_PLAN = PlanSpec(
    key='yearly',
    title='Подписка на 1 год',
    price_rub=2999,
    period='year',
    duration_days=365,
    daily_limit=20,
    product_id='robokassa.subscription.yearly',
)

PLAN_SPECS: dict[str, PlanSpec] = {
    WEEKLY_PLAN.key: WEEKLY_PLAN,
    MONTHLY_PLAN.key: MONTHLY_PLAN,
    YEARLY_PLAN.key: YEARLY_PLAN,
}

FREE_STARTER_SOLUTIONS = 5
FREE_DAILY_SOLUTIONS_AFTER_STARTER = 1
SUBSCRIPTION_DAILY_SOLUTIONS = 20
CHANNEL_PROVIDER = 'robokassa'
ENABLE_GOOGLE_PLAY = False
DISTRIBUTION_PLATFORMS = ('rustore',) if not ENABLE_GOOGLE_PLAY else ('rustore', 'google_play')
CHECKOUT_MODE = 'external'
RESET_MODE = 'calendar_day_msk'
SOLUTION_UNIT = 'final_submit'


def _is_enabled_from_env(primary_name: str, legacy_name: str, default: str = '0') -> bool:
    raw = os.environ.get(primary_name)
    if raw is None:
        raw = os.environ.get(legacy_name, default)
    return raw.strip().lower() in {'1', 'true', 'yes', 'on'}


LIMITS_ENABLED = _is_enabled_from_env('MATEMATICHKA_LIMITS_ENABLED', 'RESHAYKA_LIMITS_ENABLED')
DEVELOPMENT_UNLIMITED_DAILY_SOLUTIONS = 1_000_000


def build_public_product_config() -> dict:
    return {
        'provider': CHANNEL_PROVIDER,
        'billingProvider': CHANNEL_PROVIDER,
        'distributionPlatforms': list(DISTRIBUTION_PLATFORMS),
        'checkoutMode': CHECKOUT_MODE,
        'timezone': MSK_TIMEZONE_NAME,
        'resetMode': RESET_MODE,
        'solutionUnit': SOLUTION_UNIT,
        'limitsEnabled': LIMITS_ENABLED,
        'developmentLimitsDisabled': not LIMITS_ENABLED,
        'free': {
            'starterSolutions': FREE_STARTER_SOLUTIONS,
            'dailySolutionsAfterStarter': FREE_DAILY_SOLUTIONS_AFTER_STARTER,
            'accumulates': False,
        },
        'plans': {
            key: {
                'title': spec.title,
                'priceRub': spec.price_rub,
                'period': spec.period,
                'durationDays': spec.duration_days,
                'dailySolutions': spec.daily_limit,
                'productId': spec.product_id,
            }
            for key, spec in PLAN_SPECS.items()
        },
        'messages': {
            'dailyLimitReached': LIMIT_REACHED_MESSAGE,
            'webBillingDisabled': WEBSHOP_DISABLED_MESSAGE,
            'externalCheckoutPending': WEBSHOP_DISABLED_MESSAGE,
        },
    }


__all__ = [
    'CHANNEL_PROVIDER',
    'CHECKOUT_MODE',
    'DISTRIBUTION_PLATFORMS',
    'ENABLE_GOOGLE_PLAY',
    'FREE_DAILY_SOLUTIONS_AFTER_STARTER',
    'FREE_STARTER_SOLUTIONS',
    'DEVELOPMENT_UNLIMITED_DAILY_SOLUTIONS',
    'LIMIT_REACHED_MESSAGE',
    'LIMITS_ENABLED',
    'MONTHLY_PLAN',
    'MSK_TIMEZONE',
    'MSK_TIMEZONE_NAME',
    'PLAN_SPECS',
    'PlanSpec',
    'RESET_MODE',
    'SOLUTION_UNIT',
    'SUBSCRIPTION_DAILY_SOLUTIONS',
    'WEBSHOP_DISABLED_MESSAGE',
    'WEEKLY_PLAN',
    'YEARLY_PLAN',
    'build_public_product_config',
]
