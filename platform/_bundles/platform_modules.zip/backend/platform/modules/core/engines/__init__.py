from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

try:
    from ....compat_paths import CORE_PACKAGE_DIRS, FEATURES_ROOT, LEGACY_INTERNAL_IMPORT_DIRS, extend_module_path
except ImportError:
    from backend.compat_paths import CORE_PACKAGE_DIRS, FEATURES_ROOT, LEGACY_INTERNAL_IMPORT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [*CORE_PACKAGE_DIRS, FEATURES_ROOT, *LEGACY_INTERNAL_IMPORT_DIRS])

__all__ = ['CORE_PACKAGE_DIRS', 'FEATURES_ROOT', 'LEGACY_INTERNAL_IMPORT_DIRS']
