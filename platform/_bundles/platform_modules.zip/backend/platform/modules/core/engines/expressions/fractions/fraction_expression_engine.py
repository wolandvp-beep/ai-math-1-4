from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import List, Optional

from backend.platform.modules.core.parsing.expressions.fractions.fraction_expression_parser import (
    FractionBinaryNode,
    FractionExpressionNode,
    FractionExpressionParseResult,
    FractionLiteralNode,
    FractionUnaryNode,
    format_fraction_value,
    parse_fraction_expression,
    render_fraction_expression,
)


@dataclass(frozen=True)
class FractionExpressionStep:
    node: FractionBinaryNode
    result: Fraction


_OPERATOR_NAME = {
    '+': 'сложение',
    '-': 'вычитание',
    '*': 'умножение',
    '/': 'деление',
}


def _lcm(a: int, b: int) -> int:
    return abs(a * b) // math.gcd(a, b)


def _as_fraction_text(value: Fraction) -> str:
    return format_fraction_value(value, force_fraction=True)


def _format_fraction(value: Fraction) -> str:
    return format_fraction_value(value)


def _collect_steps(node: FractionExpressionNode) -> List[FractionExpressionStep]:
    if isinstance(node, FractionBinaryNode):
        return [*_collect_steps(node.left), *_collect_steps(node.right), FractionExpressionStep(node=node, result=node.value)]
    if isinstance(node, FractionUnaryNode):
        return _collect_steps(node.operand)
    return []


def _render_step_expression(node: FractionExpressionNode) -> str:
    return render_fraction_expression(node)


def _add_integer_conversion_lines(lines: list[str], value: Fraction) -> None:
    if value.denominator == 1:
        lines.append(f'Представляем число {value.numerator} в виде дроби: {value.numerator} = {value.numerator}/1.')


def _explain_addition_or_subtraction(step: FractionExpressionStep, index: int) -> list[str]:
    node = step.node
    left = node.left.value
    right = node.right.value
    result = node.value
    operator_text = '+' if node.operator == '+' else '-'
    action_text = 'Складываем' if node.operator == '+' else 'Вычитаем'
    expression_text = _render_step_expression(node)
    left_value_text = _format_fraction(left)
    right_value_text = _format_fraction(right)
    result_text = _format_fraction(result)
    common_denominator = _lcm(left.denominator, right.denominator)
    left_num = left.numerator * (common_denominator // left.denominator)
    right_num = right.numerator * (common_denominator // right.denominator)
    unsimplified_numerator = left_num + right_num if node.operator == '+' else left_num - right_num
    unsimplified_text = f'{unsimplified_numerator}/{common_denominator}'

    lines = [f'{index}) {expression_text} = {result_text}.']
    if left.denominator == 1:
        _add_integer_conversion_lines(lines, left)
    if right.denominator == 1:
        _add_integer_conversion_lines(lines, right)
    if left.denominator == right.denominator:
        lines.append(f'Знаменатели одинаковые: {left_value_text} и {right_value_text}.')
    else:
        lines.append(
            f'Приводим дроби к общему знаменателю {common_denominator}: '
            f'{left_value_text} = {left_num}/{common_denominator}, {right_value_text} = {right_num}/{common_denominator}.'
        )
    lines.append(
        f'{action_text} числители: {left_num}/{common_denominator} {operator_text} '
        f'{right_num}/{common_denominator} = {unsimplified_text}.'
    )
    if unsimplified_text != result_text:
        lines.append(f'Сокращаем дробь: {unsimplified_text} = {result_text}.')
    return lines


def _explain_multiplication(step: FractionExpressionStep, index: int) -> list[str]:
    node = step.node
    left = node.left.value
    right = node.right.value
    result = node.value
    expression_text = _render_step_expression(node)
    left_value_text = _format_fraction(left)
    right_value_text = _format_fraction(right)
    result_text = _format_fraction(result)
    product_numerator = left.numerator * right.numerator
    product_denominator = left.denominator * right.denominator
    unsimplified_text = f'{product_numerator}/{product_denominator}'
    lines = [f'{index}) {expression_text} = {result_text}.']
    if left.denominator == 1:
        _add_integer_conversion_lines(lines, left)
    if right.denominator == 1:
        _add_integer_conversion_lines(lines, right)
    lines.append(
        'Умножаем числители и знаменатели: '
        f'({_as_fraction_text(left)}) × ({_as_fraction_text(right)}) = '
        f'({left.numerator}×{right.numerator})/({left.denominator}×{right.denominator}) = {unsimplified_text}.'
    )
    if unsimplified_text != result_text:
        lines.append(f'Сокращаем дробь: {unsimplified_text} = {result_text}.')
    return lines


def _explain_division(step: FractionExpressionStep, index: int) -> list[str]:
    node = step.node
    left = node.left.value
    right = node.right.value
    if right == 0:
        return [f'{index}) Делить на ноль нельзя.']
    result = node.value
    expression_text = _render_step_expression(node)
    left_value_text = _format_fraction(left)
    right_value_text = _format_fraction(right)
    result_text = _format_fraction(result)
    reciprocal = Fraction(right.denominator, right.numerator)
    product_numerator = left.numerator * reciprocal.numerator
    product_denominator = left.denominator * reciprocal.denominator
    unsimplified_text = f'{product_numerator}/{product_denominator}'
    lines = [f'{index}) {expression_text} = {result_text}.']
    if left.denominator == 1:
        _add_integer_conversion_lines(lines, left)
    if right.denominator == 1:
        _add_integer_conversion_lines(lines, right)
    lines.append(
        'Заменяем деление умножением на обратную дробь: '
        f'{_as_fraction_text(left)} : {_as_fraction_text(right)} = '
        f'{_as_fraction_text(left)} × {_as_fraction_text(reciprocal)}.'
    )
    lines.append(
        'Умножаем числители и знаменатели: '
        f'({left.numerator}×{reciprocal.numerator})/({left.denominator}×{reciprocal.denominator}) = {unsimplified_text}.'
    )
    if unsimplified_text != result_text:
        lines.append(f'Сокращаем дробь: {unsimplified_text} = {result_text}.')
    return lines


def _build_step_lines(step: FractionExpressionStep, index: int) -> list[str]:
    if step.node.operator in {'+', '-'}:
        return _explain_addition_or_subtraction(step, index)
    if step.node.operator == '*':
        return _explain_multiplication(step, index)
    if step.node.operator == '/':
        return _explain_division(step, index)
    return [f'{index}) {_render_step_expression(step.node)} = {_format_fraction(step.result)}.']


def build_fraction_expression_payload(raw_text: str) -> Optional[dict]:
    parsed = parse_fraction_expression(raw_text)
    if parsed is None:
        return None
    steps = _collect_steps(parsed.root)
    if not steps:
        return None

    pretty_expression = render_fraction_expression(parsed.root)
    result_text = _format_fraction(parsed.root.value)
    lines: list[str] = [f'Пример: {pretty_expression} = {result_text}.', 'Решение по действиям:']
    for index, step in enumerate(steps, start=1):
        lines.extend(_build_step_lines(step, index))
    lines.append(f'Ответ: {result_text}.')
    lines.append('Совет: сначала решай действия в скобках, потом умножение и деление дробей, потом сложение и вычитание.')
    return {
        'result': '\n'.join(line.rstrip() for line in lines if str(line).strip()).strip(),
        'source': 'expression_fraction:direct',
        'validated': True,
        'expression_source': parsed.source,
        'fraction_literal_count': parsed.fraction_literal_count,
        'fraction_step_count': len(steps),
        'explicit_division_count': parsed.explicit_division_count,
    }


__all__ = ['build_fraction_expression_payload']
