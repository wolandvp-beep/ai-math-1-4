from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import math
import re
from typing import Iterable, Optional


@dataclass(frozen=True)
class FractionToken:
    kind: str
    text: str
    value: Fraction | None = None
    position: int = 0


@dataclass(frozen=True)
class FractionLiteralNode:
    value: Fraction
    text: str
    token_kind: str = 'fraction'


@dataclass(frozen=True)
class FractionUnaryNode:
    operator: str
    operand: 'FractionExpressionNode'
    value: Fraction


@dataclass(frozen=True)
class FractionBinaryNode:
    operator: str
    left: 'FractionExpressionNode'
    right: 'FractionExpressionNode'
    value: Fraction
    operator_position: int = 0


FractionExpressionNode = FractionLiteralNode | FractionUnaryNode | FractionBinaryNode


@dataclass(frozen=True)
class FractionExpressionParseResult:
    raw_source: str
    source: str
    tokens: tuple[FractionToken, ...]
    root: FractionExpressionNode
    fraction_literal_count: int
    explicit_division_count: int
    non_integer_fraction_literal_count: int


_LEADING_COMMAND_RE = re.compile(r'^(?:пример|реши|вычисли|найди)\b\s*[:\-]?\s*', re.IGNORECASE)


def normalize_fraction_expression_source(raw_text: str) -> str | None:
    text = str(raw_text or '').strip()
    if not text:
        return None
    text = _LEADING_COMMAND_RE.sub('', text).strip()
    text = re.sub(r'[=?]+$', '', text).strip()
    text = text.replace('×', '*').replace('·', '*')
    text = text.replace('−', '-').replace('–', '-').replace('—', '-')
    text = re.sub(r'\s+', ' ', text)
    if not text:
        return None
    if re.search(r'[A-Za-zА-Яа-я]', text):
        return None
    if not re.fullmatch(r'[0-9\s+\-*/():÷]+', text):
        return None
    return text


def _make_fraction_token(text: str, position: int) -> FractionToken:
    numerator_text, denominator_text = text.split('/', 1)
    denominator = int(denominator_text)
    if denominator == 0:
        raise ZeroDivisionError('division by zero in fraction literal')
    return FractionToken(
        kind='fraction',
        text=text,
        value=Fraction(int(numerator_text), denominator),
        position=position,
    )


def tokenize_fraction_expression(source: str) -> tuple[FractionToken, ...] | None:
    tokens: list[FractionToken] = []
    index = 0
    length = len(source)
    while index < length:
        ch = source[index]
        if ch.isspace():
            index += 1
            continue
        if ch.isdigit():
            start = index
            while index < length and source[index].isdigit():
                index += 1
            number_text = source[start:index]
            if index < length and source[index] == '/' and index + 1 < length and source[index + 1].isdigit():
                fraction_start = start
                fraction_index = index + 1
                while fraction_index < length and source[fraction_index].isdigit():
                    fraction_index += 1
                fraction_text = source[start:fraction_index]
                try:
                    tokens.append(_make_fraction_token(fraction_text, fraction_start))
                except ZeroDivisionError:
                    return None
                index = fraction_index
                continue
            tokens.append(FractionToken(kind='number', text=number_text, value=Fraction(int(number_text), 1), position=start))
            continue
        if ch in '+-*':
            tokens.append(FractionToken(kind='operator', text=ch, position=index))
            index += 1
            continue
        if ch in ':/÷':
            tokens.append(FractionToken(kind='operator', text='/', position=index))
            index += 1
            continue
        if ch == '(':
            tokens.append(FractionToken(kind='lparen', text=ch, position=index))
            index += 1
            continue
        if ch == ')':
            tokens.append(FractionToken(kind='rparen', text=ch, position=index))
            index += 1
            continue
        return None
    return tuple(tokens)


class _FractionTokenStream:
    def __init__(self, tokens: Iterable[FractionToken]):
        self._tokens = tuple(tokens)
        self._index = 0

    def peek(self) -> FractionToken | None:
        if self._index >= len(self._tokens):
            return None
        return self._tokens[self._index]

    def pop(self) -> FractionToken | None:
        token = self.peek()
        if token is not None:
            self._index += 1
        return token

    def remaining(self) -> tuple[FractionToken, ...]:
        return self._tokens[self._index:]


def _parse_primary(stream: _FractionTokenStream) -> FractionExpressionNode | None:
    token = stream.peek()
    if token is None:
        return None
    if token.kind in {'number', 'fraction'} and token.value is not None:
        stream.pop()
        token_kind = 'fraction' if token.kind == 'fraction' else 'number'
        return FractionLiteralNode(value=token.value, text=token.text, token_kind=token_kind)
    if token.kind == 'operator' and token.text == '-':
        stream.pop()
        operand = _parse_primary(stream)
        if operand is None:
            return None
        return FractionUnaryNode(operator='-', operand=operand, value=-operand.value)
    if token.kind == 'lparen':
        stream.pop()
        node = _parse_expression(stream)
        if node is None:
            return None
        closing = stream.pop()
        if closing is None or closing.kind != 'rparen':
            return None
        return node
    return None


def _combine_binary(operator_token: FractionToken, left: FractionExpressionNode, right: FractionExpressionNode) -> FractionBinaryNode | None:
    operator = operator_token.text
    try:
        if operator == '+':
            value = left.value + right.value
        elif operator == '-':
            value = left.value - right.value
        elif operator == '*':
            value = left.value * right.value
        elif operator == '/':
            if right.value == 0:
                return None
            value = left.value / right.value
        else:
            return None
    except ZeroDivisionError:
        return None
    return FractionBinaryNode(
        operator=operator,
        left=left,
        right=right,
        value=value,
        operator_position=operator_token.position,
    )


def _parse_term(stream: _FractionTokenStream) -> FractionExpressionNode | None:
    node = _parse_primary(stream)
    if node is None:
        return None
    while True:
        token = stream.peek()
        if token is None or token.kind != 'operator' or token.text not in {'*', '/'}:
            break
        stream.pop()
        right = _parse_primary(stream)
        if right is None:
            return None
        node = _combine_binary(token, node, right)
        if node is None:
            return None
    return node


def _parse_expression(stream: _FractionTokenStream) -> FractionExpressionNode | None:
    node = _parse_term(stream)
    if node is None:
        return None
    while True:
        token = stream.peek()
        if token is None or token.kind != 'operator' or token.text not in {'+', '-'}:
            break
        stream.pop()
        right = _parse_term(stream)
        if right is None:
            return None
        node = _combine_binary(token, node, right)
        if node is None:
            return None
    return node


def parse_fraction_expression(raw_text: str) -> FractionExpressionParseResult | None:
    raw_source = str(raw_text or '')
    source = normalize_fraction_expression_source(raw_source)
    if not source:
        return None
    tokens = tokenize_fraction_expression(source)
    if not tokens:
        return None
    fraction_literals = [token for token in tokens if token.kind == 'fraction' and token.value is not None]
    if not fraction_literals:
        return None
    non_integer_fraction_literal_count = sum(1 for token in fraction_literals if token.value is not None and token.value.denominator != 1)
    explicit_division_count = sum(1 for token in tokens if token.kind == 'operator' and token.text == '/')

    use_fraction_mode = False
    if len(fraction_literals) >= 2:
        use_fraction_mode = True
    elif non_integer_fraction_literal_count >= 1:
        use_fraction_mode = True
    elif re.search(r'\bдроб', raw_source, flags=re.IGNORECASE):
        use_fraction_mode = True
    if not use_fraction_mode:
        return None

    stream = _FractionTokenStream(tokens)
    root = _parse_expression(stream)
    if root is None:
        return None
    if stream.peek() is not None:
        return None
    return FractionExpressionParseResult(
        raw_source=raw_source,
        source=source,
        tokens=tokens,
        root=root,
        fraction_literal_count=len(fraction_literals),
        explicit_division_count=explicit_division_count,
        non_integer_fraction_literal_count=non_integer_fraction_literal_count,
    )


def format_fraction_value(value: Fraction, *, force_fraction: bool = False) -> str:
    simplified = Fraction(value.numerator, value.denominator)
    if simplified.denominator == 1 and not force_fraction:
        return str(simplified.numerator)
    return f'{simplified.numerator}/{simplified.denominator}'


_PRECEDENCE = {'+': 1, '-': 1, '*': 2, '/': 2}
_OPERATOR_DISPLAY = {'+': '+', '-': '-', '*': '×', '/': ':'}


def _literal_render(node: FractionLiteralNode, *, force_fraction: bool = False) -> str:
    if node.token_kind == 'fraction':
        if force_fraction and node.value.denominator == 1:
            return f'{node.value.numerator}/1'
        return node.text
    return format_fraction_value(node.value, force_fraction=force_fraction)


def render_fraction_expression(node: FractionExpressionNode, *, parent_precedence: int = 0, is_right_child: bool = False) -> str:
    if isinstance(node, FractionLiteralNode):
        return _literal_render(node)
    if isinstance(node, FractionUnaryNode):
        inner = render_fraction_expression(node.operand, parent_precedence=3)
        if isinstance(node.operand, FractionBinaryNode):
            inner = f'({inner})'
        return f'-{inner}'
    current_precedence = _PRECEDENCE[node.operator]
    left_text = render_fraction_expression(node.left, parent_precedence=current_precedence)
    right_text = render_fraction_expression(node.right, parent_precedence=current_precedence, is_right_child=True)
    text = f'{left_text} {_OPERATOR_DISPLAY[node.operator]} {right_text}'
    needs_brackets = current_precedence < parent_precedence or (
        is_right_child and node.operator in {'+', '-'} and current_precedence == parent_precedence
    )
    return f'({text})' if needs_brackets else text


def render_fraction_literal(value: Fraction, *, force_fraction: bool = False) -> str:
    return format_fraction_value(value, force_fraction=force_fraction)


__all__ = [
    'FractionBinaryNode',
    'FractionExpressionNode',
    'FractionExpressionParseResult',
    'FractionLiteralNode',
    'FractionToken',
    'FractionUnaryNode',
    'format_fraction_value',
    'normalize_fraction_expression_source',
    'parse_fraction_expression',
    'render_fraction_expression',
    'render_fraction_literal',
    'tokenize_fraction_expression',
]
