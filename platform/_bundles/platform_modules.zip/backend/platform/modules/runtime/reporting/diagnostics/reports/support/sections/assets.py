from __future__ import annotations

from typing import Any

from backend.handler_source_registry import handler_source_wrapper_spec  # noqa: F401 - keeps registry importable in support context
from backend.legacy_runtime_manifest import REMAINING_RUNTIME_SPECS
from backend.legacy_runtime_module_shard_manifest import LEGACY_RUNTIME_MODULE_SHARD_MANIFEST
from backend.legacy_runtime_shard_manifest import LEGACY_RUNTIME_SHARD_MANIFEST
from backend.runtime_asset_catalog import runtime_asset_catalog_counts
from backend.platform.compat_paths import (
    LEGACY_RUNTIME_MODULE_SHARDS_ROOT,
    LEGACY_RUNTIME_SHARDS_ROOT,
    STATIC_RUNTIME_MODULES_ROOT,
    MATERIALIZED_HANDLER_SOURCE_FALLBACKS_ROOT,
    SHARED_HANDLER_SOURCE_BODIES_ROOT,
    SHARED_RUNTIME_MODULE_BODIES_ROOT,
    SHARED_RUNTIME_SOURCE_BODIES_ROOT,
    SEEDED_RUNTIME_MODULE_FALLBACKS_ROOT,
    SEEDED_RUNTIME_SOURCE_FALLBACKS_ROOT,
    STATIC_HANDLER_SOURCES_ROOT,
    STATIC_RUNTIME_SOURCES_ROOT,
)
from backend.source_audit import count_module_lines, list_module_files


def _effective_module_listing(
    primary_root,
    shared_modules: list[str],
    *,
    primary_label: str,
    shared_label: str,
) -> tuple[str, list[str], dict[str, int]]:
    primary_modules = list_module_files(primary_root)
    primary_line_map = count_module_lines(primary_root)
    if primary_modules:
        return primary_label, primary_modules, primary_line_map
    return shared_label, list(shared_modules), primary_line_map



def build_runtime_asset_sections() -> dict[str, Any]:
    runtime_shard_dir = LEGACY_RUNTIME_SHARDS_ROOT
    runtime_module_shard_dir = LEGACY_RUNTIME_MODULE_SHARDS_ROOT
    seeded_runtime_source_fallback_dir = SEEDED_RUNTIME_SOURCE_FALLBACKS_ROOT
    seeded_runtime_module_fallback_dir = SEEDED_RUNTIME_MODULE_FALLBACKS_ROOT
    materialized_handler_source_fallback_dir = MATERIALIZED_HANDLER_SOURCE_FALLBACKS_ROOT
    module_specs = [spec for spec in REMAINING_RUNTIME_SPECS if spec.source_kind == 'module']
    blob_specs = [spec for spec in REMAINING_RUNTIME_SPECS if spec.source_kind == 'blob']
    shared_runtime_source_bodies = list_module_files(SHARED_RUNTIME_SOURCE_BODIES_ROOT)
    shared_runtime_module_bodies = list_module_files(SHARED_RUNTIME_MODULE_BODIES_ROOT)
    shared_handler_source_bodies = list_module_files(SHARED_HANDLER_SOURCE_BODIES_ROOT)
    runtime_source_origin, source_modules, prepared_runtime_source_wrapper_line_map = _effective_module_listing(
        STATIC_RUNTIME_SOURCES_ROOT,
        shared_runtime_source_bodies,
        primary_label='static',
        shared_label='static_shared_body_redirect',
    )
    runtime_module_origin, runtime_modules, prepared_runtime_module_wrapper_line_map = _effective_module_listing(
        STATIC_RUNTIME_MODULES_ROOT,
        shared_runtime_module_bodies,
        primary_label='static',
        shared_label='static_shared_body_redirect',
    )
    handler_source_origin, handler_source_modules, prepared_handler_source_wrapper_line_map = _effective_module_listing(
        STATIC_HANDLER_SOURCES_ROOT,
        shared_handler_source_bodies,
        primary_label='static',
        shared_label='static_shared_body_redirect',
    )
    seeded_runtime_source_origin, seeded_runtime_source_fallbacks, materialized_runtime_source_fallback_wrapper_line_map = _effective_module_listing(
        seeded_runtime_source_fallback_dir,
        shared_runtime_source_bodies,
        primary_label='materialized_seeded_fallback',
        shared_label='shared_body_redirect',
    )
    seeded_runtime_module_origin, seeded_runtime_module_fallbacks, materialized_runtime_module_fallback_wrapper_line_map = _effective_module_listing(
        seeded_runtime_module_fallback_dir,
        shared_runtime_module_bodies,
        primary_label='materialized_seeded_fallback',
        shared_label='shared_body_redirect',
    )
    materialized_handler_source_fallback_origin, materialized_handler_source_fallbacks, materialized_handler_source_fallback_wrapper_line_map = _effective_module_listing(
        materialized_handler_source_fallback_dir,
        shared_handler_source_bodies,
        primary_label='materialized_handler_fallback',
        shared_label='shared_body_redirect',
    )
    shard_line_map = count_module_lines(runtime_shard_dir)
    module_shard_line_map = count_module_lines(runtime_module_shard_dir)
    runtime_asset_catalog_summary = runtime_asset_catalog_counts()
    return {
        'remaining_runtime_wrappers': [spec.wrapper_module for spec in REMAINING_RUNTIME_SPECS],
        'remaining_runtime_module_count': len(module_specs),
        'remaining_runtime_modules': [spec.source_ref for spec in module_specs],
        'remaining_runtime_blob_count': len(blob_specs),
        'remaining_runtime_blobs': [spec.source_ref for spec in blob_specs],
        'runtime_asset_catalog_entry_count': runtime_asset_catalog_summary['entry_count'],
        'runtime_asset_catalog_runtime_source_count': runtime_asset_catalog_summary['runtime_source_count'],
        'runtime_asset_catalog_runtime_module_count': runtime_asset_catalog_summary['runtime_module_count'],
        'runtime_asset_catalog_handler_source_count': runtime_asset_catalog_summary['handler_source_count'],
        'runtime_asset_catalog_shared_body_count': runtime_asset_catalog_summary['shared_body_count'],
        'runtime_asset_catalog_apply_wrapper_count': runtime_asset_catalog_summary['apply_wrapper_count'],
        'runtime_asset_catalog_deep_seeded_group_count': runtime_asset_catalog_summary['deep_seeded_group_count'],
        'runtime_asset_catalog_deep_seeded_module_count': runtime_asset_catalog_summary['deep_seeded_module_count'],
        'prepared_runtime_source_module_origin': runtime_source_origin,
        'prepared_runtime_source_module_count': len(source_modules),
        'prepared_runtime_source_modules': source_modules,
        'prepared_runtime_module_origin': runtime_module_origin,
        'prepared_runtime_module_count': len(runtime_modules),
        'prepared_runtime_modules': runtime_modules,
        'runtime_shard_group_count': len(LEGACY_RUNTIME_SHARD_MANIFEST),
        'runtime_shard_total_count': sum(len(value) for value in LEGACY_RUNTIME_SHARD_MANIFEST.values()),
        'runtime_shard_manifest': {key: list(value) for key, value in LEGACY_RUNTIME_SHARD_MANIFEST.items()},
        'runtime_shard_max_lines': max(shard_line_map.values()) if shard_line_map else 0,
        'runtime_shard_modules_by_lines': shard_line_map,
        'runtime_module_shard_group_count': len(LEGACY_RUNTIME_MODULE_SHARD_MANIFEST),
        'runtime_module_shard_total_count': sum(len(value) for value in LEGACY_RUNTIME_MODULE_SHARD_MANIFEST.values()),
        'runtime_module_shard_manifest': {key: list(value) for key, value in LEGACY_RUNTIME_MODULE_SHARD_MANIFEST.items()},
        'runtime_module_shard_max_lines': max(module_shard_line_map.values()) if module_shard_line_map else 0,
        'runtime_module_shard_modules_by_lines': module_shard_line_map,
        'shared_runtime_source_body_count': len(shared_runtime_source_bodies),
        'shared_runtime_source_bodies': shared_runtime_source_bodies,
        'shared_runtime_module_body_count': len(shared_runtime_module_bodies),
        'shared_runtime_module_bodies': shared_runtime_module_bodies,
        'shared_handler_source_body_count': len(shared_handler_source_bodies),
        'shared_handler_source_bodies': shared_handler_source_bodies,
        'shared_runtime_asset_body_module_count': len(shared_runtime_source_bodies) + len(shared_runtime_module_bodies) + len(shared_handler_source_bodies),
        'prepared_runtime_source_wrapper_file_count': len(prepared_runtime_source_wrapper_line_map),
        'prepared_runtime_source_wrapper_max_lines': max(prepared_runtime_source_wrapper_line_map.values()) if prepared_runtime_source_wrapper_line_map else 0,
        'prepared_runtime_module_wrapper_file_count': len(prepared_runtime_module_wrapper_line_map),
        'prepared_runtime_module_wrapper_max_lines': max(prepared_runtime_module_wrapper_line_map.values()) if prepared_runtime_module_wrapper_line_map else 0,
        'prepared_handler_source_wrapper_file_count': len(prepared_handler_source_wrapper_line_map),
        'prepared_handler_source_wrapper_max_lines': max(prepared_handler_source_wrapper_line_map.values()) if prepared_handler_source_wrapper_line_map else 0,
        'materialized_runtime_source_fallback_wrapper_file_count': len(materialized_runtime_source_fallback_wrapper_line_map),
        'materialized_runtime_source_fallback_origin': seeded_runtime_source_origin,
        'materialized_runtime_source_fallback_wrapper_max_lines': max(materialized_runtime_source_fallback_wrapper_line_map.values()) if materialized_runtime_source_fallback_wrapper_line_map else 0,
        'materialized_runtime_module_fallback_wrapper_file_count': len(materialized_runtime_module_fallback_wrapper_line_map),
        'materialized_runtime_module_fallback_origin': seeded_runtime_module_origin,
        'materialized_runtime_module_fallback_wrapper_max_lines': max(materialized_runtime_module_fallback_wrapper_line_map.values()) if materialized_runtime_module_fallback_wrapper_line_map else 0,
        'materialized_handler_source_fallback_wrapper_file_count': len(materialized_handler_source_fallback_wrapper_line_map),
        'materialized_handler_source_fallback_origin': materialized_handler_source_fallback_origin,
        'materialized_handler_source_fallback_wrapper_max_lines': max(materialized_handler_source_fallback_wrapper_line_map.values()) if materialized_handler_source_fallback_wrapper_line_map else 0,
        'handler_source_module_origin': handler_source_origin,
        'handler_source_module_count': len(handler_source_modules),
        'handler_source_modules': handler_source_modules,
        'materialized_handler_source_fallback_count': len(materialized_handler_source_fallbacks),
        'materialized_handler_source_fallbacks': materialized_handler_source_fallbacks,
        'seeded_runtime_source_fallback_count': len(seeded_runtime_source_fallbacks),
        'seeded_runtime_source_fallbacks': seeded_runtime_source_fallbacks,
        'seeded_runtime_module_fallback_count': len(seeded_runtime_module_fallbacks),
        'seeded_runtime_module_fallbacks': seeded_runtime_module_fallbacks,
    }


__all__ = ['build_runtime_asset_sections']
