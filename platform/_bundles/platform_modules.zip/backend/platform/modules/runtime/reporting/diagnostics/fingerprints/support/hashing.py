from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable


def hash_bytes(parts: Iterable[bytes]) -> str:
    digest = hashlib.sha256()
    for part in parts:
        digest.update(part)
    return digest.hexdigest()


def fingerprint_files(paths: Iterable[Path], *, root: Path) -> dict[str, object]:
    sorted_paths = sorted({path.resolve() for path in paths})
    payload_parts: list[bytes] = []
    items: list[dict[str, object]] = []
    for path in sorted_paths:
        relative = str(path.relative_to(root.parent))
        data = path.read_bytes()
        payload_parts.append(relative.encode('utf-8'))
        payload_parts.append(b'\0')
        payload_parts.append(data)
        items.append({'path': relative, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    return {
        'file_count': len(items),
        'sha256': hash_bytes(payload_parts),
        'files': items,
    }


__all__ = ['fingerprint_files', 'hash_bytes']
