from __future__ import annotations

import importlib
from pathlib import Path
from zipfile import ZipFile

from backend.platform.layout_specs.shared import module_path_entries
from backend.source_audit import list_module_files, path_line_count, path_size_bytes

REGISTRY_HELPER_MODULES = [
    'candidate_chain_exports.py',
    'candidate_chain_specs.py',
    'handler_proxy_factory.py',
    'handler_source_registry.py',
    'runtime_asset_catalog.py',
    'runtime_asset_catalog_audit.py',
    'runtime_candidate_registry.py',
    'runtime_namespace_adoption.py',
    'runtime_namespace_factory.py',
    'static_candidate_exports.py',
]


def pick_module_dir(*candidates: tuple[str, Path]) -> tuple[str, Path]:
    for label, directory in candidates:
        if list_module_files(directory):
            return label, directory
    return candidates[-1]


def imported_module_file(module_name: str) -> str:
    module = importlib.import_module(module_name)
    module_file = getattr(module, '__file__', None)
    if not module_file:
        raise RuntimeError(f'Module {module_name} does not expose __file__')
    return str(module_file).replace('\\', '/')


def imported_module_line_count(module_name: str) -> int:
    return path_line_count(imported_module_file(module_name))


def imported_module_size_bytes(module_name: str) -> int:
    return path_size_bytes(imported_module_file(module_name))


def _zip_parts(path: str) -> tuple[Path, str] | None:
    path = path.replace('\\', '/')
    marker = '.zip/'
    index = path.find(marker)
    if index < 0:
        return None
    zip_file = Path(path[: index + 4])
    if not zip_file.is_file():
        return None
    return zip_file, path[index + len(marker):].strip('/')


def list_named_module_files(module_paths: list[Path], names: list[str]) -> list[str]:
    available = set()
    for directory in module_paths:
        for entry in module_path_entries(directory):
            zip_parts = _zip_parts(entry)
            if zip_parts is None:
                entry_path = Path(entry)
                if not entry_path.exists():
                    continue
                for name in names:
                    if (entry_path / name).exists():
                        available.add(name)
                continue
            zip_file, inner_root = zip_parts
            prefix = inner_root.rstrip('/') + '/'
            with ZipFile(zip_file) as archive:
                name_set = set(archive.namelist())
                for name in names:
                    if prefix + name in name_set:
                        available.add(name)
    return sorted(available)


__all__ = [
    'REGISTRY_HELPER_MODULES',
    'imported_module_file',
    'imported_module_line_count',
    'imported_module_size_bytes',
    'list_named_module_files',
    'pick_module_dir',
]
