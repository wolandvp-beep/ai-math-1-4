from __future__ import annotations

from pathlib import Path
from typing import Any

from backend.runtime_asset_catalog_audit import build_runtime_asset_catalog_audit
from backend.runtime_fingerprint import build_runtime_fingerprint
from backend.runtime_manifest_audit import build_runtime_manifest_audit
from backend.runtime_namespace_audit import build_runtime_namespace_audit
from backend.runtime_symbol_inventory import build_runtime_symbol_inventory
from backend.source_audit import (
    find_explicit_exec_sites,
    find_init_call_sites,
    find_inert_init_files,
    find_unresolved_relative_import_sites,
    largest_python_files,
    list_init_files,
    list_namespace_package_dirs,
    list_python_files,
)
from backend.platform.compat_paths import (
    CORE_ROOT,
    FEATURES_ROOT,
    HEALTH_ROOT,
    LEGACY_ROOT,
    RUNTIME_ASSETS_ROOT,
    RUNTIME_COMPAT_DIRS,
    RUNTIME_ROOT,
)
from backend.platform.modules.runtime.reporting.diagnostics.reports.support.runtime_report_paths import (
    REGISTRY_HELPER_MODULES,
    list_named_module_files,
)


PACKAGE_BOOTSTRAP_GROUPS = {
    'runtime_assets': RUNTIME_ASSETS_ROOT,
    'runtime': RUNTIME_ROOT,
    'health': HEALTH_ROOT,
    'legacy': LEGACY_ROOT,
    'core': CORE_ROOT,
    'features': FEATURES_ROOT,
}


def build_runtime_scan_sections(platform_root: Path) -> dict[str, Any]:
    registry_helper_files = list_named_module_files([Path(path) for path in RUNTIME_COMPAT_DIRS], REGISTRY_HELPER_MODULES)
    python_files = list_python_files(platform_root)
    init_files = list_init_files(platform_root)
    inert_init_files = find_inert_init_files(platform_root)
    namespace_package_dirs = list_namespace_package_dirs(platform_root)
    explicit_exec_sites = find_explicit_exec_sites(platform_root)
    unresolved_relative_import_sites = find_unresolved_relative_import_sites(platform_root)
    platform_package_bootstrap_init_sites = find_init_call_sites(platform_root, 'bootstrap_package(')
    platform_legacy_extend_module_path_init_sites = find_init_call_sites(platform_root, 'extend_module_path(__path__')
    package_bootstrap_group_counts = {
        name: len(find_init_call_sites(root, 'bootstrap_package('))
        for name, root in PACKAGE_BOOTSTRAP_GROUPS.items()
    }
    namespace_audit = build_runtime_namespace_audit(platform_root)
    manifest_audit = build_runtime_manifest_audit(platform_root)
    runtime_fingerprint = build_runtime_fingerprint(platform_root)
    runtime_symbol_inventory = build_runtime_symbol_inventory()
    runtime_asset_catalog_audit = build_runtime_asset_catalog_audit()
    return {
        'platform_python_file_count': len(python_files),
        'platform_init_file_count': len(init_files),
        'platform_inert_init_file_count': len(inert_init_files),
        'platform_inert_init_files': inert_init_files,
        'platform_namespace_package_dir_count': len(namespace_package_dirs),
        'platform_namespace_package_dirs': namespace_package_dirs,
        'registry_helper_module_count': len(registry_helper_files),
        'registry_helper_modules': registry_helper_files,
        'explicit_exec_site_count': len(explicit_exec_sites),
        'explicit_exec_sites': explicit_exec_sites,
        'unresolved_relative_import_site_count': len(unresolved_relative_import_sites),
        'unresolved_relative_import_sites': unresolved_relative_import_sites,
        'platform_package_bootstrap_init_site_count': len(platform_package_bootstrap_init_sites),
        'platform_legacy_extend_module_path_init_site_count': len(platform_legacy_extend_module_path_init_sites),
        'package_bootstrap_group_init_counts': package_bootstrap_group_counts,
        'runtime_namespace_audit': namespace_audit,
        'runtime_manifest_audit': manifest_audit,
        'runtime_asset_catalog_audit': runtime_asset_catalog_audit,
        'runtime_fingerprint': runtime_fingerprint,
        'runtime_symbol_inventory': runtime_symbol_inventory,
        'largest_backend_files': largest_python_files(platform_root, limit=12),
    }


__all__ = ['PACKAGE_BOOTSTRAP_GROUPS', 'build_runtime_scan_sections']
