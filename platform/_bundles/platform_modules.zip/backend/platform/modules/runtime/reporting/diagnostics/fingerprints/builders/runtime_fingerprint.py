from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from backend.source_audit import list_python_files
from backend.platform.modules.runtime.reporting.diagnostics.fingerprints.support.filters import (
    handler_source_related_files,
    runtime_related_files,
)
from backend.platform.modules.runtime.reporting.diagnostics.fingerprints.support.hashing import fingerprint_files


@lru_cache(maxsize=1)
def build_runtime_fingerprint(base_dir: Path) -> dict[str, object]:
    backend_files = list_python_files(base_dir)
    runtime_files = runtime_related_files(backend_files)
    handler_source_files = handler_source_related_files(backend_files)
    return {
        'backend': fingerprint_files(backend_files, root=base_dir),
        'runtime_related': fingerprint_files(runtime_files, root=base_dir),
        'handler_sources': fingerprint_files(handler_source_files, root=base_dir),
    }


__all__ = ['build_runtime_fingerprint', 'fingerprint_files']
