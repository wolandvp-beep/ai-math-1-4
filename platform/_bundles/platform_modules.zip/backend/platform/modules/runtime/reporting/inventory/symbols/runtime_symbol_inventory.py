from __future__ import annotations

from functools import lru_cache
from typing import Any

from backend.legacy_bridge import expose_core


INTERESTING_SYMBOLS = (
    'build_explanation',
    'build_explanation_local_first',
    '_extract_count_question_noun',
    '_detect_question_unit',
    '_detailed_maybe_enrich_answer',
    '_try_reverse_transfer_problem',
    '_try_reverse_dual_subject_total_after_changes_problem',
)


@lru_cache(maxsize=1)
def build_runtime_symbol_inventory() -> dict[str, Any]:
    core = expose_core()
    symbols: list[dict[str, str]] = []
    for name in INTERESTING_SYMBOLS:
        value = getattr(core, name, None)
        symbols.append({
            'name': name,
            'module': getattr(value, '__module__', ''),
            'qualname': getattr(value, '__qualname__', ''),
            'callable': str(callable(value)).lower(),
        })
    return {
        'symbol_count': len(symbols),
        'symbols': symbols,
    }


__all__ = ['INTERESTING_SYMBOLS', 'build_runtime_symbol_inventory']
