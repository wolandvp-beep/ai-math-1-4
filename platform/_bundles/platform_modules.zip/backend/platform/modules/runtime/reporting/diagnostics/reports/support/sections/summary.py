from __future__ import annotations

from pathlib import Path
from typing import Any

from backend.legacy_runtime_pipeline import RUNTIME_PIPELINE
from backend.runtime_namespace_adoption import RUNTIME_IMPORT_APPLY_MODE

from .assets import build_runtime_asset_sections
from .scans import PACKAGE_BOOTSTRAP_GROUPS, build_runtime_scan_sections


def build_runtime_report_sections(platform_root: Path) -> dict[str, Any]:
    return {
        'runtime_import_apply_mode': RUNTIME_IMPORT_APPLY_MODE,
        'runtime_pipeline': [name for name, _ in RUNTIME_PIPELINE],
        **build_runtime_asset_sections(),
        **build_runtime_scan_sections(platform_root),
    }


__all__ = ['PACKAGE_BOOTSTRAP_GROUPS', 'build_runtime_report_sections']
