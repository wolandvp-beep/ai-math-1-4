from __future__ import annotations

from functools import lru_cache
from typing import Any

from backend.legacy_bridge import expose_core
from backend.platform import PLATFORM_ROOT as COMPAT_PLATFORM_ROOT
from backend.source_audit import find_inert_init_files, list_init_files, list_non_cache_files, list_python_files
from backend.platform.modules.runtime.reporting.diagnostics.reports.support.runtime_report_paths import imported_module_line_count, imported_module_size_bytes
from backend.platform.modules.runtime.reporting.diagnostics.reports.support.runtime_report_sections import build_runtime_report_sections


@lru_cache(maxsize=1)
def build_runtime_report() -> dict[str, Any]:
    core = expose_core()
    platform_root = COMPAT_PLATFORM_ROOT
    backend_root = platform_root.parent
    frontend_root = backend_root.parent / 'frontend'
    report_sections = build_runtime_report_sections(platform_root)
    return {
        'backend_python_file_count': len(list_python_files(backend_root)),
        'backend_non_cache_file_count': len(list_non_cache_files(backend_root)),
        'backend_init_file_count': len(list_init_files(backend_root)),
        'backend_inert_init_file_count': len(find_inert_init_files(backend_root)),
        'frontend_non_cache_file_count': len(list_non_cache_files(frontend_root)) if frontend_root.is_dir() else 0,
        'legacy_core_lines': imported_module_line_count('backend.legacy_core'),
        'legacy_core_size_bytes': imported_module_size_bytes('backend.legacy_core'),
        'build_explanation_module': getattr(core.build_explanation, '__module__', ''),
        'build_explanation_local_first_module': getattr(core.build_explanation_local_first, '__module__', ''),
        'detailed_enrichment_module': getattr(core._detailed_maybe_enrich_answer, '__module__', ''),
        **report_sections,
    }


__all__ = ['build_runtime_report']
