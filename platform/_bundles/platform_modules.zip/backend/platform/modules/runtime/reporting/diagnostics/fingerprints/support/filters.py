from __future__ import annotations

from pathlib import Path


def runtime_related_files(backend_files: list[Path]) -> list[Path]:
    return [
        path
        for path in backend_files
        if 'legacy_runtime_' in path.name
        or 'legacy_runtime_' in str(path)
        or 'static_runtime_sources' in path.parts
        or 'static_runtime_modules' in path.parts
        or 'seeded_runtime_source_fallbacks' in path.parts
        or 'seeded_runtime_module_fallbacks' in path.parts
        or 'shared_bodies' in path.parts and 'runtime_sources' in path.parts
        or 'shared_bodies' in path.parts and 'runtime_modules' in path.parts
        or path.name in {'static_module_bootstrap.py', 'runtime_namespace_adoption.py', 'runtime_namespace_factory.py'}
    ]


def handler_source_related_files(backend_files: list[Path]) -> list[Path]:
    return [
        path
        for path in backend_files
        if 'legacy_handler_sources' in path.parts
        or 'static_handler_sources' in path.parts
        or 'materialized_handler_source_fallbacks' in path.parts
        or 'seeded_handler_source_fallbacks' in path.parts
        or 'shared_bodies' in path.parts and 'handler_sources' in path.parts
        or path.name in {
            'candidate_chain_exports.py',
            'candidate_chain_specs.py',
            'handler_proxy_factory.py',
            'handler_source_registry.py',
            'runtime_candidate_registry.py',
            'runtime_namespace_adoption.py',
            'runtime_namespace_factory.py',
            'static_candidate_exports.py',
            'legacy_module_namespace_runtime.py',
        }
    ]


__all__ = ['handler_source_related_files', 'runtime_related_files']
