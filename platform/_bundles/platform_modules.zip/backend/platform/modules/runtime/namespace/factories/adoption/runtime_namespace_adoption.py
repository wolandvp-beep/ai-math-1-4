from __future__ import annotations

import inspect
from functools import lru_cache
from importlib import import_module
from types import FunctionType
from typing import Any, Mapping, MutableMapping

from backend.legacy_namespace_filters import should_export_runtime_name, should_seed_runtime_name


RUNTIME_IMPORT_APPLY_MODE = 'isolated_effective_namespace'


def adopt_function_to_namespace(
    value: FunctionType,
    namespace: dict[str, Any],
    module_name: str,
) -> FunctionType:
    rebound = FunctionType(
        value.__code__,
        namespace,
        name=value.__name__,
        argdefs=value.__defaults__,
        closure=value.__closure__,
    )
    rebound.__kwdefaults__ = getattr(value, '__kwdefaults__', None)
    rebound.__annotations__ = dict(getattr(value, '__annotations__', {}))
    rebound.__dict__.update(getattr(value, '__dict__', {}))
    rebound.__doc__ = value.__doc__
    rebound.__qualname__ = value.__qualname__
    rebound.__module__ = module_name
    return rebound


def export_names_from_mapping(
    target_namespace: MutableMapping[str, Any],
    source_mapping: Mapping[str, Any],
) -> None:
    for key, value in source_mapping.items():
        if should_export_runtime_name(key):
            target_namespace[key] = value


def adopt_exported_names_from_mapping(
    target_namespace: MutableMapping[str, Any],
    source_mapping: Mapping[str, Any],
) -> None:
    module_name = str(source_mapping.get('__name__', ''))
    for key, value in source_mapping.items():
        if not should_export_runtime_name(key):
            continue
        if inspect.isfunction(value) and getattr(value, '__module__', '') == module_name:
            target_namespace[key] = adopt_function_to_namespace(value, target_namespace, module_name)
        else:
            target_namespace[key] = value


@lru_cache(maxsize=None)
def load_imported_module_state(module_name: str):
    module = import_module(module_name)
    original_names = frozenset(vars(module).keys())
    seeded_snapshot = dict(getattr(module, '__STATIC_BOOTSTRAP_SEEDED_SNAPSHOT__', {}))
    bootstrap_seedable_names = frozenset(
        key
        for key, value in seeded_snapshot.items()
        if module.__dict__.get(key) is value
    )
    return module, original_names, bootstrap_seedable_names


def build_effective_import_namespace(
    module_name: str,
    seed_namespace: Mapping[str, Any],
) -> dict[str, Any]:
    module, original_names, bootstrap_seedable_names = load_imported_module_state(module_name)
    effective_namespace: dict[str, Any] = dict(vars(module))
    effective_namespace.setdefault('__builtins__', __builtins__)

    for key, value in seed_namespace.items():
        if not should_seed_runtime_name(key):
            continue
        if key not in original_names or key in bootstrap_seedable_names:
            effective_namespace[key] = value

    module_dict = vars(module)
    module_defined_functions = {
        key: value
        for key, value in module_dict.items()
        if inspect.isfunction(value) and getattr(value, '__module__', '') == module.__name__
    }
    for key, value in module_defined_functions.items():
        effective_namespace[key] = adopt_function_to_namespace(value, effective_namespace, module.__name__)

    return effective_namespace


def export_import_candidate_namespace(
    target_namespace: MutableMapping[str, Any],
    module_name: str,
) -> dict[str, Any]:
    effective_namespace = build_effective_import_namespace(module_name, target_namespace)
    export_names_from_mapping(target_namespace, effective_namespace)
    return effective_namespace


__all__ = [
    'RUNTIME_IMPORT_APPLY_MODE',
    'adopt_exported_names_from_mapping',
    'adopt_function_to_namespace',
    'build_effective_import_namespace',
    'export_import_candidate_namespace',
    'export_names_from_mapping',
    'load_imported_module_state',
]
