from __future__ import annotations

from collections.abc import Iterable, Mapping
from functools import lru_cache
from typing import Any, Callable

from backend.legacy_seeded_module_loader import execute_seeded_module
from backend.runtime_namespace_adoption import export_import_candidate_namespace


def build_core_seeded_namespace(
    extra_seed: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    from backend.legacy_bridge import expose_core

    core = expose_core()
    namespace = dict(vars(core))
    namespace.setdefault('__builtins__', __builtins__)
    if extra_seed:
        namespace.update(extra_seed)
    return namespace


def _iter_module_candidates(module_name: str | Iterable[str]) -> tuple[str, ...]:
    if isinstance(module_name, str):
        return (module_name,)
    return tuple(str(name) for name in module_name)


def apply_import_candidate_namespace(
    namespace: dict[str, Any],
    module_name: str | Iterable[str],
    *,
    seeded_fallback_module_name: str | None = None,
) -> None:
    candidates = _iter_module_candidates(module_name)
    last_error: Exception | None = None
    for candidate in candidates:
        try:
            export_import_candidate_namespace(namespace, candidate)
            return
        except Exception as exc:  # pragma: no cover - compatibility fallback path
            last_error = exc
    fallback_name = seeded_fallback_module_name
    if fallback_name is None and len(candidates) == 1:
        fallback_name = candidates[0]
    if fallback_name is not None:
        execute_seeded_module(namespace, fallback_name, runtime_module_name=f'{fallback_name}.__seeded__')
        return
    if last_error is not None:
        raise last_error
    raise ModuleNotFoundError('No runtime module candidates were provided')


def build_module_namespace_loader(
    module_name: str | Iterable[str],
    *,
    seeded_fallback_module_name: str | None = None,
) -> Callable[[], dict[str, object]]:
    candidates = _iter_module_candidates(module_name)

    @lru_cache(maxsize=1)
    def _loader() -> dict[str, object]:
        namespace = build_core_seeded_namespace()
        apply_import_candidate_namespace(
            namespace,
            candidates,
            seeded_fallback_module_name=seeded_fallback_module_name,
        )
        return namespace

    return _loader


__all__ = [
    'apply_import_candidate_namespace',
    'build_core_seeded_namespace',
    'build_module_namespace_loader',
]
