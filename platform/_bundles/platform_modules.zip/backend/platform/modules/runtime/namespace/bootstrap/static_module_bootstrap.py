from __future__ import annotations

from collections.abc import MutableMapping
from typing import Any

import importlib
import sys
from backend.legacy_namespace_filters import should_seed_runtime_name


def seed_static_module_globals(module_globals: MutableMapping[str, Any]) -> dict[str, Any]:
    """Seed a static materialized module with legacy core globals.

    The returned mapping captures only names that were injected by the
    bootstrap layer *before* the module's own definitions executed. Runtime
    loaders may later overwrite the subset that still points to those exact
    injected objects, while leaving true module-defined symbols intact.
    """

    module_globals.setdefault('__builtins__', __builtins__)
    core = sys.modules.get('backend.legacy_core') or importlib.import_module('backend.legacy_core')
    seeded: dict[str, Any] = {}
    for key, value in vars(core).items():
        if not should_seed_runtime_name(key):
            continue
        if key in module_globals:
            continue
        module_globals[key] = value
        seeded[key] = value
    return seeded


__all__ = ['seed_static_module_globals']
