from __future__ import annotations

from typing import Callable


def _clear_if_present(func: object) -> bool:
    clear = getattr(func, 'cache_clear', None)
    if callable(clear):
        clear()
        return True
    return False


def clear_runtime_caches() -> dict[str, bool]:
    from backend.golden_output_suite import _run_golden_output_suite_cached
    from backend.snapshot_output_suite import _run_snapshot_output_suite_cached
    from backend.health_case_matrix import _build_health_case_matrix_cached
    from backend.determinism_suite import run_determinism_suite
    from backend.cache_consistency_audit import run_cache_consistency_audit
    from backend.runtime_contract_suite import _run_runtime_contract_suite_cached
    from backend.runtime_fingerprint import build_runtime_fingerprint
    from backend.runtime_manifest_audit import build_runtime_manifest_audit
    from backend.runtime_namespace_audit import build_runtime_namespace_audit
    from backend.runtime_report import build_runtime_report
    from backend.runtime_symbol_inventory import build_runtime_symbol_inventory
    from backend.runtime_namespace_adoption import load_imported_module_state
    from backend.handler_proxy_factory import get_handler_namespace_loader
    from backend.legacy_build_runtime import load_prepatch_build_namespace
    from backend.legacy_cascade_runtime import load_prepatch_cascade_namespace
    from backend.legacy_remaining_runtime_chain import _load_apply
    from backend.legacy_source_exec_runtime import compile_legacy_source
    from backend.legacy_source_loader import load_legacy_source

    targets = {
        'health_case_matrix': _build_health_case_matrix_cached,
        'golden_output_suite': _run_golden_output_suite_cached,
        'snapshot_output_suite': _run_snapshot_output_suite_cached,
        'determinism_suite': run_determinism_suite,
        'cache_consistency_audit': run_cache_consistency_audit,
        'runtime_contract_suite': _run_runtime_contract_suite_cached,
        'runtime_report': build_runtime_report,
        'runtime_manifest_audit': build_runtime_manifest_audit,
        'runtime_namespace_audit': build_runtime_namespace_audit,
        'runtime_fingerprint': build_runtime_fingerprint,
        'runtime_symbol_inventory': build_runtime_symbol_inventory,
        'runtime_import_module_state': load_imported_module_state,
        'handler_namespace_loader': get_handler_namespace_loader,
        'prepatch_build_namespace': load_prepatch_build_namespace,
        'prepatch_cascade_namespace': load_prepatch_cascade_namespace,
        'remaining_runtime_apply_loader': _load_apply,
        'compile_legacy_source': compile_legacy_source,
        'load_legacy_source': load_legacy_source,
    }
    return {name: _clear_if_present(func) for name, func in targets.items()}


__all__ = ['clear_runtime_caches']
