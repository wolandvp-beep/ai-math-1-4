from __future__ import annotations

import ast
from pathlib import Path
from typing import Any, Iterable
from zipfile import ZipFile

from backend.platform.layout_specs.shared import module_path_entries


_INERT_INIT_SOURCE = 'from __future__ import annotations'


def _zip_parts(path: Path | str) -> tuple[Path, str] | None:
    path_str = str(path).replace('\\', '/')
    marker = '.zip/'
    index = path_str.find(marker)
    if index < 0:
        return None
    zip_file = Path(path_str[: index + 4])
    inner_path = path_str[index + len(marker):].strip('/')
    if not zip_file.is_file():
        return None
    return zip_file, inner_path


def _path_entries(path: Path | str) -> list[str]:
    entries = module_path_entries(path)
    if entries:
        return entries
    return [str(path)]


def _iter_zip_python_names(zip_file: Path, inner_root: str) -> Iterable[str]:
    prefix = inner_root.rstrip('/') + '/'
    with ZipFile(zip_file) as archive:
        for name in archive.namelist():
            if not name.startswith(prefix):
                continue
            if not name.endswith('.py'):
                continue
            if '/__pycache__/' in name or name.startswith('__pycache__/'):
                continue
            yield name


def read_text_any(path: Path | str, *, encoding: str = 'utf-8') -> str:
    zip_parts = _zip_parts(path)
    if zip_parts is None:
        return Path(path).read_text(encoding=encoding)
    zip_file, inner_path = zip_parts
    with ZipFile(zip_file) as archive:
        return archive.read(inner_path).decode(encoding)


def path_line_count(path: Path | str) -> int:
    return sum(1 for _ in read_text_any(path).splitlines())


def path_size_bytes(path: Path | str) -> int:
    zip_parts = _zip_parts(path)
    if zip_parts is None:
        return Path(path).stat().st_size
    zip_file, inner_path = zip_parts
    with ZipFile(zip_file) as archive:
        return archive.getinfo(inner_path).file_size


def list_non_cache_files(base_dir: Path) -> list[Path]:
    return sorted(path for path in base_dir.rglob('*') if path.is_file() and '__pycache__' not in path.parts)


def list_python_files(base_dir: Path) -> list[Path]:
    return sorted(path for path in base_dir.rglob('*.py') if '__pycache__' not in path.parts)


def list_init_files(base_dir: Path) -> list[Path]:
    return sorted(path for path in base_dir.rglob('__init__.py') if '__pycache__' not in path.parts)


def find_inert_init_files(base_dir: Path) -> list[str]:
    hits: list[str] = []
    for path in list_init_files(base_dir):
        try:
            source = path.read_text(encoding='utf-8').strip()
        except OSError:
            continue
        if source == _INERT_INIT_SOURCE:
            hits.append(str(path.relative_to(base_dir.parent)))
    return sorted(hits)


def list_namespace_package_dirs(base_dir: Path) -> list[str]:
    hits: list[str] = []
    for directory in sorted(path for path in base_dir.rglob('*') if path.is_dir() and '__pycache__' not in path.parts):
        if (directory / '__init__.py').exists():
            continue
        has_python_descendant = any(path.suffix == '.py' for path in directory.rglob('*.py'))
        if has_python_descendant:
            hits.append(str(directory.relative_to(base_dir.parent)))
    return hits


def find_explicit_exec_sites(base_dir: Path) -> list[str]:
    hits: list[str] = []
    for path in list_python_files(base_dir):
        try:
            source = path.read_text(encoding='utf-8')
        except OSError:
            continue
        try:
            tree = ast.parse(source, filename=str(path))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'exec':
                hits.append(f'{path.relative_to(base_dir.parent)}:{node.lineno}')
    return hits


def list_module_files(directory: Path | str) -> list[str]:
    hits: set[str] = set()
    for entry in _path_entries(directory):
        zip_parts = _zip_parts(entry)
        if zip_parts is None:
            entry_path = Path(entry)
            if not entry_path.is_dir():
                continue
            for path in entry_path.rglob('*.py'):
                if path.name == '__init__.py' or '__pycache__' in path.parts:
                    continue
                hits.add(str(path.relative_to(entry_path)))
            continue
        zip_file, inner_root = zip_parts
        prefix = inner_root.rstrip('/') + '/'
        for name in _iter_zip_python_names(zip_file, inner_root):
            relative_name = name[len(prefix):]
            if relative_name.endswith('/__init__.py') or relative_name == '__init__.py':
                continue
            hits.add(relative_name)
    return sorted(hits)


def count_module_lines(directory: Path | str) -> dict[str, int]:
    result: dict[str, int] = {}
    for entry in _path_entries(directory):
        zip_parts = _zip_parts(entry)
        if zip_parts is None:
            entry_path = Path(entry)
            if not entry_path.is_dir():
                continue
            for path in sorted(entry_path.rglob('*.py')):
                if path.name == '__init__.py':
                    continue
                result[str(path.relative_to(entry_path))] = sum(1 for _ in path.open(encoding='utf-8'))
            continue
        zip_file, inner_root = zip_parts
        prefix = inner_root.rstrip('/') + '/'
        with ZipFile(zip_file) as archive:
            for name in sorted(_iter_zip_python_names(zip_file, inner_root)):
                relative_name = name[len(prefix):]
                if relative_name.endswith('/__init__.py') or relative_name == '__init__.py':
                    continue
                result[relative_name] = len(archive.read(name).decode('utf-8').splitlines())
    return result


def find_init_call_sites(base_dir: Path, needle: str) -> list[str]:
    hits: list[str] = []
    for path in list_init_files(base_dir):
        try:
            source = path.read_text(encoding='utf-8')
        except OSError:
            continue
        if needle in source:
            hits.append(str(path.relative_to(base_dir.parent)))
    return sorted(hits)


def largest_python_files(base_dir: Path, *, limit: int = 10) -> list[dict[str, int | str]]:
    files = []
    for path in list_python_files(base_dir):
        try:
            lines = sum(1 for _ in path.open(encoding='utf-8'))
        except OSError:
            continue
        files.append({'path': str(path.relative_to(base_dir.parent)), 'lines': lines})
    files.sort(key=lambda item: int(item['lines']), reverse=True)
    return files[:limit]


def _target_exists(target: Path) -> bool:
    return target.with_suffix('.py').exists() or target.joinpath('__init__.py').exists() or target.is_dir()


def _relative_import_target_exists(path: Path, node: ast.ImportFrom) -> bool:
    package_dir = path.parent
    base_dir = package_dir
    for _ in range(node.level - 1):
        base_dir = base_dir.parent
    if node.module is None:
        for alias in node.names:
            if not _target_exists(base_dir / alias.name):
                return False
        return True
    return _target_exists(base_dir.joinpath(*node.module.split('.')))


DEFAULT_RELATIVE_IMPORT_AUDIT_ALLOWLIST = {
    'backend/main.py',
    'backend/run_backend_regressions.py',
}


def find_unresolved_relative_import_sites(
    base_dir: Path,
    *,
    allowlist: set[str] | None = None,
) -> list[dict[str, Any]]:
    allowed = set(DEFAULT_RELATIVE_IMPORT_AUDIT_ALLOWLIST if allowlist is None else allowlist)
    hits: list[dict[str, Any]] = []
    for path in list_python_files(base_dir):
        relative_path = str(path.relative_to(base_dir.parent))
        if relative_path in allowed:
            continue
        try:
            source = path.read_text(encoding='utf-8')
        except OSError:
            continue
        try:
            tree = ast.parse(source, filename=str(path))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.ImportFrom) or node.level < 1:
                continue
            if _relative_import_target_exists(path, node):
                continue
            hits.append({
                'path': relative_path,
                'line': int(node.lineno),
                'import': f"{'.' * node.level}{node.module or ''}",
            })
    return sorted(hits, key=lambda item: (str(item['path']), int(item['line']), str(item['import'])))


__all__ = [
    'DEFAULT_RELATIVE_IMPORT_AUDIT_ALLOWLIST',
    'count_module_lines',
    'find_explicit_exec_sites',
    'find_init_call_sites',
    'find_inert_init_files',
    'find_unresolved_relative_import_sites',
    'largest_python_files',
    'list_init_files',
    'list_module_files',
    'list_namespace_package_dirs',
    'list_non_cache_files',
    'list_python_files',
    'path_line_count',
    'path_size_bytes',
    'read_text_any',
]
