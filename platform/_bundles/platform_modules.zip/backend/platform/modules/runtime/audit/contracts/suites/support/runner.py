from __future__ import annotations

from functools import lru_cache
from typing import Any

from backend.runtime_report import build_runtime_report

from .definitions import CONTRACTS


def build_runtime_contract_suite(report: dict[str, Any]) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    passed = 0
    for name, producer, predicate in CONTRACTS:
        try:
            value = producer(report)
            ok = bool(predicate(value))
            issue = '' if ok else f'unexpected value: {value!r}'
        except Exception as exc:  # pragma: no cover - defensive contract harness
            ok = False
            value = None
            issue = f'{type(exc).__name__}: {exc}'
        if ok:
            passed += 1
        results.append({
            'name': name,
            'ok': ok,
            'issue': issue,
            'value_preview': str(value)[:200],
        })
    return {
        'passed': passed,
        'total': len(CONTRACTS),
        'all_passed': passed == len(CONTRACTS),
        'results': results,
    }


@lru_cache(maxsize=1)
def _run_runtime_contract_suite_cached() -> dict[str, Any]:
    return build_runtime_contract_suite(build_runtime_report())


def run_runtime_contract_suite(*, runtime_report: dict[str, Any] | None = None) -> dict[str, Any]:
    if runtime_report is not None:
        return build_runtime_contract_suite(runtime_report)
    return _run_runtime_contract_suite_cached()


__all__ = [
    '_run_runtime_contract_suite_cached',
    'build_runtime_contract_suite',
    'run_runtime_contract_suite',
]
