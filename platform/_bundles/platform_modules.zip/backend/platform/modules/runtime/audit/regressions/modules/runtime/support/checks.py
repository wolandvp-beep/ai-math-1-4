from __future__ import annotations

from importlib import import_module

from backend.platform import PLATFORM_ROOT
from backend.platform.compat_paths import (
    SHARED_HANDLER_SOURCE_BODIES_ROOT,
    SHARED_RUNTIME_MODULE_BODIES_ROOT,
    SHARED_RUNTIME_SOURCE_BODIES_ROOT,
)
from backend.legacy_source_exec_runtime import apply_legacy_runtime_module
from backend.runtime_asset_catalog import iter_all_runtime_asset_specs
from backend.runtime_asset_catalog_audit import build_runtime_asset_catalog_audit
from backend.runtime_manifest_audit import build_runtime_manifest_audit
from backend.runtime_namespace_audit import build_runtime_namespace_audit
from backend.runtime_report import build_runtime_report
from backend.source_audit import list_module_files


def runtime_module_seed_isolation_ok() -> bool:
    module_name = 'backend.static_runtime_modules.final_textbook_runtime_module'
    sentinel = 'OAI_RUNTIME_SEED_LEAK_TEST_20260422'
    module = import_module(module_name)
    module.__dict__.pop(sentinel, None)

    namespace = {'__builtins__': __builtins__, sentinel: 'seeded-value'}
    apply_legacy_runtime_module(namespace, module_name)

    helper = namespace.get('_final_20260416_prepare')
    if not callable(helper):
        return False
    return helper.__globals__.get(sentinel) == 'seeded-value' and sentinel not in module.__dict__


def shared_runtime_asset_body_import_smoke() -> int:
    body_roots = [
        ('backend.runtime_assets.shared_bodies.runtime_sources', SHARED_RUNTIME_SOURCE_BODIES_ROOT),
        ('backend.runtime_assets.shared_bodies.runtime_modules', SHARED_RUNTIME_MODULE_BODIES_ROOT),
        ('backend.runtime_assets.shared_bodies.handler_sources', SHARED_HANDLER_SOURCE_BODIES_ROOT),
    ]
    imported = 0
    for module_prefix, root in body_roots:
        for relative_path in list_module_files(root):
            module_name = f"{module_prefix}.{relative_path[:-3].replace('/', '.')}"
            import_module(module_name)
            imported += 1
    return imported


def runtime_asset_catalog_import_smoke() -> int:
    imported = 0
    for spec in iter_all_runtime_asset_specs():
        for module_name in spec.import_smoke_modules:
            import_module(module_name)
            imported += 1
    return imported


def runtime_asset_catalog_lookup_smoke() -> int:
    audit = build_runtime_asset_catalog_audit()
    if audit['duplicate_module_targets']:
        raise AssertionError(f"duplicate runtime asset catalog targets: {audit['duplicate_module_targets']}")
    if audit['missing_static_modules'] or audit['missing_shared_body_modules'] or audit['missing_legacy_wrapper_modules']:
        raise AssertionError('runtime asset catalog audit reported missing core module targets')
    return audit['entry_count']


def direct_shard_import_smoke() -> int:
    from backend.legacy_runtime_module_shard_manifest import LEGACY_RUNTIME_MODULE_SHARD_MANIFEST
    from backend.legacy_runtime_shard_manifest import LEGACY_RUNTIME_SHARD_MANIFEST

    module_names: list[str] = []
    for values in LEGACY_RUNTIME_SHARD_MANIFEST.values():
        module_names.extend(values)
    for values in LEGACY_RUNTIME_MODULE_SHARD_MANIFEST.values():
        module_names.extend(values)

    for module_name in module_names:
        import_module(module_name)
    return len(module_names)


def runtime_report_value(name: str):
    return build_runtime_report()[name]


def runtime_asset_catalog_duplicate_target_count() -> int:
    return len(build_runtime_report()['runtime_asset_catalog_audit']['duplicate_module_targets'])


def manifest_audit_missing_specs() -> list[str]:
    audit = build_runtime_manifest_audit()
    return audit['runtime_shards']['missing_specs'] + audit['runtime_module_shards']['missing_specs']


def manifest_audit_numbering_gaps():
    audit = build_runtime_manifest_audit()
    return list(audit['runtime_shards']['numbering_gaps'].items()) + list(audit['runtime_module_shards']['numbering_gaps'].items())


def namespace_audit_non_magic_dunder_symbols():
    return build_runtime_report()['runtime_namespace_audit']['non_magic_dunder_symbols']


def namespace_audit_scan_count() -> int:
    return build_runtime_namespace_audit(PLATFORM_ROOT)['non_magic_dunder_symbol_count']


__all__ = [
    'direct_shard_import_smoke',
    'manifest_audit_missing_specs',
    'manifest_audit_numbering_gaps',
    'namespace_audit_non_magic_dunder_symbols',
    'namespace_audit_scan_count',
    'runtime_asset_catalog_duplicate_target_count',
    'runtime_asset_catalog_import_smoke',
    'runtime_asset_catalog_lookup_smoke',
    'runtime_module_seed_isolation_ok',
    'runtime_report_value',
    'shared_runtime_asset_body_import_smoke',
]
