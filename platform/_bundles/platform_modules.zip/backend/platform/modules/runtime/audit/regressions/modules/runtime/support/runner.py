from __future__ import annotations

from typing import Any

from .cases import DIRECT_RUNTIME_CASES, expose_core


def run_runtime_module_regressions() -> dict[str, Any]:
    core = expose_core()
    results: list[dict[str, Any]] = []
    passed = 0
    for name, producer, predicate in DIRECT_RUNTIME_CASES:
        try:
            value = producer(core)
            ok = bool(predicate(value))
            issue = '' if ok else f'unexpected value: {value!r}'
        except Exception as exc:
            ok = False
            value = None
            issue = f'{type(exc).__name__}: {exc}'
        if ok:
            passed += 1
        results.append({
            'name': name,
            'ok': ok,
            'issue': issue,
            'value_preview': str(value)[:200],
        })
    return {
        'passed': passed,
        'total': len(DIRECT_RUNTIME_CASES),
        'all_passed': passed == len(DIRECT_RUNTIME_CASES),
        'results': results,
    }


__all__ = ['run_runtime_module_regressions']
