from __future__ import annotations

from typing import Any

from backend.runtime_asset_catalog import iter_all_runtime_asset_specs, runtime_asset_catalog_counts
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.support.audits import (
    catalog_entries,
    duplicate_module_targets,
    missing_spec_targets,
)


def build_runtime_asset_catalog_audit() -> dict[str, Any]:
    specs = iter_all_runtime_asset_specs()
    counts = runtime_asset_catalog_counts()
    return {
        **counts,
        'missing_static_modules': missing_spec_targets(specs, 'static_module'),
        'missing_shared_body_modules': missing_spec_targets(specs, 'shared_body_module'),
        'missing_legacy_wrapper_modules': missing_spec_targets(specs, 'legacy_wrapper_module'),
        'missing_seeded_runtime_fallback_modules': missing_spec_targets(
            specs,
            'seeded_fallback_module',
            kinds=('runtime_source', 'runtime_module'),
        ),
        'missing_materialized_handler_fallback_modules': missing_spec_targets(
            specs,
            'materialized_fallback_module',
            kinds=('handler_source',),
        ),
        'missing_seeded_handler_exec_modules': missing_spec_targets(
            specs,
            'seeded_exec_module',
            kinds=('handler_source',),
        ),
        'duplicate_module_targets': duplicate_module_targets(specs),
        'catalog_entries': catalog_entries(specs),
        'runtime_source_entries': catalog_entries(specs, kind='runtime_source'),
        'runtime_module_entries': catalog_entries(specs, kind='runtime_module'),
        'handler_source_entries': catalog_entries(specs, kind='handler_source'),
    }


__all__ = ['build_runtime_asset_catalog_audit']
