from __future__ import annotations

import ast
from functools import lru_cache
from pathlib import Path
from typing import Any

from backend.legacy_namespace_filters import is_runtime_magic_name
from backend.source_audit import list_python_files


def _dunder_symbols_from_tree(tree: ast.AST) -> set[str]:
    symbols: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            ident = node.id
            if ident.startswith('__') and not is_runtime_magic_name(ident):
                symbols.add(ident)
    return symbols


def scan_non_magic_dunder_symbols(base_dir: Path) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for path in list_python_files(base_dir):
        try:
            tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
        except (OSError, SyntaxError):
            continue
        symbols = sorted(_dunder_symbols_from_tree(tree))
        if symbols:
            result[str(path.relative_to(base_dir.parent))] = symbols
    return result


@lru_cache(maxsize=1)
def build_runtime_namespace_audit(base_dir: Path) -> dict[str, Any]:
    symbol_map = scan_non_magic_dunder_symbols(base_dir)
    unique_symbols = sorted({symbol for values in symbol_map.values() for symbol in values})
    return {
        'non_magic_dunder_symbol_count': len(unique_symbols),
        'non_magic_dunder_symbols': unique_symbols,
        'non_magic_dunder_symbol_files': symbol_map,
    }


__all__ = ['build_runtime_namespace_audit', 'scan_non_magic_dunder_symbols']
