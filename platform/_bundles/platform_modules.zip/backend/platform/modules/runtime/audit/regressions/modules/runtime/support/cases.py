from __future__ import annotations

from backend.legacy_bridge import expose_core
from backend.legacy_build_runtime import get_prepatch_build_explanation
from backend.legacy_cascade_runtime import get_prepatch_detect_question_unit

from .checks import (
    direct_shard_import_smoke,
    manifest_audit_missing_specs,
    manifest_audit_numbering_gaps,
    namespace_audit_non_magic_dunder_symbols,
    namespace_audit_scan_count,
    runtime_asset_catalog_duplicate_target_count,
    runtime_asset_catalog_import_smoke,
    runtime_asset_catalog_lookup_smoke,
    runtime_module_seed_isolation_ok,
    runtime_report_value,
    shared_runtime_asset_body_import_smoke,
)


DIRECT_RUNTIME_CASES = (
    ('final_textbook_fraction_source', lambda core: core._final_20260416_normalize_fraction_expression_source('1/2+3'), lambda value: value == '1/2+3'),
    ('prompt_eval_int_expression', lambda core: core._prompt20260416h_eval_int_expression('2+3'), lambda value: value == 5),
    ('continuation_clean_math_symbols', lambda core: core._cont20260416j_clean_math_symbols('6×7:2'), lambda value: value == '6*7/2'),
    ('extended_compare_handler', lambda core: core._mass20260416x_try_compare('3 ... 5'), lambda value: isinstance(value, str) and '3 < 5' in value),
    ('tail_unit_fraction_handler', lambda core: core._frac20260416_cont_try_simple_unit_fraction('Найти 1/2 от 1 м'), lambda value: isinstance(value, str) and '50 см' in value),
    ('prepatch_build_callable', lambda core: get_prepatch_build_explanation(), lambda value: callable(value)),
    ('prepatch_detect_question_unit', lambda core: get_prepatch_detect_question_unit(), lambda value: callable(value)),
    ('runtime_module_seed_isolation', lambda core: runtime_module_seed_isolation_ok(), lambda value: value is True),
    ('runtime_asset_catalog_lookup_smoke', lambda core: runtime_asset_catalog_lookup_smoke(), lambda value: value >= 17),
    ('runtime_asset_catalog_import_smoke', lambda core: runtime_asset_catalog_import_smoke(), lambda value: value >= 82),
    ('direct_shard_import_smoke', lambda core: direct_shard_import_smoke(), lambda value: value >= 65),
    ('shared_runtime_asset_body_import_smoke', lambda core: shared_runtime_asset_body_import_smoke(), lambda value: value >= 17),
    ('no_explicit_exec_sites', lambda core: runtime_report_value('explicit_exec_site_count'), lambda value: value == 0),
    ('no_platform_legacy_extend_module_path_init_sites', lambda core: runtime_report_value('platform_legacy_extend_module_path_init_site_count'), lambda value: value == 0),
    ('platform_package_bootstrap_init_site_count', lambda core: runtime_report_value('platform_package_bootstrap_init_site_count'), lambda value: value >= 20),
    ('no_platform_inert_init_files', lambda core: runtime_report_value('platform_inert_init_file_count'), lambda value: value == 0),
    ('no_backend_inert_init_files', lambda core: runtime_report_value('backend_inert_init_file_count'), lambda value: value == 0),
    ('backend_python_file_count_small', lambda core: runtime_report_value('backend_python_file_count'), lambda value: value <= 500),
    ('backend_non_cache_file_count_browser_uploadable', lambda core: runtime_report_value('backend_non_cache_file_count'), lambda value: value <= 100),
    ('frontend_non_cache_file_count_browser_uploadable', lambda core: runtime_report_value('frontend_non_cache_file_count'), lambda value: value <= 100),
    ('prepared_runtime_source_wrapper_file_count', lambda core: runtime_report_value('prepared_runtime_source_wrapper_file_count'), lambda value: value == 0),
    ('prepared_runtime_module_wrapper_file_count', lambda core: runtime_report_value('prepared_runtime_module_wrapper_file_count'), lambda value: value == 0),
    ('prepared_handler_source_wrapper_file_count', lambda core: runtime_report_value('prepared_handler_source_wrapper_file_count'), lambda value: value == 0),
    ('materialized_runtime_source_fallback_wrapper_file_count', lambda core: runtime_report_value('materialized_runtime_source_fallback_wrapper_file_count'), lambda value: value == 0),
    ('materialized_runtime_module_fallback_wrapper_file_count', lambda core: runtime_report_value('materialized_runtime_module_fallback_wrapper_file_count'), lambda value: value == 0),
    ('materialized_handler_source_fallback_wrapper_file_count', lambda core: runtime_report_value('materialized_handler_source_fallback_wrapper_file_count'), lambda value: value == 0),
    ('handler_source_module_count', lambda core: runtime_report_value('handler_source_module_count'), lambda value: value >= 9),
    ('runtime_shard_total_count', lambda core: runtime_report_value('runtime_shard_total_count'), lambda value: value >= 54),
    ('runtime_shard_max_lines', lambda core: runtime_report_value('runtime_shard_max_lines'), lambda value: 0 < value <= 905),
    ('runtime_module_shard_total_count', lambda core: runtime_report_value('runtime_module_shard_total_count'), lambda value: value >= 11),
    ('runtime_module_shard_max_lines', lambda core: runtime_report_value('runtime_module_shard_max_lines'), lambda value: 0 < value <= 905),
    ('runtime_asset_catalog_duplicate_module_target_count', lambda core: runtime_asset_catalog_duplicate_target_count(), lambda value: value == 0),
    ('namespace_audit_has_expected_dunder', lambda core: namespace_audit_non_magic_dunder_symbols(), lambda value: '__OAI_20260411_USER_PREV_BUILD_LOCAL_SAFE' in value),
    ('manifest_audit_no_missing_specs', lambda core: manifest_audit_missing_specs(), lambda value: value == []),
    ('manifest_audit_no_numbering_gaps', lambda core: manifest_audit_numbering_gaps(), lambda value: value == []),
    ('namespace_audit_scan_runs', lambda core: namespace_audit_scan_count(), lambda value: value >= 1),
)


__all__ = ['DIRECT_RUNTIME_CASES', 'expose_core']
