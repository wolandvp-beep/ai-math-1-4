from __future__ import annotations

from functools import lru_cache
from importlib.util import find_spec
from pathlib import Path
from typing import Any, Mapping, Sequence

from backend.legacy_runtime_module_shard_manifest import LEGACY_RUNTIME_MODULE_SHARD_MANIFEST
from backend.legacy_runtime_shard_manifest import LEGACY_RUNTIME_SHARD_MANIFEST


def _extract_segment_index(module_name: str) -> int | None:
    try:
        tail = module_name.rsplit('.', 1)[-1]
        if not tail.startswith('segment_'):
            return None
        return int(tail.split('_', 1)[1])
    except Exception:
        return None


def _audit_manifest(manifest: Mapping[str, Sequence[str]]) -> dict[str, Any]:
    duplicate_modules: list[str] = []
    missing_specs: list[str] = []
    numbering_gaps: dict[str, list[int]] = {}
    seen: set[str] = set()
    for key, modules in manifest.items():
        indexes = sorted(index for index in (_extract_segment_index(name) for name in modules) if index is not None)
        if indexes:
            expected = list(range(indexes[0], indexes[-1] + 1))
            gaps = sorted(set(expected) - set(indexes))
            if gaps:
                numbering_gaps[key] = gaps
        for module_name in modules:
            if module_name in seen and module_name not in duplicate_modules:
                duplicate_modules.append(module_name)
            seen.add(module_name)
            if find_spec(module_name) is None:
                missing_specs.append(module_name)
    return {
        'group_count': len(manifest),
        'module_count': sum(len(value) for value in manifest.values()),
        'duplicate_modules': duplicate_modules,
        'missing_specs': missing_specs,
        'numbering_gaps': numbering_gaps,
    }


@lru_cache(maxsize=1)
def build_runtime_manifest_audit(base_dir: Path | None = None) -> dict[str, Any]:
    return {
        'runtime_shards': _audit_manifest(LEGACY_RUNTIME_SHARD_MANIFEST),
        'runtime_module_shards': _audit_manifest(LEGACY_RUNTIME_MODULE_SHARD_MANIFEST),
    }


__all__ = ['build_runtime_manifest_audit']
