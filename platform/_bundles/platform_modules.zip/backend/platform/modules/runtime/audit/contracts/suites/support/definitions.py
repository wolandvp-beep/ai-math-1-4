from __future__ import annotations


CONTRACTS = (
    ('legacy_core_lines_small', lambda report: report['legacy_core_lines'], lambda value: value <= 100),
    ('no_explicit_exec_sites', lambda report: report['explicit_exec_site_count'], lambda value: value == 0),
    ('no_unresolved_relative_import_sites', lambda report: report['unresolved_relative_import_site_count'], lambda value: value == 0),
    ('no_platform_legacy_extend_module_path_init_sites', lambda report: report['platform_legacy_extend_module_path_init_site_count'], lambda value: value == 0),
    ('platform_package_bootstrap_init_site_count', lambda report: report['platform_package_bootstrap_init_site_count'], lambda value: value >= 20),
    ('no_platform_inert_init_files', lambda report: report['platform_inert_init_file_count'], lambda value: value == 0),
    ('no_backend_inert_init_files', lambda report: report['backend_inert_init_file_count'], lambda value: value == 0),
    ('backend_python_file_count_small', lambda report: report['backend_python_file_count'], lambda value: value <= 500),
    ('backend_non_cache_file_count_browser_uploadable', lambda report: report['backend_non_cache_file_count'], lambda value: value <= 100),
    ('frontend_non_cache_file_count_browser_uploadable', lambda report: report['frontend_non_cache_file_count'], lambda value: value <= 100),
    ('build_explanation_module', lambda report: report['build_explanation_module'], lambda value: value == 'backend.legacy_final_patch'),
    ('build_explanation_local_first_module', lambda report: report['build_explanation_local_first_module'], lambda value: value == 'backend.legacy_local_explanation_dispatcher'),
    ('detailed_enrichment_module', lambda report: report['detailed_enrichment_module'], lambda value: value == 'backend.legacy_answer_enrichment'),
    ('runtime_import_apply_mode', lambda report: report['runtime_import_apply_mode'], lambda value: value == 'isolated_effective_namespace'),
    ('runtime_asset_catalog_entry_count', lambda report: report['runtime_asset_catalog_entry_count'], lambda value: value >= 17),
    ('runtime_asset_catalog_runtime_source_count', lambda report: report['runtime_asset_catalog_runtime_source_count'], lambda value: value >= 3),
    ('runtime_asset_catalog_runtime_module_count', lambda report: report['runtime_asset_catalog_runtime_module_count'], lambda value: value >= 5),
    ('runtime_asset_catalog_handler_source_count', lambda report: report['runtime_asset_catalog_handler_source_count'], lambda value: value >= 9),
    ('runtime_asset_catalog_shared_body_count', lambda report: report['runtime_asset_catalog_shared_body_count'], lambda value: value >= 17),
    ('runtime_asset_catalog_apply_wrapper_count', lambda report: report['runtime_asset_catalog_apply_wrapper_count'], lambda value: value >= 5),
    ('runtime_asset_catalog_deep_seeded_module_count', lambda report: report['runtime_asset_catalog_deep_seeded_module_count'], lambda value: value >= 65),
    ('runtime_asset_catalog_duplicate_module_targets', lambda report: report['runtime_asset_catalog_audit']['duplicate_module_targets'], lambda value: value == []),
    ('prepared_runtime_source_module_count', lambda report: report['prepared_runtime_source_module_count'], lambda value: value >= 3),
    ('prepared_runtime_module_count', lambda report: report['prepared_runtime_module_count'], lambda value: value >= 5),
    ('handler_source_module_count', lambda report: report['handler_source_module_count'], lambda value: value >= 9),
    ('shared_runtime_asset_body_module_count', lambda report: report['shared_runtime_asset_body_module_count'], lambda value: value >= 17),
    ('prepared_runtime_source_wrapper_file_count', lambda report: report['prepared_runtime_source_wrapper_file_count'], lambda value: value == 0),
    ('prepared_runtime_module_wrapper_file_count', lambda report: report['prepared_runtime_module_wrapper_file_count'], lambda value: value == 0),
    ('prepared_handler_source_wrapper_file_count', lambda report: report['prepared_handler_source_wrapper_file_count'], lambda value: value == 0),
    ('materialized_runtime_source_fallback_wrapper_file_count', lambda report: report['materialized_runtime_source_fallback_wrapper_file_count'], lambda value: value == 0),
    ('materialized_runtime_module_fallback_wrapper_file_count', lambda report: report['materialized_runtime_module_fallback_wrapper_file_count'], lambda value: value == 0),
    ('materialized_handler_source_fallback_wrapper_file_count', lambda report: report['materialized_handler_source_fallback_wrapper_file_count'], lambda value: value == 0),
    ('runtime_shard_total_count', lambda report: report['runtime_shard_total_count'], lambda value: value >= 54),
    ('runtime_module_shard_total_count', lambda report: report['runtime_module_shard_total_count'], lambda value: value >= 11),
)


__all__ = ['CONTRACTS']
