from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from ...compat_paths import RUNTIME_COMPAT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, RUNTIME_COMPAT_DIRS)

__all__ = ['RUNTIME_COMPAT_DIRS']
