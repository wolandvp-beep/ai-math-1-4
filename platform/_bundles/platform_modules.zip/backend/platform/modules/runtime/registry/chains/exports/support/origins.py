from __future__ import annotations


def infer_origin(module_name: str) -> str:
    if '.static_runtime_sources.' in module_name:
        return 'static'
    if '.static_runtime_modules.' in module_name:
        return 'static'
    if '.static_handler_sources.' in module_name:
        return 'static'
    if '.materialized_handler_source_fallbacks.' in module_name:
        return 'materialized_handler_fallback'
    if '.seeded_runtime_source_fallbacks.' in module_name:
        return 'seeded_materialized_fallback'
    if '.seeded_runtime_module_fallbacks.' in module_name:
        return 'seeded_materialized_fallback'
    if '.seeded_handler_source_fallbacks.' in module_name:
        return 'seeded_exec_fallback'
    if '.legacy_runtime_sources.' in module_name:
        return 'legacy_wrapper'
    if '.legacy_runtime_modules.' in module_name:
        return 'legacy_wrapper'
    if '.legacy_handler_sources.' in module_name:
        return 'legacy_wrapper'
    return f'module:{module_name}'


__all__ = ['infer_origin']
