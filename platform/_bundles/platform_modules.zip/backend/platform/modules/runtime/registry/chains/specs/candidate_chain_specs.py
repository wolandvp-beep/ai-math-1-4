from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CandidateChainSpec:
    name: str
    module_candidates: tuple[str, ...]
    seeded_exec_module: str | None = None
    deep_seeded_modules: tuple[str, ...] = ()
    deep_origin: str = "seeded_shard_fallback"


__all__ = ["CandidateChainSpec"]
