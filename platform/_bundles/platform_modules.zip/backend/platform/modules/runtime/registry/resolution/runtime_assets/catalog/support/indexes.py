from __future__ import annotations

from collections.abc import Iterable

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec


def build_filename_index(specs: Iterable[RuntimeAssetSpec]) -> dict[str, RuntimeAssetSpec]:
    return {spec.filename: spec for spec in specs}


def build_stem_index(specs: Iterable[RuntimeAssetSpec]) -> dict[str, RuntimeAssetSpec]:
    return {spec.stem: spec for spec in specs}


def build_runtime_name_index(specs: Iterable[RuntimeAssetSpec]) -> dict[str, RuntimeAssetSpec]:
    return {str(spec.runtime_name): spec for spec in specs if spec.runtime_name}


__all__ = [
    'build_filename_index',
    'build_runtime_name_index',
    'build_stem_index',
]
