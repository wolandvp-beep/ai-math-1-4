from __future__ import annotations

from collections.abc import MutableMapping
from importlib import import_module
from typing import Any

from backend.legacy_namespace_filters import should_export_runtime_name


def exported_names_from_globals(module_globals: MutableMapping[str, Any]) -> list[str]:
    names = [name for name in module_globals if should_export_runtime_name(name)]
    return sorted(set(names))


def export_module_candidate(module_globals: MutableMapping[str, Any], module_name: str) -> list[str]:
    module = import_module(module_name)
    exported_names: list[str] = []
    for key, value in vars(module).items():
        if not should_export_runtime_name(key):
            continue
        module_globals[key] = value
        exported_names.append(key)
    return sorted(set(exported_names))


__all__ = ['export_module_candidate', 'exported_names_from_globals']
