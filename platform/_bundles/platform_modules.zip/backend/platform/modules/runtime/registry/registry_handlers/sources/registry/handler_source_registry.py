from __future__ import annotations

from backend.runtime_asset_catalog import handler_source_asset_spec
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.support.accessors import (
    candidate_chain_spec_from_asset,
    module_name,
)


def static_handler_source_module_name(source_name: str) -> str:
    return module_name(handler_source_asset_spec(source_name), 'static_module')


def materialized_handler_source_fallback_module_name(source_name: str) -> str:
    return module_name(handler_source_asset_spec(source_name), 'materialized_fallback_module')


def legacy_handler_source_wrapper_module_name(source_name: str) -> str:
    return module_name(handler_source_asset_spec(source_name), 'legacy_wrapper_module')


def seeded_handler_source_exec_module_name(source_name: str) -> str:
    return module_name(handler_source_asset_spec(source_name), 'seeded_exec_module')


def handler_source_wrapper_import_candidates(source_name: str) -> tuple[str, ...]:
    return handler_source_asset_spec(source_name).wrapper_import_candidates


def handler_source_namespace_candidates(source_name: str) -> tuple[str, ...]:
    return handler_source_asset_spec(source_name).namespace_candidates


def handler_source_wrapper_spec(source_name: str):
    return candidate_chain_spec_from_asset(
        handler_source_asset_spec(source_name),
        deep_origin='seeded_exec_fallback',
    )


__all__ = [
    'handler_source_namespace_candidates',
    'handler_source_wrapper_import_candidates',
    'handler_source_wrapper_spec',
    'legacy_handler_source_wrapper_module_name',
    'materialized_handler_source_fallback_module_name',
    'seeded_handler_source_exec_module_name',
    'static_handler_source_module_name',
]
