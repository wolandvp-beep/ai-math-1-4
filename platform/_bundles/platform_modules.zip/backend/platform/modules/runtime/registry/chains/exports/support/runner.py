from __future__ import annotations

from collections.abc import Iterable, MutableMapping
from typing import Any

from .exporting import export_module_candidate
from .fallbacks import export_deep_seeded_modules, export_seeded_module
from .origins import infer_origin


def export_candidate_chain(
    module_globals: MutableMapping[str, Any],
    *,
    module_candidates: Iterable[str],
    seeded_module_fallback: str | None = None,
    deep_seeded_modules: Iterable[str] = (),
    runtime_module_name: str | None = None,
    deep_origin: str = 'seeded_shard_fallback',
) -> tuple[list[str], str]:
    last_error: Exception | None = None
    for module_name in tuple(module_candidates):
        try:
            exported_names = export_module_candidate(module_globals, module_name)
        except Exception as exc:  # pragma: no cover - compatibility fallback path
            last_error = exc
            continue
        return exported_names, infer_origin(module_name)

    effective_runtime_module_name = runtime_module_name or str(module_globals.get('__name__', '__runtime__'))

    if seeded_module_fallback is not None:
        try:
            exported_names = export_seeded_module(
                module_globals,
                seeded_module_fallback=seeded_module_fallback,
                runtime_module_name=effective_runtime_module_name,
            )
        except Exception as exc:  # pragma: no cover - compatibility fallback path
            last_error = exc
        else:
            return exported_names, infer_origin(seeded_module_fallback)

    deep_modules = tuple(str(name) for name in deep_seeded_modules)
    if deep_modules:
        try:
            exported_names = export_deep_seeded_modules(
                module_globals,
                deep_seeded_modules=deep_modules,
                runtime_module_name=effective_runtime_module_name,
            )
        except Exception as exc:  # pragma: no cover - deep compatibility fallback path
            last_error = exc
        else:
            return exported_names, deep_origin

    if last_error is not None:
        raise last_error
    return [], 'no_candidates'


__all__ = ['export_candidate_chain']
