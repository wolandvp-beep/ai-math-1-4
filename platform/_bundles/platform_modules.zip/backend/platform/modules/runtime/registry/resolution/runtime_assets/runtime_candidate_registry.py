from __future__ import annotations

from backend.runtime_asset_catalog import runtime_module_asset_spec, runtime_source_asset_spec
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.support.accessors import (
    candidate_chain_spec_from_asset,
    module_name,
)


def static_runtime_source_module_name(filename: str) -> str:
    return module_name(runtime_source_asset_spec(filename), 'static_module')


def seeded_runtime_source_module_name(filename: str) -> str:
    return module_name(runtime_source_asset_spec(filename), 'seeded_fallback_module')


def legacy_runtime_source_wrapper_module_name(filename: str) -> str:
    return module_name(runtime_source_asset_spec(filename), 'legacy_wrapper_module')


def runtime_source_wrapper_spec(filename: str):
    return candidate_chain_spec_from_asset(runtime_source_asset_spec(filename), deep_origin='seeded_shard_fallback')


def runtime_source_apply_candidates(filename: str) -> tuple[str, ...]:
    return runtime_source_asset_spec(filename).apply_candidates


def static_runtime_module_name(filename: str) -> str:
    return module_name(runtime_module_asset_spec(filename), 'static_module')


def seeded_runtime_module_name(filename: str) -> str:
    return module_name(runtime_module_asset_spec(filename), 'seeded_fallback_module')


def legacy_runtime_module_wrapper_module_name(filename: str) -> str:
    return module_name(runtime_module_asset_spec(filename), 'legacy_wrapper_module')


def runtime_module_wrapper_spec(filename: str):
    return candidate_chain_spec_from_asset(runtime_module_asset_spec(filename), deep_origin='seeded_shard_fallback')


def runtime_module_apply_candidates(filename: str) -> tuple[str, ...]:
    return runtime_module_asset_spec(filename).apply_candidates


__all__ = [
    'legacy_runtime_module_wrapper_module_name',
    'legacy_runtime_source_wrapper_module_name',
    'runtime_module_apply_candidates',
    'runtime_module_wrapper_spec',
    'runtime_source_apply_candidates',
    'runtime_source_wrapper_spec',
    'seeded_runtime_module_name',
    'seeded_runtime_source_module_name',
    'static_runtime_module_name',
    'static_runtime_source_module_name',
]
