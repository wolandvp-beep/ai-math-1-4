from __future__ import annotations

from collections import Counter
from collections.abc import Iterable

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec


def duplicate_module_targets(specs: Iterable[RuntimeAssetSpec]) -> list[str]:
    module_names: list[str] = []
    for spec in specs:
        module_names.extend(spec.import_smoke_modules)
        module_names.extend(spec.deep_seeded_modules)
    counts = Counter(module_names)
    return sorted(name for name, count in counts.items() if count > 1)


def missing_spec_targets(
    specs: Iterable[RuntimeAssetSpec],
    attribute: str,
    *,
    kinds: Iterable[str] | None = None,
) -> list[str]:
    allowed = set(kinds or ())
    return [
        spec.filename
        for spec in specs
        if (not allowed or spec.kind in allowed) and not getattr(spec, attribute)
    ]


def catalog_entries(specs: Iterable[RuntimeAssetSpec], *, kind: str | None = None) -> list[str]:
    return [spec.filename for spec in specs if kind is None or spec.kind == kind]


__all__ = ['catalog_entries', 'duplicate_module_targets', 'missing_spec_targets']
