from __future__ import annotations

from .support.factories import build_runtime_module_spec
from .support.indexes import build_filename_index, build_runtime_name_index, build_stem_index


RUNTIME_MODULE_ROWS = (
    ('textbook', 'final_textbook_runtime_module', 'final_textbook', 'backend.legacy_final_textbook_runtime', 2),
    ('prompting', 'prompt_runtime_module', 'prompt', 'backend.legacy_prompt_runtime', 1),
    ('continuation', 'continuation_runtime_module', 'continuation', 'backend.legacy_continuation_runtime', 2),
    ('handlers', 'extended_handlers_runtime_module', 'extended_handlers', 'backend.legacy_extended_handlers_runtime', 4),
    ('tail', 'tail_runtime_module', 'tail', 'backend.legacy_tail_runtime', 2),
)

RUNTIME_MODULE_SPECS = tuple(
    build_runtime_module_spec(group, stem, runtime_name, apply_wrapper_module, shard_count)
    for group, stem, runtime_name, apply_wrapper_module, shard_count in RUNTIME_MODULE_ROWS
)

RUNTIME_MODULE_SPEC_BY_FILENAME = build_filename_index(RUNTIME_MODULE_SPECS)
RUNTIME_MODULE_SPEC_BY_STEM = build_stem_index(RUNTIME_MODULE_SPECS)
RUNTIME_MODULE_SPEC_BY_RUNTIME_NAME = build_runtime_name_index(RUNTIME_MODULE_SPECS)


__all__ = [
    'RUNTIME_MODULE_ROWS',
    'RUNTIME_MODULE_SPECS',
    'RUNTIME_MODULE_SPEC_BY_FILENAME',
    'RUNTIME_MODULE_SPEC_BY_RUNTIME_NAME',
    'RUNTIME_MODULE_SPEC_BY_STEM',
]
