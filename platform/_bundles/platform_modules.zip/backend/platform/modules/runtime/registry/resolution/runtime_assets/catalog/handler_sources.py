from __future__ import annotations

from .support.factories import build_handler_source_spec
from .support.indexes import build_filename_index, build_stem_index


HANDLER_SOURCE_ROWS = (
    ('change', 'sequential', 'legacy_change_problem_handlers_source'),
    ('subject_relations', 'dual_subject', 'legacy_dual_subject_problem_handlers_source'),
    ('subject_relations', 'quantity', 'legacy_quantity_problem_handlers_source'),
    ('subject_relations', 'relation', 'legacy_relation_problem_handlers_source'),
    ('applied_contexts', 'geometry', 'legacy_geometry_handlers_source'),
    ('applied_contexts', 'motion', 'legacy_motion_problem_handlers_source'),
    ('applied_contexts', 'purchase', 'legacy_purchase_problem_handlers_source'),
    ('arithmetic', 'fractions', 'legacy_fraction_problem_handlers_source'),
    ('arithmetic', 'verbal', 'legacy_verbal_arithmetic_problem_handlers_source'),
)

HANDLER_SOURCE_SPECS = tuple(
    build_handler_source_spec(group, leaf, stem)
    for group, leaf, stem in HANDLER_SOURCE_ROWS
)

HANDLER_SOURCE_SPEC_BY_FILENAME = build_filename_index(HANDLER_SOURCE_SPECS)
HANDLER_SOURCE_SPEC_BY_STEM = build_stem_index(HANDLER_SOURCE_SPECS)


__all__ = [
    'HANDLER_SOURCE_ROWS',
    'HANDLER_SOURCE_SPECS',
    'HANDLER_SOURCE_SPEC_BY_FILENAME',
    'HANDLER_SOURCE_SPEC_BY_STEM',
]
