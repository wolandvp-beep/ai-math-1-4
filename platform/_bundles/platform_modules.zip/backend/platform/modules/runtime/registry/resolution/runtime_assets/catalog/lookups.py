from __future__ import annotations

from .handler_sources import HANDLER_SOURCE_SPECS, HANDLER_SOURCE_SPEC_BY_FILENAME, HANDLER_SOURCE_SPEC_BY_STEM
from .runtime_modules import RUNTIME_MODULE_SPECS, RUNTIME_MODULE_SPEC_BY_FILENAME, RUNTIME_MODULE_SPEC_BY_RUNTIME_NAME, RUNTIME_MODULE_SPEC_BY_STEM
from .runtime_sources import RUNTIME_SOURCE_SPECS, RUNTIME_SOURCE_SPEC_BY_FILENAME, RUNTIME_SOURCE_SPEC_BY_STEM
from .support.queries import flatten_specs, lookup_runtime_asset_spec, runtime_asset_catalog_counts as _runtime_asset_catalog_counts


def iter_runtime_source_specs() -> tuple:
    return RUNTIME_SOURCE_SPECS


def iter_runtime_module_specs() -> tuple:
    return RUNTIME_MODULE_SPECS


def iter_handler_source_specs() -> tuple:
    return HANDLER_SOURCE_SPECS


def iter_all_runtime_asset_specs() -> tuple:
    return flatten_specs(RUNTIME_SOURCE_SPECS, RUNTIME_MODULE_SPECS, HANDLER_SOURCE_SPECS)


def runtime_source_asset_spec(name: str):
    return lookup_runtime_asset_spec(RUNTIME_SOURCE_SPEC_BY_FILENAME, RUNTIME_SOURCE_SPEC_BY_STEM, name)


def runtime_module_asset_spec(name: str):
    return lookup_runtime_asset_spec(RUNTIME_MODULE_SPEC_BY_FILENAME, RUNTIME_MODULE_SPEC_BY_STEM, name)


def runtime_module_asset_spec_by_runtime_name(name: str):
    try:
        return RUNTIME_MODULE_SPEC_BY_RUNTIME_NAME[name]
    except KeyError as exc:
        raise KeyError(f'Unknown runtime module runtime_name: {name}') from exc


def handler_source_asset_spec(name: str):
    return lookup_runtime_asset_spec(HANDLER_SOURCE_SPEC_BY_FILENAME, HANDLER_SOURCE_SPEC_BY_STEM, name)


def runtime_asset_catalog_counts() -> dict[str, int]:
    return _runtime_asset_catalog_counts(RUNTIME_SOURCE_SPECS, RUNTIME_MODULE_SPECS, HANDLER_SOURCE_SPECS)


__all__ = [
    'handler_source_asset_spec',
    'iter_all_runtime_asset_specs',
    'iter_handler_source_specs',
    'iter_runtime_module_specs',
    'iter_runtime_source_specs',
    'runtime_asset_catalog_counts',
    'runtime_module_asset_spec',
    'runtime_module_asset_spec_by_runtime_name',
    'runtime_source_asset_spec',
]
