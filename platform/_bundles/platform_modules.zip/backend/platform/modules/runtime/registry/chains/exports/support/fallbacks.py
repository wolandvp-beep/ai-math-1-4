from __future__ import annotations

from collections.abc import Iterable, MutableMapping
from typing import Any

from backend.legacy_seeded_module_chain import apply_seeded_module_chain
from backend.legacy_seeded_module_loader import execute_seeded_module

from .exporting import exported_names_from_globals


def export_seeded_module(
    module_globals: MutableMapping[str, Any],
    *,
    seeded_module_fallback: str,
    runtime_module_name: str,
) -> list[str]:
    execute_seeded_module(
        module_globals,
        seeded_module_fallback,
        runtime_module_name=f'{runtime_module_name}.__seeded__',
    )
    return exported_names_from_globals(module_globals)


def export_deep_seeded_modules(
    module_globals: MutableMapping[str, Any],
    *,
    deep_seeded_modules: Iterable[str],
    runtime_module_name: str,
) -> list[str]:
    apply_seeded_module_chain(module_globals, tuple(str(name) for name in deep_seeded_modules), runtime_module_name)
    return exported_names_from_globals(module_globals)


__all__ = ['export_deep_seeded_modules', 'export_seeded_module']
