from __future__ import annotations

from collections.abc import Iterable
from typing import TypeVar

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec

T = TypeVar('T')


def build_deep_seeded_manifest(specs: Iterable[RuntimeAssetSpec]) -> dict[str, tuple[str, ...]]:
    return {
        spec.filename: spec.deep_seeded_modules
        for spec in specs
    }


def build_remaining_runtime_specs(specs: Iterable[RuntimeAssetSpec], runtime_spec_cls: type[T]) -> tuple[T, ...]:
    return tuple(
        runtime_spec_cls(
            name=module_name,
            wrapper_module=wrapper_module,
            source_kind='module',
            source_ref=source_ref,
        )
        for spec in specs
        for module_name, wrapper_module, source_ref in [(
            str(spec.runtime_name),
            str(spec.apply_wrapper_module),
            str(spec.static_module),
        )]
    )


__all__ = ['build_deep_seeded_manifest', 'build_remaining_runtime_specs']
