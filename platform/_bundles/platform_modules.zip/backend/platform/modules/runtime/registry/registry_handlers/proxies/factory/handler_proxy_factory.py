from __future__ import annotations

from functools import lru_cache
from typing import Callable, Optional

from backend.handler_source_registry import handler_source_namespace_candidates
from backend.runtime_namespace_factory import build_module_namespace_loader


@lru_cache(maxsize=None)
def get_handler_namespace_loader(source_name: str):
    return build_module_namespace_loader(handler_source_namespace_candidates(source_name))


def call_raw_text_handler(source_name: str, handler_name: str, raw_text: str) -> Optional[str]:
    namespace = get_handler_namespace_loader(source_name)()
    handler = namespace.get(handler_name)
    if not callable(handler):
        return None
    return handler(raw_text)


def build_raw_text_handler_proxy(
    source_name: str,
    handler_name: str,
    *,
    module_name: str,
) -> Callable[[str], Optional[str]]:
    def _proxy(raw_text: str) -> Optional[str]:
        return call_raw_text_handler(source_name, handler_name, raw_text)

    _proxy.__name__ = handler_name
    _proxy.__qualname__ = handler_name
    _proxy.__module__ = module_name
    return _proxy


__all__ = [
    'build_raw_text_handler_proxy',
    'call_raw_text_handler',
    'get_handler_namespace_loader',
]
