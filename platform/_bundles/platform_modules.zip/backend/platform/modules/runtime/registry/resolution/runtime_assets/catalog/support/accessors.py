from __future__ import annotations

from backend.candidate_chain_specs import CandidateChainSpec
from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec


def module_name(spec: RuntimeAssetSpec, attribute: str) -> str:
    value = getattr(spec, attribute)
    if value is None:
        raise ValueError(f'{spec.filename} is missing {attribute}')
    return str(value)


def candidate_chain_spec_from_asset(
    spec: RuntimeAssetSpec,
    *,
    deep_origin: str,
    seeded_exec_module: str | None = None,
) -> CandidateChainSpec:
    return CandidateChainSpec(
        name=spec.filename,
        module_candidates=spec.wrapper_import_candidates,
        seeded_exec_module=seeded_exec_module if seeded_exec_module is not None else spec.primary_seeded_module,
        deep_seeded_modules=spec.deep_seeded_modules,
        deep_origin=deep_origin,
    )


__all__ = ['candidate_chain_spec_from_asset', 'module_name']
