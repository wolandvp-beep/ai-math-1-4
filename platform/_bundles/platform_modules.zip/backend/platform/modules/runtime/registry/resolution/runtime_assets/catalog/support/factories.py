from __future__ import annotations

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec


def _flat_shard_modules(package_name: str, stem: str, count: int) -> tuple[str, ...]:
    return tuple(
        f'backend.{package_name}.{stem}.segment_{index:03d}'
        for index in range(1, count + 1)
    )


def build_runtime_source_spec(group: str, stem: str, shard_count: int) -> RuntimeAssetSpec:
    return RuntimeAssetSpec(
        kind='runtime_source',
        filename=f'{stem}.py',
        stem=stem,
        package_group=group,
        package_leaf=None,
        static_module=f'backend.static_runtime_sources.{stem}',
        shared_body_module=f'backend.runtime_assets.shared_bodies.runtime_sources.{group}.{stem}',
        legacy_wrapper_module=f'backend.legacy_runtime_sources.{stem}',
        seeded_fallback_module=f'backend.seeded_runtime_source_fallbacks.{stem}',
        deep_seeded_modules=_flat_shard_modules('legacy_runtime_shards', stem, shard_count),
    )


def build_runtime_module_spec(
    group: str,
    stem: str,
    runtime_name: str,
    apply_wrapper_module: str,
    shard_count: int,
) -> RuntimeAssetSpec:
    return RuntimeAssetSpec(
        kind='runtime_module',
        filename=f'{stem}.py',
        stem=stem,
        package_group=group,
        package_leaf=None,
        static_module=f'backend.static_runtime_modules.{stem}',
        shared_body_module=f'backend.runtime_assets.shared_bodies.runtime_modules.{group}.{stem}',
        legacy_wrapper_module=f'backend.legacy_runtime_modules.{stem}',
        seeded_fallback_module=f'backend.seeded_runtime_module_fallbacks.{stem}',
        deep_seeded_modules=_flat_shard_modules('legacy_runtime_module_shards', stem, shard_count),
        apply_wrapper_module=apply_wrapper_module,
        runtime_name=runtime_name,
    )


def build_handler_source_spec(group: str, leaf: str, stem: str) -> RuntimeAssetSpec:
    return RuntimeAssetSpec(
        kind='handler_source',
        filename=f'{stem}.py',
        stem=stem,
        package_group=group,
        package_leaf=leaf,
        static_module=f'backend.static_handler_sources.{stem}',
        shared_body_module=f'backend.runtime_assets.shared_bodies.handler_sources.{group}.{leaf}.{stem}',
        legacy_wrapper_module=f'backend.legacy_handler_sources.{stem}',
        materialized_fallback_module=f'backend.materialized_handler_source_fallbacks.{stem}',
        seeded_exec_module=f'backend.seeded_handler_source_fallbacks.{stem}',
    )


__all__ = [
    'build_handler_source_spec',
    'build_runtime_module_spec',
    'build_runtime_source_spec',
]
