from __future__ import annotations

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog import *
from backend.platform.modules.runtime.registry.resolution.runtime_assets import catalog as _catalog

__all__ = list(_catalog.__all__)
