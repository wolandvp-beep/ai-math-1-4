from __future__ import annotations

from .support.factories import build_runtime_source_spec
from .support.indexes import build_filename_index, build_stem_index


RUNTIME_SOURCE_ROWS = (
    ('build', 'prepatch_build_source', 25),
    ('cascade', 'prepatch_cascade_source', 14),
    ('midpatch', 'midpatch_runtime_source', 15),
)

RUNTIME_SOURCE_SPECS = tuple(
    build_runtime_source_spec(group, stem, shard_count)
    for group, stem, shard_count in RUNTIME_SOURCE_ROWS
)

RUNTIME_SOURCE_SPEC_BY_FILENAME = build_filename_index(RUNTIME_SOURCE_SPECS)
RUNTIME_SOURCE_SPEC_BY_STEM = build_stem_index(RUNTIME_SOURCE_SPECS)


__all__ = [
    'RUNTIME_SOURCE_ROWS',
    'RUNTIME_SOURCE_SPECS',
    'RUNTIME_SOURCE_SPEC_BY_FILENAME',
    'RUNTIME_SOURCE_SPEC_BY_STEM',
]
