from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RuntimeAssetSpec:
    kind: str
    filename: str
    stem: str
    package_group: str
    package_leaf: str | None
    static_module: str | None
    shared_body_module: str | None
    legacy_wrapper_module: str | None
    seeded_fallback_module: str | None = None
    materialized_fallback_module: str | None = None
    seeded_exec_module: str | None = None
    deep_seeded_modules: tuple[str, ...] = ()
    apply_wrapper_module: str | None = None
    runtime_name: str | None = None

    @property
    def wrapper_import_candidates(self) -> tuple[str, ...]:
        if self.kind == 'handler_source':
            return tuple(
                module_name
                for module_name in (self.static_module, self.materialized_fallback_module)
                if module_name
            )
        return tuple(module_name for module_name in (self.static_module,) if module_name)

    @property
    def apply_candidates(self) -> tuple[str, ...]:
        return tuple(
            module_name
            for module_name in (self.static_module, self.seeded_fallback_module, self.legacy_wrapper_module)
            if module_name
        )

    @property
    def namespace_candidates(self) -> tuple[str, ...]:
        return tuple(
            module_name
            for module_name in (*self.wrapper_import_candidates, self.legacy_wrapper_module)
            if module_name
        )

    @property
    def primary_seeded_module(self) -> str | None:
        return self.seeded_exec_module or self.seeded_fallback_module

    @property
    def import_smoke_modules(self) -> tuple[str, ...]:
        seen: set[str] = set()
        ordered: list[str] = []
        for module_name in (
            self.static_module,
            self.shared_body_module,
            self.legacy_wrapper_module,
            self.materialized_fallback_module,
            self.seeded_fallback_module,
            self.seeded_exec_module,
            self.apply_wrapper_module,
        ):
            if not module_name or module_name in seen:
                continue
            seen.add(module_name)
            ordered.append(module_name)
        return tuple(ordered)


__all__ = ['RuntimeAssetSpec']
