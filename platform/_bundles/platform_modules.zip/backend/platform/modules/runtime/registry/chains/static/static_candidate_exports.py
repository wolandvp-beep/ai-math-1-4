from __future__ import annotations

from collections.abc import Iterable, MutableMapping
from typing import Any

from backend.candidate_chain_exports import export_candidate_chain


def export_static_candidate_chain(
    module_globals: MutableMapping[str, Any],
    *,
    module_candidates: Iterable[str],
    deep_exec_module: str | None = None,
) -> tuple[list[str], str]:
    return export_candidate_chain(
        module_globals,
        module_candidates=module_candidates,
        seeded_module_fallback=deep_exec_module,
        runtime_module_name=str(module_globals.get('__name__', '__runtime__')),
        deep_origin='seeded_exec_fallback',
    )


__all__ = ['export_static_candidate_chain']
