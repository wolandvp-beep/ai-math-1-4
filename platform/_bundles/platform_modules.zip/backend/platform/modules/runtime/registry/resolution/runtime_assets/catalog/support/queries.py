from __future__ import annotations

from collections.abc import Iterable

from backend.platform.modules.runtime.registry.resolution.runtime_assets.catalog.models import RuntimeAssetSpec


def lookup_runtime_asset_spec(
    mapping_by_filename: dict[str, RuntimeAssetSpec],
    mapping_by_stem: dict[str, RuntimeAssetSpec],
    name: str,
) -> RuntimeAssetSpec:
    key = str(name)
    if key in mapping_by_filename:
        return mapping_by_filename[key]
    stem = key[:-3] if key.endswith('.py') else key
    if stem in mapping_by_stem:
        return mapping_by_stem[stem]
    raise KeyError(f'Unknown runtime asset spec: {name}')


def flatten_specs(*collections: Iterable[RuntimeAssetSpec]) -> tuple[RuntimeAssetSpec, ...]:
    flattened: list[RuntimeAssetSpec] = []
    for collection in collections:
        flattened.extend(collection)
    return tuple(flattened)


def runtime_asset_catalog_counts(
    runtime_source_specs: tuple[RuntimeAssetSpec, ...],
    runtime_module_specs: tuple[RuntimeAssetSpec, ...],
    handler_source_specs: tuple[RuntimeAssetSpec, ...],
) -> dict[str, int]:
    specs = flatten_specs(runtime_source_specs, runtime_module_specs, handler_source_specs)
    return {
        'entry_count': len(specs),
        'runtime_source_count': len(runtime_source_specs),
        'runtime_module_count': len(runtime_module_specs),
        'handler_source_count': len(handler_source_specs),
        'shared_body_count': sum(1 for spec in specs if spec.shared_body_module),
        'apply_wrapper_count': sum(1 for spec in specs if spec.apply_wrapper_module),
        'deep_seeded_group_count': sum(1 for spec in specs if spec.deep_seeded_modules),
        'deep_seeded_module_count': sum(len(spec.deep_seeded_modules) for spec in specs),
    }


__all__ = [
    'flatten_specs',
    'lookup_runtime_asset_spec',
    'runtime_asset_catalog_counts',
]
