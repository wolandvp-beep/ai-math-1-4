from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

try:
    from ....compat_paths import BACKEND_COMPAT_DIRS, HEALTH_CASE_PACKAGE_DIRS, PLATFORM_ROOT, extend_module_path
except ImportError:
    from backend.compat_paths import BACKEND_COMPAT_DIRS, HEALTH_CASE_PACKAGE_DIRS, PLATFORM_ROOT, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [*HEALTH_CASE_PACKAGE_DIRS, *BACKEND_COMPAT_DIRS])

__all__ = ['BACKEND_COMPAT_DIRS', 'HEALTH_CASE_PACKAGE_DIRS', 'PLATFORM_ROOT']
