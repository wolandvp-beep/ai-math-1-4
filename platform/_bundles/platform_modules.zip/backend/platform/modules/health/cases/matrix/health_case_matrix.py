from __future__ import annotations

import time
from functools import lru_cache
from typing import Any

from backend.async_compat import run_async_compat
from backend.explanation_dispatcher import dispatch_explanation
from backend.health_summary import summarize_case_results
from backend.regression_cases import CORE_REGRESSION_CASES


def normalize_result_text(value: Any) -> str:
    text = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    return '\n'.join(line.rstrip() for line in text.split('\n')).strip()


def classify_source_family(source: str) -> str:
    if not source:
        return 'empty'
    if source.startswith('EXCEPTION:'):
        return 'exception'
    if ':' in source:
        return source.split(':', 1)[0]
    return source


async def build_health_case_matrix(*, include_probe: bool = True) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    source_family_counts: dict[str, int] = {}
    for case in CORE_REGRESSION_CASES:
        text = case['text']
        started = time.perf_counter()
        payload: dict[str, Any] = {}
        probe: dict[str, Any] = {}
        exception_issue = ''
        probe_exception = ''
        try:
            payload = await dispatch_explanation(text)
        except Exception as exc:  # pragma: no cover - defensive runtime harness
            exception_issue = f'{type(exc).__name__}: {exc}'
        if include_probe:
            try:
                from backend.smoke_checks import smoke_probe
                probe = smoke_probe(text)
            except Exception as exc:  # pragma: no cover - defensive runtime harness
                probe_exception = f'{type(exc).__name__}: {exc}'
        elapsed_seconds = time.perf_counter() - started
        source = str(payload.get('source', '')) if not exception_issue else f'EXCEPTION:{exception_issue.split(":", 1)[0]}'
        result_text = normalize_result_text(payload.get('result', ''))
        source_family = classify_source_family(source)
        source_family_counts[source_family] = source_family_counts.get(source_family, 0) + 1
        ok = not exception_issue and not probe_exception
        rows.append({
            'name': case['name'],
            'category': case.get('category', 'uncategorized'),
            'text': text,
            'case': dict(case),
            'ok': ok,
            'exception': exception_issue,
            'probe_exception': probe_exception,
            'payload': payload,
            'probe': probe,
            'source': source,
            'source_family': source_family,
            'result_text': result_text,
            'elapsed_seconds': round(elapsed_seconds, 6),
        })
    passed = sum(1 for row in rows if row['ok'])
    elapsed_values = [float(row['elapsed_seconds']) for row in rows]
    return {
        'passed': passed,
        'total': len(rows),
        'all_passed': passed == len(rows),
        'rows': rows,
        'category_summary': summarize_case_results(rows),
        'source_family_counts': dict(sorted(source_family_counts.items())),
        'timings': {
            'total_seconds': round(sum(elapsed_values), 6),
            'average_seconds': round(sum(elapsed_values) / len(elapsed_values), 6) if elapsed_values else 0.0,
            'max_seconds': round(max(elapsed_values), 6) if elapsed_values else 0.0,
        },
    }


@lru_cache(maxsize=2)
def _build_health_case_matrix_cached(include_probe: bool) -> dict[str, Any]:
    return run_async_compat(lambda: build_health_case_matrix(include_probe=include_probe))


def build_health_case_matrix_sync(*, include_probe: bool = True, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        _build_health_case_matrix_cached.cache_clear()
    return _build_health_case_matrix_cached(include_probe)


__all__ = [
    'build_health_case_matrix',
    'build_health_case_matrix_sync',
    'classify_source_family',
    'normalize_result_text',
]
