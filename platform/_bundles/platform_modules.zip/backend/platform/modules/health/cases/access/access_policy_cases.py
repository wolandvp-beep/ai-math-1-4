from __future__ import annotations

ACCESS_POLICY_CASES: tuple[dict[str, str], ...] = (
    {'name': 'free_starter_allows_five_immediately', 'kind': 'free_starter'},
    {'name': 'free_starter_blocks_sixth_same_day', 'kind': 'free_starter_block'},
    {'name': 'free_daily_reset_allows_one_next_day', 'kind': 'free_next_day'},
    {'name': 'free_daily_does_not_accumulate', 'kind': 'free_no_accumulate'},
    {'name': 'subscription_allows_twenty_per_day', 'kind': 'subscription_twenty'},
    {'name': 'subscription_blocks_twenty_first', 'kind': 'subscription_block'},
    {'name': 'subscription_resets_next_msk_day', 'kind': 'subscription_next_day'},
    {'name': 'profile_and_subscription_payload_shape', 'kind': 'payload_shape'},
    {'name': 'register_inherits_guest_usage', 'kind': 'register_merge'},
    {'name': 'login_inherits_guest_usage', 'kind': 'login_merge'},
)

__all__ = ['ACCESS_POLICY_CASES']
