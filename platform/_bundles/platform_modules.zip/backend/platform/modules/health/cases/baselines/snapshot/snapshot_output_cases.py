from __future__ import annotations

SNAPSHOT_OUTPUT_CASES = (
    {'name': 'solver_prefix_expression', 'expected_source': 'local', 'expected_sha256': '1e3dce235882077615fe9c73c0f7fa7e38cc57fe2e96a5e69f9daef18a180211'},
    {'name': 'named_quantity_arithmetic', 'expected_source': 'local:named_quantity_arithmetic', 'expected_sha256': 'ff770ffbe906726f334a44ddbf0058aedd1e217c61bdad8d46c7a5065d7d38fc'},
    {'name': 'simple_transfer', 'expected_source': 'local-change:simple_transfer', 'expected_sha256': 'f2bf0332ff3d2fac3867e6678d70ac2f778f6abe07ad16a0c2b7e29034a4533d'},
    {'name': 'reverse_number_change', 'expected_source': 'local-change:reverse_number_change', 'expected_sha256': '2324b681ad141adfbe7f6dc508a246dc1fdd0f838fc7226ad3dde6f0ff75450f'},
    {'name': 'nested_division_by_zero_guard', 'expected_source': 'local', 'expected_sha256': 'b190051681f1ea561bb84f446d71c2bfe47d0551b4240b0de60f1e7830e0cf0a'},
    {'name': 'mixed_expression_division_then_addition', 'expected_source': 'expression_mixed:direct', 'expected_sha256': 'f53547dfc446e75b4b0bddcdd80899a23141c8b47c15d3818cb77afc50137122'},
    {'name': 'column_addition_with_zeros', 'expected_source': 'column_math:direct:+', 'expected_sha256': 'c975660130f7d0188b06e75f366a0a67eedacbbde44623a5f19b8daa20f79c52'},
    {'name': 'column_subtraction_borrow_language', 'expected_source': 'column_math:direct:-', 'expected_sha256': '1fee3a28b7bc388a63ff8fea577575d13ae46186f3ad09f9ef031cf63bb0be8b'},
    {'name': 'reverse_transfer', 'expected_source': 'legacy-change:reverse_transfer_problem', 'expected_sha256': 'eed4ee5e399d0c980c95c59716e0febffcadf953fcaa374f6a6928a2bd5a1be8'},
    {'name': 'geometry_rectangle_perimeter', 'expected_source': 'legacy-geometry:rectangle_geometry', 'expected_sha256': '4ab731731a4ab022995fab97b1c8207bdf16ea7a98d2a59f0b3515b7c90d85ac'},
)


__all__ = ['SNAPSHOT_OUTPUT_CASES']
