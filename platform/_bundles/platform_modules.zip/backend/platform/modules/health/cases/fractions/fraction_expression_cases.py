from __future__ import annotations

from fractions import Fraction
from typing import Iterable


REQUIRED_RESULT_MARKERS: tuple[str, ...] = ('Решение по действиям:', 'Ответ:', 'Совет:')


def _fraction_text(value: Fraction) -> str:
    value = Fraction(value)
    if value.denominator == 1:
        return str(value.numerator)
    return f'{value.numerator}/{value.denominator}'


def _build_case(
    *,
    name: str,
    text: str,
    expected_answer: Fraction,
    expected_source_prefix: str,
    required_snippets: Iterable[str] = (),
) -> dict:
    return {
        'name': name,
        'text': text,
        'expected_answer_contains': f'Ответ: {_fraction_text(expected_answer)}',
        'expected_source_prefix': expected_source_prefix,
        'required_result_markers': REQUIRED_RESULT_MARKERS,
        'required_result_snippets': tuple(required_snippets),
    }


def _case_add_sub(name: str, a: Fraction, b: Fraction, c: Fraction) -> dict:
    text = f'{_fraction_text(a)} + {_fraction_text(b)} - {_fraction_text(c)}'
    return _build_case(
        name=name,
        text=text,
        expected_answer=a + b - c,
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Приводим дроби к общему знаменателю',),
    )


def _case_parenthesized_mul(name: str, a: Fraction, b: Fraction, c: Fraction) -> dict:
    text = f'({_fraction_text(a)} + {_fraction_text(b)}) * {_fraction_text(c)}'
    return _build_case(
        name=name,
        text=text,
        expected_answer=(a + b) * c,
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Умножаем числители и знаменатели',),
    )


def _case_fraction_then_division(name: str, a: Fraction, b: Fraction, divisor: int) -> dict:
    text = f'{_fraction_text(a)} + {_fraction_text(b)} : {divisor}'
    return _build_case(
        name=name,
        text=text,
        expected_answer=a + b / Fraction(divisor, 1),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Заменяем деление умножением на обратную дробь',),
    )


def _case_integer_mix(name: str, integer_value: int, a: Fraction, b: Fraction) -> dict:
    text = f'{integer_value} + {_fraction_text(a)} - {_fraction_text(b)}'
    return _build_case(
        name=name,
        text=text,
        expected_answer=Fraction(integer_value, 1) + a - b,
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Представляем число',),
    )


def _case_division_disambiguation(name: str, text: str, expected_answer: Fraction) -> dict:
    return _build_case(
        name=name,
        text=text,
        expected_answer=expected_answer,
        expected_source_prefix='expression_',
        required_snippets=(),
    )


FRACTIONS_A = [Fraction(1, 2), Fraction(2, 3), Fraction(3, 4), Fraction(5, 6), Fraction(7, 8)]
FRACTIONS_B = [Fraction(1, 3), Fraction(1, 4), Fraction(2, 5), Fraction(3, 8), Fraction(5, 12)]
FRACTIONS_C = [Fraction(1, 6), Fraction(1, 8), Fraction(1, 5), Fraction(1, 12), Fraction(1, 4)]
FRACTIONS_M = [Fraction(3, 4), Fraction(5, 6), Fraction(7, 9), Fraction(4, 5), Fraction(2, 7)]


cases: list[dict] = []
for index, (a, b, c) in enumerate(zip(FRACTIONS_A, FRACTIONS_B, FRACTIONS_C), start=1):
    cases.append(_case_add_sub(f'fraction-add-sub-{index:02d}', a, b, c))
    cases.append(_case_parenthesized_mul(f'fraction-parenthesized-mul-{index:02d}', a, b, FRACTIONS_M[index - 1]))
    cases.append(_case_fraction_then_division(f'fraction-division-step-{index:02d}', a, FRACTIONS_M[index - 1], index + 1))
    cases.append(_case_integer_mix(f'fraction-integer-mix-{index:02d}', index + 2, a, b))

# Additional diverse fraction cases.
extra_fraction_cases = [
    _build_case(
        name='fraction-two-parentheses-01',
        text='(1/2 + 1/3) - (1/4 - 1/8)',
        expected_answer=(Fraction(1, 2) + Fraction(1, 3)) - (Fraction(1, 4) - Fraction(1, 8)),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Приводим дроби к общему знаменателю',),
    ),
    _build_case(
        name='fraction-two-parentheses-02',
        text='(3/4 - 1/2) + (5/6 - 1/3)',
        expected_answer=(Fraction(3, 4) - Fraction(1, 2)) + (Fraction(5, 6) - Fraction(1, 3)),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Приводим дроби к общему знаменателю',),
    ),
    _build_case(
        name='fraction-nested-division-01',
        text='(3/4 + 1/8) : 2',
        expected_answer=(Fraction(3, 4) + Fraction(1, 8)) / 2,
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Заменяем деление умножением на обратную дробь',),
    ),
    _build_case(
        name='fraction-nested-division-02',
        text='(5/6 - 1/3) : 3',
        expected_answer=(Fraction(5, 6) - Fraction(1, 3)) / 3,
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Заменяем деление умножением на обратную дробь',),
    ),
    _build_case(
        name='fraction-improper-mix-01',
        text='7/3 - 1/6 + 1/2',
        expected_answer=Fraction(7, 3) - Fraction(1, 6) + Fraction(1, 2),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Приводим дроби к общему знаменателю',),
    ),
    _build_case(
        name='fraction-improper-mix-02',
        text='5/4 + 2/3 - 1/6',
        expected_answer=Fraction(5, 4) + Fraction(2, 3) - Fraction(1, 6),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Приводим дроби к общему знаменателю',),
    ),
    _build_case(
        name='fraction-mul-add-01',
        text='1/2 * 3/5 + 1/10',
        expected_answer=Fraction(1, 2) * Fraction(3, 5) + Fraction(1, 10),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Умножаем числители и знаменатели',),
    ),
    _build_case(
        name='fraction-mul-add-02',
        text='2/3 * 3/4 - 1/6',
        expected_answer=Fraction(2, 3) * Fraction(3, 4) - Fraction(1, 6),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Умножаем числители и знаменатели',),
    ),
    _build_case(
        name='fraction-div-after-parentheses-01',
        text='(1/2 + 1/4) : 3/2',
        expected_answer=(Fraction(1, 2) + Fraction(1, 4)) / Fraction(3, 2),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Заменяем деление умножением на обратную дробь',),
    ),
    _build_case(
        name='fraction-div-after-parentheses-02',
        text='(3/5 + 1/10) : 7/5',
        expected_answer=(Fraction(3, 5) + Fraction(1, 10)) / Fraction(7, 5),
        expected_source_prefix='expression_fraction:direct',
        required_snippets=('Заменяем деление умножением на обратную дробь',),
    ),
]
cases.extend(extra_fraction_cases)

# Slash disambiguation cases: these should stay in ordinary expression mode.
division_cases = [
    ('division-slash-no-spaces-01', '10/2+3', Fraction(8, 1)),
    ('division-slash-no-spaces-02', '12/3-1', Fraction(3, 1)),
    ('division-slash-no-spaces-03', '18/6+4', Fraction(7, 1)),
    ('division-slash-no-spaces-04', '21/7+5', Fraction(8, 1)),
    ('division-slash-no-spaces-05', '30/5-2', Fraction(4, 1)),
    ('division-spaced-01', '10 / 2 + 3', Fraction(8, 1)),
    ('division-spaced-02', '12 / 3 - 1', Fraction(3, 1)),
    ('division-spaced-03', '18 / 6 + 4', Fraction(7, 1)),
    ('division-spaced-04', '21 / 7 + 5', Fraction(8, 1)),
    ('division-spaced-05', '30 / 5 - 2', Fraction(4, 1)),
    ('division-mixed-01', '1 / 2 + 3', Fraction(7, 2)),
    ('division-mixed-02', '3 / 2 + 4', Fraction(11, 2)),
    ('division-mixed-03', '9 / 4 + 1', Fraction(13, 4)),
    ('division-mixed-04', '8 / 5 + 2', Fraction(18, 5)),
    ('division-colon-01', '10:2+3', Fraction(8, 1)),
    ('division-colon-02', '12:3-1', Fraction(3, 1)),
    ('division-sign-01', '10 ÷ 2 + 3', Fraction(8, 1)),
    ('division-sign-02', '12 ÷ 3 - 1', Fraction(3, 1)),
    ('division-parentheses-01', '(10/2)+3', Fraction(8, 1)),
    ('division-parentheses-02', '(12 / 3) - 1', Fraction(3, 1)),
]
for name, text, expected in division_cases:
    cases.append(_case_division_disambiguation(name, text, expected))

FRACTION_EXPRESSION_CASES: tuple[dict, ...] = tuple(cases)


__all__ = ['FRACTION_EXPRESSION_CASES', 'REQUIRED_RESULT_MARKERS']
