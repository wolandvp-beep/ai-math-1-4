from __future__ import annotations

from collections import Counter
from typing import Any

SECTION_LABELS = {
    'numbers_and_quantities': 'Числа и величины',
    'arithmetic': 'Арифметические действия',
    'word_problems': 'Текстовые задачи',
    'geometry': 'Пространственные отношения и геометрические фигуры',
    'information': 'Математическая информация',
}

TEXTBOOK_LINES = {
    'moro': 'линия Моро',
    'peterson': 'линия Петерсон',
    'dorofeev': 'линия Дорофеева',
    'rudnitskaya': 'линия Рудницкой',
    'istomina': 'линия Истоминой',
}

LINE_ORDER: tuple[str, ...] = tuple(TEXTBOOK_LINES)
BAD_SOURCE_PREFIXES = ('guard', 'guard-extra', 'fallback', 'legacy-ai', 'EXCEPTION:')
REQUIRED_RESULT_MARKERS = ('Решение', 'Ответ:')
UNIT_FORMS = {
    'см': {'gen': 'сантиметров', 'prep': 'сантиметрах'},
    'дм': {'gen': 'дециметров', 'prep': 'дециметрах'},
    'м': {'gen': 'метров', 'prep': 'метрах'},
    'мм': {'gen': 'миллиметров', 'prep': 'миллиметрах'},
    'г': {'gen': 'граммов', 'prep': 'граммах'},
    'кг': {'gen': 'килограммов', 'prep': 'килограммах'},
    'мин': {'gen': 'минут', 'prep': 'минутах'},
    'ч': {'gen': 'часов', 'prep': 'часах'},
}


def _case(
    name: str,
    line_key: str,
    grade: int,
    section_key: str,
    text: str,
    expected_answer_contains: str,
) -> dict[str, Any]:
    line_label = TEXTBOOK_LINES[line_key]
    return {
        'name': name,
        'textbook_line_key': line_key,
        'textbook_line': line_label,
        'grade': grade,
        'section_key': section_key,
        'section': SECTION_LABELS[section_key],
        'category': f'{line_label} · {grade} класс · {SECTION_LABELS[section_key]}',
        'text': text,
        'expected_answer_contains': expected_answer_contains,
        'forbid_source_prefixes': BAD_SOURCE_PREFIXES,
        'required_result_markers': REQUIRED_RESULT_MARKERS,
    }


def _relation(a: int, b: int) -> str:
    return f'{a} > {b}' if a > b else f'{a} < {b}' if a < b else f'{a} = {b}'


def _compare_text(line_key: str, a: int, b: int) -> str:
    if line_key in {'moro', 'istomina'}:
        return f'Сравни числа {a} и {b}.'
    return f'Какой знак поставить между {a} и {b}?'


def _next_text(line_key: str, n: int) -> str:
    if line_key in {'peterson', 'dorofeev'}:
        return f'Назови число, которое следует за {n}.'
    return f'Какое число следует за {n}?'


def _prev_text(line_key: str, n: int) -> str:
    if line_key in {'peterson', 'dorofeev'}:
        return f'Назови число, которое стоит перед {n}.'
    return f'Какое число стоит перед {n}?'


def _bigger_text(line_key: str, base: int, delta: int) -> str:
    if line_key in {'rudnitskaya', 'istomina'}:
        return f'Найди число больше {base} на {delta}.'
    return f'Какое число больше {base} на {delta}?'


def _smaller_text(line_key: str, base: int, delta: int) -> str:
    if line_key in {'rudnitskaya', 'istomina'}:
        return f'Найди число меньше {base} на {delta}.'
    return f'Какое число меньше {base} на {delta}?'


def _conversion_text(line_key: str, quantity_text: str, target_unit: str) -> str:
    forms = UNIT_FORMS[target_unit]
    if line_key == 'moro':
        return f'Сколько {forms["gen"]} в {quantity_text}?'
    if line_key == 'peterson':
        return f'Сколько всего {forms["gen"]} в {quantity_text}?'
    if line_key == 'dorofeev':
        return f'Сколько {forms["gen"]} составляют {quantity_text}?'
    return f'Вырази {quantity_text} в {forms["prep"]}.'


def _truth_text(line_key: str, statement: str) -> str:
    if line_key in {'dorofeev', 'rudnitskaya'}:
        return f'Правда ли, что {statement}?'
    return f'Верно ли, что {statement}?'


def _shape_name_text(line_key: str, description: str) -> str:
    if line_key in {'peterson', 'dorofeev'}:
        return f'Назови фигуру, у которой {description}.'
    return f'Как называется фигура, у которой {description}?'


def _pattern_text(line_key: str, seq: list[int]) -> str:
    prefix = 'Продолжи закономерность' if line_key in {'peterson', 'istomina'} else 'Продолжи ряд'
    return f'{prefix}: {", ".join(str(x) for x in seq)}, ...'


def _table_entries_text(entries: list[tuple[str, int]]) -> str:
    return ', '.join(f'{name} — {value}' for name, value in entries)


def _table_total_text(line_key: str, entries: list[tuple[str, int]]) -> str:
    prefix = 'В таблице записано' if line_key in {'rudnitskaya', 'istomina'} else 'В таблице'
    return f'{prefix}: {_table_entries_text(entries)}. Сколько всего?'


def _table_diff_text(line_key: str, entries: list[tuple[str, int]], first: str, second: str) -> str:
    prefix = 'В таблице записано' if line_key in {'rudnitskaya', 'istomina'} else 'В таблице'
    return f'{prefix}: {_table_entries_text(entries)}. На сколько у {first} больше, чем у {second}?'


def _arith_text(line_key: str, expr: str) -> str:
    if line_key == 'moro':
        return expr
    if line_key == 'peterson':
        return f'Вычисли {expr}'
    if line_key == 'dorofeev':
        return f'Найди значение выражения {expr}'
    if line_key == 'rudnitskaya':
        return f'Реши пример: {expr}'
    return f'Вычисли {expr}'


def _equation_text(_: str, equation: str) -> str:
    return f'Реши уравнение {equation}'


def _build_numbers_cases(line_key: str, grade: int) -> list[dict[str, Any]]:
    idx = LINE_ORDER.index(line_key)
    cases: list[dict[str, Any]] = []
    if grade == 1:
        entries = [
            (_compare_text(line_key, 12 + idx, 15 + idx), _relation(12 + idx, 15 + idx)),
            (_compare_text(line_key, 19 + idx, 11 + idx), _relation(19 + idx, 11 + idx)),
            (_next_text(line_key, 20 + idx), str(21 + idx)),
            (_prev_text(line_key, 31 + idx), str(30 + idx)),
            (_bigger_text(line_key, 7 + idx, 4), str(11 + idx)),
            (_smaller_text(line_key, 15 + idx, 5), str(10 + idx)),
            (_conversion_text(line_key, f'1 дм {3 + idx} см', 'см'), f'{13 + idx} см'),
            (_conversion_text(line_key, f'2 дм {1 + idx} см', 'см'), f'{21 + idx} см'),
            (_conversion_text(line_key, f'3 дм {2 + idx} см', 'см'), f'{32 + idx} см'),
            (f'Сколько десятков и единиц в числе {40 + idx}?', f'{4} десятков и {idx} единиц'),
        ]
    elif grade == 2:
        number = 230 + 11 * idx
        entries = [
            (_compare_text(line_key, 34 + idx, 43 + idx), _relation(34 + idx, 43 + idx)),
            (_compare_text(line_key, 78 + idx, 65 + idx), _relation(78 + idx, 65 + idx)),
            (lambda number: (f'Сколько десятков и единиц в числе {number}?', f'{number // 10} десятков и {number % 10} единиц'))(56 + idx),
            (f'Сколько сотен, десятков и единиц в числе {number}?', f'{number // 100} сотен, {(number // 10) % 10} десятков и {number % 10} единиц'),
            (f'Запиши число, в котором {3 + idx} сотен {4 + idx} десятков {5 + idx} единиц.', str((3 + idx) * 100 + (4 + idx) * 10 + (5 + idx))),
            (f'Сколько сотен в числе {500 + 10 * idx + 7}?', str((500 + 10 * idx + 7) // 100)),
            (_conversion_text(line_key, f'2 м {3 + idx} см', 'см'), f'{203 + idx} см'),
            (_conversion_text(line_key, f'1 кг {200 + 10 * idx} г', 'г'), f'{1200 + 10 * idx} г'),
            (_conversion_text(line_key, f'1 ч {10 + 5 * idx} мин', 'мин'), f'{70 + 5 * idx} мин'),
            (_conversion_text(line_key, f'2 м {idx + 2} дм', 'дм'), f'{22 + idx} дм'),
        ]
    elif grade == 3:
        number = 3000 + 210 + 11 * idx
        entries = [
            (_compare_text(line_key, 345 + idx, 354 + idx), _relation(345 + idx, 354 + idx)),
            (_compare_text(line_key, 780 + idx, 708 + idx), _relation(780 + idx, 708 + idx)),
            (f'Сколько сотен в числе {640 + idx}?', str((640 + idx) // 100)),
            (f'Сколько десятков в числе {86 + idx}?', str((86 + idx) // 10)),
            (f'Сколько тысяч, сотен, десятков и единиц в числе {number}?', f'{number // 1000} тысяч, {(number // 100) % 10} сотен, {(number // 10) % 10} десятков и {number % 10} единиц'),
            (f'Запиши число, в котором {4 + idx} тысяч {2 + idx} сотен {3 + idx} десятков {1 + idx} единиц.', str((4 + idx) * 1000 + (2 + idx) * 100 + (3 + idx) * 10 + (1 + idx))),
            (_conversion_text(line_key, f'3 м {5 + idx} см', 'см'), f'{305 + idx} см'),
            (_conversion_text(line_key, f'2 кг {300 + 10 * idx} г', 'г'), f'{2300 + 10 * idx} г'),
            (_conversion_text(line_key, f'2 ч {15 + 5 * idx} мин', 'мин'), f'{135 + 5 * idx} мин'),
            (_conversion_text(line_key, f'4 см {6 + idx} мм', 'мм'), f'{46 + idx} мм'),
        ]
    else:
        number = 4000 + 320 + 11 * idx
        entries = [
            (_compare_text(line_key, 3456 + idx, 3546 + idx), _relation(3456 + idx, 3546 + idx)),
            (_compare_text(line_key, 7801 + idx, 7081 + idx), _relation(7801 + idx, 7081 + idx)),
            (f'Сколько сотен в числе {572 + 100 * idx}?', str((572 + 100 * idx) // 100)),
            (f'Сколько десятков в числе {96 + idx}?', str((96 + idx) // 10)),
            (f'Сколько тысяч, сотен, десятков и единиц в числе {number}?', f'{number // 1000} тысяч, {(number // 100) % 10} сотен, {(number // 10) % 10} десятков и {number % 10} единиц'),
            (f'Запиши число, в котором {5 + idx} тысяч {1 + idx} сотен {4 + idx} десятков {2 + idx} единиц.', str((5 + idx) * 1000 + (1 + idx) * 100 + (4 + idx) * 10 + (2 + idx))),
            (f'Запиши число, в котором {6 + idx} тысяч {0} сотен {3 + idx} десятков {4 + idx} единиц.', str((6 + idx) * 1000 + (3 + idx) * 10 + (4 + idx))),
            (_conversion_text(line_key, f'4 м {7 + idx} см', 'см'), f'{407 + idx} см'),
            (_conversion_text(line_key, f'3 кг {450 + 10 * idx} г', 'г'), f'{3450 + 10 * idx} г'),
            (_conversion_text(line_key, f'3 ч {20 + 5 * idx} мин', 'мин'), f'{200 + 5 * idx} мин'),
        ]
    for pos, (text, answer) in enumerate(entries, 1):
        cases.append(_case(f'{line_key}_g{grade}_numbers_{pos:02d}', line_key, grade, 'numbers_and_quantities', text, str(answer)))
    return cases


def _build_arithmetic_cases(line_key: str, grade: int) -> list[dict[str, Any]]:
    idx = LINE_ORDER.index(line_key)
    cases: list[dict[str, Any]] = []
    if grade == 1:
        expressions = [
            (f'{2 + idx}+{3 + idx}', 5 + 2 * idx),
            (f'{9 + idx}-{4}', 5 + idx),
            (f'{5 + idx}+{6}', 11 + idx),
            (f'{12 + idx}-{5}', 7 + idx),
            (f'{3 + idx}+{8}', 11 + idx),
            (f'{14 + idx}-{6}', 8 + idx),
        ]
        equations = [
            (f'x + {4 + idx} = {10 + idx}', 6),
            (f'x + {7 + idx} = {15 + idx}', 8),
            (f'{12 + idx} - x = {5 + idx}', 7),
            (f'x - {3 + idx} = {8 + idx}', (8 + idx) + (3 + idx)),
        ]
    elif grade == 2:
        expressions = [
            (f'{34 + idx}+{27 + idx}', 61 + 2 * idx),
            (f'{58 + idx}-{19}', 39 + idx),
            (f'{6 + idx}*{4}', (6 + idx) * 4),
            (f'{24 + 3 * idx}/{3}', (24 + 3 * idx) // 3),
            (f'{46 + idx}+{35}', 81 + idx),
            (f'{90 + idx}-{26}', 64 + idx),
        ]
        equations = [
            (f'x + {18 + idx} = {43 + idx}', (43 + idx) - (18 + idx)),
            (f'x - {12 + idx} = {25 + idx}', (25 + idx) + (12 + idx)),
            (f'{70 + idx} - x = {24 + idx}', (70 + idx) - (24 + idx)),
            (f'x + {9 + idx} = {30 + idx}', (30 + idx) - (9 + idx)),
        ]
    elif grade == 3:
        expressions = [
            (f'{345 + idx}+{478 + idx}', 823 + 2 * idx),
            (f'{900 + idx}-{345}', 555 + idx),
            (f'({34 + idx}+{16})*2', (34 + idx + 16) * 2),
            (f'120/({5 + idx}+{5 - idx if idx < 5 else 1})', int(120 / ((5 + idx) + (5 - idx if idx < 5 else 1)))),
            (f'{567 + idx}+{289}', 856 + idx),
            (f'{804 + idx}-{156}', 648 + idx),
        ]
        equations = [
            (f'x + {47 + idx} = {120 + idx}', (120 + idx) - (47 + idx)),
            (f'x - {27 + idx} = {15 + idx}', (15 + idx) + (27 + idx)),
            (f'{90 + idx} - x = {35 + idx}', (90 + idx) - (35 + idx)),
            (f'x + {36 + idx} = {90 + idx}', (90 + idx) - (36 + idx)),
        ]
    else:
        expressions = [
            (f'{2345 + idx}+{4789}', 7134 + idx),
            (f'{9000 + idx}-{3456}', 5544 + idx),
            (f'({120 + 10 * idx}+{80})/2', (120 + 10 * idx + 80) // 2),
            (f'({35 + idx}+{15})*3', (35 + idx + 15) * 3),
            (f'{5678 + idx}+{2891}', 8569 + idx),
            (f'{8040 + idx}-{1567}', 6473 + idx),
        ]
        equations = [
            (f'x + {470 + idx} = {1200 + idx}', (1200 + idx) - (470 + idx)),
            (f'x - {270 + idx} = {150 + idx}', (150 + idx) + (270 + idx)),
            (f'{900 + idx} - x = {350 + idx}', (900 + idx) - (350 + idx)),
            (f'x + {360 + idx} = {900 + idx}', (900 + idx) - (360 + idx)),
        ]
    for pos, (expr, answer) in enumerate(expressions, 1):
        cases.append(_case(f'{line_key}_g{grade}_arith_expr_{pos:02d}', line_key, grade, 'arithmetic', _arith_text(line_key, expr), str(answer)))
    for pos, (eq, answer) in enumerate(equations, 1):
        cases.append(_case(f'{line_key}_g{grade}_arith_eq_{pos:02d}', line_key, grade, 'arithmetic', _equation_text(line_key, eq), str(answer)))
    return cases


def _build_word_problem_cases(line_key: str, grade: int) -> list[dict[str, Any]]:
    idx = LINE_ORDER.index(line_key)
    cases: list[dict[str, Any]] = []
    if grade == 1:
        tasks = [
            (f'У Ани {3 + idx} яблока, а у Оли {5 + idx} яблок. Сколько всего яблок?', str(8 + 2 * idx)),
            (f'У Пети {4 + idx} машинки, а у Вани {6 + idx} машинок. Сколько всего машинок?', str(10 + 2 * idx)),
            (f'На столе {7 + idx} тетрадей и {2 + idx} книги. Сколько всего предметов?', str(9 + 2 * idx)),
            (f'В корзине {5 + idx} груши и {4 + idx} яблока. Сколько всего фруктов?', str(9 + 2 * idx)),
            (f'У Пети было {9 + idx} карандашей. Он отдал {4} карандаша. Сколько осталось?', str(5 + idx)),
            (f'У Маши было {8 + idx} яблок. Она съела {3} яблока. Сколько осталось?', str(5 + idx)),
            (f'На тарелке было {10 + idx} конфет. {6} конфет съели. Сколько осталось?', str(4 + idx)),
            (f'У Кати {7 + idx} яблок, а у Оли {5 + idx} яблок. На сколько у Кати больше?', '2'),
            (f'У Пети {9 + idx} марок, а у Вани {4 + idx} марки. На сколько у Пети больше?', '5'),
            (f'У Саши {12 + idx} орехов, а у Димы {8 + idx} орехов. На сколько у Саши больше?', '4'),
        ]
    elif grade == 2:
        tasks = [
            (f'В {4 + idx} коробках по 6 карандашей. Сколько всего карандашей?', str((4 + idx) * 6)),
            (f'На {3 + idx} полках по 5 книг. Сколько всего книг?', str((3 + idx) * 5)),
            (f'В {5 + idx} пакетах по 4 яблока. Сколько всего яблок?', str((5 + idx) * 4)),
            (f'На {2 + idx} тарелках по 7 пирожков. Сколько всего пирожков?', str((2 + idx) * 7)),
            (f'У Пети стало {15 + idx} карандашей после того, как он дал другу 4 карандаша. Сколько было у Пети сначала?', str(19 + idx)),
            (f'У Маши стало {12 + idx} открыток после того, как она дала другу 3 открытки. Сколько было у Маши сначала?', str(15 + idx)),
            (f'У Коли стало {18 + idx} марок после того, как он дал другу 5 марок. Сколько было у Коли сначала?', str(23 + idx)),
            (f'У Маши {6 + idx} карандашей, у Лены на 4 карандаша больше. Сколько карандашей у Лены?', str(10 + idx)),
            (f'У Кати {8 + idx} яблок, это на 3 яблока больше, чем у Оли. Сколько яблок у Оли?', str(5 + idx)),
            (f'У Димы {10 + idx} наклеек, это на 2 наклейки больше, чем у Саши. Сколько наклеек у Саши?', str(8 + idx)),
        ]
    elif grade == 3:
        tasks = [
            (f'3 тетради стоят {24 + 3 * idx} рубля. Сколько стоят 5 тетрадей?', str(((24 + 3 * idx) // 3) * 5)),
            (f'4 ручки стоят {28 + 4 * idx} рублей. Сколько стоят 6 ручек?', str(((28 + 4 * idx) // 4) * 6)),
            (f'5 карандашей стоят {30 + 5 * idx} рублей. Сколько стоят 2 карандаша?', str(((30 + 5 * idx) // 5) * 2)),
            (f'2 альбома стоят {18 + 2 * idx} рублей. Сколько стоят 7 альбомов?', str(((18 + 2 * idx) // 2) * 7)),
            (f'Скорость {60 + 5 * idx} км/ч, время 3 ч. Какое расстояние?', str((60 + 5 * idx) * 3)),
            (f'Скорость {70 + 5 * idx} км/ч, время 4 ч. Какое расстояние?', str((70 + 5 * idx) * 4)),
            (f'Скорость {80 + 5 * idx} км/ч, время 2 ч. Какое расстояние?', str((80 + 5 * idx) * 2)),
            (f'Расстояние {270 + 30 * idx} км, скорость {90 + 10 * idx} км/ч. Сколько часов ехали?', str((270 + 30 * idx) // (90 + 10 * idx))),
            (f'Расстояние {320 + 40 * idx} км, скорость {80 + 10 * idx} км/ч. Сколько часов были в пути?', str((320 + 40 * idx) // (80 + 10 * idx))),
            (f'Расстояние {180 + 30 * idx} км, скорость {60 + 10 * idx} км/ч. Сколько часов ехали?', str((180 + 30 * idx) // (60 + 10 * idx))),
        ]
    else:
        tasks = [
            (f'После двух изменений число стало {18 + idx}. Сначала его увеличили на 7, потом уменьшили на 4. Какое число было сначала?', str(15 + idx)),
            (f'После двух изменений число стало {24 + idx}. Сначала его увеличили на 9, потом уменьшили на 6. Какое число было сначала?', str(21 + idx)),
            (f'После двух изменений число стало {30 + idx}. Сначала его увеличили на 8, потом уменьшили на 5. Какое число было сначала?', str(27 + idx)),
            (f'После двух изменений число стало {41 + idx}. Сначала его увеличили на 12, потом уменьшили на 7. Какое число было сначала?', str(36 + idx)),
            (f'5 тетрадей стоят {40 + 5 * idx} рублей. Сколько стоят 8 тетрадей?', str(((40 + 5 * idx) // 5) * 8)),
            (f'6 ручек стоят {54 + 6 * idx} рублей. Сколько стоят 9 ручек?', str(((54 + 6 * idx) // 6) * 9)),
            (f'4 альбома стоят {28 + 4 * idx} рублей. Сколько стоят 7 альбомов?', str(((28 + 4 * idx) // 4) * 7)),
            (f'Скорость {80 + 5 * idx} км/ч, время 4 ч. Какое расстояние?', str((80 + 5 * idx) * 4)),
            (f'Расстояние {360 + 40 * idx} км, скорость {90 + 10 * idx} км/ч. Сколько часов ехали?', str((360 + 40 * idx) // (90 + 10 * idx))),
            (f'Расстояние {420 + 60 * idx} км, скорость {70 + 10 * idx} км/ч. Сколько часов были в пути?', str((420 + 60 * idx) // (70 + 10 * idx))),
        ]
    for pos, (text, answer) in enumerate(tasks, 1):
        cases.append(_case(f'{line_key}_g{grade}_word_{pos:02d}', line_key, grade, 'word_problems', text, str(answer)))
    return cases


def _build_geometry_cases(line_key: str, grade: int) -> list[dict[str, Any]]:
    idx = LINE_ORDER.index(line_key)
    cases: list[dict[str, Any]] = []
    if grade == 1:
        tasks = [
            ('Сколько углов у квадрата?', '4'),
            ('Сколько углов у треугольника?', '3'),
            ('Сколько сторон у прямоугольника?', '4'),
            ('Сколько сторон у круга?', '0'),
            (_shape_name_text(line_key, '3 стороны и 3 угла'), 'треугольник'),
            (_shape_name_text(line_key, '4 равные стороны и 4 прямых угла'), 'квадрат'),
            (_shape_name_text(line_key, '4 стороны и 4 угла'), 'прямоугольник'),
            (_shape_name_text(line_key, 'нет сторон и нет углов'), 'круг'),
            ('Сколько углов у прямоугольника?', '4'),
            ('Сколько сторон у треугольника?', '3'),
        ]
    elif grade == 2:
        tasks = [
            (f'Прямоугольник со сторонами {4 + idx} см и 3 см. Найди периметр.', str(2 * ((4 + idx) + 3))),
            (f'Прямоугольник со сторонами 6 см и {2 + idx} см. Найди периметр.', str(2 * (6 + 2 + idx))),
            (f'Прямоугольник со сторонами {5 + idx} см и 4 см. Найди периметр.', str(2 * ((5 + idx) + 4))),
            (f'Прямоугольник со сторонами 7 см и {3 + idx} см. Найди периметр.', str(2 * (7 + 3 + idx))),
            (f'Прямоугольник со сторонами 8 см и {1 + idx} см. Найди периметр.', str(2 * (8 + 1 + idx))),
            (_shape_name_text(line_key, '4 равные стороны и 4 прямых угла'), 'квадрат'),
            (_shape_name_text(line_key, '3 стороны и 3 угла'), 'треугольник'),
            ('Сколько сторон у квадрата?', '4'),
            ('Сколько углов у круга?', '0'),
            ('Сколько сторон у прямоугольника?', '4'),
        ]
    elif grade == 3:
        tasks = [
            (f'Прямоугольник со сторонами {6 + idx} см и 4 см. Найди площадь.', str((6 + idx) * 4)),
            (f'Прямоугольник со сторонами 5 см и {3 + idx} см. Найди площадь.', str(5 * (3 + idx))),
            (f'Прямоугольник со сторонами {8 + idx} см и 2 см. Найди площадь.', str((8 + idx) * 2)),
            (f'Прямоугольник со сторонами 7 см и {5 + idx} см. Найди площадь.', str(7 * (5 + idx))),
            (f'Прямоугольник со сторонами {9 + idx} см и 3 см. Найди площадь.', str((9 + idx) * 3)),
            (_shape_name_text(line_key, '4 стороны и 4 угла'), 'прямоугольник'),
            (_shape_name_text(line_key, 'нет сторон и нет углов'), 'круг'),
            ('Сколько углов у треугольника?', '3'),
            ('Сколько сторон у квадрата?', '4'),
            ('Сколько сторон у круга?', '0'),
        ]
    else:
        tasks = [
            (f'Прямоугольник со сторонами {12 + idx} см и 5 см. Найди площадь.', str((12 + idx) * 5)),
            (f'Прямоугольник со сторонами 14 см и {6 + idx} см. Найди площадь.', str(14 * (6 + idx))),
            (f'Прямоугольник со сторонами {20 + idx} см и 3 см. Найди площадь.', str((20 + idx) * 3)),
            (f'Прямоугольник со сторонами 15 см и {8 + idx} см. Найди площадь.', str(15 * (8 + idx))),
            (f'Прямоугольник со сторонами {18 + idx} см и 7 см. Найди площадь.', str((18 + idx) * 7)),
            (f'Прямоугольник со сторонами {10 + idx} см и 4 см. Найди периметр.', str(2 * ((10 + idx) + 4))),
            (_shape_name_text(line_key, '4 равные стороны и 4 прямых угла'), 'квадрат'),
            (_shape_name_text(line_key, '3 стороны и 3 угла'), 'треугольник'),
            ('Сколько углов у прямоугольника?', '4'),
            ('Сколько сторон у круга?', '0'),
        ]
    for pos, (text, answer) in enumerate(tasks, 1):
        cases.append(_case(f'{line_key}_g{grade}_geometry_{pos:02d}', line_key, grade, 'geometry', text, str(answer)))
    return cases


def _build_information_cases(line_key: str, grade: int) -> list[dict[str, Any]]:
    idx = LINE_ORDER.index(line_key)
    cases: list[dict[str, Any]] = []
    if grade == 1:
        patterns = [
            ([1 + idx, 2 + idx, 3 + idx], f'{4 + idx}, {5 + idx}, {6 + idx}'),
            ([2 + idx, 4 + idx, 6 + idx], f'{8 + idx}, {10 + idx}, {12 + idx}'),
            ([5 + idx, 7 + idx, 9 + idx], f'{11 + idx}, {13 + idx}, {15 + idx}'),
            ([3 + idx, 6 + 2 * idx, 9 + 3 * idx], f'{12 + 4 * idx}, {15 + 5 * idx}, {18 + 6 * idx}'),
        ]
        truths = [
            (_truth_text(line_key, f'{10 + idx} + 5 = {15 + idx}'), 'верно'),
            (_truth_text(line_key, f'{12 + idx} - 4 = {9 + idx}'), 'неверно'),
            (_truth_text(line_key, f'{8 + idx} > {5 + idx}'), 'верно'),
        ]
        tables = [
            (_table_total_text(line_key, [('Миша', 6 + idx), ('Оля', 5 + idx), ('Таня', 4 + idx)]), str(15 + 3 * idx)),
            (_table_diff_text(line_key, [('Миша', 6 + idx), ('Оля', 9 + idx), ('Таня', 8 + idx)], 'Оли', 'Миши'), '3'),
            (_table_diff_text(line_key, [('Коля', 7 + idx), ('Лена', 10 + idx), ('Ира', 9 + idx)], 'Лены', 'Коли'), '3'),
        ]
    elif grade == 2:
        patterns = [
            ([10 + idx, 20 + idx, 30 + idx], f'{40 + idx}, {50 + idx}, {60 + idx}'),
            ([25 + idx, 20 + idx, 15 + idx], f'{10 + idx}, {5 + idx}, {idx}'),
            ([4 + idx, 8 + 2 * idx, 12 + 3 * idx], f'{16 + 4 * idx}, {20 + 5 * idx}, {24 + 6 * idx}'),
            ([20 + idx, 40 + 2 * idx, 80 + 4 * idx], f'{160 + 8 * idx}, {320 + 16 * idx}, {640 + 32 * idx}'),
        ]
        truths = [
            (_truth_text(line_key, f'{34 + idx} + 16 = {50 + idx}'), 'верно'),
            (_truth_text(line_key, f'{40 + idx} - 7 = {34 + idx}'), 'неверно'),
            (_truth_text(line_key, f'{8 + idx} * 3 = {24 + 3 * idx}'), 'верно'),
        ]
        tables = [
            (_table_total_text(line_key, [('Коля', 12 + idx), ('Лена', 7 + idx), ('Ира', 11 + idx)]), str(30 + 3 * idx)),
            (_table_diff_text(line_key, [('Миша', 14 + idx), ('Оля', 18 + idx), ('Таня', 16 + idx)], 'Оли', 'Миши'), '4'),
            (_table_diff_text(line_key, [('Петя', 9 + idx), ('Даша', 13 + idx), ('Лена', 10 + idx)], 'Даши', 'Пети'), '4'),
        ]
    elif grade == 3:
        patterns = [
            ([100 + idx, 200 + idx, 300 + idx], f'{400 + idx}, {500 + idx}, {600 + idx}'),
            ([450 + idx, 400 + idx, 350 + idx], f'{300 + idx}, {250 + idx}, {200 + idx}'),
            ([12 + idx, 22 + idx, 32 + idx], f'{42 + idx}, {52 + idx}, {62 + idx}'),
            ([3 + idx, (3 + idx) * 2, (3 + idx) * 4], f'{(3 + idx) * 8}, {(3 + idx) * 16}, {(3 + idx) * 32}'),
        ]
        truths = [
            (_truth_text(line_key, f'{120 + idx} + 35 = {155 + idx}'), 'верно'),
            (_truth_text(line_key, f'{84 + idx} : 7 = {12 + idx}'), 'верно'),
            (_truth_text(line_key, f'{63 + idx} : 9 = {8 + idx}'), 'неверно'),
        ]
        tables = [
            (_table_total_text(line_key, [('Класс А', 24 + idx), ('Класс Б', 21 + idx), ('Класс В', 23 + idx)]), str(68 + 3 * idx)),
            (_table_diff_text(line_key, [('Миша', 26 + idx), ('Оля', 31 + idx), ('Таня', 29 + idx)], 'Оли', 'Миши'), '5'),
            (_table_diff_text(line_key, [('Коля', 18 + idx), ('Лена', 24 + idx), ('Ира', 20 + idx)], 'Лены', 'Коли'), '6'),
        ]
    else:
        patterns = [
            ([1000 + idx, 2000 + idx, 3000 + idx], f'{4000 + idx}, {5000 + idx}, {6000 + idx}'),
            ([950 + idx, 900 + idx, 850 + idx], f'{800 + idx}, {750 + idx}, {700 + idx}'),
            ([14 + idx, 28 + 2 * idx, 42 + 3 * idx], f'{56 + 4 * idx}, {70 + 5 * idx}, {84 + 6 * idx}'),
            ([5 + idx, (5 + idx) * 3, (5 + idx) * 9], f'{(5 + idx) * 27}, {(5 + idx) * 81}, {(5 + idx) * 243}'),
        ]
        truths = [
            (_truth_text(line_key, f'{1200 + idx} + 350 = {1550 + idx}'), 'верно'),
            (_truth_text(line_key, f'{640 + idx} : 8 = {80 + idx}'), 'верно'),
            (_truth_text(line_key, f'{900 + idx} - 450 = {400 + idx}'), 'неверно'),
        ]
        tables = [
            (_table_total_text(line_key, [('Группа 1', 34 + idx), ('Группа 2', 29 + idx), ('Группа 3', 31 + idx)]), str(94 + 3 * idx)),
            (_table_diff_text(line_key, [('Миша', 42 + idx), ('Оля', 48 + idx), ('Таня', 45 + idx)], 'Оли', 'Миши'), '6'),
            (_table_diff_text(line_key, [('Петя', 37 + idx), ('Даша', 44 + idx), ('Лена', 40 + idx)], 'Даши', 'Пети'), '7'),
        ]
    pos = 1
    for seq, answer in patterns:
        cases.append(_case(f'{line_key}_g{grade}_info_{pos:02d}', line_key, grade, 'information', _pattern_text(line_key, seq), answer))
        pos += 1
    for text, answer in truths:
        cases.append(_case(f'{line_key}_g{grade}_info_{pos:02d}', line_key, grade, 'information', text, answer))
        pos += 1
    for text, answer in tables:
        cases.append(_case(f'{line_key}_g{grade}_info_{pos:02d}', line_key, grade, 'information', text, answer))
        pos += 1
    return cases


def build_other_primary_math_textbook_cases() -> tuple[dict[str, Any], ...]:
    cases: list[dict[str, Any]] = []
    for line_key in LINE_ORDER:
        for grade in (1, 2, 3, 4):
            cases.extend(_build_numbers_cases(line_key, grade))
            cases.extend(_build_arithmetic_cases(line_key, grade))
            cases.extend(_build_word_problem_cases(line_key, grade))
            cases.extend(_build_geometry_cases(line_key, grade))
            cases.extend(_build_information_cases(line_key, grade))

    expected_total = len(LINE_ORDER) * 4 * len(SECTION_LABELS) * 10
    if len(cases) != expected_total:
        raise ValueError(f'expected {expected_total} cases, got {len(cases)}')

    counter: Counter[tuple[str, int, str]] = Counter((case['textbook_line_key'], case['grade'], case['section_key']) for case in cases)
    for line_key in LINE_ORDER:
        for grade in (1, 2, 3, 4):
            for section_key in SECTION_LABELS:
                if counter[(line_key, grade, section_key)] != 10:
                    raise ValueError(
                        f'expected 10 cases for {(line_key, grade, section_key)}, got {counter[(line_key, grade, section_key)]}'
                    )

    return tuple(cases)


OTHER_PRIMARY_MATH_TEXTBOOK_CASES = build_other_primary_math_textbook_cases()

__all__ = [
    'BAD_SOURCE_PREFIXES',
    'OTHER_PRIMARY_MATH_TEXTBOOK_CASES',
    'REQUIRED_RESULT_MARKERS',
    'SECTION_LABELS',
    'TEXTBOOK_LINES',
    'build_other_primary_math_textbook_cases',
]
