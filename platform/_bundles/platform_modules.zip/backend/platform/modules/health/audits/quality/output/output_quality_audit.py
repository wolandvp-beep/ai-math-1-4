from __future__ import annotations

import re
from typing import Any

from backend.async_compat import run_async_compat
from backend.health_case_matrix import build_health_case_matrix
from backend.health_summary import summarize_case_results


BAD_PATTERNS = {
    'dangling_number_parenthesis': re.compile(r'(?m)^\d+\)$'),
    'bare_self_equality_line': re.compile(r'(?m)^\d+\s*=\s*\d+\.?$'),
    'negative_borrow_phrase': re.compile(r'-\d+\s+меньше\s+\d+'),
    'nonsensical_hour_overflow': re.compile(r'195\s*ч'),
}


async def run_output_quality_audit(*, case_matrix: dict[str, Any] | None = None) -> dict[str, Any]:
    matrix = case_matrix or await build_health_case_matrix(include_probe=False)
    results: list[dict[str, Any]] = []
    passed = 0
    for row in matrix['rows']:
        result_text = str(row.get('result_text', ''))
        exception = str(row.get('exception') or '')
        if exception:
            ok = False
            issue = exception
            matches = {name: False for name in BAD_PATTERNS}
        else:
            matches = {name: bool(pattern.search(result_text)) for name, pattern in BAD_PATTERNS.items()}
            ok = not any(matches.values())
            issue = '' if ok else ', '.join(name for name, flag in matches.items() if flag)
        if ok:
            passed += 1
        results.append({
            'name': row['name'],
            'category': row['category'],
            'text': row['text'],
            'ok': ok,
            'issue': issue,
            'matches': matches,
            'result_preview': result_text[:180],
        })
    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


def run_output_quality_audit_sync(*, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        from backend.health_case_matrix import build_health_case_matrix_sync
        matrix = build_health_case_matrix_sync(include_probe=False, fresh=True)
        return run_async_compat(lambda: run_output_quality_audit(case_matrix=matrix))
    return run_async_compat(run_output_quality_audit)


__all__ = ['BAD_PATTERNS', 'run_output_quality_audit', 'run_output_quality_audit_sync']
