from __future__ import annotations

from functools import lru_cache
from typing import Any

from backend.health_case_matrix import build_health_case_matrix_sync
from backend.snapshot_output_cases import SNAPSHOT_OUTPUT_CASES
from backend.legacy_runtime_pipeline import RUNTIME_PIPELINE
from backend.runtime_fingerprint import build_runtime_fingerprint
from backend.runtime_symbol_inventory import build_runtime_symbol_inventory
from backend.compat_paths import PLATFORM_ROOT


def _snapshot_signature(matrix: dict[str, Any]) -> dict[str, tuple[str, str]]:
    row_map = {row['name']: row for row in matrix['rows']}
    result: dict[str, tuple[str, str]] = {}
    for case in SNAPSHOT_OUTPUT_CASES:
        row = row_map.get(case['name'])
        if row is None:
            result[case['name']] = ('', '')
        else:
            result[case['name']] = (str(row.get('source', '')), str(row.get('result_text', '')))
    return result


def _runtime_consistency_signature() -> dict[str, Any]:
    return {
        'runtime_pipeline': [name for name, _ in RUNTIME_PIPELINE],
        'runtime_fingerprint': build_runtime_fingerprint(PLATFORM_ROOT),
        'runtime_symbol_inventory': build_runtime_symbol_inventory(),
    }


@lru_cache(maxsize=1)
def run_cache_consistency_audit() -> dict[str, Any]:
    from backend.runtime_cache_control import clear_runtime_caches

    clear_runtime_caches()
    fresh_runtime = _runtime_consistency_signature()
    fresh_matrix = build_health_case_matrix_sync(include_probe=False, fresh=True)
    cached_runtime = _runtime_consistency_signature()
    cached_matrix = build_health_case_matrix_sync(include_probe=False, fresh=False)

    checks = {
        'runtime_pipeline': fresh_runtime.get('runtime_pipeline') == cached_runtime.get('runtime_pipeline'),
        'runtime_fingerprint': fresh_runtime.get('runtime_fingerprint') == cached_runtime.get('runtime_fingerprint'),
        'runtime_symbol_inventory': fresh_runtime.get('runtime_symbol_inventory') == cached_runtime.get('runtime_symbol_inventory'),
        'snapshot_signature': _snapshot_signature(fresh_matrix) == _snapshot_signature(cached_matrix),
    }
    results = [
        {
            'name': name,
            'ok': ok,
            'issue': '' if ok else 'fresh and cached values differ',
        }
        for name, ok in checks.items()
    ]
    passed = sum(1 for item in results if item['ok'])
    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'results': results,
    }


__all__ = ['run_cache_consistency_audit']
