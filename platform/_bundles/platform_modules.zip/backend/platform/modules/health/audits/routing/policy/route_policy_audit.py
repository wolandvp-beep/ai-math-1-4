from __future__ import annotations

from typing import Any

from backend.health_case_matrix import build_health_case_matrix_sync
from backend.health_summary import summarize_case_results


def run_route_policy_audit(*, fresh: bool = False) -> dict[str, Any]:
    matrix = build_health_case_matrix_sync(include_probe=False, fresh=fresh)
    results: list[dict[str, Any]] = []
    passed = 0
    for row in matrix['rows']:
        case = row['case']
        source = str(row.get('source', ''))
        issues: list[str] = []
        expected_prefix = case.get('expected_source_prefix')
        if expected_prefix and not source.startswith(str(expected_prefix)):
            issues.append(f"source={source!r} does not start with {expected_prefix!r}")
        for forbidden in case.get('forbid_source_prefixes', ()):
            if source.startswith(str(forbidden)):
                issues.append(f"source={source!r} starts with forbidden prefix {forbidden!r}")
        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': row['name'],
            'category': row['category'],
            'ok': ok,
            'issues': issues,
            'source': source,
            'source_family': row['source_family'],
        })
    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


__all__ = ['run_route_policy_audit']
