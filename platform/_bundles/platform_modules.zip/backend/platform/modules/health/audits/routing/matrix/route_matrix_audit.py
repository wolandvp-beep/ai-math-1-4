from __future__ import annotations

from typing import Any

from backend.async_compat import run_async_compat
from backend.health_case_matrix import build_health_case_matrix


async def build_route_matrix(*, case_matrix: dict[str, Any] | None = None) -> dict[str, Any]:
    matrix = case_matrix or await build_health_case_matrix(include_probe=False)
    rows = [
        {
            'name': row['name'],
            'category': row['category'],
            'source': row['source'],
            'source_family': row['source_family'],
        }
        for row in matrix['rows']
    ]
    unique_sources = sorted({row['source'] for row in rows})
    unique_source_families = sorted({row['source_family'] for row in rows})
    return {
        'row_count': len(rows),
        'unique_source_count': len(unique_sources),
        'unique_sources': unique_sources,
        'unique_source_family_count': len(unique_source_families),
        'unique_source_families': unique_source_families,
        'rows': rows,
    }


def build_route_matrix_sync(*, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        from backend.health_case_matrix import build_health_case_matrix_sync
        matrix = build_health_case_matrix_sync(include_probe=False, fresh=True)
        return run_async_compat(lambda: build_route_matrix(case_matrix=matrix))
    return run_async_compat(build_route_matrix)


__all__ = ['build_route_matrix', 'build_route_matrix_sync']
