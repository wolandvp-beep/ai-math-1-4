from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from backend.health_markdown_report import render_health_markdown
from backend.platform.modules.health.reporting.registry.sections.support.builders import (
    HEALTH_BUNDLE_SECTION_NAMES,
    HEALTH_SECTION_BUILDERS,
    build_health_bundle_builders,
)
from backend.platform.modules.health.reporting.registry.sections.support.invocation import (
    invoke_health_builder,
)


BUNDLE_BUILDERS = build_health_bundle_builders()


def export_health_bundle(output_dir: str | Path, *, fresh: bool = False) -> dict[str, Any]:
    target_dir = Path(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    written_files: list[str] = []
    payloads: dict[str, Any] = {}
    for name in HEALTH_BUNDLE_SECTION_NAMES:
        payload = invoke_health_builder(HEALTH_SECTION_BUILDERS[name], fresh=fresh)
        payloads[name] = payload
        file_path = target_dir / f'{name}.json'
        file_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        written_files.append(file_path.name)
    markdown_path = target_dir / 'health_summary.md'
    markdown_path.write_text(render_health_markdown(payloads['healthcheck']), encoding='utf-8')
    written_files.append(markdown_path.name)
    manifest = {
        'output_dir': str(target_dir),
        'written_files': written_files,
        'file_count': len(written_files),
        'bundle_builder_count': len(BUNDLE_BUILDERS),
    }
    (target_dir / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return manifest


__all__ = ['BUNDLE_BUILDERS', 'export_health_bundle']
