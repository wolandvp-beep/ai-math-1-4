from __future__ import annotations

from typing import Any, Callable

from backend.backend_healthcheck import build_backend_healthcheck
from backend.benchmark_suite import build_benchmark_suite
from backend.cache_consistency_audit import run_cache_consistency_audit
from backend.determinism_suite import run_determinism_suite
from backend.golden_output_suite import run_golden_output_suite
from backend.health_case_matrix import build_health_case_matrix_sync
from backend.output_quality_audit import run_output_quality_audit_sync
from backend.regression_suite import run_core_regression_suite_sync
from backend.route_matrix_audit import build_route_matrix_sync
from backend.route_policy_audit import run_route_policy_audit
from backend.runtime_contract_suite import run_runtime_contract_suite
from backend.runtime_module_regressions import run_runtime_module_regressions
from backend.runtime_report import build_runtime_report
from backend.snapshot_output_suite import run_snapshot_output_suite
from backend.platform.modules.health.suites.curriculum.primary_math_textbook_suite import run_primary_math_textbook_suite_sync
from backend.platform.modules.health.suites.curriculum.other_primary_math_textbook_suite import run_other_primary_math_textbook_suite_sync
from backend.platform.modules.health.suites.fractions.fraction_expression_suite import run_fraction_expression_suite_sync
from backend.platform.modules.health.suites.access.access_policy_suite import run_access_policy_suite
from backend.platform.modules.health.open_source_primary_web_suite import run_open_source_primary_web_suite_sync
from backend.platform.modules.health.single_task_guard_suite import run_single_task_guard_suite_sync


HEALTH_SECTION_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    'healthcheck': build_backend_healthcheck,
    'summary': build_backend_healthcheck,
    'runtime-report': build_runtime_report,
    'regression': run_core_regression_suite_sync,
    'runtime-module': run_runtime_module_regressions,
    'quality': run_output_quality_audit_sync,
    'route-matrix': build_route_matrix_sync,
    'route-policy': run_route_policy_audit,
    'golden': run_golden_output_suite,
    'snapshot': run_snapshot_output_suite,
    'benchmark': build_benchmark_suite,
    'determinism': run_determinism_suite,
    'cache-consistency': run_cache_consistency_audit,
    'runtime-contract': run_runtime_contract_suite,
    'textbook-primary': run_primary_math_textbook_suite_sync,
    'textbook-other-1000': run_other_primary_math_textbook_suite_sync,
    'textbook-open-web-500': run_open_source_primary_web_suite_sync,
    'fraction-expression': run_fraction_expression_suite_sync,
    'single-task-guard': run_single_task_guard_suite_sync,
    'access-policy': run_access_policy_suite,
    'case-matrix': build_health_case_matrix_sync,
}

HEALTH_BUNDLE_SECTION_NAMES: tuple[str, ...] = (
    'healthcheck',
    'runtime-report',
    'regression',
    'quality',
    'route-policy',
    'golden',
    'snapshot',
    'benchmark',
    'route-matrix',
    'case-matrix',
    'determinism',
    'cache-consistency',
    'runtime-contract',
    'access-policy',
)


def build_health_bundle_builders() -> dict[str, Callable[..., dict[str, Any]]]:
    return {name: HEALTH_SECTION_BUILDERS[name] for name in HEALTH_BUNDLE_SECTION_NAMES}


__all__ = [
    'HEALTH_BUNDLE_SECTION_NAMES',
    'HEALTH_SECTION_BUILDERS',
    'build_health_bundle_builders',
]
