from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from backend.compat_paths import BACKEND_COMPAT_DIRS, PLATFORM_ROOT, HEALTH_REPORTING_REGISTRY_PACKAGE_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, [*HEALTH_REPORTING_REGISTRY_PACKAGE_DIRS, *BACKEND_COMPAT_DIRS])

__all__ = ['BACKEND_COMPAT_DIRS', 'PLATFORM_ROOT', 'HEALTH_REPORTING_REGISTRY_PACKAGE_DIRS']
