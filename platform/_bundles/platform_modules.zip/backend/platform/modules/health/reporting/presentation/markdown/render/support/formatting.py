from __future__ import annotations


def bool_icon(value: bool) -> str:
    return '✅' if value else '❌'


__all__ = ['bool_icon']
