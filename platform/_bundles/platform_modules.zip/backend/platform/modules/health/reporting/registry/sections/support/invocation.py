from __future__ import annotations

from typing import Any, Callable


def invoke_health_builder(builder: Callable[..., dict[str, Any]], *, fresh: bool) -> dict[str, Any]:
    try:
        return builder(fresh=fresh)
    except TypeError:
        return builder()


__all__ = ['invoke_health_builder']
