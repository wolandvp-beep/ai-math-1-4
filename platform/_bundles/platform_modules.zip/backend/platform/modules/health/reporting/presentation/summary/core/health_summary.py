from __future__ import annotations

from collections import defaultdict
from typing import Any, Iterable


def summarize_case_results(results: Iterable[dict[str, Any]], *, category_key: str = 'category') -> dict[str, dict[str, int]]:
    grouped: dict[str, dict[str, int]] = defaultdict(lambda: {'passed': 0, 'total': 0})
    for item in results:
        category = str(item.get(category_key) or 'uncategorized')
        grouped[category]['total'] += 1
        if item.get('ok'):
            grouped[category]['passed'] += 1
    return dict(sorted(grouped.items()))


def summarize_boolean_sections(sections: dict[str, Any]) -> dict[str, bool]:
    return {name: bool(payload.get('all_passed')) for name, payload in sections.items()}


__all__ = ['summarize_boolean_sections', 'summarize_case_results']
