from __future__ import annotations

from typing import Any


def render_runtime_summary_lines(payload: dict[str, Any]) -> list[str]:
    runtime = payload.get('runtime_report', {}) if isinstance(payload, dict) else {}
    benchmark = payload.get('benchmark_suite', {}) if isinstance(payload, dict) else {}
    return [
        f"- `legacy_core_lines`: {runtime.get('legacy_core_lines', 'n/a')}",
        f"- `explicit_exec_site_count`: {runtime.get('explicit_exec_site_count', 'n/a')}",
        f"- `runtime_asset_catalog_entry_count`: {runtime.get('runtime_asset_catalog_entry_count', 'n/a')}",
        f"- `runtime_asset_catalog_deep_seeded_module_count`: {runtime.get('runtime_asset_catalog_deep_seeded_module_count', 'n/a')}",
        f"- `runtime_shard_total_count`: {runtime.get('runtime_shard_total_count', 'n/a')}",
        f"- `runtime_module_shard_total_count`: {runtime.get('runtime_module_shard_total_count', 'n/a')}",
        f"- `build_backend_healthcheck` seconds: {payload.get('timings_seconds', {}).get('build_backend_healthcheck', 'n/a')}",
        f"- benchmark total seconds: {benchmark.get('timings_seconds', {}).get('total', 'n/a')}",
    ]


def render_case_matrix_lines(payload: dict[str, Any]) -> list[str]:
    case_matrix = payload.get('case_matrix_summary', {}) if isinstance(payload, dict) else {}
    if not case_matrix:
        return []
    return [
        '## Case matrix',
        '',
        f"- passed: {case_matrix.get('passed')} / {case_matrix.get('total')}",
        f"- source families: {case_matrix.get('source_family_counts')}",
        f"- timings: {case_matrix.get('timings')}",
        '',
    ]


__all__ = ['render_case_matrix_lines', 'render_runtime_summary_lines']
