from __future__ import annotations

from typing import Any

from backend.platform.modules.health.reporting.presentation.markdown.render.support.formatting import bool_icon
from backend.platform.modules.health.reporting.presentation.markdown.render.support.sections import (
    render_case_matrix_lines,
    render_runtime_summary_lines,
)
from backend.platform.modules.health.reporting.presentation.markdown.render.support.tables import render_section_table


def render_health_markdown(payload: dict[str, Any]) -> str:
    section_status = payload.get('section_status', {}) if isinstance(payload, dict) else {}
    lines = [
        '# Backend health summary',
        '',
        f"Общий статус: {bool_icon(bool(payload.get('all_passed')))}",
        '',
        *render_runtime_summary_lines(payload),
        '',
        '## Разделы',
        '',
        render_section_table(section_status),
        '',
        *render_case_matrix_lines(payload),
    ]
    return '\n'.join(lines).strip() + '\n'


__all__ = ['render_health_markdown']
