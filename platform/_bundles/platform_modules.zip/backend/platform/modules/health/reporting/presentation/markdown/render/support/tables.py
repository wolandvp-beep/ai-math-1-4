from __future__ import annotations

from .formatting import bool_icon


def render_section_table(section_status: dict[str, bool]) -> str:
    lines = ['| Раздел | Статус |', '|---|---|']
    for name, ok in section_status.items():
        lines.append(f'| `{name}` | {bool_icon(bool(ok))} |')
    return '\n'.join(lines)


__all__ = ['render_section_table']
