from __future__ import annotations

from backend.package_bootstrap import bootstrap_package

from ...compat_paths import HEALTH_COMPAT_DIRS, extend_module_path

__path__ = bootstrap_package(__path__, __name__, HEALTH_COMPAT_DIRS)

__all__ = ['HEALTH_COMPAT_DIRS']
