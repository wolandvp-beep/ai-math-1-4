from __future__ import annotations

import re
from typing import Any, Iterable

from backend.async_compat import run_async_compat
from backend.health_case_matrix import build_health_case_matrix, build_health_case_matrix_sync
from backend.health_summary import summarize_case_results
from backend.regression_cases import CORE_REGRESSION_CASES


def _contains(haystack: Any, needle: str) -> bool:
    return needle in str(haystack or '')


def _iter_needles(value: Any) -> Iterable[str]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(str(item) for item in value)
    return (str(value),)


async def run_core_regression_suite(*, case_matrix: dict[str, Any] | None = None) -> dict[str, Any]:
    matrix = case_matrix or await build_health_case_matrix(include_probe=True)
    case_rows = {row['name']: row for row in matrix['rows']}
    results: list[dict[str, Any]] = []
    passed = 0
    for case in CORE_REGRESSION_CASES:
        row = case_rows.get(case['name'], {})
        issues: list[str] = []
        payload = row.get('payload', {})
        probe = row.get('probe', {})
        exception_issue = str(row.get('exception') or row.get('probe_exception') or '')
        result_text = str(row.get('result_text', ''))
        expected_source_contains = case.get('expected_source_contains')
        expected_result_contains = case.get('expected_result_contains')
        expected_probe_key = case.get('expected_probe_key')
        expected_probe_value_contains = case.get('expected_probe_value_contains')
        unexpected_result_contains = case.get('unexpected_result_contains')
        unexpected_result_regex = case.get('unexpected_result_regex')

        if exception_issue:
            issues.append(f'exception during dispatch/probe: {exception_issue}')
        if not exception_issue and expected_source_contains and not _contains(payload.get('source'), expected_source_contains):
            issues.append(f"source={payload.get('source')!r} does not contain {expected_source_contains!r}")
        if not exception_issue:
            for needle in _iter_needles(expected_result_contains):
                if needle and needle not in result_text:
                    issues.append(f"result does not contain {needle!r}")
            for needle in _iter_needles(unexpected_result_contains):
                if needle and needle in result_text:
                    issues.append(f"result unexpectedly contains {needle!r}")
            for pattern in _iter_needles(unexpected_result_regex):
                if pattern and re.search(pattern, result_text):
                    issues.append(f"result unexpectedly matches regex {pattern!r}")
        if not exception_issue and expected_probe_key and not _contains(probe.get(expected_probe_key), expected_probe_value_contains or ''):
            issues.append(f"probe[{expected_probe_key!r}]={probe.get(expected_probe_key)!r} does not contain {expected_probe_value_contains!r}")

        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'category': case.get('category', 'uncategorized'),
            'text': case['text'],
            'ok': ok,
            'issues': issues,
            'source': payload.get('source'),
            'result_preview': result_text[:240],
            'exception': exception_issue,
        })

    return {
        'passed': passed,
        'total': len(CORE_REGRESSION_CASES),
        'all_passed': passed == len(CORE_REGRESSION_CASES),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


def run_core_regression_suite_sync(*, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        matrix = build_health_case_matrix_sync(include_probe=True, fresh=True)
        return run_async_compat(lambda: run_core_regression_suite(case_matrix=matrix))
    return run_async_compat(run_core_regression_suite)


if __name__ == '__main__':
    import json

    print(json.dumps(run_core_regression_suite_sync(), ensure_ascii=False, indent=2))


__all__ = ['run_core_regression_suite', 'run_core_regression_suite_sync']
