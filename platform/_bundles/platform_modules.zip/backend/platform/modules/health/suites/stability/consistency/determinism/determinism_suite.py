from __future__ import annotations

import hashlib
from functools import lru_cache
from typing import Any

from backend.health_case_matrix import build_health_case_matrix_sync
from backend.health_summary import summarize_case_results
from backend.snapshot_output_cases import SNAPSHOT_OUTPUT_CASES


def _digest_row(row: dict[str, Any]) -> tuple[str, str]:
    text = str(row.get('result_text', ''))
    return str(row.get('source', '')), hashlib.sha256(text.encode('utf-8')).hexdigest()


@lru_cache(maxsize=1)
def run_determinism_suite() -> dict[str, Any]:
    from backend.runtime_cache_control import clear_runtime_caches

    clear_runtime_caches()
    first = build_health_case_matrix_sync(include_probe=False, fresh=True)
    clear_runtime_caches()
    second = build_health_case_matrix_sync(include_probe=False, fresh=True)
    first_map = {row['name']: row for row in first['rows']}
    second_map = {row['name']: row for row in second['rows']}
    results: list[dict[str, Any]] = []
    passed = 0
    for case in SNAPSHOT_OUTPUT_CASES:
        first_row = first_map.get(case['name'])
        second_row = second_map.get(case['name'])
        issues: list[str] = []
        if first_row is None or second_row is None:
            issues.append('missing case in one of the matrix runs')
            first_value = ('', '')
            second_value = ('', '')
        else:
            first_value = _digest_row(first_row)
            second_value = _digest_row(second_row)
            if first_value != second_value:
                issues.append(f'mismatch between runs: {first_value!r} != {second_value!r}')
        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'category': 'determinism',
            'ok': ok,
            'issues': issues,
            'first_source': first_value[0],
            'second_source': second_value[0],
            'first_sha256': first_value[1],
            'second_sha256': second_value[1],
        })
    return {
        'passed': passed,
        'total': len(SNAPSHOT_OUTPUT_CASES),
        'all_passed': passed == len(SNAPSHOT_OUTPUT_CASES),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


__all__ = ['run_determinism_suite']
