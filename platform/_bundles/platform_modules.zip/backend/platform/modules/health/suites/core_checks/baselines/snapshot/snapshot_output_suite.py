from __future__ import annotations

import hashlib
from functools import lru_cache
from typing import Any

from backend.health_case_matrix import build_health_case_matrix_sync
from backend.health_summary import summarize_case_results
from backend.snapshot_output_cases import SNAPSHOT_OUTPUT_CASES


@lru_cache(maxsize=1)
def _run_snapshot_output_suite_cached() -> dict[str, Any]:
    matrix = build_health_case_matrix_sync(include_probe=False, fresh=False)
    row_map = {row['name']: row for row in matrix['rows']}
    results: list[dict[str, Any]] = []
    passed = 0
    for case in SNAPSHOT_OUTPUT_CASES:
        row = row_map.get(case['name'])
        issues: list[str] = []
        source = ''
        digest = ''
        preview = ''
        if row is None:
            issues.append('missing case in matrix')
        else:
            source = str(row.get('source', ''))
            result_text = str(row.get('result_text', ''))
            preview = result_text[:240]
            digest = hashlib.sha256(result_text.encode('utf-8')).hexdigest()
            if case.get('expected_source') and source != case['expected_source']:
                issues.append(f"source={source!r} != {case['expected_source']!r}")
            if case.get('expected_sha256') and digest != case['expected_sha256']:
                issues.append(f"sha256={digest!r} != {case['expected_sha256']!r}")
        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'category': 'snapshot',
            'ok': ok,
            'issues': issues,
            'source': source,
            'sha256': digest,
            'result_preview': preview,
        })
    return {
        'passed': passed,
        'total': len(SNAPSHOT_OUTPUT_CASES),
        'all_passed': passed == len(SNAPSHOT_OUTPUT_CASES),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


def run_snapshot_output_suite(*, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        _run_snapshot_output_suite_cached.cache_clear()
        build_health_case_matrix_sync(include_probe=False, fresh=True)
    return _run_snapshot_output_suite_cached()


__all__ = ['run_snapshot_output_suite']
