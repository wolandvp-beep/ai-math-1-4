from __future__ import annotations

from functools import lru_cache
from typing import Any

from backend.golden_output_cases import GOLDEN_OUTPUT_CASES
from backend.health_case_matrix import build_health_case_matrix_sync
from backend.health_summary import summarize_case_results


def _row_map(fresh: bool = False) -> dict[str, dict[str, Any]]:
    matrix = build_health_case_matrix_sync(include_probe=False, fresh=fresh)
    return {row['name']: row for row in matrix['rows']}


@lru_cache(maxsize=1)
def _run_golden_output_suite_cached() -> dict[str, Any]:
    row_map = _row_map(fresh=False)
    results: list[dict[str, Any]] = []
    passed = 0
    for case in GOLDEN_OUTPUT_CASES:
        row = row_map.get(case['name'])
        issues: list[str] = []
        if row is None:
            issues.append('missing case in matrix')
            source = ''
            result_text = ''
        else:
            source = str(row.get('source', ''))
            result_text = str(row.get('result_text', ''))
            if case.get('expected_source') and source != case['expected_source']:
                issues.append(f"source={source!r} != {case['expected_source']!r}")
            expected_exact = str(case.get('expected_exact') or '')
            if expected_exact and result_text != expected_exact:
                issues.append('exact result mismatch')
        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'category': 'golden',
            'ok': ok,
            'issues': issues,
            'source': source,
            'result_preview': result_text[:240],
        })
    return {
        'passed': passed,
        'total': len(GOLDEN_OUTPUT_CASES),
        'all_passed': passed == len(GOLDEN_OUTPUT_CASES),
        'category_summary': summarize_case_results(results),
        'results': results,
    }


def run_golden_output_suite(*, fresh: bool = False) -> dict[str, Any]:
    if fresh:
        _run_golden_output_suite_cached.cache_clear()
        _row_map(fresh=True)
    return _run_golden_output_suite_cached()


__all__ = ['run_golden_output_suite']
