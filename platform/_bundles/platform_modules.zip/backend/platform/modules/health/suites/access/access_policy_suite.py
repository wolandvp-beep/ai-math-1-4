from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Any

from backend.platform.modules.core.public.services.access.service import AccessService, LimitExceededError
from backend.platform.modules.core.public.services.access.store import JsonAccessStateStore
from backend.platform.modules.health.cases.access.access_policy_cases import ACCESS_POLICY_CASES


class _TempAccessHarness:
    def __init__(self) -> None:
        self._tmpdir = tempfile.TemporaryDirectory(prefix='reshayka_access_suite_')
        self.path = Path(self._tmpdir.name) / 'state.json'
        self.service = AccessService(JsonAccessStateStore(self.path))

    def close(self) -> None:
        self._tmpdir.cleanup()


def _force_next_day(service: AccessService, *, install_id: str) -> None:
    def _mutate(state: dict[str, Any]) -> None:
        record = state['users'][f'guest:{install_id}']
        record['usage']['dailyUsedDateMsk'] = '2000-01-01'
        record['usage']['dailyUsedCount'] = 0
    service.store.mutate(_mutate)


def _run_case(kind: str) -> tuple[bool, list[str], dict[str, Any]]:
    harness = _TempAccessHarness()
    service = harness.service
    install_id = 'suite-install-1'
    issues: list[str] = []
    details: dict[str, Any] = {}
    try:
        if kind == 'free_starter':
            status = {}
            for _ in range(5):
                status = service.record_final_submission(token=None, install_id=install_id)
            if status['usage']['starterUsed'] != 5:
                issues.append('starterUsed should be 5 after five submissions')
            if status['usage']['canSubmit'] is not False:
                issues.append('canSubmit should be false after the fifth same-day free submission')
            details = status
        elif kind == 'free_starter_block':
            for _ in range(5):
                service.record_final_submission(token=None, install_id=install_id)
            try:
                service.record_final_submission(token=None, install_id=install_id)
                issues.append('sixth free submission should be blocked')
            except LimitExceededError:
                pass
            details = service.get_access_status(token=None, install_id=install_id)
        elif kind == 'free_next_day':
            for _ in range(5):
                service.record_final_submission(token=None, install_id=install_id)
            _force_next_day(service, install_id=install_id)
            status = service.record_final_submission(token=None, install_id=install_id)
            if status['usage']['dailyUsed'] != 1:
                issues.append('dailyUsed should reset to 1 on the next day')
            details = status
        elif kind == 'free_no_accumulate':
            for _ in range(5):
                service.record_final_submission(token=None, install_id=install_id)
            for _ in range(3):
                _force_next_day(service, install_id=install_id)
                service.get_access_status(token=None, install_id=install_id)
            _force_next_day(service, install_id=install_id)
            status = service.record_final_submission(token=None, install_id=install_id)
            if status['usage']['dailyRemaining'] != 0:
                issues.append('free daily quota should remain single-use and non-accumulating')
            try:
                service.record_final_submission(token=None, install_id=install_id)
                issues.append('second free submission on the same day should be blocked after starter is exhausted')
            except LimitExceededError:
                pass
            details = status
        elif kind == 'subscription_twenty':
            service.activate_subscription_for_tests(install_id=install_id, plan='yearly')
            status = {}
            for _ in range(20):
                status = service.record_final_submission(token=None, install_id=install_id)
            if status['usage']['dailyUsed'] != 20:
                issues.append('subscription dailyUsed should reach 20')
            details = status
        elif kind == 'subscription_block':
            service.activate_subscription_for_tests(install_id=install_id, plan='monthly')
            for _ in range(20):
                service.record_final_submission(token=None, install_id=install_id)
            try:
                service.record_final_submission(token=None, install_id=install_id)
                issues.append('21st subscription submission should be blocked')
            except LimitExceededError:
                pass
            details = service.get_access_status(token=None, install_id=install_id)
        elif kind == 'subscription_next_day':
            service.activate_subscription_for_tests(install_id=install_id, plan='monthly')
            for _ in range(20):
                service.record_final_submission(token=None, install_id=install_id)
            _force_next_day(service, install_id=install_id)
            status = service.record_final_submission(token=None, install_id=install_id)
            if status['usage']['dailyUsed'] != 1:
                issues.append('subscription counter should reset next day')
            details = status
        elif kind == 'payload_shape':
            register_payload = service.register(name='Анна', email='anna@example.com', password='test1234', install_id=install_id)
            token = register_payload['token']
            profile = service.get_profile(token=token)
            subscription = service.get_subscription(token=token, install_id=install_id)
            if subscription['product']['plans']['monthly']['priceRub'] != 299:
                issues.append('monthly price should be 299')
            if subscription['product']['plans']['yearly']['priceRub'] != 1990:
                issues.append('yearly price should be 1990')
            if profile.get('email') != 'anna@example.com':
                issues.append('profile email mismatch')
            details = {'profile': profile, 'subscription': subscription}
        elif kind == 'register_merge':
            for _ in range(5):
                service.record_final_submission(token=None, install_id=install_id)
            register_payload = service.register(name='Марина', email='marina@example.com', password='pass1234', install_id=install_id)
            token = register_payload['token']
            subscription = service.get_subscription(token=token, install_id=install_id)
            if subscription['usage']['starterUsed'] != 5:
                issues.append('register should inherit guest starter usage')
            if subscription['usage']['canSubmit'] is not False:
                issues.append('register should preserve same-day free block after guest starter is exhausted')
            details = subscription
        elif kind == 'login_merge':
            service.register(name='Илья', email='ilya@example.com', password='pass1234', install_id='other-install')
            for _ in range(5):
                service.record_final_submission(token=None, install_id=install_id)
            login_payload = service.login(email='ilya@example.com', password='pass1234', install_id=install_id)
            token = login_payload['token']
            subscription = service.get_subscription(token=token, install_id=install_id)
            if subscription['usage']['starterUsed'] != 5:
                issues.append('login should inherit guest starter usage from current install')
            if subscription['usage']['canSubmit'] is not False:
                issues.append('login should preserve same-day free block after guest starter is exhausted')
            details = subscription
        else:
            issues.append(f'unknown case kind {kind!r}')
    finally:
        harness.close()
    return not issues, issues, details


def run_access_policy_suite(*, fresh: bool = False) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    passed = 0
    for case in ACCESS_POLICY_CASES:
        ok, issues, details = _run_case(case['kind'])
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'ok': ok,
            'issues': issues,
            'details': details,
        })
    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'results': results,
    }


if __name__ == '__main__':
    import json

    print(json.dumps(run_access_policy_suite(), ensure_ascii=False, indent=2))


__all__ = ['run_access_policy_suite']
