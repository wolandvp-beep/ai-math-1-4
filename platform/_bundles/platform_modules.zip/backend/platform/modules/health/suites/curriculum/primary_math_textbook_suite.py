from __future__ import annotations

import time
from collections import Counter, defaultdict
from typing import Any, Iterable

from backend.async_compat import run_async_compat
from backend.explanation_dispatcher import dispatch_explanation
from backend.health_case_matrix import classify_source_family, normalize_result_text
from backend.health_summary import summarize_case_results
from backend.platform.modules.health.cases.curriculum.primary_math_textbook_cases import (
    PRIMARY_MATH_TEXTBOOK_CASES,
)

RECOMMENDED_RESULT_MARKERS: tuple[str, ...] = ('Совет:',)
FAILURE_PHRASES: tuple[str, ...] = (
    'не удалось',
    'пока нет надёжного решения',
    'нет надёжного решения',
)


def _iter_needles(value: Any) -> Iterable[str]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(str(item) for item in value)
    return (str(value),)


async def run_primary_math_textbook_suite() -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    source_family_counts: Counter[str] = Counter()
    advice_present = 0
    section_summary: defaultdict[tuple[int, str], dict[str, Any]] = defaultdict(lambda: {
        'passed': 0,
        'total': 0,
        'advice_present': 0,
    })

    for case in PRIMARY_MATH_TEXTBOOK_CASES:
        started = time.perf_counter()
        issues: list[str] = []
        payload: dict[str, Any] = {}
        exception_issue = ''
        try:
            payload = await dispatch_explanation(case['text'])
        except Exception as exc:  # pragma: no cover - defensive runtime harness
            exception_issue = f'{type(exc).__name__}: {exc}'
        elapsed_seconds = time.perf_counter() - started
        source = str(payload.get('source', '')) if not exception_issue else f'EXCEPTION:{exception_issue.split(":", 1)[0]}'
        result_text = normalize_result_text(payload.get('result', ''))
        source_family = classify_source_family(source)
        source_family_counts[source_family] += 1

        if exception_issue:
            issues.append(f'exception during dispatch: {exception_issue}')
        for prefix in _iter_needles(case.get('forbid_source_prefixes')):
            if prefix and source.startswith(prefix):
                issues.append(f'source starts with forbidden prefix {prefix!r}: {source!r}')
        for marker in _iter_needles(case.get('required_result_markers')):
            if marker and marker not in result_text:
                issues.append(f'missing required marker {marker!r}')
        expected_answer = str(case.get('expected_answer_contains') or '').strip()
        if expected_answer and expected_answer not in result_text:
            issues.append(f'expected answer fragment {expected_answer!r} missing in result')
        lowered_result = result_text.lower()
        for phrase in FAILURE_PHRASES:
            if phrase in lowered_result:
                issues.append(f'result contains failure phrase {phrase!r}')
        has_advice = all(marker in result_text for marker in RECOMMENDED_RESULT_MARKERS)
        if has_advice:
            advice_present += 1

        ok = not issues
        section_key = (int(case['grade']), str(case['section_key']))
        summary = section_summary[section_key]
        summary['total'] += 1
        summary['advice_present'] += 1 if has_advice else 0
        if ok:
            summary['passed'] += 1

        results.append({
            'name': case['name'],
            'category': case['category'],
            'grade': case['grade'],
            'section_key': case['section_key'],
            'section': case['section'],
            'text': case['text'],
            'expected_answer_contains': expected_answer,
            'ok': ok,
            'issues': issues,
            'source': source,
            'source_family': source_family,
            'result_preview': result_text[:240],
            'elapsed_seconds': round(elapsed_seconds, 6),
        })

    passed = sum(1 for item in results if item['ok'])
    formatted_section_summary = {
        f'{grade}:{section_key}': {
            **values,
            'all_passed': values['passed'] == values['total'],
            'advice_coverage_ratio': round(values['advice_present'] / values['total'], 4) if values['total'] else 0.0,
        }
        for (grade, section_key), values in sorted(section_summary.items())
    }

    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'category_summary': summarize_case_results(results),
        'grade_section_summary': formatted_section_summary,
        'source_family_counts': dict(sorted(source_family_counts.items())),
        'advice_coverage': {
            'present': advice_present,
            'missing': len(results) - advice_present,
            'ratio': round(advice_present / len(results), 4) if results else 0.0,
        },
        'results': results,
    }


def run_primary_math_textbook_suite_sync(*, fresh: bool = False) -> dict[str, Any]:
    return run_async_compat(run_primary_math_textbook_suite)


if __name__ == '__main__':
    import json

    print(json.dumps(run_primary_math_textbook_suite_sync(), ensure_ascii=False, indent=2))


__all__ = [
    'run_primary_math_textbook_suite',
    'run_primary_math_textbook_suite_sync',
]
