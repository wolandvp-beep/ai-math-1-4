from __future__ import annotations

from typing import Any

from backend.benchmark_suite import build_benchmark_suite
from backend.cache_consistency_audit import run_cache_consistency_audit
from backend.determinism_suite import run_determinism_suite
from backend.golden_output_suite import run_golden_output_suite
from backend.output_quality_audit import run_output_quality_audit
from backend.regression_suite import run_core_regression_suite
from backend.route_matrix_audit import build_route_matrix
from backend.route_policy_audit import run_route_policy_audit
from backend.runtime_contract_suite import run_runtime_contract_suite
from backend.runtime_module_regressions import run_runtime_module_regressions
from backend.snapshot_output_suite import run_snapshot_output_suite
from backend.platform.modules.health.suites.access.access_policy_suite import run_access_policy_suite


async def build_healthcheck_section_payloads(
    *,
    case_matrix: dict[str, Any],
    runtime_report: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    regression_suite = await run_core_regression_suite(case_matrix=case_matrix)
    output_quality_audit = await run_output_quality_audit(case_matrix=case_matrix)
    route_matrix = await build_route_matrix(case_matrix=case_matrix)
    sections = {
        'regression_suite': regression_suite,
        'runtime_module_regressions': run_runtime_module_regressions(),
        'output_quality_audit': output_quality_audit,
        'route_policy_audit': run_route_policy_audit(fresh=False),
        'golden_output_suite': run_golden_output_suite(fresh=False),
        'snapshot_output_suite': run_snapshot_output_suite(fresh=False),
        'determinism_suite': run_determinism_suite(),
        'cache_consistency_audit': run_cache_consistency_audit(),
        'runtime_contract_suite': run_runtime_contract_suite(runtime_report=runtime_report),
        'access_policy_suite': run_access_policy_suite(),
    }
    extras = {
        'route_matrix': route_matrix,
        'benchmark_suite': build_benchmark_suite(fresh=False),
    }
    return sections, extras


__all__ = ['build_healthcheck_section_payloads']
