from __future__ import annotations

from typing import Any

from backend.health_case_matrix import build_health_case_matrix_sync


def build_benchmark_suite(*, fresh: bool = False) -> dict[str, Any]:
    matrix = build_health_case_matrix_sync(include_probe=False, fresh=fresh)
    rows = [
        {
            'name': row['name'],
            'category': row['category'],
            'source_family': row['source_family'],
            'elapsed_seconds': row['elapsed_seconds'],
        }
        for row in matrix['rows']
    ]
    elapsed_values = [float(row['elapsed_seconds']) for row in rows]
    return {
        'row_count': len(rows),
        'timings_seconds': {
            'total': round(sum(elapsed_values), 6),
            'average': round(sum(elapsed_values) / len(elapsed_values), 6) if elapsed_values else 0.0,
            'max': round(max(elapsed_values), 6) if elapsed_values else 0.0,
            'min': round(min(elapsed_values), 6) if elapsed_values else 0.0,
        },
        'rows': rows,
    }


__all__ = ['build_benchmark_suite']
