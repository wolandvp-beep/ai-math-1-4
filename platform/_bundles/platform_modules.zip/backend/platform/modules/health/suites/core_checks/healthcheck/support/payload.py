from __future__ import annotations

import time
from typing import Any

from backend.health_summary import summarize_boolean_sections


def build_healthcheck_payload(
    *,
    started: float,
    runtime_report: dict[str, Any],
    case_matrix: dict[str, Any],
    sections: dict[str, Any],
    extras: dict[str, Any],
) -> dict[str, Any]:
    section_status = summarize_boolean_sections(sections)
    return {
        'runtime_report': runtime_report,
        'case_matrix_summary': {
            'passed': case_matrix['passed'],
            'total': case_matrix['total'],
            'all_passed': case_matrix['all_passed'],
            'category_summary': case_matrix['category_summary'],
            'source_family_counts': case_matrix['source_family_counts'],
            'timings': case_matrix['timings'],
        },
        **sections,
        **extras,
        'section_status': section_status,
        'timings_seconds': {
            'build_backend_healthcheck': round(time.perf_counter() - started, 6),
        },
        'all_passed': all(section_status.values()),
    }


__all__ = ['build_healthcheck_payload']
