from __future__ import annotations

import time
from typing import Any

from backend.async_compat import run_async_compat
from backend.health_case_matrix import build_health_case_matrix
from backend.runtime_report import build_runtime_report
from backend.platform.modules.health.suites.core_checks.healthcheck.support.payload import (
    build_healthcheck_payload,
)
from backend.platform.modules.health.suites.core_checks.healthcheck.support.sections import (
    build_healthcheck_section_payloads,
)


async def build_backend_healthcheck_async(*, fresh: bool = False) -> dict[str, Any]:
    started = time.perf_counter()
    runtime_report = build_runtime_report()
    case_matrix = await build_health_case_matrix(include_probe=True)
    sections, extras = await build_healthcheck_section_payloads(
        case_matrix=case_matrix,
        runtime_report=runtime_report,
    )
    return build_healthcheck_payload(
        started=started,
        runtime_report=runtime_report,
        case_matrix=case_matrix,
        sections=sections,
        extras=extras,
    )


def build_backend_healthcheck(*, fresh: bool = False) -> dict[str, Any]:
    return run_async_compat(lambda: build_backend_healthcheck_async(fresh=fresh))


__all__ = ['build_backend_healthcheck', 'build_backend_healthcheck_async']
