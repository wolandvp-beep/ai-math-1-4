from __future__ import annotations

import time
from collections import Counter
from typing import Any, Iterable

from backend.async_compat import run_async_compat
from backend.explanation_dispatcher import dispatch_explanation
from backend.health_case_matrix import classify_source_family, normalize_result_text
from backend.health_summary import summarize_case_results
from backend.platform.modules.health.cases.fractions.fraction_expression_cases import (
    FRACTION_EXPRESSION_CASES,
)

FAILURE_PHRASES: tuple[str, ...] = (
    'не удалось',
    'пока нет надёжного решения',
    'нет надёжного решения',
)


def _iter_needles(value: Any) -> Iterable[str]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(str(item) for item in value)
    return (str(value),)


async def run_fraction_expression_suite() -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    source_family_counts: Counter[str] = Counter()
    passed = 0

    for case in FRACTION_EXPRESSION_CASES:
        started = time.perf_counter()
        payload: dict[str, Any] = {}
        issues: list[str] = []
        exception_issue = ''
        try:
            payload = await dispatch_explanation(case['text'])
        except Exception as exc:  # pragma: no cover - runtime harness
            exception_issue = f'{type(exc).__name__}: {exc}'
        elapsed_seconds = time.perf_counter() - started
        source = str(payload.get('source', '')) if not exception_issue else f'EXCEPTION:{exception_issue.split(":", 1)[0]}'
        result_text = normalize_result_text(payload.get('result', ''))
        source_family = classify_source_family(source)
        source_family_counts[source_family] += 1

        if exception_issue:
            issues.append(f'exception during dispatch: {exception_issue}')
        expected_source_prefix = str(case.get('expected_source_prefix') or '').strip()
        if expected_source_prefix and not source.startswith(expected_source_prefix):
            issues.append(f'source {source!r} does not start with expected prefix {expected_source_prefix!r}')
        expected_answer = str(case.get('expected_answer_contains') or '').strip()
        if expected_answer and expected_answer not in result_text:
            issues.append(f'expected answer fragment {expected_answer!r} missing in result')
        for marker in _iter_needles(case.get('required_result_markers')):
            if marker and marker not in result_text:
                issues.append(f'missing required marker {marker!r}')
        for snippet in _iter_needles(case.get('required_result_snippets')):
            if snippet and snippet not in result_text:
                issues.append(f'missing required snippet {snippet!r}')
        lowered = result_text.lower()
        for phrase in FAILURE_PHRASES:
            if phrase in lowered:
                issues.append(f'result contains failure phrase {phrase!r}')

        ok = not issues
        if ok:
            passed += 1
        results.append({
            'name': case['name'],
            'text': case['text'],
            'ok': ok,
            'issues': issues,
            'source': source,
            'source_family': source_family,
            'result_preview': result_text[:300],
            'elapsed_seconds': round(elapsed_seconds, 6),
        })

    return {
        'passed': passed,
        'total': len(results),
        'all_passed': passed == len(results),
        'category_summary': summarize_case_results(results),
        'source_family_counts': dict(sorted(source_family_counts.items())),
        'results': results,
    }


def run_fraction_expression_suite_sync(*, fresh: bool = False) -> dict[str, Any]:
    return run_async_compat(run_fraction_expression_suite)


if __name__ == '__main__':
    import json

    print(json.dumps(run_fraction_expression_suite_sync(), ensure_ascii=False, indent=2))


__all__ = ['run_fraction_expression_suite', 'run_fraction_expression_suite_sync']
